<?php
/**
 * Template Blog Archive
 */
get_header(); ?>

<main class="archive-blog">
    <div class="container">
        <h1 class="archive-title">Blog</h1>

        <?php if (have_posts()) : ?>
            <div class="blog-list">
                <?php while (have_posts()) : the_post(); ?>
                    <article class="blog-item">
                        <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                        <div class="excerpt"><?php the_excerpt(); ?></div>
                    </article>
                <?php endwhile; ?>
            </div>

            <div class="pagination">
                <?php the_posts_pagination([
                    'prev_text' => '←',
                    'next_text' => '→',
                ]); ?>
            </div>
        <?php else : ?>
            <p>Không có bài viết nào.</p>
        <?php endif; ?>
    </div>
</main>

<?php get_footer(); ?>
