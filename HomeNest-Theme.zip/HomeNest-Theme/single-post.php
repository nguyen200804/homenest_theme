<?php
/*
Template Name: Single Post
*/

// Prevent direct access to file
if (!defined('ABSPATH')) {
    exit;
}

// Register AJAX handlers
add_action('init', 'homenest_register_ajax_handlers');

function homenest_register_ajax_handlers() {
    add_action('wp_ajax_homenest_submit_reply', 'homenest_handle_reply_submission');
    add_action('wp_ajax_nopriv_homenest_submit_reply', 'homenest_handle_reply_submission');
}

function homenest_handle_reply_submission() {
    // Verify nonce
    if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'homenest_reply_nonce')) {
        wp_send_json_error('Lỗi bảo mật. Vui lòng tải lại trang và thử lại.');
        return;
    }

    // Get and validate required fields
    $post_id = isset($_POST['comment_post_ID']) ? (int) $_POST['comment_post_ID'] : 0;
    $parent_id = isset($_POST['comment_parent']) ? (int) $_POST['comment_parent'] : 0;
    $author = isset($_POST['author']) ? sanitize_text_field($_POST['author']) : '';
    $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
    $comment = isset($_POST['comment']) ? sanitize_textarea_field($_POST['comment']) : '';

    // Validate all required fields
    if (!$post_id || !$parent_id || !$author || !$email || !$comment) {
        wp_send_json_error('Vui lòng điền đầy đủ thông tin.');
        return;
    }

    // Validate email format
    if (!is_email($email)) {
        wp_send_json_error('Email không hợp lệ.');
        return;
    }

    // Prepare comment data
    $commentdata = array(
        'comment_post_ID' => $post_id,
        'comment_author' => $author,
        'comment_author_email' => $email,
        'comment_content' => $comment,
        'comment_parent' => $parent_id,
        'comment_type' => 'comment',
        'comment_approved' => 0
    );

    // Insert comment
    $comment_id = wp_insert_comment($commentdata);

    if ($comment_id) {
        wp_send_json_success('Bình luận đã được gửi thành công và đang chờ duyệt.');
    } else {
        wp_send_json_error('Không thể lưu bình luận. Vui lòng thử lại.');
    }
}

function human_time_diff_vn($from, $to = '') {
    if (empty($to)) {
        $to = time();
    }
    $diff = (int) abs($to - $from);
    
    if ($diff < 60) {
        return 'vừa xong';
    } elseif ($diff < 3600) {
        $mins = round($diff / 60);
        return $mins . ' phút trước';
    } elseif ($diff < 86400) {
        $hours = round($diff / 3600);
        return $hours . ' giờ trước';
    } elseif ($diff < 604800) {
        $days = round($diff / 86400);
        return $days . ' ngày trước';
    } elseif ($diff < 2592000) {
        $weeks = round($diff / 604800);
        return $weeks . ' tuần trước';
    } elseif ($diff < 31536000) {
        $months = round($diff / 2592000);
        return $months . ' tháng trước';
    } else {
        $years = round($diff / 31536000);
        return $years . ' năm trước';
    }
}

get_header(); 
?>


<!-- Single Post Content -->
<div class="homenest__single__post">
    <div class="single-post-content-wrapper">
        <div class="test1">
            <div class="background-single-bot">
                <img src="/wp-content/uploads/2025/05/Vector-1-1-2.webp" alt="Homenest" title="Homenest">
            </div>
            <?php
            if (have_posts()) :
                while (have_posts()) : the_post();
            ?>
            <h1 class="single-post-title"><?php the_title(); ?></h1>
            <a href="<?php echo esc_url(home_url('/blog')); ?>" class="back-to-blog-btn">
                <i class="fas fa-arrow-left"></i> Quay lại Blog
            </a>
            <div class="post-meta">
                <div class="author-info">
                    <div class="author-avatar">
                        <?php echo get_avatar(get_the_author_meta('ID'), 40); ?>
                    </div>
                    <div class="background-single-bot2">
                        <img src="/wp-content/uploads/2025/05/Vector-1-1-2.webp" alt="Homenest" title="Homenest">
                    </div>
                    <div class="background-single-bot">
                        <img src="/wp-content/uploads/2025/05/Vector-1-1-2.webp" alt="Homenest" title="Homenest">
                    </div>
                    <div class="author-meta">
                        <span class="by">Bởi</span>
                        <span class="author-name"><?php the_author(); ?></span>
                    </div>
                </div>
                <span class="post-date"><?php 
                    $date = get_the_date('F j, Y');
                    $date = str_replace(
                        array('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'),
                        array('Tháng 1', 'Tháng 2', 'Tháng 3', 'Tháng 4', 'Tháng 5', 'Tháng 6', 'Tháng 7', 'Tháng 8', 'Tháng 9', 'Tháng 10', 'Tháng 11', 'Tháng 12'),
                        $date
                    );
                    echo $date;
                ?></span>
                <div class="post-category">
                    <?php
                    $categories = get_the_category();
                    if (!empty($categories)) {
                        echo '<a href="' . esc_url(get_category_link($categories[0]->term_id)) . '" style="color: #fff; text-decoration: none; display: block;">' . esc_html($categories[0]->name) . '</a>';
                    }
                    ?>
                </div>
            </div>
            <div class="breadcrumb-container">
                <div class="breadcrumb">
                    <a href="<?php echo esc_url(home_url()); ?>">Trang chủ</a>
                    <span class="separator">/</span>
                    <?php
                    $categories = get_the_category();
                    if (!empty($categories)) {
                        $category = $categories[0];
                        echo '<a href="' . esc_url(get_category_link($category->term_id)) . '">' . esc_html($category->name) . '</a>';
                        echo '<span class="separator">/</span>';
                    }
                    ?>
                    <span class="current"><?php the_title(); ?></span>
                </div>
            </div>
            <div class="single-post-content">
                <?php 
                // Check and display featured image at the beginning of the post
                if (has_post_thumbnail()) {
                    echo '<div class="featured-image-container">';
                    the_post_thumbnail('full', array(
                        'class' => 'featured-image',
                        'loading' => 'lazy',
                        'alt' => get_the_title()
                    ));
                    echo '</div>';
                }
                
                // Display the rest of the content
                the_content(); 
                ?>
            </div>
			<?php echo do_shortcode('[lien-he-1]'); ?>
            <?php
            $prev_post = get_previous_post();
            $next_post = get_next_post();
            if ($prev_post || $next_post) : ?>
            <div class="post-navigation">
                <div>
                    <?php if ($prev_post) : ?>
                    <a class="nav-previous" href="<?php echo esc_url(get_permalink($prev_post->ID)); ?>">
    <svg width="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="icon line" transform="scale(-1 1)"><path style="fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-width:1.5" d="m14 5 7 7-7 7"/><path data-name="primary" style="fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-width:1.5" d="M21 12H3"/></svg> Bài Viết Trước </a>
                    <?php endif; ?>
                </div>
                <div>
                    <?php if ($next_post) : ?>
                    <a class="nav-next" href="<?php echo esc_url(get_permalink($next_post->ID)); ?>">
 Bài Viết Sau<svg width="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="icon line"><path style="fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-width:1.5" d="m14 5 7 7-7 7"/><path data-name="primary" style="fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-width:1.5" d="M21 12H3"/></svg>
                    </a>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif;
                endwhile;
            else :
                echo '<p>Không tìm thấy nội dung.</p>';
            endif;
            ?>
            <div class="banner">
                <p>
                    Chào mừng đến với dịch vụ HomeNest của chúng tôi 
                </p>
            </div>
        </div>
        <div class="test2">
            <div class="popup-form promo">
    <button class="popup-close">&times;</button>
    <p class="font">NHẬN ƯU ĐÃI NGAY</p>
    
    <form id="promoForm">
        <input type="text" placeholder="Tên của bạn" required>
        <input type="tel" placeholder="Số điện thoại" required>
        <select required>
            <option value="" disabled selected>SEO Tổng Thể</option>
            <option value="basic">SEO Cơ Bản</option>
            <option value="standard">SEO Tiêu Chuẩn</option>
            <option value="premium">SEO Premium</option>
        </select>
        <button type="submit" class="popup-button">Nhận ưu đãi</button>
    </form>
</div>

<div class="popup-form seo">
    <img src="/wp-content/uploads/2025/05/1-18.webp" alt="Homenest" title="Homenest">
</div>

<div class="mobile-contact-bar">
    <a href="tel:YOUR_PHONE" class="mobile-contact-button phone">
        <i class="fas fa-phone"></i>
        Gọi ngay
    </a>
    <a href="#promoForm" class="mobile-contact-button promo">
        <i class="fas fa-gift"></i>
        Nhận ưu đãi
    </a>
</div>

    </div>
</div>

    <!-- Comments Section -->
    <?php if (comments_open()) : ?>
    <div class="homenest__single__comments">
        <div class="background-single-bot">
            <img src="/wp-content/uploads/2025/05/Vector-1-1-2.webp" alt="Homenest" title="Homenest">
        </div>
        <?php if (get_comments_number() > 0) : ?>
        <h3 class="comments-title">Tất cả bình luận (<?php echo esc_html(get_comments_number()); ?>)</h3>

        <div class="comment-list">
            <?php
            $comments = get_comments([
                'post_id' => get_the_ID(),
                'status' => 'approve',
                'orderby' => 'comment_date_gmt',
                'order' => 'ASC'
            ]);

            $comment_structure = [];
            foreach ($comments as $comment) {
                if ($comment->comment_parent == 0) {
                    $comment_structure[$comment->comment_ID] = [
                        'comment' => $comment,
                        'replies' => []
                    ];
                } else {
                    $parent_id = $comment->comment_parent;
                    while (!isset($comment_structure[$parent_id]) && $parent_id != 0) {
                        $parent_comment = get_comment($parent_id);
                        if (!$parent_comment) break;
                        $parent_id = $parent_comment->comment_parent;
                    }
                    if (isset($comment_structure[$parent_id])) {
                        $comment_structure[$parent_id]['replies'][] = $comment;
                    } else {
                        $comment_structure[$comment->comment_ID] = [
                            'comment' => $comment,
                            'replies' => []
                        ];
                    }
                }
            }

            foreach ($comment_structure as $comment_id => $data) :
                $comment = $data['comment'];
                $comment_time = strtotime($comment->comment_date_gmt);
                $human_time = human_time_diff_vn($comment_time, current_time('timestamp')) . ' trước';
            ?>
            <div class="comment-item" data-comment-id="<?php echo esc_attr($comment->comment_ID); ?>">
                <div class="comment-avatar">
                    <img src="<?php echo esc_url(get_avatar_url($comment->comment_author_email, ['size' => 50])); ?>" alt="<?php echo esc_attr($comment->comment_author); ?>">
                </div>
                <div class="comment-content">
                    <div class="comment-author"><?php echo esc_html($comment->comment_author); ?></div>
                    <div class="comment-text"><?php echo esc_html($comment->comment_content); ?></div>
                    <div class="comment-meta">
                        <span class="comment-time"><?php 
                            $comment_time = strtotime($comment->comment_date_gmt);
                            echo human_time_diff_vn($comment_time, current_time('timestamp')); 
                        ?></span>
                        <a href="#" class="comment-reply-link" data-comment-id="<?php echo esc_attr($comment->comment_ID); ?>">Trả lời</a>
                    </div>
                </div>
                <div class="reply-form-container" style="display: none;">
                    <form class="reply-form-inline" action="<?php echo esc_url(site_url('/wp-comments-post.php')); ?>" method="post">
                        <?php wp_nonce_field('comment_form', '_wpnonce'); ?>
                        <div class="underline-inputs-row">
                            <div class="underline-input underline-input-half">
                                <input type="text" name="author" placeholder="Họ và tên*" required>
                            </div>
                            <div class="underline-input underline-input-half">
                                <input type="email" name="email" placeholder="Email*" required>
                            </div>
                        </div>
                        <div class="underline-input">
                            <textarea name="comment" placeholder="Trả lời*" rows="3" required></textarea>
                        </div>
                        <input type="hidden" name="comment_post_ID" value="<?php echo get_the_ID(); ?>">
                        <input type="hidden" name="comment_parent" value="<?php echo esc_attr($comment->comment_ID); ?>">
                        <button type="submit" class="send-reply">
                            <i class="fas fa-paper-plane"></i> Gửi trả lời
                        </button>
                        <div class="reply-success-message" style="display: none;"></div>
                        <div class="reply-error-message" style="display: none;"></div>
                    </form>
                </div>
                <?php if (!empty($data['replies'])) : ?>
                <div class="replies">
                    <?php foreach ($data['replies'] as $reply) :
                        $reply_time = strtotime($reply->comment_date_gmt);
                        $reply_human_time = human_time_diff_vn($reply_time, current_time('timestamp'));
                    ?>
                    <div class="comment-item" data-comment-id="<?php echo esc_attr($reply->comment_ID); ?>">
                        <div class="comment-avatar">
                            <img src="<?php echo esc_url(get_avatar_url($reply->comment_author_email, ['size' => 50])); ?>" alt="<?php echo esc_attr($reply->comment_author); ?>">
                        </div>
                        <div class="comment-content">
                            <div class="comment-author"><?php echo esc_html($reply->comment_author); ?></div>
                            <div class="comment-text"><?php echo esc_html($reply->comment_content); ?></div>
                            <div class="comment-meta">
                                <span class="comment-time"><?php echo esc_html($reply_human_time); ?></span>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <div class="comment-form-container">
            <h3 class="comment-form-title">Bình luận của bạn</h3>
            <p class="comment-form-subtitle">Địa chỉ email của bạn sẽ không được công khai. Các trường bắt buộc được đánh dấu *</p>

            <form id="comment-form" action="<?php echo esc_url(site_url('/wp-comments-post.php')); ?>" method="post">
                <?php wp_nonce_field('comment_form', '_wpnonce'); ?>
                <input type="hidden" name="comment_post_ID" value="<?php echo esc_attr(get_the_ID()); ?>" />
                <input type="hidden" name="comment_parent" id="comment_parent" value="0" />

                <div class="underline-inputs-row">
                    <div class="underline-input underline-input-half">
                        <label for="author">Họ và tên*</label>
                        <input type="text" id="author" name="author" required>
                    </div>
                    <div class="underline-input underline-input-half">
                        <label for="email">Email*</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                </div>

                <div class="underline-input">
                    <label for="comment">Lời nhắn*</label>
                    <textarea id="comment" name="comment" rows="4" required></textarea>
                </div>

                <div class="form-checkbox">
                    <input type="checkbox" id="save-info" name="save-info">
                    <label for="save-info">Lưu thông tin cho lần bình luận sau</label>
                </div>

                <button type="submit" class="submit-button">Gửi bình luận <svg fill="#fff" width="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="icon line"><path style="fill:none;stroke:#fff;stroke-linecap:round;stroke-linejoin:round;stroke-width:1.5" d="m14 5 7 7-7 7"/><path data-name="primary" style="fill:none;stroke:#fff;stroke-linecap:round;stroke-linejoin:round;stroke-width:1.5" d="M21 12H3"/></svg></button>
            </form>
        </div>
    </div>
    <?php else : ?>
    <p>Bình luận đã bị đóng.</p>
    <?php endif; ?>

    <!-- Related Posts Section -->
    <div class="homenest__single__related prisma__single_post">
        <h2>Bài viết đề xuất</h2>

        <?php
        $categories = get_the_category();
        if (!empty($categories)) {
            $category_ids = array();
            foreach ($categories as $category) {
                $category_ids[] = $category->term_id;
            }

            $args = array(
                'category__in' => $category_ids,
                'post__not_in' => array(get_the_ID()),
                'posts_per_page' => -1,
            );

            $related_posts_query = new WP_Query($args);
        ?>
        <p class="related-posts-subtitle">Khám phá thêm <?php echo ($related_posts_query->post_count > 0) ? esc_html($related_posts_query->post_count) : 'nhiều'; ?> bài viết khác từ danh mục này</p>
        <?php
            if ($related_posts_query->have_posts()) :
                $post_counter = 0;
                $total_posts = $related_posts_query->post_count;

                // First 3 posts in grid layout
                echo '<ul class="related-posts__list">';
                while ($related_posts_query->have_posts() && $post_counter < 3) : $related_posts_query->the_post();
                    $post_counter++;
        ?>
        <li class="related-post-item">
            <div class="related-post-card">
                <div class="related-post-image">
                    <a href="<?php the_permalink(); ?>">
                        <?php if (has_post_thumbnail()) : ?>
                        <img src="<?php echo esc_url(the_post_thumbnail_url('large')); ?>" alt="<?php the_title_attribute(); ?>" loading="lazy">
                        <?php else : ?>
                        <img src="/wp-content/uploads/2025/07/Logo_HomeNest-team.webp" alt="Placeholder" loading="lazy">
                        <?php endif; ?>
                    </a>
                    <div class="related-post-time">
                        <span><?php echo esc_html(get_the_date('F j, Y')); ?> / <?php the_author(); ?></span>
                    </div>
                </div>
                <div class="related-post-content">
                    <a href="<?php the_permalink(); ?>">
                        <h3><?php the_title(); ?></h3>
                    </a>
                    <p><?php echo esc_html(wp_trim_words(get_the_excerpt(), 20, '...')); ?></p>
                    <div class="related-post-breadcrumb">/ <a href="<?php echo esc_url(get_category_link(get_the_category()[0]->term_id)); ?>" style="pointer-events: auto !important; cursor: pointer !important;"><?php echo esc_html(get_the_category()[0]->name); ?></a> /</div>
                </div>
            </div>
        </li>
        <?php
                endwhile;
                echo '</ul>';

                // Posts 4-8 in horizontal layout
                if ($total_posts > 3) {
                    echo '<ul class="related-posts-horizontal__list">';
                    $related_posts_query->rewind_posts();
                    $post_counter = 0;
                    while ($related_posts_query->have_posts()) : $related_posts_query->the_post();
                        $post_counter++;
                        if ($post_counter >= 4 && $post_counter <= 8) :
        ?>
        <li class="related-post-item-horizontal">
            <div class="related-post-card-horizontal">
                <div class="related-post-time-horizontal">
                    <span class="day"><?php echo esc_html(get_the_date('j')); ?></span>
                    <span class="year"><?php 
                        $month_year = get_the_date('M Y');
                        $month_year = str_replace(
                            array('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'),
                            array('Tháng 1', 'Tháng 2', 'Tháng 3', 'Tháng 4', 'Tháng 5', 'Tháng 6', 'Tháng 7', 'Tháng 8', 'Tháng 9', 'Tháng 10', 'Tháng 11', 'Tháng 12'),
                            $month_year
                        );
                        echo $month_year;
                    ?></span>
                </div>
                <div class="related-post-image-horizontal">
                    <a href="<?php the_permalink(); ?>">
                        <?php if (has_post_thumbnail()) : ?>
                        <img src="<?php echo esc_url(the_post_thumbnail_url('full')); ?>" alt="<?php the_title_attribute(); ?>" loading="lazy">
                        <?php else : ?>
                        <img src="/wp-content/uploads/2025/07/Logo_HomeNest-team.webp" alt="Placeholder" loading="lazy">
                        <?php endif; ?>
                    </a>
                </div>
                <div class="related-post-content-horizontal">
                    <a href="<?php the_permalink(); ?>">
                        <h3><?php the_title(); ?></h3>
                    </a>
                    <p><?php echo esc_html(wp_trim_words(get_the_excerpt(), 15, '...')); ?></p>
                </div>
            </div>
        </li>
        <?php
                        endif;
                    endwhile;
                    echo '</ul>';
                }

                // More posts (9+ hidden, shown on button click)
                if ($total_posts > 8) {
                    echo '<div class="more-posts-container">';
                    $related_posts_query->rewind_posts();
                    $post_counter = 0;
                    while ($related_posts_query->have_posts()) : $related_posts_query->the_post();
                        $post_counter++;
                        if ($post_counter > 8) :
        ?>
        <li class="related-post-item-horizontal">
            <div class="related-post-card-horizontal">
                <div class="related-post-time-horizontal">
                    <span class="day"><?php echo esc_html(get_the_date('j')); ?></span>
                    <span class="year"><?php 
                        $month_year = get_the_date('M Y');
                        $month_year = str_replace(
                            array('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'),
                            array('Tháng 1', 'Tháng 2', 'Tháng 3', 'Tháng 4', 'Tháng 5', 'Tháng 6', 'Tháng 7', 'Tháng 8', 'Tháng 9', 'Tháng 10', 'Tháng 11', 'Tháng 12'),
                            $month_year
                        );
                        echo $month_year;
                    ?></span>
                </div>
                <div class="related-post-image-horizontal">
                    <a href="<?php the_permalink(); ?>">
                        <?php if (has_post_thumbnail()) : ?>
                        <img src="<?php echo esc_url(the_post_thumbnail_url('thumbnail')); ?>" alt="<?php the_title_attribute(); ?>" loading="lazy">
                        <?php else : ?>
                        <img src="/wp-content/uploads/2025/07/Logo_HomeNest-team.webp" alt="Placeholder" loading="lazy">
                        <?php endif; ?>
                    </a>
                </div>
                <div class="related-post-content-horizontal">
                    <a href="<?php the_permalink(); ?>">
                        <h3><?php the_title(); ?></h3>
                    </a>
                    <p><?php echo esc_html(wp_trim_words(get_the_excerpt(), 15, '...')); ?></p>
                </div>
            </div>
        </li>
        <?php
                        endif;
                    endwhile;
                    echo '</div>';
                }
        ?>
        <div class="view-all-posts">
            <button class="view-all-button">Xem tất cả bài viết</button>
        </div>
        <?php
                wp_reset_postdata();
            else :
        ?>
        <p>Không có bài viết liên quan.</p>
        <?php
            endif;
        }
        ?>
    </div>
</div>






<?php get_footer() ?>