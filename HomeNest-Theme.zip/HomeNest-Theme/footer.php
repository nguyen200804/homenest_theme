<?php
if ( ! is_front_page() && ! is_home() ) {
    echo do_shortcode('[shortcode_cham_soc_khach_hang_247]');
}
?>

<?php
// Lấy mã ngôn ngữ hiện tại (ví dụ: 'vi', 'en')
if (function_exists('pll_current_language')) {
    $lang_code = pll_current_language();
} else {
    // Dự phòng nếu Polylang chưa được kích hoạt
    $lang_code = '';
}

// Xây dựng tên tệp template. 
// Nếu ngôn ngữ là 'en', $template_name sẽ là 'footer-en'.
// Nếu ngôn ngữ là 'vi' hoặc ngôn ngữ mặc định, $template_name sẽ là 'footer'.
$template_name = ($lang_code && $lang_code !== 'vi') ? 'footer-' . $lang_code : 'footer';

// Gọi template
// WordPress sẽ tìm: 
// 1. template-parts/footer/footer-en.php (nếu $lang_code là 'en')
// 2. template-parts/footer/footer.php (nếu $lang_code là 'vi' hoặc ngôn ngữ mặc định)
get_template_part('template-parts/footer/' . $template_name);
?>