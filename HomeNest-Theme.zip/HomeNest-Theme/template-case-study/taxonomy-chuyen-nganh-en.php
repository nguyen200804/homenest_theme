<?php get_header(); ?>


<div id="prisma__project">
	<section class="homenest__archive-project__header">
		<div class="project__header__title">
			<div class="header__title">
				<h1 class="font-zise-title">HomeNest - <span class="color-title">Yout Partner in Digital</span> Excellence.</h1>

				<p>Elevate your brand with HomeNest’s holistic digital ecosystem. From website optimization to advanced SEO and branding, we turn technology into opportunity. We walk beside you on the journey to digital mastery, ensuring your business not only competes but thrives with sustainable profitability.</p>
				<div class="statistic-section">
					<div class="list-statistic">
						<div class="widget-container">
							<div class="counter-number">
								<span class="suffix">+</span>
								<span class="number">300</span>
								<span class="unit">%</span>
							</div>
							<div class="counter-title">
								Website Growth Rate
							</div>
						</div>
					</div>
					<div class="list-statistic">
						<div class="widget-container">
							<div class="counter-number">
								<span class="suffix">+</span>
								<span class="number">2.000</span>
								<span class="unit">%</span>
							</div>
							<div class="counter-title">
								Traffic Increase
							</div>
						</div>
					</div>
					<div class="list-statistic">
						<div class="widget-container">
							<div class="counter-number">
								<span class="number">6.000</span>
								<span class="suffix">+</span>
							</div>
							<div class="counter-title">
								Monthly Leads Generated
							</div>
						</div>
					</div>
				</div>



				<div class="button-container">
					<a href="#" target="_blank">
						<span>Contact Us</span>
						<span class="arrow">
							<i class="fa-light fa-arrow-right"></i>
							<i class="fa-light fa-arrow-right"></i>
						</span>
					</a>
				</div>


			</div>  
			<div class="animation__container">
				<lottie-player
							   src="/wp-content/themes/HomeNest-Theme/animation/Animation-1742802767942.json"
							   background="transparent"
							   speed="1.5"
							   loop
							   autoplay
							   style="width: 500px; height: 530px;">
				</lottie-player>
			</div>
		</div>
	</section>



	<!-- Hiển thị danh sách dự án và lọc dự án -->
	<?php
	// Lấy danh sách chuyên ngành và danh mục dự án
	$terms_chuyen_nganh = get_terms(array(
		'taxonomy' => 'chuyen-nganh',
		'hide_empty' => false,
	));
	$terms_danh_muc = get_terms(array(
		'taxonomy' => 'danh-muc-du-an',
		'hide_empty' => false,
	));
	?>

	<section id="project" class="homenest__archive-project__show-project">
		<div class="project-archive">
			<!-- Form lọc -->


			<?php
			// Assuming this is within a WordPress theme or plugin file
			echo do_shortcode('[tim-kiem-du-an-va-chon-nganh]');
			echo do_shortcode('[tat-ca-danh-muc-du-an]');
			echo do_shortcode('[tat-ca-du-an]');
			?>

		</div>
	</section>





	<section class="homenest__archive-project__banner">
		<div class="content-container">
			<div class="title-container">
				<h2>Empower your business with HomeNest. We help you target ideal customers, drive revenue growth, and maximize your advertising ROI. Let's start now.</h2>
			</div>
			<div class="button-container2">
				<div class="button-container">
					<a href="#" target="_blank">
						<span>Contact Now</span>
						<span class="arrow">
							<i class="fa-light fa-arrow-right"></i>
							<i class="fa-light fa-arrow-right"></i>
						</span>
					</a>
				</div>
			</div>
		</div>
	</section>
	<!-- //////////////// -->
	<section class="homenest__archive-project__hero-section">
		<div class="custom-hero-container">
			<div class="custom-hero-image">
				<img src="/wp-content/uploads/2025/05/Group-1217-scaled-1.webp" alt="Decor Image">
			</div>
			<div class="custom-hero-content">
				<p class="custom-hero-quote">
					"<span class="text-gradient">Beyond Services</span> –
					<span class="text-gradient">Partners in </span>
					Your Total Growth"
				</p>
				<div class="custom-signature-block">
					<div class="name">
						<img src="https://homenest.media/wp-content/uploads/2025/01/nTien-SignatureGenerator.svg" alt="nTien Signature" class="custom-signature">
						<div class="custom-role">CO-FOUNDER</div>
					</div>
					<hr class="custom-underline">
				</div>
			</div>
		</div>
	</section>
	<!-- /////////// -->
	<section class="homenest__archive-project__marquee">
		<div class="hn__marquee-container">
			<div class="hn__marquee-wrapper">

				<div class="marquee--contain">
					<div class="marquee-item left">
						<div>
							<img src="/wp-content/uploads/2025/05/Logo_website-26.webp" class="rectangle"  alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-19.webp" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-6.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-11.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-18.webp" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-12.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-31.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-65.webp" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-30.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-60.webp" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-34.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-59.webp" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-42.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-52.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-23.webp" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-49.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-50.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-67.webp" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-47.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-37.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-35.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-25.webp" alt="Homenest" title="Homenest">
						</div>
					</div>
					<div class="marquee-item left">
						<div>
							<img src="/wp-content/uploads/2025/05/Logo_website-62.webp" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-10.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-16.webp" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-9.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-7.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-15.webp" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-5.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-21.webp" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-4.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-2.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-22.webp" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-39.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-58.webp" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-43.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-41.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-24.webp" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-38.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-1.webp" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-55.webp">
							<img src="/wp-content/uploads/2025/05/Logo_website-48.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-63.webp" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-45.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-36.webp" class="rectangle" alt="Homenest" title="Homenest">
						</div>
					</div>
					<div class="marquee-item left">
						<div>
							<img src="/wp-content/uploads/2025/05/Logo_website-53.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-17.webp" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-8.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-14.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-13.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-61.webp" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-27.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-3.webp" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-40.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-32.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-66.webp" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-34.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-57.webp" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-29.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-64.webp" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-28.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-51.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-46.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-56.webp" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-44.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-54.webp" class="rectangle" alt="Homenest" title="Homenest">
							<img src="/wp-content/uploads/2025/05/Logo_website-20.webp" alt="Homenest" title="Homenest">
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

</div>

<script>
	// Counter animation code (unchanged, already in vanilla JS)
	document.addEventListener("DOMContentLoaded", function () {
		const counters = document.querySelectorAll(".counter-number .number");

		const animateCounter = (el, finalValue) => {
			const duration = 1500; // Total duration (ms)
			let start = 0;
			let startTime = null;

			// Handle formatted numbers with dots
			const isFormatted = finalValue.includes(".");
			const cleanValue = parseFloat(finalValue.replace(/\./g, "").replace(",", ""));

			const step = (timestamp) => {
				if (!startTime) startTime = timestamp;
				const progress = timestamp - startTime;
				const current = Math.min(Math.floor((progress / duration) * cleanValue), cleanValue);

				// Format number with dots
				el.innerText = isFormatted ? current.toLocaleString("de-DE") : current;

				if (current < cleanValue) {
					requestAnimationFrame(step);
				}
			};

			requestAnimationFrame(step);
		};

		const observer = new IntersectionObserver((entries, obs) => {
			entries.forEach(entry => {
				if (entry.isIntersecting) {
					const el = entry.target;
					const finalValue = el.textContent.trim();
					animateCounter(el, finalValue);
					obs.unobserve(el); // Run once
				}
			});
		}, { threshold: 1.0 });

		counters.forEach(counter => {
			observer.observe(counter);
		});




		const marqueeItems = document.querySelectorAll('.hn__marquee-wrapper .marquee-item');
		marqueeItems.forEach(item => {
			const div = item.querySelector('div');
			if (div) {
				// Lấy width và gán vào --width
				const width = div.offsetWidth;
				item.style.setProperty('--width', `${width}px`);

				// Sao chép phần tử div
				const divClone = div.cloneNode(true); // true để sao chép cả nội dung bên trong
				item.appendChild(divClone); // Thêm bản sao vào .marquee-item
			}
		});
	});

	// Converted jQuery to vanilla JavaScript
	document.addEventListener("DOMContentLoaded", function () {
		function filterProjects(page = 1) {
			console.log('Calling filterProjects with page: ' + page);
			const formData = new FormData();
			formData.append('action', 'filter_projects');
			formData.append('s', document.querySelector('#filterForm input[name="s"]').value);
			formData.append('chuyen_nganh', document.querySelector('#industrySelect').value);
			formData.append('danh_muc', document.querySelector('.nav-tabs .tab.active')?.dataset.danhMuc || '');
							formData.append('paged', page);

							fetch(homenestAjax.ajaxurl, {
							method: 'POST',
							body: formData
							})
				.then(response => {
				console.log('Fetch response received');
				return response.json();
			})
				.then(data => {
				console.log('Fetch response data: ', data);
				const projectResults = document.querySelector('#projectResults');
				if (data.success) {
					projectResults.innerHTML = data.data;
				} else {
					projectResults.innerHTML = `<p>Đã xảy ra lỗi: ${data.data || 'Không có dữ liệu'}</p>`;
				}
			})
				.catch(error => {
				console.log('Fetch error: ', error);
				document.querySelector('#projectResults').innerHTML = '<p>Đã xảy ra lỗi khi tải dữ liệu. Vui lòng thử lại.</p>';
			});

			// Show loading state
			document.querySelector('#projectResults').innerHTML = '<p>Đang tải...</p>';
		}

		// Search button click
		document.querySelector('#searchBtn').addEventListener('click', function (e) {
			e.preventDefault();
			filterProjects(1);
		});

		// Industry select change
		document.querySelector('#industrySelect').addEventListener('change', function () {
			filterProjects(1);
		});

		// Tab click
		document.querySelectorAll('.nav-tabs .tab').forEach(tab => {
			tab.addEventListener('click', function (e) {
				e.preventDefault();
				document.querySelectorAll('.nav-tabs .tab').forEach(t => t.classList.remove('active'));
				this.classList.add('active');
				filterProjects(1);
			});
		});

		// Search input enter key
		document.querySelector('#filterForm input[name="s"]').addEventListener('keypress', function (e) {
			if (e.key === 'Enter') {
				e.preventDefault();
				filterProjects(1);
			}
		});

		// Pagination click (using event delegation)
		document.addEventListener('click', function (e) {
			const paginationLink = e.target.closest('.pagination a');
			if (paginationLink) {
				e.preventDefault();
				const page = paginationLink.dataset.page;
				console.log('Pagination clicked, page: ' + page);
				if (page) {
					filterProjects(page);
				}
			}
		});



	});
</script>

<?php get_footer(); ?>