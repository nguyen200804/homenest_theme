<?php
get_header(); // Gọi header

if ( have_posts() ) :
while ( have_posts() ) : the_post();
$all_meta = get_post_meta(get_the_ID());
?>

<body>
	<div class="h3homenest container">
		<div style="max-width: 1400px; width: 100%; padding: 0 10px;">
			<nav class="breadcrumbs">
				<a href="<?php echo home_url(); ?>">
					<svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
						<path d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z"/>
					</svg>
					Trang chủ</a>

				<?php if (is_single()) : ?>
				<span> <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400 " aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
					<path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 9 4-4-4-4"/>
					</svg> </span>
				<?php
				$post_type_obj = get_post_type_object('case_study');
				$project_label = $post_type_obj ? $post_type_obj->labels->name : 'Không tìm thấy';
				?>  <a href="<?php echo get_post_type_archive_link('case_study'); ?>"><?php echo esc_html($project_label); ?></a>


				<?php if (is_single()) : ?>
				<span> <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400 " aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
					<path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 9 4-4-4-4"/>
					</svg> </span>
				<span><?php the_title(); ?></span>
				<?php endif; ?>

				<?php elseif (is_page()) : ?>
				<span> <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400 " aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
					<path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 9 4-4-4-4"/>
					</svg> </span>
				<span><?php the_title(); ?></span>

				<?php endif; ?>
			</nav>
		</div>
		<section class="single_project item">
			<?php if ( has_post_thumbnail() ) : 
			$thumb_url = get_the_post_thumbnail_url(get_the_ID(), 'full'); ?>
			<img src="<?php echo esc_url($thumb_url); ?>" alt="" class="project_img__main">
			<?php else : ?>
			<div style="width:100px; height:auto; margin-right:30px;"></div>
			<?php endif; ?>
			<div class="project_post__content">
				<h1 class="text--gradient"><?php the_title(); ?></h1>
				<hr style="width: 170px; margin-bottom: 10px;">
				<?php
				if ( !empty($all_meta['mo_ta_du_an_chinh'][0]) ) {
					echo wpautop(wp_kses_post($all_meta['mo_ta_du_an_chinh'][0]));
				} else {
					echo '<div style="min-height: 50px;"></div>'; // giữ khoảng trống tương đương mô tả
				}
				?>
				<hr>
				<div class="project_post_meta_wrapper">
					<div class="project_post_meta_item">
						<?php 
						$terms = get_the_terms(get_the_ID(), 'chuyen-nganh'); // 'linh_vuc' là tên slug của taxonomy
						echo '<h5 class="project_post_meta_label">Ngành - Lĩnh vực</h5>';
						if (!empty($terms) && !is_wp_error($terms)) {
							echo '<ul>';
							foreach ($terms as $term) {
								echo '<li>' . esc_html($term->name) . '</li>';
							}
							echo '</ul>';
						} else {
							echo '<div style="min-height: 40px;"></div>';
						}
						?>
					</div>
					<div class="project_post_meta_item">
						<?php
						$year = get_field('nam'); // trả về giá trị number trực tiếp
						if ($year) {
							echo '<h5 class="project_post_meta_label">Năm thực hiện</h5>';
							echo '<ul><li>' . esc_html($year) . '</li></ul>';
						} else {
							echo '<div style="min-height: 40px;"></div>';
						}
						?>
					</div>
					<div class="project_post_meta_item">
						<?php
						$pp = get_field('nhan_su'); // trả về giá trị number trực tiếp
						if ($pp) {
							echo '<h5 class="project_post_meta_label">Nhân sự</h5>';
							echo '<ul><li>' . esc_html($pp) . '</li></ul>';
						} else {
							echo '<div style="min-height: 40px;"></div>';
						}
						?>
					</div>
					<div class="project_post_meta_item">
						<?php 
						$terms = get_the_terms(get_the_ID(), 'linh-vuc'); // 'linh_vuc' là tên slug của taxonomy
						echo '<h5 class="project_post_meta_label">Dịch vụ</h5>';
						if (!empty($terms) && !is_wp_error($terms)) {
							echo '<ul>';
							foreach ($terms as $term) {
								echo '<li>' . esc_html($term->name) . '</li>';
							}
							echo '</ul>';
						} else {
							echo '<div style="min-height: 40px;"></div>';
						}
						?>
					</div>
					<div class="project_post_meta_item">
						<?php
						$pp = get_field('time'); // trả về giá trị number trực tiếp
						if ($pp) {
							echo '<h5 class="project_post_meta_label">Thời gian</h5>';
							echo '<ul><li>' . esc_html($pp) . ' người</li></ul>';
						} else {
							echo '<div style="min-height: 40px;"></div>';
						}
						?>
					</div>
				</div>
				<h2 class="ngon_ngu">
					Công cụ hỗ trợ
				</h2>
				<div class="solution-brand-inner">
					<?php
					$gallery = get_field('logo_ngon_ngu_cong_cu');
					if ($gallery) {
						foreach ($gallery as $image) {
							echo '<span class="solution-brand-item">';
							echo '<img src="' . esc_url($image['url']) . '" alt="Logo ngôn ngữ, công cụ">';
							echo '</span>';
						}
					}
					?>
				</div>
				<div class="group_button">
					<button class="neuros_button">
						<span class="button_content">
							<span class="button_text">Tư vấn khách hàng</span>
						</span>
						<i class="homenest-icon-arrow-right"></i>         
					</button>
					<a href="#">
						<span class="button_text">Trải nghiệm thực tế</span>
						<i class="homenest-icon-arrow-right"></i> 
					</a>
				</div>
			</div>
		</section>

		<?php 
		$all_meta = get_post_meta(get_the_ID());

		$banner_raw = isset($all_meta['banner'][0]) ? $all_meta['banner'][0] : null;
		$banner_url = '';

		if ($banner_raw) {
			$banner_data = maybe_unserialize($banner_raw);
			$banner_id = is_array($banner_data) && !empty($banner_data) ? $banner_data[0] : $banner_raw;
			$banner_url = wp_get_attachment_url($banner_id);
		}

		// Lấy video
		$video_meta = isset($all_meta['video'][0]) ? maybe_unserialize($all_meta['video'][0]) : null; 
		$video_url  = !empty($video_meta['url']) ? esc_url($video_meta['url']) : '';
		$embed_url  = $video_url ? str_replace('watch?v=', 'embed/', $video_url) : '';
		?>

		<?php if ($banner_url): ?>
		<section class="project__banner item">
			<img src="<?php echo esc_url($banner_url); ?>" alt="Homenest" title="Homenest">
			<?php if ($embed_url): ?>
			<!-- Nút mở video -->
			<button class="link_video" onclick="openVideoModal()">
				<span class="icon-wrapper" style="position: relative; display: inline-block;">
					<i class="homenest-icon-play"></i>
				</span>
				<span class="neuros_button_text">Watch video</span>
			</button>
		</section>
		<!-- Modal Video -->
		<div id="videoModal" class="modal">
			<div class="modal-content">
				<span class="close" onclick="closeVideoModal()"><svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none"
					  stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
					  <circle cx="12" cy="12" r="11" />
					  <line x1="15" y1="9" x2="9" y2="15" />
					  <line x1="9" y1="9" x2="15" y2="15" />
					</svg></span>
				<div class="video-container">
					<iframe id="youtubeVideo" width="100%" height="100%" frameborder="0" allowfullscreen allow="autoplay"></iframe>
				</div>
			</div>
		</div>
		<?php endif; ?>
		<?php endif; ?>

		<?php if ($embed_url): ?>
		<script>
			const videoUrl = "<?php echo $embed_url; ?>";

			function openVideoModal() {
				document.getElementById("videoModal").style.display = "block";
				document.getElementById("youtubeVideo").src = videoUrl;
			}

			function closeVideoModal() {
				document.getElementById("videoModal").style.display = "none";
				document.getElementById("youtubeVideo").src = "";
			}

			window.onclick = function(event) {
				const modal = document.getElementById("videoModal");
				if (event.target === modal) {
					closeVideoModal();
				}
			}
		</script>
		<?php endif; ?>


		<!--         </section> -->
		<section class="project__content_main item">
			<img src="/wp-content/uploads/2025/05/Vector-1-1-1.webp" style="position: absolute; top: -33px; left: -50%; witdh: 290px; height:52vh; filter: blur(160px); z-index:-1;" alt="Homenest" title="Homenest">
			<div class="project__content_main_title">
				<h2 class="text--gradient" style="">Ý tưởng thiết kế</h2>
			</div>
			<div class="project__content_main_content">
				<?php the_content(); ?>
				<div class="project__widget">
					<img src="/wp-content/uploads/2025/05/z6619870433268_9fcc32f261823f35b897c28603a683d2-removebg-preview.webp" alt="Icon Homenest">
					<div>
						<?php
						$trich_dan = get_field('trich_dẫn'); // lấy cả group

						if (!empty($trich_dan)) {
							$content_td = $trich_dan['content'] ?? '';
							$author_td  = $trich_dan['author'] ?? '';

							if ($content_td || $author_td):
								?>
								<?php if ($content_td): ?>
									<h3><?php echo esc_html($content_td); ?></h3>
								<?php endif; ?>

								<?php if ($author_td): ?>
									<span><?php echo esc_html($author_td); ?></span>
								<?php endif; ?>
								<?php
							endif;
						}
						?>
					</div>
				</div>
			</div>
		</section>
		<?php
		$gallery_raw = isset($all_meta['gallery_du_an']) ? $all_meta['gallery_du_an'] : [];

		$gallery = [];

		if (!empty($gallery_raw) && is_array($gallery_raw)) {
			// Giả sử gallery_raw chứa mảng serialized
			$gallery = maybe_unserialize($gallery_raw[0]);
		}

		$img_urls = [];

		if (!empty($gallery) && is_array($gallery)) {
			foreach ($gallery as $img_id) {
				$img_url = wp_get_attachment_url($img_id);
				if ($img_url) {
					$img_urls[] = esc_url($img_url);
				}
			}
		}
		?>

		<section class="project__imgs item">
			<div class="swiper mySwiper">
				<div class="swiper-wrapper">
					<?php foreach ($img_urls as $index => $img_url): ?>
					<div class="swiper-slide custom-cursor-area">
						<img src="<?php echo $img_url; ?>" alt="Gallery Image Homenest" class="lightbox-trigger" data-index="<?php echo $index; ?>" />
						<div class="radius_container"><span class="text--gradient">Homenest</span></div>
					</div>
					<?php endforeach; ?>
				</div>
			</div>
			<div class="custom-navigation">
				<button class="swiper-button-prev-main"><i class="homenest-icon-arrow-left"></i></button>
				<button class="swiper-button-next-main"><i class="homenest-icon-arrow-right"></i></button>
			</div>
		</section>
		<div id="lightboxModal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.9); z-index:9999;">
			<div class="swiper lightbox-swiper custom-cursor-area" style="height: 100%; width: 100%;">
				<div class="swiper-wrapper">
					<?php foreach ($img_urls as $img_url): ?>
					<div class="swiper-slide">
						<div class="swiper-zoom-container">
							<img src="<?php echo $img_url; ?>" alt="Gallery Full Homenest" />
						</div>
					</div>
					<?php endforeach; ?>
				</div>
				<div class="swiper-button-next"></div>
				<div class="swiper-button-prev"></div>
				<div class="swiper-pagination"></div>
			</div>
			<!-- Nút điều khiển -->
			<div style="position: absolute; top: 20px; right: 30px; z-index: 10000; display: flex; gap: 10px;">
				<button onclick="zoomIn()" style="background: none; border: none; color: white; font-size: 30px; cursor: pointer;">
					<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="none" stroke="currentColor" stroke-width="2"
					  stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
					  <circle cx="11" cy="11" r="8" />
					  <line x1="11" y1="8" x2="11" y2="14" />
					  <line x1="8" y1="11" x2="14" y2="11" />
					  <line x1="21" y1="21" x2="16.65" y2="16.65" />
					</svg>
				</button>
				<button onclick="zoomOut()" style="background: none; border: none; color: white; font-size: 30px; cursor: pointer;">
					<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="none" stroke="currentColor" stroke-width="2"
					  stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
					  <circle cx="11" cy="11" r="8" />
					  <line x1="8" y1="11" x2="14" y2="11" />
					  <line x1="21" y1="21" x2="16.65" y2="16.65" />
					</svg>
				</button>
				<button onclick="closeLightbox()" style="background: none; border: none; color: white; font-size: 30px; cursor: pointer; margin-left:20px;">
					<svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none"
					  stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
					  <circle cx="12" cy="12" r="11" />
					  <line x1="15" y1="9" x2="9" y2="15" />
					  <line x1="9" y1="9" x2="15" y2="15" />
					</svg>
				</button>
			</div>
		</div>
		
  <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

		<script>
			// Swiper chính
			var swiper = new Swiper(".mySwiper", {
				slidesPerView: 1, // Mặc định cho mobile
				spaceBetween: 20,
				navigation: {
					nextEl: '.swiper-button-next-main',
					prevEl: '.swiper-button-prev-main',
				},
				breakpoints: {
					600: { // ✅ Đúng cú pháp: key : value
						slidesPerView: 2,
						spaceBetween: 30,
					},
					1000: { // ✅ Đúng cú pháp: key : value
						slidesPerView: 3,
						spaceBetween: 30,
					},
					1200: { // ✅ Đúng cú pháp: key : value
						slidesPerView: 4,
						spaceBetween: 30,
					},
				},
				autoplay: {
					delay: 2500,
					disableOnInteraction: false,
				  },
			});

			// Swiper cho lightbox
			const lightboxSwiper = new Swiper('.lightbox-swiper', {
				navigation: {
					nextEl: '.swiper-button-next',
					prevEl: '.swiper-button-prev',
				},
				pagination: {
					el: '.swiper-pagination',
				},
				zoom: {
					maxRatio: 5, // mức phóng tối đa
					minRatio: 1, // mức thu nhỏ tối thiểu
				},
			});
			let currentZoom = 1;
			const lightboxTriggers = document.querySelectorAll('.lightbox-trigger');
			const lightboxModal = document.getElementById('lightboxModal');

			lightboxTriggers.forEach(trigger => {
				trigger.addEventListener('click', function () {
					const index = parseInt(this.dataset.index);
					lightboxModal.style.display = 'block';
					lightboxSwiper.slideTo(index, 0);
				});
			});
			function zoomIn() {
				currentZoom = Math.min(currentZoom + 0.2, 5);
				const slide = lightboxSwiper.slides[lightboxSwiper.activeIndex];
				const zoomContainer = slide.querySelector('.swiper-zoom-container');
				if (zoomContainer) {
					zoomContainer.style.transform = `scale(${currentZoom})`;
				}
			}
			function zoomOut() {
				currentZoom = Math.max(currentZoom - 0.2, 1);
				const slide = lightboxSwiper.slides[lightboxSwiper.activeIndex];
				const zoomContainer = slide.querySelector('.swiper-zoom-container');
				if (zoomContainer) {
					zoomContainer.style.transform = `scale(${currentZoom})`;
				}
			}

			function closeLightbox() {
				lightboxModal.style.display = 'none';
			}
		</script>
		<section class="project__content_counter item">
			<div class="space">
				<img src="/wp-content/uploads/2025/07/global-remake-scaled-1.webp" alt="Homenest" title="Homenest">
				<img src="/wp-content/uploads/2025/05/Vector-1-1.webp" style="position: absolute; top: -40vh; left: -60%; height:40vh; filter: blur(240px); z-index:-1;" alt="Homenest" title="Homenest">
			</div>
			<div class="project__content_counter_text">
				<h2>Giải pháp</h2>
				<?php
				if ( isset($all_meta['ket_qua_du_an'][0]) ) {
					echo wpautop( wp_kses_post( $all_meta['ket_qua_du_an'][0] ) );
				}
				?>
			</div>
			<div class="project__content_counter_items">
				<div>
					<?php
					$number = isset($all_meta['con_so_number'][0]) ? esc_html($all_meta['con_so_number'][0]) : '';
					$text   = isset($all_meta['con_so_text'][0]) ? esc_html($all_meta['con_so_text'][0]) : '';

					if ($number || $text):
					?>
					<div>
						<?php if ($number): ?>
						<span class="count" data-target="<?php echo (int)$number; ?>">0</span><span>%</span>
						<?php endif; ?>
					</div>
					<?php if ($text): ?>
					<p><?php echo $text; ?></p>
					<?php endif; ?>
					<?php endif; ?>
				</div>

				<div>
					<?php
					$number2 = isset($all_meta['con_so_second_number'][0]) ? esc_html($all_meta['con_so_second_number'][0]) : '';
					$text2   = isset($all_meta['con_so_second_text'][0]) ? esc_html($all_meta['con_so_second_text'][0]) : '';

					if ($number2 || $text2):
					?>
					<div>
						<?php if ($number2): ?>
						<span class="count" data-target="<?php echo (int)$number2; ?>">0</span><span>+</span>
						<?php endif; ?>
					</div>
					<?php if ($text2): ?>
					<p><?php echo $text2; ?></p>
					<?php endif; ?>
					<?php endif; ?>
				</div>
			</div>
		</section>
		<?php 
$image = get_field('danh_gia');
if ($image) : ?>
    <div class="danh_gia">
        <h2>
            Đánh giá dự án dựa trên thống số Homenest tự thống kê và feedback khách hàng
        </h2>
        <img 
            src="<?php echo esc_url($image['url']); ?>" 
            alt="<?php echo esc_attr($image['title']); ?>" 
        />
    </div>
<?php endif; ?>


<script>
document.addEventListener('DOMContentLoaded', function () {
  const rows = document.querySelectorAll('.marquee-row');
  const speed = 1.5;

  rows.forEach((row) => {
    let pos = 0;

    function move() {
      pos -= speed;
      if (Math.abs(pos) >= row.scrollWidth / 2) pos = 0;
      row.style.transform = `translateX(${pos}px)`;
      requestAnimationFrame(move);
    }

    move();
  });

  // 🔄 Di chuyển phần xử lý phóng to ảnh vào đây
  const overlay = document.getElementById('image-overlay');
  const overlayImg = document.getElementById('overlay-img');
  const closeBtn = document.querySelector('#image-overlay .close-btn');
  const backdrop = document.querySelector('#image-overlay .overlay-backdrop');

  document.querySelectorAll('.marquee-row img').forEach(img => {
    img.addEventListener('click', () => {
      overlayImg.src = img.src;
      overlay.style.display = 'flex';
    });
  });

  closeBtn.addEventListener('click', () => {
    overlay.style.display = 'none';
    overlayImg.src = '';
  });

  backdrop.addEventListener('click', () => {
    overlay.style.display = 'none';
    overlayImg.src = '';
  });
});
</script>



<?php
$ui_design = get_field('ui_design');
$images = $ui_design['anh_du_an'] ?? [];
$content = $ui_design['content'] ?? '';
if (!empty($images)) :
    // Chia làm 2 hàng
    $half = ceil(count($images) / 2);
    $row1 = array_slice($images, 0, $half);
    $row2 = array_slice($images, $half);

    // Nhân đôi để tạo hiệu ứng lặp vô hạn
    $row1 = array_merge($row1, $row1);
    $row2 = array_merge($row2, $row2);
?>
<div class="content_logo_duan">
	<h2>
		UX DESIGN
	</h2>
	<p>
		<?php echo wpautop(esc_html($content)); ?>
	</p>
</div>
<div class="marquee-container">
    <div class="marquee-row row-1">
        <?php foreach ($row1 as $img): ?>
            <img src="<?= esc_url($img['url']); ?>" alt="<?= esc_attr($img['title'] ?? ''); ?>">
        <?php endforeach; ?>
    </div>
    <div class="marquee-row row-2">
        <?php foreach ($row2 as $img): ?>
            <img src="<?= esc_url($img['url']); ?>" alt="<?= esc_attr($img['title'] ?? ''); ?>">
        <?php endforeach; ?>
    </div>
</div>
<div id="image-overlay" style="display: none;">
  <div class="overlay-backdrop"></div>
  <div class="overlay-content">
    <span class="close-btn">&times;</span>
    <img id="overlay-img" src="" alt="Phóng to ảnh">
  </div>
</div>
<?php endif; ?>
		<?php
		global $post;

		// Lấy danh sách tất cả bài viết project theo ID tăng dần
		$projects = get_posts(array(
			'post_type' => 'case_study',
			'posts_per_page' => -1,
			'orderby' => 'ID',
			'order' => 'ASC',
			'fields' => 'ids', // chỉ lấy ID để nhẹ hơn
		));

		$current_index = array_search($post->ID, $projects);

		// Xác định bài trước và sau (vòng tròn)
		$prev_index = ($current_index === 0) ? count($projects) - 1 : $current_index - 1;
		$next_index = ($current_index === count($projects) - 1) ? 0 : $current_index + 1;

		$prev_post_id = $projects[$prev_index];
		$next_post_id = $projects[$next_index];

		$prev_post = get_post($prev_post_id);
		$next_post = get_post($next_post_id);

		// Lấy thông tin danh mục của bài viết (taxonomy: danh-muc-du-an)
		$prev_cats = wp_get_post_terms($prev_post->ID, 'linh-vuc');
		$next_cats = wp_get_post_terms($next_post->ID, 'linh-vuc');

		if ($prev_post || $next_post) :
		?>

		<div class="pagination item">
			<?php if ($prev_post) :
			$prev_title = get_the_title($prev_post->ID);
			$prev_link = get_permalink($prev_post->ID);
			$prev_thumb = get_the_post_thumbnail($prev_post->ID, 'medium');
			?>
			<div class="pagination__prev">
				<a href="<?php echo esc_url($prev_link); ?>" class="button">
					<div class="protect__layout_button">
						<i class="homenest-icon-arrow-left"></i>
						<span class="text-label">Prev project</span>
						<i class="homenest-icon-arrow-left"></i>
					</div>
				</a>
				<div>
					<a  class="img_main" href="<?php echo esc_url($prev_link); ?>">
						<?php echo $prev_thumb; ?>
					</a>
					<div>
						<?php if (!empty($prev_cats)) : ?>
						<a href="<?php echo esc_url(get_term_link($prev_cats[0])); ?>">
							<span><?php echo esc_html($prev_cats[0]->name); ?></span>
						</a>
						<?php endif; ?>
						<a href="<?php echo esc_url($prev_link); ?>">
							<h2><?php echo esc_html($prev_title); ?></h2>
						</a>
					</div>
				</div>
			</div>
			<?php endif; ?>

			<a href="#" class="icon-hover">
				<i class="homenest-icon-grid-2"></i>
			</a>

			<?php if ($next_post) :
			$next_title = get_the_title($next_post->ID);
			$next_link = get_permalink($next_post->ID);
			$next_thumb = get_the_post_thumbnail($next_post->ID, 'medium');
			?>
			<div class="pagination__next">
				<a href="<?php echo esc_url($next_link); ?>" class="button">
					<div class="protect__layout_button">
						<i class="homenest-icon-arrow-right"></i>
						<span class="text-label">Next project</span>
						<i class="homenest-icon-arrow-right"></i>
					</div>
				</a>
				<div>
					<div>
						<?php if (!empty($next_cats)) : ?>
						<a href="<?php echo esc_url(get_term_link($next_cats[0])); ?>">
							<span><?php echo esc_html($next_cats[0]->name); ?></span>
						</a>
						<?php endif; ?>
						<a href="<?php echo esc_url($next_link); ?>">
							<h2><?php echo esc_html($next_title); ?></h2>
						</a>
					</div>
					<a class="img_main" href="<?php echo esc_url($next_link); ?>">
						<?php echo $next_thumb; ?>
					</a>
				</div>
			</div>
			<?php endif; ?>
		</div>

		<?php endif; ?>
		<div class="form__container item">
			<?php if (get_comments_number() > 0) : ?>
			<h4 class="post__comment_title text--gradient">
				Tất cả bình luận
				<span class="post__comment_title_counter">(<?php echo get_comments_number(); ?>)</span>
			</h4>
			<?php
			$comments = get_comments([
				'post_id' => get_the_ID(),
				'status' => 'approve',
				'orderby' => 'comment_date_gmt',
				'order' => 'ASC'
			]);

			$comment_tree = [];
			$comments_by_id = [];

			foreach ($comments as $comment) {
				$comments_by_id[$comment->comment_ID] = $comment;
			}

			foreach ($comments as $comment) {
				$root_id = $comment->comment_ID;
				while ($comments_by_id[$root_id]->comment_parent != 0) {
					$root_id = $comments_by_id[$root_id]->comment_parent;
				}

				if (!isset($comment_tree[$root_id])) {
					$comment_tree[$root_id] = ['comment' => $comments_by_id[$root_id], 'replies' => []];
				}

				if ($comment->comment_ID != $root_id) {
					$comment_tree[$root_id]['replies'][] = $comment;
				}
			}
			?>

			<div class="post__comment_list">
				<?php foreach ($comment_tree as $node): ?>
				<div class="post__comment_item">
					<div class="post__comment_avatar">
						<img src="//secure.gravatar.com/avatar/<?php echo md5(strtolower(trim($node['comment']->comment_author_email))); ?>?s=122&d=mm&r=g" alt="Homenest" title="Homenest">
					</div>
					<div class="post__comment_main">
						<div class="post__comment_meta">
							<div class="post__comment_info">
								<div class="post__comment_author text--gradient"><?php echo esc_html($node['comment']->comment_author); ?></div>
								<div class="post__comment_content">
									<?php echo esc_html($node['comment']->comment_content); ?>
								</div>
							</div>
							<div style="display: flex; justify-content: start; align-items: center;">
								<div class="post__comment_time">
									<?php
									$comment_time = strtotime($node['comment']->comment_date_gmt);
									$human_time = human_time_diff($comment_time, current_time('timestamp')) . ' trước';
									echo $human_time;
									?>
								</div>
								<div class="post__comment_button">
									<a href="#" class="reply-btn" data-comment-id="<?php echo $node['comment']->comment_ID; ?>" data-author="<?php echo esc_attr($node['comment']->comment_author); ?>">Trả lời</a>
								</div>
							</div>
							<div class="reply-form-container" style="display:none;"></div>
						</div>

						<?php if (!empty($node['replies'])): ?>
						<div class="post__comment_replies" style="margin-left: 40px;" data-comment-root="<?php echo $node['comment']->comment_ID; ?>">
							<?php
							$reply_index = 0;
							foreach ($node['replies'] as $reply):
							$reply_index++;
							?>
							<div class="post__comment_item reply"
								 style="display: none;">
								<div class="post__comment_avatar">
									<img src="//secure.gravatar.com/avatar/<?php echo md5(strtolower(trim($reply->comment_author_email))); ?>?s=122&d=mm&r=g" alt="Homenest" title="Homenest">
								</div>
								<div class="post__comment_main">
									<div class="post__comment_meta">
										<div class="post__comment_info">
											<?php
											$parent_comment = get_comment($reply->comment_parent);
											$reply_to_author = $parent_comment ? $parent_comment->comment_author : '';
											?>
											<div class="post__comment_author text--gradient"><?php echo esc_html($reply->comment_author); ?>
												<?php if ($reply_to_author): ?>
												<span class="reply-to">(Trả lời <?php echo esc_html($reply_to_author); ?>)</span>
												<?php endif; ?>
											</div>
											<div class="post__comment_content">
												<?php echo esc_html($reply->comment_content); ?>
											</div>
										</div>
										<div style="display: flex; justify-content: start; align-items: center;">
											<div class="post__comment_time">
												<?php
												$comment_time = strtotime($reply->comment_date_gmt);
												$human_time = human_time_diff($comment_time, current_time('timestamp')) . ' trước';
												echo $human_time;
												?>
											</div>
											<div class="post__comment_button">
												<a href="#" class="reply-btn" data-comment-id="<?php echo $reply->comment_ID; ?>" data-author="<?php echo esc_attr($reply->comment_author); ?>">Trả lời</a>
											</div>
										</div>
										<div class="reply-form-container" style="display:none;"></div>
									</div>
								</div>
							</div>
							<?php endforeach; ?>

							<?php if (count($node['replies']) > 0): ?>
							<button class="load-more-replies text--gradient" data-root-id="<?php echo $node['comment']->comment_ID; ?>" data-current="0">Xem thêm bình luận</button>
							<?php endif; ?>
						</div>
						<?php endif; ?>
					</div>
				</div>
				<?php endforeach; ?>
			</div>
			<?php endif; ?>


			<script>
				document.addEventListener('DOMContentLoaded', function () {
					console.log("3");
					const replyFormHTML = () => {
						const name = localStorage.getItem('reply_name') || '';
						const email = localStorage.getItem('reply_email') || '';
						const isLoggedIn = name && email;

						return `
<div class="reply-form-inline">
${!isLoggedIn ? `
<input type="text" class="reply-name" placeholder="Tên của bạn" value="${name}" required>
<input type="email" class="reply-email" placeholder="Email của bạn" value="${email}" required>
` : ''}
<textarea class="reply-textarea" placeholder="Nhập bình luận..." required></textarea>
<button type="submit" class="send-reply">Gửi</button>
				</div>
`;
					};


					let currentVisibleForm = null;

					document.querySelectorAll('.reply-btn').forEach(btn => {
						btn.addEventListener('click', function (e) {
							e.preventDefault();
							const parentId = btn.dataset.commentId;
							const container = btn.closest('.post__comment_meta').querySelector('.reply-form-container');
							const name = localStorage.getItem('reply_name') || '';
							const email1 = localStorage.getItem('reply_email') || '';
							const isLoggedIn = name && email;
							if (currentVisibleForm && currentVisibleForm !== container) {
								currentVisibleForm.innerHTML = '';
								currentVisibleForm.style.display = 'none';
							}

							if (container.style.display === 'none' || container.innerHTML === '') {
								container.innerHTML = replyFormHTML();
								container.style.display = 'block';
								currentVisibleForm = container;

								const sendBtn = container.querySelector('.send-reply');
								sendBtn.addEventListener('click', function () {
									let author = '';
									let email = '';
									if (!isLoggedIn) {
										author = container.querySelector('.reply-name')?.value.trim() || '';
										email = container.querySelector('.reply-email')?.value.trim() || '';
									} else {
										author = name;  // name của user đã login
										email = email1;  // email của user đã login
									}
										const content = container.querySelector('.reply-textarea').value.trim();
										const postId = <?php echo get_the_ID(); ?>;

										if (!author || !email || !content) {
										alert('Vui lòng nhập đầy đủ thông tin');
										return;
									}
										localStorage.setItem('reply_name', author);
										localStorage.setItem('reply_email', email);
										fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
										method: 'POST',
											headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
												body: new URLSearchParams({
													action: 'custom_submit_comment',
													post_id: postId,
													parent_id: parentId,
													author: author,
													email: email,
													content: content
												})
									})
										.then(res => res.json())
											.then(data => {
											if (data.success) {
												alert('Bình luận đã được gửi!');
												container.innerHTML = '';
												container.style.display = 'none';
												location.reload();
											} else {
												alert(data.message || 'Đã xảy ra lỗi.');
											}
										});
								});

							} else {
								container.innerHTML = '';
								container.style.display = 'none';
								currentVisibleForm = null;
							}
						});
					});

					// =========================
					// Xem thêm reply
					// =========================
					document.querySelectorAll('.load-more-replies').forEach(button => {
						button.addEventListener('click', function () {
							button.style.position = "static";
							button.style.top = "0px";
							button.style.left = "0px";
							const container = button.closest('.post__comment_replies');
							const replies = container.querySelectorAll('.post__comment_item.reply');
							let current = parseInt(button.getAttribute('data-current')) || 0;
							let next = current + 3;
							let total = replies.length;

							for (let i = current; i < next && i < total; i++) {
								replies[i].style.display = 'flex';
							}

							button.setAttribute('data-current', next);

							if (next >= total) {
								button.style.display = 'none';
							}
						});
					});
				});
			</script>



			<div id="comment-form" class="form__contact item">
				<p class="form__title text--gradient" style="display: flex; justify-content:start; align-items:center;">
					Bình luận của bạn
				</p>
				<p class="form__content">Địa chỉ email của bạn sẽ không được công khai. Các trường bắt buộc được đánh dấu *</p>
				<form id="main-comment-form">
					<?php wp_nonce_field('comment_form'); ?>
					<input type="hidden" name="comment_post_ID" value="<?php echo get_the_ID(); ?>" />
					<input type="hidden" name="comment_parent" id="comment_parent" value="0" />

					<div class="form_rows">
						<div class="form_group" style="margin-right: 20px;">
							<input id="author" name="author" type="text" value="<?php echo isset($_POST['author']) ? esc_attr($_POST['author']) : ''; ?>" required>
							<div class="underline"></div>
							<label for="name">Họ và tên*</label>
						</div>
						<div class="form_group">
							<input type="email" id="email" name="email" value="<?php echo isset($_POST['email']) ? esc_attr($_POST['email']) : ''; ?>" required>
							<div class="underline"></div>
							<label for="email">Email*</label>
						</div>
					</div>
					<div class="form_rows">
						<div class="form_group textarea">
							<textarea id="comment" name="comment" rows="8" cols="80" required><?php echo isset($_POST['comment']) ? esc_textarea($_POST['comment']) : ''; ?></textarea>
							<br />
							<div class="underline"></div>
							<label for="message">Lời nhắn</label>
						</div>
					</div>
					<style>
						button .icon-button-arrow.right .homenest-icon path{
							fill: white;
						}
					</style>
					<p class="form__save_contact">"Lưu tên, email và website của tôi trên trình duyệt này để lần sau tôi bình luận."</p>
					<button type="submit" name="submit" id="submit" class="submit">
						<span class="icon-button-arrow left"></span>
						Gửi bình luận
						<span class="icon-button-arrow right"><i class="homenest-icon-arrow-right"></i></span>
					</button>
				</form>
			</div>
		</div>

		<script>
			document.addEventListener('DOMContentLoaded', function () {
				console.log("2");
				const commentForm = document.getElementById('main-comment-form');
				if (commentForm) {
					commentForm.addEventListener('submit', function (e) {
						e.preventDefault();

						const author = commentForm.querySelector('[name="author"]').value.trim();
						const email = commentForm.querySelector('[name="email"]').value.trim();
						const content = commentForm.querySelector('[name="comment"]').value.trim();
						const postId = commentForm.querySelector('[name="comment_post_ID"]').value;

						if (!author || !email || !content) {
							alert('Vui lòng điền đầy đủ thông tin.');
							return;
						}

						fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
							method: 'POST',
							headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
							body: new URLSearchParams({
								action: 'custom_submit_comment',
								post_id: postId,
								parent_id: 0,
								author: author,
								email: email,
								content: content
							})
						})
							.then(res => res.json())
							.then(data => {
							if (data.success) {
								alert('Bình luận đã được gửi!');
								location.reload();
							} else {
								alert(data.message || 'Đã xảy ra lỗi khi gửi bình luận.');
							}
						});
					});
				}
			});
		</script>
		<div class="related-posts">
			<h2><del class="text--gradient item">Dự Án Khác</del></h2>
			<hr style="width: 200px; margin: 20px 0;">

			<?php
			$current_id = get_the_ID();

			// 1. Truy vấn các bài liên quan theo taxonomy: danh-muc-du-an
			$danh_muc_terms = get_the_terms($current_id, 'danh-muc-du-an');
			$danh_muc_ids = ($danh_muc_terms && !is_wp_error($danh_muc_terms)) ? wp_list_pluck($danh_muc_terms, 'term_id') : [];

			$related_by_danh_muc = new WP_Query([
				'post_type' => 'project',
				'posts_per_page' => 3,
				'post__not_in' => [$current_id],
				'tax_query' => [
					[
						'taxonomy' => 'danh-muc-du-an',
						'field' => 'term_id',
						'terms' => $danh_muc_ids,
					],
				],
			]);

			$excluded_ids = [$current_id]; // để loại trừ trong truy vấn tiếp theo

			if ($related_by_danh_muc->have_posts()) :
			echo '<ul class="related-posts__list item">';
			while ($related_by_danh_muc->have_posts()) : $related_by_danh_muc->the_post();
			$excluded_ids[] = get_the_ID();
			?>
			<li>
				<div class="card__container">
					<div class="card__image">
						<a href="<?php the_permalink(); ?>">
							<?php if (has_post_thumbnail()) : ?>
							<img src="<?php the_post_thumbnail_url('medium'); ?>" alt="<?php the_title(); ?>">
							<?php endif; ?>
						</a>
						<div class="card__time">
							<div class="time__main"><?php echo get_the_date(); ?> / <?php the_author(); ?></div>
							<div class="rectangle"></div>
						</div>
					</div>
					<div class="card__content">
						<a style="text-decoration: none;" href="<?php the_permalink(); ?>">
							<h2 class="text--gradient"><?php the_title(); ?></h2>
						</a>
						<p><?php echo wp_trim_words(get_the_excerpt(), 20, '...'); ?></p>
						<div class="card__breadcrumb">
							/ 
							<?php
							$terms = get_the_terms(get_the_ID(), 'danh-muc-du-an');
							if ($terms && !is_wp_error($terms)) {
								$term_links = array();
								foreach ($terms as $term) {
									$term_links[] = '<a href="' . esc_url(get_term_link($term)) . '">' . esc_html($term->name) . '</a>';
								}
								echo implode(' / ', $term_links); 
							}
							?> /
						</div>
					</div>
				</div>
			</li>
			<?php
			endwhile;
			echo '</ul>';
			endif;

			wp_reset_postdata();
			?> 
			<h2><del class="text--gradient item">Cùng Chuyên Ngành</del></h2>
			<hr style="width: 200px; margin: 20px 0;">  
			<?php
			// 2. Truy vấn các bài viết còn lại theo chuyên ngành
			$chuyen_nganh_terms = get_the_terms($current_id, 'chuyen-nganh');
			$chuyen_nganh_ids = ($chuyen_nganh_terms && !is_wp_error($chuyen_nganh_terms)) ? wp_list_pluck($chuyen_nganh_terms, 'term_id') : [];

			$related_by_chuyen_nganh = new WP_Query([
				'post_type' => 'project',
				'posts_per_page' => -1,
				'post__not_in' => $excluded_ids,
				'tax_query' => [
					[
						'taxonomy' => 'chuyen-nganh',
						'field' => 'term_id',
						'terms' => $chuyen_nganh_ids,
					],
				],
			]);

			if ($related_by_chuyen_nganh->have_posts()) :
			echo '<div class="related-posts-2 item">';
			echo '<ul class="related-posts-2__list">';
			while ($related_by_chuyen_nganh->have_posts()) : $related_by_chuyen_nganh->the_post();
			?>
			<li>
				<div class="post__item">
					<div class="post__date">
						<span class="day">
							<del class="text--gradient"><?php echo get_the_date('d'); ?></del>
						</span>
						<span class="month-year">
							<del class="text--gradient"><?php echo get_the_date('M Y'); ?></del>
						</span>
					</div>
					<div class="post__content">
						<h3 class="post__title">
							<a href="<?php the_permalink(); ?>">
								<del class="text--gradient"><?php the_title(); ?></del>
							</a>
						</h3>
						<p class="post__excrept"><?php echo wp_trim_words(get_the_excerpt(), 25, '...'); ?></p>
						<div style="display: flex; justify-content:space-between; padding-right:20px;">
							<div class="post__breadcrumb">/ 
								<?php
								$terms = get_the_terms(get_the_ID(), 'chuyen-nganh');
								if ($terms && !is_wp_error($terms)) {
									$term_links = array();
									foreach ($terms as $term) {
										$term_links[] = '<a href="' . esc_url(get_term_link($term)) . '">' . esc_html($term->name) . '</a>';
									}
									echo implode(' / ', $term_links);
								}
								?> /
							</div>
							<a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>" class="post__author">
								<?php the_author(); ?>
							</a>
						</div>
					</div>
				</div>
			</li>
			<?php
			endwhile;
			echo '</ul></div>';
			endif;

			wp_reset_postdata();
			?>
			<div class="custom-cursor"></div>
		</div>
		
		<script>
			document.addEventListener("DOMContentLoaded", function() {
				console.log("1");
				const counters = document.querySelectorAll('.count');
				const items = document.querySelectorAll('.item');
				const speed = 200;

				// Gộp 2 tập phần tử vào 1 array để observe
				const targets = [...counters, ...items];

				const observer = new IntersectionObserver((entries, observer) => {
					entries.forEach(entry => {
						if(entry.isIntersecting) {
							const el = entry.target;

							// Nếu là phần tử .count thì chạy đếm số
							if(el.classList.contains('count')) {
								const updateCount = () => {
									const target = +el.getAttribute('data-target');
									let count = +el.innerText;
									const increment = Math.ceil(target / speed);

									if(count < target) {
										el.innerText = count + increment > target ? target : count + increment;
										setTimeout(updateCount, 20);
									} else {
										el.innerText = target;
									}
								};
								updateCount();

								// Nếu là phần tử .item thì thêm class visible để hiện hiệu ứng
							} else if (el.classList.contains('item')) {
								el.classList.add('visible');
							}

							// Unobserve sau khi xử lý
							observer.unobserve(el);
						}
					});
				}, { threshold: 0.1 });

				targets.forEach(el => observer.observe(el));
			});
		</script>

		<script>
			const cursor = document.querySelector('.custom-cursor');
			const areas = document.querySelectorAll('.custom-cursor-area');

			areas.forEach(area => {
				area.addEventListener('mouseenter', () => {
					cursor.style.display = 'block';
				});
				area.addEventListener('mouseleave', () => {
					cursor.style.display = 'none';
				});
			});

			document.addEventListener('mousemove', (e) => {
				cursor.style.left = e.pageX + 'px';
				cursor.style.top = e.pageY + 'px';
			});
		</script>
		</body>
	<?php
	endwhile;
	endif;

	get_footer(); // Gọi footer
	?>
