<?php get_header(); ?>
<div id="wrapper">
	<section id="homenest__service-archive-container">
		<div class="service-title">
			<div class="service-title-name1">
				<div class="title-name">
					<h3>
						<span> We Are Creative AI </span>
					</h3>
				</div>
				<div class="button-service">
					<a style="--d-in: 0.75s" class="button _txt" href="#">
						<span data-text="Discover More">
							<span style="--d: 0.1s">D</span>
							<span style="--d: 0.125s">i</span>
							<span style="--d: 0.15s">s</span>
							<span style="--d: 0.175s">c</span>
							<span style="--d: 0.2s">o</span>
							<span style="--d: 0.225s">v</span>
							<span style="--d: 0.25s">e</span>
							<span style="--d: 0.275s">r</span>
							<span style="--d: 0.3s">&nbsp;</span>
							<span style="--d: 0.325s">M</span>
							<span style="--d: 0.35s">o</span>
							<span style="--d: 0.375s">r</span>
							<span style="--d: 0.4s">e</span>
						</span>
						<i class="fa-solid fa-arrow-up-right"></i>
					</a>
				</div>
			</div>
			<div class="service-title-name2">
				<div class="title-img">
					<img src="/wp-content/uploads/2025/06/nebula.webp" alt="">
				</div>
				<div class="title-name">
					<h3>
						<span> Design Studio </span>
					</h3>
					<p>Artificial Intelligence encompasses the creation of computer systems capable of executing
						tasks usually necessitating human intelligence</p>
				</div>
			</div>
		</div>
	</section>
	<section id="homenest__service-archive-background-container">
		<div class="hero-section">
			<div class="scroll-button">
				<a href="#homenest__services" class="scroll-link">
					<div class="btn-title">
						<span>Scroll Down</span>
					</div>
					<div class="btn-icon">
						<i class="fa-solid fa-arrow-right"></i>
					</div>
				</a>
			</div>
			<div class="curve-images">
				<div class="box">
					<div class="box1">
						<img src="/wp-content/uploads/2025/06/img-box-1-2-1-1400x1400-1.webp" class="curve-img img1" alt="Image 1">
					</div>
					<div class="box2">
						<img src="/wp-content/uploads/2025/06/img-box2.webp" class="curve-img img2" alt="Image 2">
					</div>
					<div class="box3">
						<img src="/wp-content/uploads/2025/06/img-box3.webp" class="curve-img img3" alt="Image 3">
					</div>
				</div>
				<div class="user-counter">
					<div class="elementor-widget-container">
						<div class="pxl--user-count-widget pxl--user-count-widget1 style-2" data-wow-delay="ms">
							<div class="pxl-background">
								<div class="pxl-background bg-image"
									 style="background-image: url(https://demo.casethemes.net/aimo/wp-content/uploads/2024/11/Subtract.webp);">
								</div>
							</div>
							<div class="pxl-counter--holder">
								<div class="pxl-counter--number">
									<span class="counter--number">20</span>
									<span class="counter--suffix">k+</span>
									<span class="counter--plus"></span>
								</div>
								<div class="pxl-content">
									<div class="pxl-counter--title">Customers</div>
									<div class="pxl-counter--desc">Download our Apps to enjoy ai magic!</div>
								</div>
								<div class="pxl-item-inner">
									<div class="pxl-item--images el-empty">
										<div class="pxl-item--img">
											<img loading="lazy" decoding="async" width="300" height="300"
												 src="https://demo.casethemes.net/aimo/wp-content/uploads/2024/11/avatar3.webp"
												 class="attachment-full" alt="">
										</div>
										<div class="pxl-item--img">
											<img loading="lazy" decoding="async" width="300" height="300"
												 src="https://demo.casethemes.net/aimo/wp-content/uploads/2024/11/avatar2.webp"
												 class="attachment-full" alt="">
										</div>
										<div class="pxl-item--img">
											<img loading="lazy" decoding="async" width="300" height="300"
												 src="https://demo.casethemes.net/aimo/wp-content/uploads/2024/11/avatar5.webp"
												 class="attachment-full" alt="">
										</div>
										<div class="pxl-item--img">
											<img loading="lazy" decoding="async" width="300" height="300"
												 src="https://demo.casethemes.net/aimo/wp-content/uploads/2024/11/avatar4.webp"
												 class="attachment-full" alt="">
										</div>
										<div class="pxl-item--img">
											<img loading="lazy" decoding="async" width="300" height="300"
												 src="https://demo.casethemes.net/aimo/wp-content/uploads/2024/11/avatar1-1.webp"
												 class="attachment-full" alt="">
										</div>
										<div class="pxl-item--title">more+</div>
									</div>
								</div>
								<div class="pxl-button">
									<a class="pxl-item--link" href="https://h3.homenest.tech/contact/">
										<div class="pxl-item--icon">
											<svg xmlns="http://www.w3.org/2000/svg" width="33" height="33"
												 viewBox="0 0 33 33" fill="none">
												<path
													  d="M27.6758 9.104L4.72379 32.056L0.953125 28.2853L23.9024 5.33333H3.67579V0H33.0091V29.3333H27.6758V9.104Z"
													  fill="url(#paint0_linear_1_188)"></path>
												<defs>
													<linearGradient id="paint0_linear_1_188" x1="16.9811" y1="0"
																	x2="16.9811" y2="32.056" gradientUnits="userSpaceOnUse">
														<stop stop-color="#F8B6BC"></stop>
														<stop offset="0.465" stop-color="#771A99"></stop>
														<stop offset="1" stop-color="#BD6FFD"></stop>
													</linearGradient>
												</defs>
											</svg>
										</div>
									</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

		</div>
	</section>
	<section id="homenest__about-us" class="homenest__about-us__container">
		<div class="homenest__about-us__content">
			<!-- Add floating images -->
			<img src="/wp-content/uploads/2025/06/Rectangle-673-249x302-1.webp" alt="Floating Image 1" class="homenest__about-us__float-img float-1">
			<img src="/wp-content/uploads/2025/06/Rectangle-675-293x370-1.webp" alt="Floating Image 2" class="homenest__about-us__float-img float-2">
			<img src="/wp-content/uploads/2025/06/Rectangle-674-184x184-1.webp" alt="Floating Image 3" class="homenest__about-us__float-img float-3">

			<div class="homenest__about-us__heading">
				<span class="gradient-text">ABOUT US</span>
			</div>

			<div class="homenest__about-us__title">
				<h2>Machine intelligence involves</h2>
				<div class="title-with-icon">
					<span class="gray-text">creating computer</span>
					<div class="btn-video-container">
						<div class="btn-video-wrap">
							<a class="pxl-btn-video pxl-action-popup style5" href="https://www.youtube.com/watch?v=SF4aHwxHtZ0"> <i aria-hidden="true" class="fas fa-play-circle"></i>
							</a>
						</div>
					</div>
					<span class="gray-text">systems</span>
				</div>
				<div class="gray-text">capable of tasks usually needing human</div>
				<div class="gray-text">smarts. It encompasses developing</div>
				<div class="gray-text">algorithms and models that allow</div>
				<div class="gray-text">machines to learn, think, sense, and</div>
				<div class="team-text">decide, <div class="team-icons">
					<img src="/wp-content/uploads/2025/06/img-text-h4.webp" alt="Team member">
					</div><span class="emphasis-text">mimicking human-like</span></div>
				<div class="emphasis-text">cognitive abilities.</div>
			</div>
			<div class="homenest__about-us__button-service">
				<div class="button-service2">
					<a style="--d-in: 0.75s" class="button _txt2" href="https://h3.homenest.tech/contact/" target="blank">
						<span data-text="Know About Us">
							<span style="--d: 0.1s">k</span>
							<span style="--d: 0.125s">n</span>
							<span style="--d: 0.15s">o</span>
							<span style="--d: 0.175s">w</span>
							<span style="--d: 0.3s">&nbsp;</span>
							<span style="--d: 0.2s">A</span>
							<span style="--d: 0.225s">b</span>
							<span style="--d: 0.25s">o</span>
							<span style="--d: 0.275s">u</span>
							<span style="--d: 0.325s">t</span>
							<span style="--d: 0.3s">&nbsp;</span>
							<span style="--d: 0.35s">U</span>
							<span style="--d: 0.375s">s</span>
						</span>
						<i class="fa-solid fa-arrow-up-right"></i>
					</a>
				</div>
			</div>

		</div>
	</section>
	<section id="homenest__services" class="homenest__services__container">
		<img src="/wp-content/uploads/2025/06/robot-ss4-h4.webp" alt="Service Shape" class="service-shape">
		<div class="homenest__services__content">
			<div class="homenest__services__heading">
				<div class="homenest__services__tag-wrapper">
					<span class="gradient-text text-service">SERVICES</span>
					<h2 class="scrollTextEffect">
						<span class="text-gradient">Services Designed To Meet All Your Needs</span>
					</h2>
					<p>We specialize in crafting intelligent AI driven solutions, from advanced data analytics automated workflows, empowering businesses.</p>
					<div class="button-service3">
						<a style="--d-in: 0.75s" class="button _txt2" href="https://h3.homenest.tech/services/seo-tong-the/" target="blank">
							<span data-text="View All Service ">
								<span style="--d: 0.1s">V</span>
								<span style="--d: 0.125s">i</span>
								<span style="--d: 0.15s">e</span>
								<span style="--d: 0.175s">w</span>
								<span style="--d: 0.3s">&nbsp;</span>
								<span style="--d: 0.2s">A</span>
								<span style="--d: 0.225s">l</span>
								<span style="--d: 0.25s">l</span>
								<span style="--d: 0.3s">&nbsp;</span>
								<span style="--d: 0.275s">S</span>
								<span style="--d: 0.325s">e</span>
								<span style="--d: 0.35s">r</span>
								<span style="--d: 0.375s">v</span>
								<span style="--d: 0.375s">i</span>
								<span style="--d: 0.375s">c</span>
								<span style="--d: 0.375s">e</span>
							</span>
							<i class="fa-solid fa-arrow-up-right"></i>
						</a>
					</div>
				</div>

			</div>

			<div class="homenest__services__cards">
				<!-- Card 1 -->
				<div class="service-card">
					<div class="service-image">
						<img src="/wp-content/uploads/2025/06/service-h4-3.webp " alt="Data Analytics and Insights">
					</div>
					<div class="service-content">
						<h3>Data Analytics and Insights</h3>
						<div class="service-item--inner" style="translate: none; rotate: none; scale: none; transform: translate(0%, 0px);">
						</div>
						<p>Integrating intelligent data analytics to help businesses gain deeper insights into customers, optimize strate...</p>
					</div>
					<div class="service-link-container">
						<img src="/wp-content/uploads/2025/06/service-ovl-h4-3.webp" alt="">
						<a href="#" class="service-link">
							<svg class="service-arrow-icon" width="40" height="40" viewBox="0 0 40 40">
								<path d="M20 0L16.84 3.16L30.68 17H0V21H30.68L16.84 34.84L20 38L40 18L20 0Z" />
							</svg>
						</a>
					</div>
				</div>

				<!-- Card 2 -->
				<div class="service-card">
					<div class="service-image">
						<img src="/wp-content/uploads/2025/06/service-h4-1.webp" alt="Machine Learning Solutions">
					</div>
					<div class="service-content">
						<h3>Machine Learning Solutions</h3>
						<div class="service-item--inner" style="translate: none; rotate: none; scale: none; transform: translate(0%, 0px);">
						</div>
						<p>Providing advanced machine learning solutions to optimize processes and improve decision-marking capabilities...</p>
					</div>
					<div class="service-link-container">
						<img src="/wp-content/uploads/2025/06/service-ovl-h4-4.webp" alt="">
						<a href="#" class="service-link">
							<svg class="service-arrow-icon" width="40" height="40" viewBox="0 0 40 40">
								<path d="M20 0L16.84 3.16L30.68 17H0V21H30.68L16.84 34.84L20 38L40 18L20 0Z" />
							</svg>
						</a>
					</div>
				</div>

				<!-- Card 3 -->
				<div class="service-card">
					<div class="service-image">
						<img src="/wp-content/uploads/2025/06/service-h4-2.webp" alt="AI Development">
					</div>
					<div class="service-content">
						<h3>AI Development</h3>
						<div class="service-item--inner" style="translate: none; rotate: none; scale: none; transform: translate(0%, 0px);">
						</div>
						<p>Building custom AI solutions that automate tasks, enhance efficiency, and drive innovation across various industries...</p>

					</div>
					<div class="service-link-container">
						<img src="/wp-content/uploads/2025/06/service-ovl-h4-2.webp" alt="">
						<a href="#" class="service-link">
							<svg class="service-arrow-icon" width="40" height="40" viewBox="0 0 40 40">
								<path d="M20 0L16.84 3.16L30.68 17H0V21H30.68L16.84 34.84L20 38L40 18L20 0Z" />
							</svg>
						</a>
					</div>
				</div>

				<!-- Card 4 -->
				<div class="service-card">
					<div class="service-image">
						<img src="/wp-content/uploads/2025/06/service-h4-4.webp" alt="Predictive Analytics">
					</div>
					<div class="service-content">
						<h3>Predictive Analytics</h3>
						<div class="service-item--inner" style="translate: none; rotate: none; scale: none; transform: translate(0%, 0px);">
						</div>
						<p>Leveraging advanced algorithms and machine learning to forecast trends and make data-driven business decisions...</p>

					</div>
					<div class="service-link-container">
						<img src="/wp-content/uploads/2025/06/service-ovl-h4-1.webp" alt="">
						<a href="#" class="service-link">
							<svg class="service-arrow-icon" width="40" height="40" viewBox="0 0 40 40">
								<path d="M20 0L16.84 3.16L30.68 17H0V21H30.68L16.84 34.84L20 38L40 18L20 0Z" />
							</svg>
						</a>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section id="homenest__fun-facts" class="homenest__fun-facts__container">
		<div class="homenest__fun-facts__content">
			<div class="homenest__fun-facts__header">
				<span class="fun-facts-tag">Fun Facts</span>
				<h2>We Are Happy For Our Achievement</h2>
				<p class="fun-facts-title">Aimo handles over 80% of daily customer service interactions, taking the load off teams while making customer experiences feel magical.</p>
				<div class="app-buttons">
					<a href="#" class="app-store">
						<div class="app-container">
							<p class="download">
								Download on the
							</p>
							<p class="nameapp">
								App Store
							</p>
						</div>
						<div class="fun-facts-icon">
							<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="#fff" height="25px" width="21px" id="Capa_1" viewBox="0 0 22.773 22.773" xml:space="preserve" stroke="#ffffff">
								<g id="SVGRepo_bgCarrier" stroke-width="0"></g>
								<g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
								<g id="SVGRepo_iconCarrier">
									<g>
										<g>
											<path d="M15.769,0c0.053,0,0.106,0,0.162,0c0.13,1.606-0.483,2.806-1.228,3.675c-0.731,0.863-1.732,1.7-3.351,1.573 c-0.108-1.583,0.506-2.694,1.25-3.561C13.292,0.879,14.557,0.16,15.769,0z"></path>
											<path d="M20.67,16.716c0,0.016,0,0.03,0,0.045c-0.455,1.378-1.104,2.559-1.896,3.655c-0.723,0.995-1.609,2.334-3.191,2.334 c-1.367,0-2.275-0.879-3.676-0.903c-1.482-0.024-2.297,0.735-3.652,0.926c-0.155,0-0.31,0-0.462,0 c-0.995-0.144-1.798-0.932-2.383-1.642c-1.725-2.098-3.058-4.808-3.306-8.276c0-0.34,0-0.679,0-1.019 c0.105-2.482,1.311-4.5,2.914-5.478c0.846-0.52,2.009-0.963,3.304-0.765c0.555,0.086,1.122,0.276,1.619,0.464 c0.471,0.181,1.06,0.502,1.618,0.485c0.378-0.011,0.754-0.208,1.135-0.347c1.116-0.403,2.21-0.865,3.652-0.648 c1.733,0.262,2.963,1.032,3.723,2.22c-1.466,0.933-2.625,2.339-2.427,4.74C17.818,14.688,19.086,15.964,20.67,16.716z"></path>
										</g>
										<g> </g>
										<g> </g>
										<g> </g>
										<g> </g>
										<g> </g>
										<g> </g>
										<g> </g>
										<g> </g>
										<g> </g>
										<g> </g>
										<g> </g>
										<g> </g>
										<g> </g>
										<g> </g>
										<g> </g>
									</g>
								</g>
							</svg>
						</div>
					</a>
					<a href="#" class="play-store">
						<div class="app-container">
							<p class="comingsoon">
								Coming Soon to
							</p>
							<p class="nameapp">
								Google Play
							</p>
						</div>
						<div class="fun-facts-icon">
							<i class="fa-brands fa-google-play"></i>
						</div>
					</a>
				</div>
			</div>

			<div class="homenest__fun-facts__stats">
				<div class="stat-item">
					<div>
						<h3>
							<span class="counter-number">43000</span>
						</h3>
					</div>
					<span class="activeCustomers stat-title">Active Customers</span>
				</div>
				<div class="stat-item">
					<div>
						<h3>
							<span class="counter-number">205</span>
						</h3>
					</div>
					<span class="teamMembers stat-title">Team Members</span>
				</div>
			</div>

			<div class="homenest__fun-facts__stats2">
				<div class="stat-item">
					<div>
						<h3>
							<span class="counter-number">205</span>
						</h3>
					</div>
					<span class="clientsSatisfactoryReviews stat-title">Clients Satisfactory Reviews</span>
				</div>
				<div class="stat-item">
					<div>
						<h3>
							<span class="counter-number">95</span>
							<span class="counter-suffix">%</span>
							<span class="counter--plus"></span>
						</h3>
					</div>
					<span class="successRate stat-title">Success Rate</span>
				</div>
			</div>
		</div>
	</section>
	<section id="homenest__why-choose-us" class="homenest__why-choose-us__container">
		<div class="homenest__why-choose-us__content">
			<!-- Left Column - Images -->
			<div class="img-background">
				<img src="/wp-content/uploads/2025/06/img-1-1.webp" alt="AI Innovation" class="main-image">
			</div>
			<div class="homenest__why-choose-us__images">
				<img src="/wp-content/uploads/2025/06/Union1.webp" alt="AI Innovation" class="main-image">
				<div class="testimonial-card">
					<div class="testimonial-avatar">
						<img src="/wp-content/uploads/2025/06/img1-process-h3-140x124-1.webp" alt="Feature Image" class="feature-image">
					</div>
					<p>"This is due to their excellent service, competitive pricing and support. It's throughly refreshing to get such a personal touch."</p>
				</div>
			</div>

			<!-- Right Column - Content -->
			<div class="homenest__why-choose-us__info">
				<div style="padding-left: 51px;
							max-width: 700px;">
					<span class="tag gradient-text">WHY CHOOSE US</span>
					<h2 class="scrollTextEffect "><span class="text-gradient">Empowering Innovation With Intelligent AI Solutions Built For Your Success.</span></h2>
					<p>We deliver custom AI solutions designed to drive innovation, streamline operations, and unlock new growth opportunities tailored</p>
				</div>
				<div class="features-container">
					<img src="/wp-content/uploads/2025/06/Subtract1.webp" alt="Bottom Image" class="bottom-image">
					<div class="features-list-container">
						<ul class="features-list">
							<li>Enterprise ready</li>
							<li>Most advanced technology</li>
							<li>Cost-Effectiveness</li>
							<li>Unlock Cross-Platform AI</li>
							<li>Startup friendly</li>
						</ul>

						<div class="button-service4">
							<a style="--d-in: 0.75s" class="button _txt" href="#">
								<span data-text="Learn All More">
									<span style="--d: 0.1s">L</span>
									<span style="--d: 0.125s">e</span>
									<span style="--d: 0.15s">a</span>
									<span style="--d: 0.175s">r</span>
									<span style="--d: 0.2s">n</span>
									<span style="--d: 0.3s">&nbsp;</span>
									<span style="--d: 0.225s">A</span>
									<span style="--d: 0.25s">l</span>
									<span style="--d: 0.275s">l</span>
									<span style="--d: 0.3s">&nbsp;</span>
									<span style="--d: 0.325s">M</span>
									<span style="--d: 0.35s">o</span>
									<span style="--d: 0.375s">r</span>
									<span style="--d: 0.4s">e</span>
								</span>
								<i class="fa-solid fa-arrow-up-right"></i>
							</a>
						</div>
					</div>
				</div>

			</div>
		</div>
	</section>
	<section id="homenest__process" class="homenest__process__container">
		<div class="homenest__process__content">
			<div class="homenest__process__stats">
				<div class="process-stat">
					<div class="stat-bubble purple">
						<div class="process__stats-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="url(#paint0_linear_1_408)">
								<g clip-path="url(#clip0_1_408)">
									<path d="M5.41772 6.58228L6.48681 7.65132L11.244 2.89413L11.244 24L12.756 24L12.756 2.89413L17.5132 7.65132L18.5822 6.58228L12 -2.87718e-07L5.41772 6.58228Z"></path>
								</g>
								<defs>
									<linearGradient id="paint0_linear_1_408" x1="12" y1="-2.8772e-07" x2="12" y2="24" gradientUnits="userSpaceOnUse">
										<stop stop-color="white"></stop>
										<stop offset="1" stop-color="#999999" stop-opacity="0"></stop>
									</linearGradient>
									<clipPath id="clip0_1_408">
										<rect width="24" height="24" fill="white" transform="translate(0 24) rotate(-90)"></rect>
									</clipPath>
								</defs>
							</svg>
						</div>
						<h3>
							<span class="counter-number">99</span>
							<span class="counter-suffix">%</span>
							<span class="counter-plus"></span>
						</h3>
						<p>Client easily conversions growth increased.</p>
					</div>
				</div>

				<div class="process-image">
					<img src="/wp-content/uploads/2025/06/woman-futuristic1.webp" alt="AI Process" class="main-process-img">
				</div>

				<div class="process-stat">
					<div class="stat-bubble orange">
						<div class="process__stats-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="url(#paint0_linear_1_408)">
								<g clip-path="url(#clip0_1_408)">
									<path d="M5.41772 6.58228L6.48681 7.65132L11.244 2.89413L11.244 24L12.756 24L12.756 2.89413L17.5132 7.65132L18.5822 6.58228L12 -2.87718e-07L5.41772 6.58228Z"></path>
								</g>
								<defs>
									<linearGradient id="paint0_linear_1_408" x1="12" y1="-2.8772e-07" x2="12" y2="24" gradientUnits="userSpaceOnUse">
										<stop stop-color="white"></stop>
										<stop offset="1" stop-color="#999999" stop-opacity="0"></stop>
									</linearGradient>
									<clipPath id="clip0_1_408">
										<rect width="24" height="24" fill="white" transform="translate(0 24) rotate(-90)"></rect>
									</clipPath>
								</defs>
							</svg>
						</div>
						<h3>
							<span class="counter-number">30</span>
							<span class="counter-plus">+</span>
						</h3>
						<p>Our 30+ years of web design & development expertise.</p>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="homenest__process-steps-container">
		<div class="img-background2">
			<img src="/wp-content/uploads/2025/06/mask-group-prs-h4.webp" alt="AI Innovation">
		</div>
		<div class="homenest__process-steps">
			<div class="process-steps__content">
				<div class="process-steps__header">
					<span class="process-steps__tag gradient-text">EASY STEPS</span>
					<h2 class="process-steps__title scrollTextEffect">
						<span class="text-gradient">
							Our Process Is Divided Into Three<br>Key Phases
						</span>
					</h2>
				</div>

				<div class="process-steps__cards-container">
					<div class="process-steps__cards1">
						<div class="step-card pink">
							<h3 class="step-card__title">Step 1: Vision</h3>
							<img src="/wp-content/uploads/2025/06/service-h4-3-88x88-1.webp" alt="Step 1" class="step-card__icon">
							<p class="step-card__desc">We'll learn about your business goals and explore how AI can improve your operations.</p>
							<div class="step-icon">
								<svg xmlns="http://www.w3.org/2000/svg" width="140" height="140" viewBox="0 0 140 140" fill="#fff">
									<g opacity="0.32">
										<path d="M135.625 68.3594H71.636V44.0188C71.636 25.4007 55.8031 10.2539 37.185 10.2539C18.567 10.2539 2.73438 25.4007 2.73438 44.0188V70C2.73438 70.9059 3.4691 71.6406 4.375 71.6406H68.364V95.9812C68.364 114.599 84.1969 129.746 102.815 129.746C121.433 129.746 137.266 114.599 137.266 95.9812V70C137.266 69.0938 136.531 68.3594 135.625 68.3594H135.625ZM47.2218 68.3594H27.1485V44.68C27.1485 39.1508 31.6509 34.6525 37.1853 34.6525C42.7197 34.6525 47.2218 39.1508 47.2218 44.68V68.3594ZM58.3928 68.3594H50.5031V44.68C50.5031 37.3414 44.5288 31.3712 37.1853 31.3712C29.8419 31.3712 23.8673 37.3414 23.8673 44.68V68.3594H15.9775V44.6802C15.9775 32.9957 25.4912 23.4896 37.1853 23.4896C48.8794 23.4896 58.3928 32.9957 58.3928 44.6802V68.3594ZM68.355 68.3594H61.6741V44.6802C61.6741 31.1864 50.6885 20.2084 37.1853 20.2084C23.6821 20.2084 12.6965 31.1864 12.6965 44.6802V68.3594H6.01562V44.0188C6.01562 27.21 20.3766 13.5352 37.1853 13.5352C53.9941 13.5352 68.355 27.21 68.355 44.0188V68.3594ZM92.7782 71.6406H112.851V95.32C112.851 100.849 108.349 105.348 102.815 105.348C97.2803 105.348 92.7782 100.849 92.7782 95.32V71.6406ZM81.6071 71.6406H89.4969V95.32C89.4969 102.659 95.4712 108.629 102.815 108.629C110.158 108.629 116.133 102.659 116.133 95.32V71.6406H124.022V95.32C124.022 107.004 114.509 116.51 102.815 116.51C91.1206 116.51 81.6071 107.004 81.6071 95.32V71.6406ZM133.984 95.9812C133.984 112.79 119.623 126.465 102.815 126.465C86.0059 126.465 71.645 112.79 71.645 95.9812V71.6406H78.3259V95.32C78.3259 108.814 89.3115 119.792 102.815 119.792C116.318 119.792 127.304 108.814 127.304 95.32V71.6406H133.985V95.9812H133.984Z"></path>
										<path d="M37.3222 78.1406C31.1007 78.1406 26.0391 83.1989 26.0391 89.4166C26.0391 95.6343 31.1007 100.692 37.3222 100.692C43.5437 100.692 48.6056 95.6341 48.6056 89.4166C48.6056 83.1992 43.5437 78.1406 37.3222 78.1406ZM37.3222 97.4114C32.91 97.4114 29.3203 93.825 29.3203 89.4169C29.3203 85.0088 32.91 81.4222 37.3222 81.4222C41.7344 81.4222 45.3243 85.0086 45.3243 89.4169C45.3243 93.8253 41.7346 97.4114 37.3222 97.4114Z"></path>
										<path d="M37.1855 106.875C30.9639 106.875 25.9023 111.933 25.9023 118.151C25.9023 124.368 30.9639 129.426 37.1855 129.426C43.407 129.426 48.4689 124.368 48.4689 118.151C48.4689 111.933 43.407 106.875 37.1855 106.875ZM37.1855 126.146C32.7733 126.146 29.1836 122.559 29.1836 118.151C29.1836 113.743 32.7733 110.157 37.1855 110.157C41.5977 110.157 45.1876 113.743 45.1876 118.151C45.1876 122.559 41.5979 126.146 37.1855 126.146Z"></path>
										<path d="M102.885 11.3848C96.6634 11.3848 91.6016 16.4431 91.6016 22.6608C91.6016 28.8785 96.6634 33.9368 102.885 33.9368C109.106 33.9368 114.168 28.8785 114.168 22.6608C114.168 16.4431 109.106 11.3848 102.885 11.3848ZM102.885 30.6555C98.4725 30.6555 94.8828 27.0691 94.8828 22.6608C94.8828 18.2524 98.4725 14.666 102.885 14.666C107.297 14.666 110.887 18.2524 110.887 22.6608C110.887 27.0691 107.297 30.6555 102.885 30.6555Z"></path>
										<path d="M102.748 40.1191C96.5267 40.1191 91.4648 45.1775 91.4648 51.3949C91.4648 57.6123 96.5267 62.6709 102.748 62.6709C108.97 62.6709 114.031 57.6126 114.031 51.3949C114.031 45.1772 108.97 40.1191 102.748 40.1191ZM102.748 59.3897C98.3358 59.3897 94.7461 55.8032 94.7461 51.3949C94.7461 46.9865 98.3358 43.4004 102.748 43.4004C107.161 43.4004 110.75 46.9868 110.75 51.3949C110.75 55.803 107.16 59.3897 102.748 59.3897Z"></path>
									</g>
								</svg>
							</div>
						</div>
					</div>
					<div class="process-steps__cards2">
						<div class="step-card orange">
							<h3 class="step-card__title">Step 2: Design</h3>
							<img src="/wp-content/uploads/2025/06/service-h4-4-88x88-1.webp" alt="Step 2" class="step-card__icon">
							<p class="step-card__desc">Based on our findings, we create a data-driven AI solution tailored to your needs.</p>
							<div class="step-icon">
								<svg xmlns="http://www.w3.org/2000/svg" width="140" height="140" viewBox="0 0 140 140" fill="#fff">
									<g opacity="0.32">
										<path d="M133.094 90.5827H86.7467V63.5137H105.235C107.299 63.5137 108.977 61.8348 108.977 59.7714V40.9234C108.977 38.86 107.299 37.1811 105.235 37.1811H86.3874C84.3241 37.1811 82.6452 38.86 82.6452 40.9234V59.4119H55.5762V14.8399C55.5762 12.7766 53.8973 11.0977 51.8339 11.0977H24.4216C23.289 11.0977 22.3708 12.0156 22.3708 13.1484C22.3708 14.2813 23.289 15.1992 24.4216 15.1992H51.4749V59.4121H7.26199V15.1995H14.8343C15.9669 15.1995 16.8851 14.2816 16.8851 13.1487C16.8851 12.0159 15.9669 11.0979 14.8343 11.0979H6.90242C4.83906 11.0979 3.16016 12.7768 3.16016 14.8402V59.7717C3.16016 61.8351 4.83879 63.514 6.90242 63.514H51.4747V90.5829H24.0464C21.983 90.5829 20.3041 92.2618 20.3041 94.3252V122.113C20.3041 124.176 21.9828 125.855 24.0464 125.855H51.8342C53.8976 125.855 55.5765 124.176 55.5765 122.113V94.6845H82.6454V122.113C82.6454 124.176 84.3243 125.855 86.3877 125.855H91.9021C93.0347 125.855 93.9529 124.937 93.9529 123.804C93.9529 122.672 93.0347 121.754 91.9021 121.754H86.7467V94.6848H132.734V121.754H101.521C100.389 121.754 99.4703 122.672 99.4703 123.804C99.4703 124.937 100.389 125.855 101.521 125.855H133.094C135.157 125.855 136.836 124.176 136.836 122.113V94.3249C136.836 92.2616 135.157 90.5827 133.094 90.5827ZM86.7467 41.283H104.876V59.4121H86.7467V41.283ZM51.4747 121.753H24.4057V94.6845H51.4747V121.753ZM55.5762 63.5137H82.6452V90.5827H55.5762V63.5137Z"></path>
										<path d="M108.617 19.0641H120.197C122.26 19.0641 123.939 17.3852 123.939 15.3218V3.74227C123.939 1.67891 122.26 0 120.197 0H108.617C106.554 0 104.875 1.67891 104.875 3.74227V15.3221C104.875 17.3852 106.554 19.0641 108.617 19.0641ZM108.977 4.10156H119.838V14.9625H108.977V4.10156Z"></path>
										<path d="M22.3546 135.898H5.21094C4.07836 135.898 3.16016 136.816 3.16016 137.949C3.16016 139.082 4.07836 140 5.21094 140H22.3546C23.4872 140 24.4054 139.082 24.4054 137.949C24.4054 136.816 23.4872 135.898 22.3546 135.898Z"></path>
										<path d="M122.336 61.3887C122.336 62.5215 123.254 63.4395 124.387 63.4395H134.784C135.917 63.4395 136.835 62.5215 136.835 61.3887C136.835 60.2558 135.917 59.3379 134.784 59.3379H124.387C123.254 59.3379 122.336 60.2558 122.336 61.3887Z"></path>
									</g>
								</svg>
							</div>
						</div>
					</div>
					<div class="process-steps__cards3">
						<div class="step-card purple">
							<h3 class="step-card__title">Step 3: Launch</h3>
							<img src="/wp-content/uploads/2025/06/service-h4-2-88x88-1.webp" alt="Step 3" class="step-card__icon">
							<p class="step-card__desc">Launch marks the final phase, where we roll out the project to users, ensuring a smooth transition.</p>
							<div class="step-icon">
								<svg xmlns="http://www.w3.org/2000/svg" width="140" height="140" viewBox="0 0 140 140" fill="#fff">
									<g opacity="0.3">
										<path d="M21.933 90.7834V116.409C21.933 117.315 22.6674 118.049 23.5736 118.049H49.6757L67.8595 136.768C68.1814 137.099 68.6087 137.266 69.0364 137.266C69.4482 137.266 69.8603 137.112 70.1791 136.802L90.1064 117.458L117.871 116.611C118.306 116.598 118.718 116.412 119.016 116.095C119.314 115.779 119.474 115.356 119.46 114.921L118.651 88.4116L136.82 69.0839C137.118 68.7667 137.278 68.3443 137.264 67.9092C137.251 67.4742 137.065 67.0624 136.748 66.7644L118.066 49.2162V23.591C118.066 22.6852 117.332 21.9504 116.426 21.9504H90.3238L72.1402 3.23171C71.5088 2.58203 70.4708 2.56671 69.8206 3.19753L49.8933 22.5413L22.129 23.3884C21.694 23.4016 21.2822 23.5872 20.9841 23.9041C20.6861 24.221 20.5258 24.6435 20.5392 25.0783L21.3486 51.588L3.17952 70.916C2.88147 71.2332 2.72151 71.6556 2.73518 72.0907C2.74858 72.5257 2.93452 72.9375 3.25171 73.2355L21.933 90.7837V90.7834ZM25.2142 114.768V93.8656L37.0844 105.016C37.401 105.313 37.8046 105.46 38.2074 105.46C38.6444 105.46 39.0802 105.287 39.4032 104.943L68.3594 74.1403V114.768H25.2142ZM69.0706 133.305L54.2503 118.049H70C70.9062 118.049 71.6406 117.315 71.6406 116.409V74.0433L100.023 103.26L69.0706 133.305V133.305ZM93.5982 114.069L103.486 104.471C103.798 104.168 103.977 103.753 103.983 103.318C103.99 102.883 103.823 102.463 103.52 102.151L73.7699 71.526L114.815 70.2737L116.131 113.381L93.5979 114.069L93.5982 114.069ZM133.305 68.0323L118.51 83.7716L118.045 68.5338C118.017 67.6282 117.26 66.9134 116.355 66.944L73.9066 68.239L101.864 38.498L133.306 68.032L133.305 68.0323ZM114.785 25.2314V46.1341L102.915 34.9841C102.255 34.3634 101.217 34.3959 100.597 35.0563L71.6406 65.8593V25.2317H114.786L114.785 25.2314ZM70.9294 6.69452L85.7494 21.9504H70C69.0938 21.9504 68.3594 22.6852 68.3594 23.591V65.9566L39.9774 36.7401L70.9294 6.69452ZM46.4018 25.9309L36.5143 35.5288C36.202 35.8318 36.0229 36.2466 36.0166 36.6819C36.0103 37.1169 36.1769 37.5369 36.4804 37.8492L66.2301 68.4739L25.1852 69.7262L23.8692 26.6188L46.4021 25.9311L46.4018 25.9309ZM21.4903 56.2283L21.9554 71.4661C21.9825 72.3548 22.7114 73.0567 23.5944 73.0567C23.6113 73.0567 23.6283 73.0567 23.6452 73.0559L66.0934 71.7609L38.1355 101.502L6.69456 71.9673L21.4903 56.2283Z"></path>
									</g>
								</svg>
							</div>
						</div>
					</div>
				</div>

			</div>
		</div>
	</section>

	<section id="homenest__testimonials">
		<div class="homenest__testimonials__container">
			<div class="testimonials__content-container">
				<div class="testimonials__title">
					<span class="testimonials-tag gradient-text">TESTIMONIALS</span>
					<h2 class="scrollTextEffect">
						<span class="text-gradient">
							See What Our Clients Say<br>About Us
						</span>
					</h2>
				</div>

				<div class="owl-carousel testimonial-carousel">
					<div class="testimonial-item">
						<div class="stars">★ ★ ★ ★ ☆</div>
						<p class="quote">"This AI agency transformed our workflow with intelligent solutions that delivered measurable results. Their expertise and innovation made a lasting impact on our business."</p>
						<div class="author">
							<img src="/wp-content/uploads/2025/06/user-5-64x64-1.webp" alt="Avatar">
							<div class="info">
								<strong>Leslie Alexander</strong>
								<span>Web Developer</span>
							</div>
						</div>
					</div>

					<div class="testimonial-item">
						<div class="stars">★ ★ ★ ★ ★</div>
						<p class="quote">"Thanks to their expert industrial service, our machinery runs flawless. Downtime is minimised, boosting our productivity significantly. Truly a game-changer for our operations."</p>
						<div class="author">
							<img src="/wp-content/uploads/2025/06/user-2-64x64-1.webp" alt="Avatar">
							<div class="info">
								<strong>Jenny Wilson</strong>
								<span>Marketing Lead</span>
							</div>
						</div>
					</div>

					<div class="testimonial-item">
						<div class="stars">★ ★ ★ ★ ★</div>
						<p class="quote">"Thanks to their expert industrial service, our machinery runs flawless. Downtime is minimised, boosting our productivity significantly. Truly a game-changer for our operations."</p>
						<div class="author">
							<img src="/wp-content/uploads/2025/06/user-3-64x64-1.webp" alt="Avatar">
							<div class="info">
								<strong>Jenny Wilson</strong>
								<span>Marketing Lead</span>
							</div>
						</div>
					</div>

					<div class="testimonial-item">
						<div class="stars">★ ★ ★ ★ ★</div>
						<p class="quote">"Thanks to their expert industrial service, our machinery runs flawless. Downtime is minimised, boosting our productivity significantly. Truly a game-changer for our operations."</p>
						<div class="author">
							<img src="/wp-content/uploads/2025/06/user-3-64x64-1.webp" alt="Avatar">
							<div class="info">
								<strong>Jenny Wilson</strong>
								<span>Marketing Lead</span>
							</div>
						</div>
					</div>
				</div>

			</div>

			<div class="testimonials__images">
				<img src="/wp-content/uploads/2025/06/mask-group.webp" alt="AI Technology">
				<div class="item-wrap">
					<div class="item-icon">
						<i class="fa-regular fa-arrow-right"></i>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section id="homenest__blog" class="homenest__blog__container">
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
		<div class="homenest__blog__content">
			<span class="blog-tag gradient-text">LATEST POSTS</span>
			<h2 class="scrollTextEffect">
				<span class="text-gradient">
					Take A Look At Our Latest<br>Blog & Articles.
				</span>
			</h2>

			<div class="swiper blog-swiper" style="z-index:0 !important;">
				<div class="swiper-wrapper">
					<?php
					$args = array(
						'post_type' => 'post',
						'posts_per_page' => 9, // Lấy 9 bài, để hiển thị thành 3 slide (3 bài/slide)
						'orderby' => 'date',
						'order' => 'DESC'
					);
					$query = new WP_Query($args);
					$count = 0;
					if ($query->have_posts()) :
					echo '<div class="swiper-slide"><div class="blog-slide-group">';
					while ($query->have_posts()) : $query->the_post();
					?>
					<article class="blog-card">
						<a href="<?php the_permalink(); ?>" class="blog-card-link">
							<div class="blog-image">
								<?php if (has_post_thumbnail()) : ?>
								<?php the_post_thumbnail('full'); ?>
								<?php endif; ?>
								<div class="blog-date">
									<span class="day"><?php echo get_the_date('d'); ?></span>
									<span class="month"><?php echo get_the_date('M'); ?></span>
								</div>
							</div>
							<div class="blog-content">
								<h3><?php the_title(); ?></h3>
								<div class="blog-author">
									<div style="display: inline-flex;align-content: center;justify-content: center;align-items: center;">
										<?php echo get_avatar(get_the_author_meta('ID'), 40); ?>
										<span><?php the_author(); ?></span>
									</div>
									<div class="blog-meta">
										<span class="post-time">
											<?php
											$post_time = get_the_time('U');
											$current_time = current_time('timestamp');
											$diff = human_time_diff($post_time, $current_time);

											// Chuyển đổi sang tiếng Việt
											$diff_vi = str_replace(
												[' mins', ' min', ' hours', ' hour', ' days', ' day', ' weeks', ' week', ' months', ' month', ' years', ' year'],
												[' phút', ' phút', ' giờ', ' giờ', ' ngày', ' ngày', ' tuần', ' tuần', ' tháng', ' tháng', ' năm', ' năm'],
												$diff
											);

											echo $diff_vi . ' trước';
											?>
										</span>
									</div>
								</div>
								<p><?php echo wp_trim_words(get_the_excerpt(), 20); ?></p>
							</div>
						</a>
					</article>
					<?php
					$count++;
					if ($count % 3 === 0 && $count < $query->post_count) {
						echo '</div></div>'; // đóng nhóm & slide hiện tại
						echo '<div class="swiper-slide"><div class="blog-slide-group">'; // mở nhóm mới
					}
					endwhile;
					echo '</div></div>'; // đóng nhóm & slide cuối
					wp_reset_postdata();
					endif;
					?>
				</div> <!-- .swiper-wrapper -->
				<div class="swiper-button-next"></div>
				<div class="swiper-button-prev"></div>
			</div> <!-- .swiper -->
			<div class="button-service5">
				<a style="--d-in: 0.75s" class="button _txt2" href="https://h3.homenest.tech/blog/" target="blank">
					<span data-text="View All Blogs ">
						<span style="--d: 0.1s">V</span>
						<span style="--d: 0.125s">i</span>
						<span style="--d: 0.15s">e</span>
						<span style="--d: 0.175s">w</span>
						<span style="--d: 0.3s">&nbsp;</span>
						<span style="--d: 0.2s">A</span>
						<span style="--d: 0.225s">l</span>
						<span style="--d: 0.25s">l</span>
						<span style="--d: 0.3s">&nbsp;</span>
						<span style="--d: 0.275s">B</span>
						<span style="--d: 0.325s">l</span>
						<span style="--d: 0.35s">o</span>
						<span style="--d: 0.375s">g</span>
						<span style="--d: 0.375s">s</span>
					</span>
					<i class="fa-solid fa-arrow-up-right"></i>
				</a>
			</div>
		</div>
	</section>
</div>
<?php get_footer(); ?>
