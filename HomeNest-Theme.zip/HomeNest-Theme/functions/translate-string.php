<?php
// functions/translate-string.php

// ======================= Usage ==================
// 
// Đăng ký chuỗi
// pll_register_string('id_string', 'Default String', 'Group transition');
// 
// Gọi chuỗi
// . echo pll__('id_string') . 
// ======================= Usage ==================


if (function_exists('pll_register_string')) {
	
	// 	Tìm kiếm
    pll_register_string('Tất cả lĩnh vực', 'Tất cả lĩnh vực', 'Custom Search');
    pll_register_string('Tìm kiếm...', 'Tìm kiếm...', 'Custom Search');
    pll_register_string('Tìm kiếm', 'Tìm kiếm', 'Custom Search');
    pll_register_string('Tất cả', 'Tất cả', 'Custom Search');
	
	

		
}