<?php
// functions/ajax.php

// ========== AJAX: Gửi bình luận ==========
add_action('wp_ajax_custom_submit_comment', 'custom_submit_comment_callback');
add_action('wp_ajax_nopriv_custom_submit_comment', 'custom_submit_comment_callback');

function custom_submit_comment_callback() {
	$post_id  = intval($_POST['post_id']);
	$parent_id = intval($_POST['parent_id']);
	$author   = sanitize_text_field($_POST['author']);
	$email    = sanitize_email($_POST['email']);
	$content  = sanitize_text_field($_POST['content']);

	if (!$post_id || empty($author) || empty($email) || empty($content)) {
		wp_send_json_error(['message' => 'Thông tin không hợp lệ.']);
	}

	$commentdata = [
		'comment_post_ID'      => $post_id,
		'comment_parent'       => $parent_id,
		'comment_author'       => $author,
		'comment_author_email' => $email,
		'comment_content'      => $content,
		'comment_approved'     => 0,
	];

	$comment_id = wp_insert_comment($commentdata);

	if ($comment_id) {
		wp_send_json_success(['message' => 'Gửi bình luận thành công.']);
	} else {
		wp_send_json_error(['message' => 'Không thể gửi bình luận.']);
	}
}






