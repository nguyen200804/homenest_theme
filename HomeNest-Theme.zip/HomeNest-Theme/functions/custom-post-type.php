<?php
// functions/custom-post-type.php

// === CUSTOM POST TYPE: DỰ ÁN ===
add_action('init', function () {
	register_post_type('case_study', [
		'labels' => [
			'name'               => 'Case Studies',
			'singular_name'      => 'Case Study',
			'add_new'            => 'Add New',
			'add_new_item'       => 'Thêm Case Study',
			'edit_item'          => 'Edit Case Study',
			'new_item'           => 'New Case Study',
			'view_item'          => 'View Case Study',
			'search_items'       => 'Search Case Studies',
			'not_found'          => 'No Case Studies found',
			'not_found_in_trash' => 'No Case Studies found in Trash',
			'menu_name'          => 'Case Studies',
		],
		'public'            => true,
		'has_archive'       => true,
		'show_in_rest'      => true,
        'exclude_from_search'  => false, 
		'publicly_queryable'   => true, 
		'rewrite'           => ['slug' => 'case-studies'],
		'supports'          => ['title', 'editor', 'thumbnail', 'custom-fields', 'comments'],
		'menu_icon'         => 'dashicons-portfolio',
	]);
});

add_action('init', function () {
    // Chuyên ngành (taxonomy)
    register_taxonomy('chuyen-nganh', 'case_study', [
        'labels' => [
            'name'              => 'Chuyên ngành',
            'singular_name'     => 'Chuyên ngành',
            'search_items'      => 'Tìm Chuyên ngành',
            'all_items'         => 'Tất cả Chuyên ngành',
            'parent_item'       => 'Chuyên ngành cha',
            'parent_item_colon' => 'Chuyên ngành cha:',
            'edit_item'         => 'Chỉnh sửa Chuyên ngành',
            'update_item'       => 'Cập nhật Chuyên ngành',
            'add_new_item'      => 'Thêm Chuyên ngành mới',
            'new_item_name'     => 'Tên Chuyên ngành mới',
            'menu_name'         => 'Chuyên ngành',
        ],
        'hierarchical' => true,
        'show_in_rest' => true,
        'rewrite'      => ['slug' => 'chuyen-nganh'],
    ]);

    // Lĩnh vực (taxonomy)
    register_taxonomy('linh-vuc', 'case_study', [
        'labels' => [
            'name'              => 'Lĩnh vực',
            'singular_name'     => 'Lĩnh vực',
            'search_items'      => 'Tìm Lĩnh vực',
            'all_items'         => 'Tất cả Lĩnh vực',
            'parent_item'       => 'Lĩnh vực cha',
            'parent_item_colon' => 'Lĩnh vực cha:',
            'edit_item'         => 'Chỉnh sửa Lĩnh vực',
            'update_item'       => 'Cập nhật Lĩnh vực',
            'add_new_item'      => 'Thêm Lĩnh vực mới',
            'new_item_name'     => 'Tên Lĩnh vực mới',
            'menu_name'         => 'Lĩnh vực',
        ],
        'hierarchical' => true,
        'show_in_rest' => true,
        'rewrite'      => ['slug' => 'linh-vuc'],
    ]);
});

// === CUSTOM POST TYPE: DỊCH VỤ ===
add_action('init', function () {
	register_post_type('service', [
		'labels' => [
			'name'               => 'Dịch vụ',
			'singular_name'      => 'Dịch vụ',
			'add_new'            => 'Thêm mới',
			'add_new_item'       => 'Thêm dịch vụ mới',
			'edit_item'          => 'Chỉnh sửa dịch vụ',
			'new_item'           => 'Dịch vụ mới',
			'view_item'          => 'Xem dịch vụ',
			'search_items'       => 'Tìm kiếm dịch vụ',
			'not_found'          => 'Không có dịch vụ nào',
			'not_found_in_trash' => 'Không có dịch vụ nào trong thùng rác',
			'menu_name'          => 'Dịch vụ'
		],
		'public'        => true,
		'has_archive'   => true,
		'show_in_rest'  => true,
		'rewrite' => ['slug' => 'dich-vu'],
		'supports'      => ['title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'],
		'menu_icon'     => 'dashicons-hammer',
	]);
});

// Cho phép page template cho post type "service"
add_action('init', function () {
	add_post_type_support('service', 'page-attributes');
});
