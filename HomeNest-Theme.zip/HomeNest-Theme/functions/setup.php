<?php
// functions/setup.php

add_theme_support('custom-logo', [
	'height'      => 60,
	'width'       => 200,
	'flex-height' => true,
	'flex-width'  => true,
	'header-text' => ['site-title', 'site-description'],
]);

add_theme_support('title-tag');
add_theme_support('post-thumbnails');

add_filter('use_block_editor_for_post', '__return_false');

add_action('after_setup_theme', function () {
	register_nav_menus([
		'primary' => __('Menu chính', 'homenest')
	]);
});
