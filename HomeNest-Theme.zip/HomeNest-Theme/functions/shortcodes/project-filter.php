<?php
// functions/shortcodes/project-filter.php

// Shortcode: Hiển thị tất cả danh mục dự án (taxonomy)
function display_all_projects_shortcode() {
    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

    $args = array(
        'post_type' => 'case_study',
        'posts_per_page' => 12,
        'post_status' => 'publish',
        'orderby' => 'date',
        'order' => 'DESC',
        'paged' => $paged,
    );

    // Taxonomy queries
    $tax_queries = array();

    if (is_tax('linh-vuc')) {
        $term = get_queried_object();
        if ($term && isset($term->term_id)) {
            $tax_queries[] = array(
                'taxonomy' => 'linh-vuc',
                'field' => 'term_id',
                'terms' => $term->term_id,
            );
        }
    } elseif (is_tax('chuyen-nganh')) {
        $term = get_queried_object();
        if ($term && isset($term->term_id)) {
            $tax_queries[] = array(
                'taxonomy' => 'chuyen-nganh',
                'field' => 'term_id',
                'terms' => $term->term_id,
            );
        } else {
            error_log('No valid term found for chuyen-nganh in display_all_projects_shortcode');
        }
    }

    if (count($tax_queries) > 0) {
        $args['tax_query'] = $tax_queries;
    }

    $projects = new WP_Query($args);

    if (!$projects->have_posts()) {
        error_log('No projects found in display_all_projects_shortcode. Args: ' . print_r($args, true));
    }

    $output = '';
    $output .= '<div class="homenest__archive-project__project-grid">';

    if ($projects->have_posts()) {
        while ($projects->have_posts()) {
            $projects->the_post();
            $output .= '<div class="project-item">';

            // Display featured image
            $output .= '<div class="featured-image">';
            $output .= '<a href="' . get_permalink() . '">';
            if (has_post_thumbnail()) {
                $output .= get_the_post_thumbnail(get_the_ID(), 'medium');
            } else {
                $output .= '<img src="/wp-content/uploads/2025/05/elementor-placeholder-image.webp" alt="No Featured Image" />';
            }
            $output .= '</a>';
            $output .= '</div>';

            // Project info container 
            $logo_du_an = get_field('logo_du_an');
            $result_project_1 = get_field('result_project_1');
            $result_project_2 = get_field('result_project_2');
            $result_project_3 = get_field('result_project_3');

            if ($logo_du_an || $result_project_1['con_so_dat_duoc'] || $result_project_1['mo_ta_con_so'] || $result_project_2['con_so_dat_duoc'] || $result_project_2['mo_ta_con_so'] || $result_project_3['con_so_dat_duoc'] || $result_project_3['mo_ta_con_so']) {
                $output .= '<div class="project-info">';

                // Display logo_du_an (ACF Image Field)
                $output .= '<div class="logo">';
                $output .= '<a href="' . get_permalink() . '">';
                if ($logo_du_an) {
                    $output .= '<img src="' . esc_url($logo_du_an['url']) . '" alt="' . esc_attr($logo_du_an['alt'] ?: get_the_title()) . '" />';
                }
                $output .= '</a>';
                $output .= '</div>';

                // Display result_project_1 (ACF Group Field)
                if ($result_project_1 && !empty($result_project_1['con_so_dat_duoc']) && !empty($result_project_1['mo_ta_con_so'])) {
                    $output .= '<div class="result-project1">';
                    $output .= '<p><strong>' . esc_html($result_project_1['con_so_dat_duoc']) . '</strong><i class="fa-solid fa-sort-up"></i></p>';
                    $output .= '<p>' . esc_html($result_project_1['mo_ta_con_so']) . '</p>';
                    $output .= '</div>';
                }

                // Display result_project_2 (ACF Group Field)
                if ($result_project_2 && !empty($result_project_2['con_so_dat_duoc']) && !empty($result_project_2['mo_ta_con_so'])) {
                    $output .= '<div class="result-project2">';
                    $output .= '<p><strong>' . esc_html($result_project_2['con_so_dat_duoc']) . '</strong><i class="fa-solid fa-sort-up"></i></p>';
                    $output .= '<p>' . esc_html($result_project_2['mo_ta_con_so']) . '</p>';
                    $output .= '</div>';
                }

                if ($result_project_3 && !empty($result_project_3['con_so_dat_duoc']) && !empty($result_project_3['mo_ta_con_so'])) {
                    $output .= '<div class="result-project3">';
                    $output .= '<p><strong>' . esc_html($result_project_3['con_so_dat_duoc']) . '</strong><i class="fa-solid fa-sort-up"></i></p>';
                    $output .= '<p>' . esc_html($result_project_3['mo_ta_con_so']) . '</p>';
                    $output .= '</div>';
                }

                $output .= '</div>'; // Close project-info
            }

            $output .= '</div>'; // Close project-item
        }

        // Pagination
        $output .= '<div class="hn__pagination">';
        $output .= paginate_links(array(
            'total' => $projects->max_num_pages,
            'current' => $paged,
            'prev_text' => __('<i class="fa-solid fa-arrow-left"></i><span>Trang trước</span>'),
            'next_text' => __('<span>Trang sau</span> <i class="fa-solid fa-arrow-right"></i>'),
            'type' => 'plain',
        ));
        $output .= '</div>';
    } else {
        $output .= '<p>Không tìm thấy project nào.</p>';
    }

    $output .= '</div>';
    wp_reset_postdata();

    return $output;
}
add_shortcode('tat-ca-du-an', 'display_all_projects_shortcode');





function neuros_project_categories_shortcode() {
    $taxonomy = 'chuyen-nganh'; // Giả định [tat-ca-danh-muc-du-an] luôn dùng chuyen-nganh

    $terms = get_terms(array(
        'taxonomy' => $taxonomy,
        'hide_empty' => false,
    ));

    $current_slug = '';
    $current_term_id = '';
    if (is_tax('chuyen-nganh')) {
        $queried_object = get_queried_object();
        if ($queried_object && isset($queried_object->slug)) {
            $current_slug = $queried_object->slug;
            $current_term_id = $queried_object->term_id;
        }
    }

    $output = '<ul class="hn__taxonomy_neuros-project-category">';
    $output .= '<li class="hn__taxonomy-item"><a href="#" class="' . ($current_term_id ? '' : 'active') . '" data-term-id="all">Tất cả</a></li>';

    if (!empty($terms) && !is_wp_error($terms)) {
        foreach ($terms as $term) {
            $active_class = ($term->term_id == $current_term_id) ? 'active' : '';
            $output .= '<li class="hn__taxonomy-item"><a href="#" class="' . esc_attr($term->slug) . ' ' . $active_class . '" data-term-id="' . esc_attr($term->term_id) . '">' . esc_html($term->name) . '</a></li>';
        }
    }

    $output .= '</ul>';

    $output .= '
    <script>
    jQuery(document).ready(function($) {
        function filterProjects($element, isAutomatic) {
            $(".hn__taxonomy_neuros-project-category a").removeClass("active");
            $element.addClass("active");
            var termId = $element.data("term-id");
            var nganhTermId = $("#nganh-dropdown").val();
            var searchTerm = $("#project-search-input").val();
            console.log("Sending AJAX: project_category_id = " + termId + ", term_id = " + nganhTermId + ", search_term = " + searchTerm);

            $.ajax({
                url: ajax_object.ajaxurl,
                type: "POST",
                data: {
                    action: "filter_projects_by_nganh",
                    term_id: nganhTermId,
                    project_category_id: termId,
                    search_term: searchTerm,
                    paged: 1
                },
                success: function(response) {
                    $(".homenest__archive-project__project-grid").html(response.html);
                    if (!isAutomatic && $("#project").length) {
                        $("html, body").animate({
                            scrollTop: $("#project").offset().top
                        }, 500);
                    }
                },
                error: function(xhr, status, error) {
                    console.log("Lỗi AJAX: " + error);
                }
            });
        }

        $(".hn__taxonomy_neuros-project-category a").click(function(e) {
            e.preventDefault();
            filterProjects($(this), false);
        });

        var currentSlug = "' . esc_js($current_slug) . '";
        if (currentSlug) {
            var $matchingLink = $(".hn__taxonomy_neuros-project-category a." + currentSlug);
            if ($matchingLink.length && !$matchingLink.hasClass("active")) {
                filterProjects($matchingLink, true);
            }
        }
    });
    </script>';

    return $output;
}
add_shortcode('tat-ca-danh-muc-du-an', 'neuros_project_categories_shortcode');






function custom_search_dropdown_shortcode() {
    $dropdown_taxonomy = 'linh-vuc'; // Giả định dropdown dùng linh-vuc
    
    $categories = get_categories(array(
        'taxonomy' => $dropdown_taxonomy,
        'orderby' => 'name',
        'order'   => 'ASC',
        'hide_empty' => 0,
    ));
$output = '<div class="hn__search-and-dropdown" style="display: flex;">';

    // Dropdown
    $output .= '<select name="category" class="dropdown hn__dropdown" id="nganh-dropdown">';
    // Dịch chuỗi "Tất cả lĩnh vực" sử dụng Polylang
$output .= '<option class="hn__dropdown-item" value="">' . pll__('Tất cả lĩnh vực') . '</option>';
    foreach ($categories as $category) {
        $output .= '<option value="' . esc_attr($category->term_id) . '">' .
esc_html($category->name) . '</option>';
    }
    $output .= '</select>';
// Search input
    // Dịch placeholder "Tìm kiếm..." sử dụng Polylang
    $output .= '<input type="text" name="search" id="project-search-input" class="hn__search-project-input" placeholder="' . pll__('Tìm kiếm...') . '">';
// Search button
    // Dịch chữ trên nút "Tìm kiếm" sử dụng Polylang
    $output .= '<button class="hn__search-project-submit-button" id="project-search-button"><span><span>' . pll__('Tìm kiếm') . '</span><i class="fa-regular fa-magnifying-glass"></i></span></button>';

    $output .= '</div>';

    // Đã bỏ toàn bộ <script>...</script> chứa jQuery và AJAX
    
    return $output;
}
add_shortcode('tim-kiem-du-an-va-chon-nganh', 'custom_search_dropdown_shortcode');




