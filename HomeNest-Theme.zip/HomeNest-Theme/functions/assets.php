<?php
// functions/assets.php
add_action('wp_enqueue_scripts', function () {
	$base_dir = get_template_directory();
	$base_uri = get_template_directory_uri();

	// ==== CSS CHUNG ====
	wp_enqueue_style('fonts', $base_uri . '/assets/css/fonts.css', [], null);
	wp_enqueue_style('main', $base_uri . '/assets/css/main.css', [], null);
	wp_enqueue_style('footer-style', $base_uri . '/assets/css/footer.css', [], filemtime($base_dir . '/assets/css/footer.css'));
	wp_enqueue_script('footer-script', $base_uri . '/assets/js/footer.js', [], filemtime($base_dir . '/assets/js/footer.js'));

	// ==== JS CHUNG ====
	wp_enqueue_script('homenest-header-js', $base_uri . '/assets/js/homenest-header.js', [], filemtime($base_dir . '/assets/js/homenest-header.js'), true);

	// ==== SWIPER: Chỉ load ở trang có dùng ====
	if (
		is_singular('case_study') ||
		is_page_template('page-templates/homepage.php') ||
		is_page_template('page-templates/about-us.php') ||
		is_page_template('template-service/zalo-ads.php') ||
		is_page_template('template-service/cham-soc-website.php')
	) {
		wp_enqueue_style('swiper-css', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css');
		wp_enqueue_script('swiper-js', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js', [], null, true);
	}

	// ==== HOMEPAGE: gọi file CSS riêng ====
	if (is_page_template('page-templates/homepage.php')) {
		wp_enqueue_style(
			'homepage-style',
			$base_uri . '/assets/css/page/homepage.css',
			[],
			filemtime($base_dir . '/assets/css/page/homepage.css')
		);
	}

	// ==== THEO POST TYPE (case_study / service) ====
	if (is_singular()) {
		$post       = get_post();
		$post_type  = get_post_type($post);
		$slug       = sanitize_title($post->post_name);
		$allowed    = ['service', 'case_study'];
		$slug_map   = [
			'thiet-ke-web'                   => 'thiet-ke-website',
			'thiet-ke-website-chuyen-nghiep' => 'thiet-ke-website',
		];
		$actual_slug = $slug_map[$slug] ?? $slug;

		if (in_array($post_type, $allowed)) {
			$folder = $post_type === 'case_study' ? 'case-studies' : $post_type;

			// CSS
			$default_css = "{$base_dir}/assets/css/{$folder}/default.css";
			$custom_css  = "{$base_dir}/assets/css/{$folder}/{$actual_slug}.css";
			if (file_exists($default_css)) {
				wp_enqueue_style("{$post_type}-default-style", "{$base_uri}/assets/css/{$folder}/default.css", [], filemtime($default_css));
			}
			if (file_exists($custom_css)) {
				wp_enqueue_style("{$post_type}-{$actual_slug}-style", "{$base_uri}/assets/css/{$folder}/{$actual_slug}.css", ["{$post_type}-default-style"], filemtime($custom_css));
			}

			// JS
			$default_js = "{$base_dir}/assets/js/{$folder}/default.js";
			$custom_js  = "{$base_dir}/assets/js/{$folder}/{$actual_slug}.js";
			if (file_exists($default_js)) {
				wp_enqueue_script("{$post_type}-default-script", "{$base_uri}/assets/js/{$folder}/default.js", [], filemtime($default_js), true);
			}
			if (file_exists($custom_js)) {
				wp_enqueue_script("{$post_type}-{$actual_slug}-script", "{$base_uri}/assets/js/{$folder}/{$actual_slug}.js", ["{$post_type}-default-script"], filemtime($custom_js), true);
			}
		}
	}
});

// ==== TEMPLATE-SERVICE: load CSS động, hỗ trợ cả template '-en' ====
add_action('template_include', 'homenest_enqueue_service_assets', 20);

function homenest_enqueue_service_assets($template) {
    $theme_dir = get_template_directory();
    $theme_uri = get_template_directory_uri();
    $template_dir = $theme_dir . '/template-service/';

    // Chỉ áp dụng nếu file template nằm trong template-service/
    if (strpos($template, $template_dir) === 0) {
        
        // 1. Trích xuất tên file template, loại bỏ đuôi '.php'
        $template_filename_raw = basename($template, '.php');

        // 2. Kiểm tra nếu template kết thúc bằng '-en', thì loại bỏ nó để lấy tên cơ sở
        // Ví dụ: single-service-en -> single-service
        if (substr($template_filename_raw, -3) === '-en') {
            $template_filename = substr($template_filename_raw, 0, -3);
        } else {
            // Trường hợp template mặc định: single-service
            $template_filename = $template_filename_raw;
        }

        // --- Sử dụng tên cơ sở đã lọc để tạo đường dẫn CSS/JS ---
        
        // Đường dẫn tới file CSS & JS tương ứng
        $css_path = $theme_dir . "/assets/css/service/{$template_filename}.css";
        $css_uri  = $theme_uri . "/assets/css/service/{$template_filename}.css";

        $js_path = $theme_dir . "/assets/js/service/{$template_filename}.js";
        $js_uri  = $theme_uri . "/assets/js/service/{$template_filename}.js";

        // Gắn vào hook wp_enqueue_scripts
        add_action('wp_enqueue_scripts', function () use ($template_filename, $css_path, $css_uri, $js_path, $js_uri) {
            if (file_exists($css_path)) {
                // Tên handle: service-style-single-service
                wp_enqueue_style("service-style-{$template_filename}", $css_uri, [], null);
            }
            if (file_exists($js_path)) {
                // Tên handle: service-script-single-service
                wp_enqueue_script("service-script-{$template_filename}", $js_uri, ['jquery'], null, true); // Thêm dependency JQuery
            }
        });
    }

    return $template;
}
add_action('wp_enqueue_scripts', function () {
	if (is_page_template(['page-templates/homepage.php', 'page-templates/homepage-en.php']))  {
		$base_dir = get_template_directory();
		$base_uri = get_template_directory_uri();

		// CSS riêng
		wp_enqueue_style(
			'homepage-style',
			$base_uri . '/assets/css/page/homepage.css',
			[],
			filemtime($base_dir . '/assets/css/page/homepage.css')
		);

		// JS riêng
		wp_enqueue_script(
			'homepage-script',
			$base_uri . '/assets/js/page/homepage.js',
			[],
			filemtime($base_dir . '/assets/js/page/homepage.js'),
			true
		);
	}
});
add_action('wp_enqueue_scripts', function () {
	if (is_page_template(['page-templates/about-us.php', 'page-templates/about-us-en.php'])) {
		$base_dir = get_template_directory();
		$base_uri = get_template_directory_uri();

		// CSS riêng cho trang About Us
		wp_enqueue_style(
			'about-us-style',
			$base_uri . '/assets/css/page/about-us.css',
			[],
			filemtime($base_dir . '/assets/css/page/about-us.css')
		);

		// JS riêng cho trang About Us
		wp_enqueue_script(
			'about-us-script',
			$base_uri . '/assets/js/page/about-us.js',
			[],
			filemtime($base_dir . '/assets/js/page/about-us.js'),
			true
		);
	}
});

add_action('wp_enqueue_scripts', function () {
	if (is_singular('case_study') || is_post_type_archive('case_study') || is_tax(['chuyen-nganh', 'linh-vuc'])) {
		$base_dir = get_template_directory();
		$base_uri = get_template_directory_uri();
		$folder   = 'case-studies';

		// CSS default
		$css_path = "{$base_dir}/assets/css/{$folder}/default.css";
		$css_uri  = "{$base_uri}/assets/css/{$folder}/default.css";
		if (file_exists($css_path)) {
			wp_enqueue_style("{$folder}-style", $css_uri, [], filemtime($css_path));
		}

		// JS default
		$js_path = "{$base_dir}/assets/js/{$folder}/default.js";
		$js_uri  = "{$base_uri}/assets/js/{$folder}/default.js";
		if (file_exists($js_path)) {
			wp_enqueue_script("{$folder}-script", $js_uri, [], filemtime($js_path), true);
		}
	}
});
add_action('wp_enqueue_scripts', function () {
	if (is_404()) {
		$base_dir = get_template_directory();
		$base_uri = get_template_directory_uri();

		$css_path = "{$base_dir}/assets/css/page/404.css";
		if (file_exists($css_path)) {
			wp_enqueue_style('404-style', $base_uri . '/assets/css/page/404.css', [], filemtime($css_path));
		}

		$js_path = "{$base_dir}/assets/js/page/404.js";
		if (file_exists($js_path)) {
			wp_enqueue_script('404-script', $base_uri . '/assets/js/page/404.js', [], filemtime($js_path), true);
		}
	}
});
add_action('wp_enqueue_scripts', function () {
	if (is_category()) {
		$base_dir = get_template_directory();
		$base_uri = get_template_directory_uri();

		$css_path = "{$base_dir}/assets/css/blog/category.css";
		if (file_exists($css_path)) {
			wp_enqueue_style('blog-category-style', $base_uri . '/assets/css/blog/category.css', [], filemtime($css_path));
		}

		$js_path = "{$base_dir}/assets/js/blog/category.js";
		if (file_exists($js_path)) {
			wp_enqueue_script('blog-category-script', $base_uri . '/assets/js/blog/category.js', [], filemtime($js_path), true);
		}
	}
});

add_action('wp_enqueue_scripts', function () {
	if (is_single() && get_post_type() === 'post') {
		$base_dir = get_template_directory();
		$base_uri = get_template_directory_uri();

		// CSS
		$css_path = "{$base_dir}/assets/css/blog/single.css";
		if (file_exists($css_path)) {
			wp_enqueue_style('blog-single-style', $base_uri . '/assets/css/blog/single.css', [], filemtime($css_path));
		}

		// JS
		$js_path = "{$base_dir}/assets/js/blog/single.js";
		if (file_exists($js_path)) {
			wp_enqueue_script('blog-single-script', $base_uri . '/assets/js/blog/single.js', [], filemtime($js_path), true);
		}
	}
});
add_action('wp_enqueue_scripts', function () {
	if (is_page_template(['page-templates/blog.php', 'page-templates/blog-en.php'])) {
		$base_dir = get_template_directory();
		$base_uri = get_template_directory_uri();

		// CSS cho trang blog
		$css_path = "{$base_dir}/assets/css/page/blog.css";
		if (file_exists($css_path)) {
			wp_enqueue_style('page-blog-style', $base_uri . '/assets/css/page/blog.css', [], filemtime($css_path));
		}

	}
});
add_action('wp_head', function () {
    $icon_dir = get_template_directory() . '/icon/';
	foreach (glob($icon_dir . '*.php') as $filename) {
		require_once $filename;
	}
});
add_action('wp_enqueue_scripts', function () {
	if (is_search()) {
		$base_dir = get_template_directory();
		$base_uri = get_template_directory_uri();

		$css_path = "{$base_dir}/assets/css/search.css";
		if (file_exists($css_path)) {
			wp_enqueue_style('search-style', $base_uri . '/assets/css/search.css', [], filemtime($css_path));
		}

		$js_path = "{$base_dir}/assets/js/search.js";
		if (file_exists($js_path)) {
			wp_enqueue_script('search-script', $base_uri . '/assets/js/search.js', [], filemtime($js_path), true);
		}
	}
});

add_action('wp_enqueue_scripts', function () {
	if (is_search()) {
		$base_dir = get_template_directory();
		$base_uri = get_template_directory_uri();

		$js_path = "{$base_dir}/assets/js/page/search.js";
		if (file_exists($js_path)) {
			wp_enqueue_script('search-page-script', $base_uri . '/assets/js/page/search.js', [], filemtime($js_path), true);
		}
	}
});
add_action('wp_enqueue_scripts', function () {
	if (is_post_type_archive('service')) {
		$base_dir = get_template_directory();
		$base_uri = get_template_directory_uri();

		$css_path = "{$base_dir}/assets/css/service/archive.css";
		if (file_exists($css_path)) {
			wp_enqueue_style('archive-service-style', $base_uri . '/assets/css/service/archive.css', [], filemtime($css_path));
		}

		$js_path = "{$base_dir}/assets/js/service/archive.js";
		if (file_exists($js_path)) {
			wp_enqueue_script('archive-service-script', $base_uri . '/assets/js/service/archive.js', [], filemtime($js_path), true);
		}
	}
});

add_action('wp_enqueue_scripts', function () {
	if (is_singular('case_study')) {
		$base_dir = get_template_directory();
		$base_uri = get_template_directory_uri();

		// Enqueue CSS
		$css_path = "{$base_dir}/assets/css/case-studies/single.css";
		if (file_exists($css_path)) {
			wp_enqueue_style('single-case-study-style', $base_uri . '/assets/css/case-studies/single.css', [], filemtime($css_path));
		}

		// Enqueue JS
		$js_path = "{$base_dir}/assets/js/case-studies/single.js";
		if (file_exists($js_path)) {
			wp_enqueue_script('single-case-study-script', $base_uri . '/assets/js/case-studies/single.js', [], filemtime($js_path), true);
		}
	}
});

add_action('wp_enqueue_scripts', function () {
	$base_dir = get_template_directory();
	$base_uri = get_template_directory_uri();

	// Popup CSS
	$css_path = "{$base_dir}/assets/css/global/popup.css";
	if (file_exists($css_path)) {
		wp_enqueue_style('global-popup-style', $base_uri . '/assets/css/global/popup.css', [], filemtime($css_path));
	}

	// Popup JS
	$js_path = "{$base_dir}/assets/js/global/popup.js";
	if (file_exists($js_path)) {
		wp_enqueue_script('global-popup-script', $base_uri . '/assets/js/global/popup.js', [], filemtime($js_path), true);
	}
});

add_action('wp_enqueue_scripts', function () {
	if (is_page_template(['page-templates/contact.php', 'page-templates/contact-en.php'])) {
		$base_dir = get_template_directory();
		$base_uri = get_template_directory_uri();

		$css_path = "{$base_dir}/assets/css/page/contact.css";
		if (file_exists($css_path)) {
			wp_enqueue_style('contact-style', $base_uri . '/assets/css/page/contact.css', [], filemtime($css_path));
		}

		$js_path = "{$base_dir}/assets/js/page/contact.js";
		if (file_exists($js_path)) {
			wp_enqueue_script('contact-script', $base_uri . '/assets/js/page/contact.js', [], filemtime($js_path), true);
		}
	}
});

//============================================================
//     TỰ ĐỘNG TẠO ALT KHI CHƯA CÓ THẺ ALT IMAGE
//============================================================
add_action('shutdown', function () {
	$final = '';
	$levels = ob_get_level();
	for ($i = 0; $i < $levels; $i++) {
		$final .= ob_get_clean();
	}
	echo homenest_add_alt_to_all_images($final);
}, 0);

function homenest_add_alt_to_all_images($html) {
	return preg_replace_callback('/<img([^>]*?)src=["\']([^"\']+)["\']([^>]*?)>/i', function ($matches) {
		$before = $matches[1];
		$src = $matches[2];
		$after = $matches[3];

		// Nếu alt đã có nội dung thì giữ nguyên
		if (preg_match('/alt=["\']([^"\']+)["\']/', $before . $after, $alt_match) && trim($alt_match[1]) !== '') {
			return $matches[0];
		}

		// Lấy alt từ Media Library
		$attachment_id = attachment_url_to_postid($src);
		if ($attachment_id) {
			$alt = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
			if (!$alt) {
				$alt = get_the_title($attachment_id);
			}
		} else {
			// Tự tạo alt từ tên file nếu không có ID
			$filename = basename($src);
			$alt = preg_replace('/[-_]+/', ' ', preg_replace('/\.(webp|jpg|jpeg|png|gif)$/i', '', $filename));
			$alt = ucwords(trim($alt));
		}

		// Nếu alt tồn tại sẵn nhưng rỗng → thay thế
		if (preg_match('/alt=["\'].*?["\']/', $before . $after)) {
			return preg_replace('/alt=["\'].*?["\']/', 'alt="' . esc_attr($alt) . '"', $matches[0]);
		} else {
			return '<img' . $before . 'src="' . $src . '" alt="' . esc_attr($alt) . '"' . $after . '>';
		}
	}, $html);
}
//============================================================
//    Tạo shortcode [thoigian] trả về tháng/năm hiện tại
//============================================================
function current_year() {
	return date('m/Y'); // Ví dụ: 04/2025
}
add_shortcode('thoigian', 'current_year');

// Kích hoạt shortcode trong tiêu đề, đoạn trích và nội dung
add_filter('the_title', 'do_shortcode');
add_filter('the_excerpt', 'do_shortcode');
add_filter('the_content', 'do_shortcode');

// thay đổi và lấy tháng năm hiện tại title SEO
add_action( 'rank_math/vars/register_extra_replacements', function(){
	rank_math_register_var_replacement(
		'namthang',
		[
			'name'        => esc_html__( 'Current month', 'rank-math' ),
			'description' => esc_html__( 'Get and return the current month', 'rank-math' ),
			'variable'    => 'namthang',
			'example'     => my_Current_Month_Custom_callback(),
		],
		'my_Current_Month_Custom_callback'
	);
});
function my_Current_Month_Custom_callback(){
	//Có thể tuỳ biến dòng dưới để đúng định dạng mong muốn
	return date('m').'/'.date('Y');
}
//
//
//
// 
