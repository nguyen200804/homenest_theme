<?php
// functions/widgets.php

// Sidebar và Footer cơ bản
add_action('widgets_init', function () {
	register_sidebar([
		'name'          => __('Sidebar', 'homenest'),
		'id'            => 'sidebar-1',
		'description'   => __('Khu vực widget cho Sidebar', 'homenest'),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	]);

	register_sidebar([
		'name'          => __('Footer Widget Area', 'homenest'),
		'id'            => 'footer-1',
		'description'   => __('Khu vực widget cho Footer', 'homenest'),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	]);
});

// Widget riêng cho từng post type
add_action('widgets_init', function () {
	$widget_zones = [
		[
			'id'    => 'widget_dich_vu',
			'name'  => 'Widget Dịch vụ',
		],
		[
			'id'    => 'widget_du_an',
			'name'  => 'Widget Dự án',
		],
		[
			'id'    => 'widget_blog',
			'name'  => 'Widget Blog',
		],
	];

	foreach ($widget_zones as $zone) {
		register_sidebar([
			'name'          => $zone['name'],
			'id'            => $zone['id'],
			'before_widget' => '<div class="widget %2$s" id="%1$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3>',
			'after_title'   => '</h3>',
		]);
	}
});
