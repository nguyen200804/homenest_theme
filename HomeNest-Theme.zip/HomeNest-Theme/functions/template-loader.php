<?php
// functions/template-loader.php

add_filter('template_include', 'homenest_custom_template_loader');
function homenest_custom_template_loader($template) {
    // Kiểm tra xem Polylang đã được kích hoạt và hàm pll_current_language có tồn tại không
    if (function_exists('pll_current_language') && pll_current_language('slug') === 'en') {
        $lang_suffix = '-en';
    } else {
        $lang_suffix = '';
    }

    $template_dir = get_template_directory() . '/template-case-study/';

    // 1. Archive Template cho 'case_study'
    if (is_post_type_archive('case_study')) {
        $base_filename = 'archive-case_study.php';
        $custom_template = $template_dir . 'archive-case_study' . $lang_suffix . '.php';

        // Ưu tiên template Tiếng Anh nếu đang ở ngôn ngữ 'en'
        if ($lang_suffix !== '' && file_exists($custom_template)) {
            return $custom_template;
        } 
        
        // Trở về template mặc định nếu không phải Tiếng Anh hoặc template -en không tồn tại
        $default_template = $template_dir . $base_filename;
        if (file_exists($default_template)) {
            return $default_template;
        }
    }

    // 2. Single Template cho 'case_study'
    if (is_singular('case_study')) {
        $base_filename = 'single-case_study.php';
        $custom_template = $template_dir . 'single-case_study' . $lang_suffix . '.php';

        if ($lang_suffix !== '' && file_exists($custom_template)) {
            return $custom_template;
        } 

        $default_template = $template_dir . $base_filename;
        if (file_exists($default_template)) {
            return $default_template;
        }
    }

    // 3. Taxonomy 'chuyen-nganh'
    if (is_tax('chuyen-nganh')) {
        $base_filename = 'taxonomy-chuyen-nganh.php';
        $custom_template = $template_dir . 'taxonomy-chuyen-nganh' . $lang_suffix . '.php';

        if ($lang_suffix !== '' && file_exists($custom_template)) {
            return $custom_template;
        } 

        $default_template = $template_dir . $base_filename;
        if (file_exists($default_template)) {
            return $default_template;
        }
    }

    // 4. Taxonomy 'linh-vuc'
    if (is_tax('linh-vuc')) {
        $base_filename = 'taxonomy-linh-vuc.php';
        $custom_template = $template_dir . 'taxonomy-linh-vuc' . $lang_suffix . '.php';

        if ($lang_suffix !== '' && file_exists($custom_template)) {
            return $custom_template;
        } 

        $default_template = $template_dir . $base_filename;
        if (file_exists($default_template)) {
            return $default_template;
        }
    }

    return $template;
}