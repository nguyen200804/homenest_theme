<?php get_header(); 
?>

<main id="primary" class="site-main" role="main">
	<div class="container">
		<?php if ( have_posts() ) : ?>
			<header class="page-header">
				<h1 class="page-title"><?php bloginfo('name'); ?> – Cập nhật bài viết mới</h1>
				<p class="page-description">Tin tức, dự án, kiến thức và xu hướng từ Homenest – chuyên gia thiết kế website & marketing hàng đầu.</p>
			</header>

			<section class="post-archive">
				<?php while ( have_posts() ) : the_post(); ?>
					<article id="post-<?php the_ID(); ?>" <?php post_class('post-item'); ?> itemscope itemtype="https://schema.org/Article">
						<header class="entry-header">
							<h2 class="entry-title" itemprop="headline">
								<a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a>
							</h2>
							<div class="entry-meta">
								<time class="published" datetime="<?php echo get_the_date('c'); ?>" itemprop="datePublished"><?php echo get_the_date(); ?></time>
								<span class="author" itemprop="author"><?php the_author(); ?></span>
							</div>
						</header>

						<?php if ( has_post_thumbnail() ) : ?>
							<div class="entry-thumbnail">
								<a href="<?php the_permalink(); ?>">
									<?php the_post_thumbnail('medium', ['itemprop' => 'image']); ?>
								</a>
							</div>
						<?php endif; ?>

						<div class="entry-summary" itemprop="description">
							<?php the_excerpt(); ?>
						</div>

						<footer class="entry-footer">
							<a class="read-more" href="<?php the_permalink(); ?>" aria-label="Đọc thêm về <?php the_title_attribute(); ?>">Xem chi tiết →</a>
						</footer>
					</article>
				<?php endwhile; ?>
			</section>

			<nav class="pagination" aria-label="Pagination">
				<?php
				the_posts_pagination([
					'mid_size' => 2,
					'prev_text' => __('← Trước', 'homenest'),
					'next_text' => __('Tiếp →', 'homenest'),
					'screen_reader_text' => __('Pagination navigation'),
				]);
				?>
			</nav>

		<?php else : ?>
			<section class="no-content not-found">
				<header class="page-header">
					<h2 class="page-title">Không có bài viết nào</h2>
				</header>
				<div class="page-content">
					<p>Hiện tại chưa có nội dung được đăng. Vui lòng quay lại sau hoặc truy cập <a href="<?php echo home_url(); ?>">trang chủ</a>.</p>
				</div>
			</section>
		<?php endif; ?>
	</div>
</main>

<?php get_footer(); ?>
