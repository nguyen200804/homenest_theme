<?php
// functions.php
$base = get_template_directory();

// 1. Cấu hình theme
require_once $base . '/functions/setup.php';

// 2. Gọi CSS/JS
require_once $base . '/functions/assets.php';

// 3. CPT & Taxonomies
require_once $base . '/functions/custom-post-type.php';

// 4. Widget
require_once $base . '/functions/widgets.php';

// 5. AJAX
$ajax_file = $base . '/functions/ajax.php';
if (file_exists($ajax_file)) {
    require_once $ajax_file;
}

// 6. Shortcodes
$shortcode_files = [
    '/functions/shortcodes/contact.php',
    '/functions/shortcodes/project-filter.php'
];
foreach ($shortcode_files as $file) {
    $path = $base . $file;
    if (file_exists($path)) {
        require_once $path;
    }
}

// 7. Template loader cho case_study
require_once $base . '/functions/template-loader.php';

add_filter('admin_footer_text', function () {
    return '<em>Giao diện quản trị được tùy chỉnh bởi <a href="https://homenest.com.vn" target="_blank">HomeNest</a></em>';
});

// 8. Allow add file sgv
function allow_svg_upload($mimes) {
    $mimes['svg'] = 'image/svg+xml';
    return $mimes;
}
add_filter('upload_mimes', 'allow_svg_upload');

// 9. Custom Translate Polylang
require_once $base . '/functions/translate-string.php';


function display_latest_posts($number_of_posts = 3) {
    // Thiết lập các tham số để lấy bài viết
    $args = array(
        'posts_per_page' => $number_of_posts,
        'post_status' => 'publish',
    );
    // Lấy các bài viết mới nhất
    $latest_posts = new WP_Query($args);
    if ($latest_posts->have_posts()) {
        echo ''; // Thêm class row để phân chia cột
        $post_count = 0;
        while ($latest_posts->have_posts()) {
            $latest_posts->the_post();
            $post_count++;
            
            // Lấy ngày tháng năm theo định dạng tùy chỉnh
            $custom_date = date_i18n('l, d/m/Y', strtotime(get_the_date('Y-m-d')));
            
            // Kiểm tra nếu là bài viết thứ ba thì không thêm class 'border-end'
            if ($post_count == 3) {
                echo '<div class="homenest-home-tintuc-border">';
            } else {
                echo '<div class="homenest-home-tintuc-border homenest-home-row-border-wiki">';
            }
            
            echo '<small class="homenest-home-tintuc-date">' . nl2br(esc_html($custom_date)) . '</small>';
            echo '<h4 class="homenest-home-tintuc-display-h4 text-wiki-left"><a href="' . get_permalink() . '">' . get_the_title() . '</a></h4>';
            echo '<p class="homenest-home-tintuc-residual text-wiki-left">' . get_the_excerpt() . '</p>';
            echo '</div>';
        }
        echo '';
        // Reset lại $post
        wp_reset_postdata();
    } else {
        echo '<p>No posts found.</p>';
    }
}

//
function homenest_meta_description() {
    if ( is_singular() ) {
        $desc = has_excerpt() ? get_the_excerpt() : wp_trim_words( get_the_content(), 30, '...' );
    } else {
        $desc = get_bloginfo('description');
    }
    echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
}
add_action('wp_head', 'homenest_meta_description');





function custom_div_polylang_switcher() {
    // 1. LẤY DỮ LIỆU TỪ POLYLANG
    if (!function_exists('pll_the_languages')) {
        return '';
    }

    $languages = pll_the_languages(['raw' => 1]);
    if (empty($languages)) {
        return '';
    }

    // Tìm ngôn ngữ hiện tại và các ngôn ngữ khác
    $current_lang = null;
    $other_langs = [];
    foreach ($languages as $lang) {
        if ($lang['current_lang']) {
            $current_lang = $lang;
        } else {
            $other_langs[] = $lang;
        }
    }

    // Nếu không tìm thấy ngôn ngữ hiện tại, không hiển thị gì cả
    if ($current_lang === null) {
        return '';
    }

    $unique_id = 'custom-switcher-' . wp_unique_id();

    // 2. TẠO CẤU TRÚC HTML BẰNG DIV
    $html = '<div id="' . esc_attr($unique_id) . '" class="custom-polylang-switcher">';
    
    // Phần hiển thị ngôn ngữ đang chọn (để click vào)
    $html .= '<div class="switcher-selected">';
    $html .= '<span>' . strtoupper(esc_html($current_lang['slug'])) . '</span>';
    $html .= '<svg class="arrow" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" /></svg>';
    $html .= '</div>';
    
    // Danh sách các ngôn ngữ khác (mặc định ẩn)
    $html .= '<ul class="switcher-options">';
    foreach ($other_langs as $lang) {
        $html .= '<li><a href="' . esc_url($lang['url']) . '">' . strtoupper(esc_html($lang['slug'])) . '</a></li>';
    }
    $html .= '</ul>';

    $html .= '</div>';


    // 3. TẠO CSS ĐỂ TẠO KIỂU
    // CSS được chèn trực tiếp để đảm bảo dropdown luôn hoạt động mà không cần file riêng
    $css = "
    <style>
        .custom-polylang-switcher {
            position: relative;
            display: inline-block;
            font-family: sans-serif;
            user-select: none; /* Chặn bôi đen chữ */
        }
        .switcher-selected {
            display: flex;
            align-items: center;
            cursor: pointer;
            padding: 5px 10px;
        }
        .switcher-selected .arrow {
            width: 16px;
            height: 16px;
            margin-left: 5px;
            transition: transform 0.2s ease-in-out;
        }
        .custom-polylang-switcher.is-open .switcher-selected .arrow {
            transform: rotate(180deg);
        }
        .switcher-options {
            display: none; /* Mặc định ẩn danh sách */
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background-color: white;
            border: 1px solid #ddd;
            border-radius: 4px;
            list-style: none;
            margin: 5px 0 0 0;
            padding: 0;
            z-index: 1000;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .custom-polylang-switcher.is-open .switcher-options {
            display: block; /* Hiện danh sách khi có class 'is-open' */
        }
        .switcher-options li a {
            display: block;
            padding: 8px 12px;
            text-decoration: none;
            color: #333;
        }
        .switcher-options li a:hover {
            background-color: #f0f0f0; /* <-- BẠN CÓ THỂ ĐỔI MÀU NỀN KHI HOVER Ở ĐÂY */
        }
    </style>
    ";

    // 4. TẠO JAVASCRIPT ĐỂ XỬ LÝ LOGIC CLICK
    $javascript = "
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const switcher = document.getElementById('" . esc_js($unique_id) . "');
        if (!switcher) return;

        const selected = switcher.querySelector('.switcher-selected');

        selected.addEventListener('click', function(event) {
            event.stopPropagation(); // Ngăn sự kiện click lan ra ngoài
            switcher.classList.toggle('is-open');
        });

        // Đóng dropdown khi click ra ngoài
        document.addEventListener('click', function() {
            if (switcher.classList.contains('is-open')) {
                switcher.classList.remove('is-open');
            }
        });
    });
    </script>
    ";

    // Trả về kết quả cuối cùng
    return $html . $css . $javascript;
}

// Đăng ký shortcode (bạn có thể giữ tên cũ hoặc đổi)
add_shortcode('polylang_dropdown', 'custom_div_polylang_switcher');


