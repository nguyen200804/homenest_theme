<?php get_header(); ?>
<main class="homenest__search-results">
	<div class="container">
		<div class="col1">

			<div class="col1-sub">
				<div class="outline">

				</div>
				<div class="search-content">
					<p>
						Services
					</p>
					<h1 class="title">
						Smart AI Automation Driving Business Success
					</h1>
					<div class="button">
						<a href="#">
							<span class="text-btn">
								<span style="--d: 0s;">V</span>
								<span style="--d: 0.05s;">i</span>
								<span style="--d: 0.1s;">e</span>
								<span style="--d: 0.15s;">w</span>
								<span style="--d: 0.2s;">&nbsp;</span>
								<span style="--d: 0.25s;">A</span>
								<span style="--d: 0.3s;">l</span>
								<span style="--d: 0.35s;">l</span>
								<span style="--d: 0.4s;">&nbsp;</span>
								<span style="--d: 0.45s;">S</span>
								<span style="--d: 0.5s;">e</span>
								<span style="--d: 0.55s;">r</span>
								<span style="--d: 0.6s;">v</span>
								<span style="--d: 0.65s;">i</span>
								<span style="--d: 0.7s;">c</span>
								<span style="--d: 0.75s;">e</span>
								<span style="--d: 0.8s;">s</span>
							</span>
							<svg width="16" viewBox="3 3 9 9" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M3.646 11.354a.5.5 0 0 1 0-.707L10.293 4H6a.5.5 0 0 1 0-1h5.5a.5.5 0 0 1 .5.5V9a.5.5 0 0 1-1 0V4.707l-6.646 6.647a.5.5 0 0 1-.708 0" fill="#fff"/></svg>
						</a>	
					</div>

				</div>

				<div style="--h: 33px;" class="block"></div>
				<div style="--h: 24px;" class="block"></div>
				<div style="--h: 18px; " class="block"></div>
				<div style="--h: 13px;" class="block"></div>
				<div style="--h: 9px;" class="block"></div>
				<div style="--h: 6px;" class="block"></div>
			</div>
		</div>
		<div class="col2">

			<div class="blog-search-title">
				<?php if (is_search() && get_search_query()) : ?>
				<p><span class="text--gradient">Từ khóa tìm kiếm:</span> <strong><?php echo esc_html(get_search_query()); ?></strong></p>
				<?php endif; ?>

			</div>

			<div class="blog-list__boxed">
				<div class="blog-list__container">
					<div id="blog-posts">
						<?php
						$search_query = new WP_Query(array(
							's' => get_search_query(),
							'post_type' => 'post',
							'posts_per_page' => -1,
						));

						if ($search_query->have_posts()) :
						while ($search_query->have_posts()) : $search_query->the_post(); ?>
						<div class="blog-item">
							<div class="blog-content">
								<div class="blog-border"></div>
								<svg class="ll" xmlns="http://www.w3.org/2000/svg" width="326" height="446" viewBox="0 0 326 446" fill="none">
									<foreignObject x="-20" y="-20" width="326" height="446"></foreignObject>
									<path data-figma-bg-blur-radius="20" fill-rule="evenodd" clip-rule="evenodd" d="M326 10C326 4.47715 321.523 0 316 0H10C4.47715 0 0 4.47716 0 10V436C0 441.523 4.47715 446 10 446H119C124.523 446 128.852 441.427 130.452 436.141C134.678 422.171 147.651 412 163 412C178.349 412 191.322 422.171 195.548 436.141C197.148 441.427 201.477 446 207 446H316C321.523 446 326 441.523 326 436V10Z" fill="white" fill-opacity="0.12"/>
									<defs>
										<clipPath id="bgblur_0_1_298_clip_path">
											<path fill-rule="evenodd" clip-rule="evenodd" d="M326 10C326 4.47715 321.523 0 316 0H10C4.47715 0 0 4.47716 0 10V436C0 441.523 4.47715 446 10 446H119C124.523 446 128.852 441.427 130.452 436.141C134.678 422.171 147.651 412 163 412C178.349 412 191.322 422.171 195.548 436.141C197.148 441.427 201.477 446 207 446H316C321.523 446 326 441.523 326 436V10Z"/>
											<path d="M0,0 L300,0 L300,240 C210,300 90,300 0,240 Z"/>
										</clipPath>
									</defs>
								</svg>
								<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
								<?php if (has_post_thumbnail()) : ?>
								<div class="post-thumbnail">
									<a href="<?php the_permalink(); ?>">
										<?php the_post_thumbnail('medium', array('alt' => get_the_title(), 'class' => 'search-thumbnail')); ?>
									</a>
								</div>
								<?php else : ?>
								<div class="post-thumbnail">
									<a href="<?php the_permalink(); ?>">
										<img src="<?php echo get_template_directory_uri(); ?>/images/fallback-image.jpg" alt="Homenest" title="Homenest" class="search-thumbnail" />
									</a>
								</div>
								<?php endif; ?>
								<p class="excrept"><?php echo get_the_excerpt(); ?></p>
							</div>
							<div class="blog-button">
								<div class="btn-see-more">
									<a href="<?php the_permalink(); ?>"><svg width="16" viewBox="3 3 9 9" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M3.646 11.354a.5.5 0 0 1 0-.707L10.293 4H6a.5.5 0 0 1 0-1h5.5a.5.5 0 0 1 .5.5V9a.5.5 0 0 1-1 0V4.707l-6.646 6.647a.5.5 0 0 1-.708 0" fill="#fff"/></svg></a>
								</div>
							</div>
						</div>
						<?php endwhile; ?>
						<?php else : ?>
						<p>Không tìm thấy kết quả nào cho từ khóa "<strong><?php echo get_search_query(); ?></strong>".</p>
						<?php endif; ?>
						<?php wp_reset_postdata(); ?>
					</div>
					<div class="load-more-container">
						<button id="load-more" class="btn-load-more"><span>Xem thêm</span><i class="homenest-icon-arrow-right-down"></i></button>
 						<button id="collapse-posts" class="btn-collapse" style="display: none;">Thu gọn</button> -->
					</div>
				</div>
			</div>
		</div>
	</div>

</main>

<?php get_footer(); ?>
