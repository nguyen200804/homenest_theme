<form role="search" class="search-form" action="<?php echo home_url('/search/'); ?>"
  onsubmit="event.preventDefault(); window.location.href = this.action + encodeURIComponent(this.querySelector('#search-field').value) + '/';">
  
  <label class="screen-reader-text" for="search-field">Tìm kiếm:</label>
  
  <input type="search" id="search-field" class="search-field"
    placeholder="Nhập từ khóa..." value="<?php echo get_search_query(); ?>" required />

  <button type="submit" class="search-submit"><i class="fa-light fa-magnifying-glass"></i></button>
</form>