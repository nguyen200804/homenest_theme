<?php
/**
 * Footer template
 */
?>


<footer class="footer">
	<img src="/wp-content/uploads/2025/05/Vector-1-1.webp" alt="Homenest" title="Homenest">
	<img src="/wp-content/uploads/2025/05/Vector-1.webp" alt="Homenest" title="Homenest">
	<img src="/wp-content/uploads/2025/05/Vector-1-1-1.webp" alt="Homenest" title="Homenest">


	<div class="footer-content">

		<!-- Hàng 1: Chi nhánh -->
		<div class="footer-top">
			<div class="footer-col">
				<h4 class="text--gradient" style="display: inline-block;">HEADQUARTERS</h4>
				<p><strong>Address:</strong><br>
					SAV4, The Sun Avenue, 28 Mai Chi Tho, <br>
					Binh trung, Ho Chi Minh, Viet Nam
				</p>
				<p><strong>Operating Time:</strong><br>
					Monday – Friday from 8h30 – 17h30,<br>
					Saturday from 8h30 – 12h30
				</p>
			</div>
			<div class="footer-col">
				<h4 class="text--gradient" style="display: inline-block;">PHU YEN BRANCH</h4>
				<p><strong>Address:</strong><br>
					Son Tho, Son Thanh Tay, Tuy Hoa, <br>Phu Yen, Viet Nam
				</p>
				<p><strong>Operating Time:</strong><br>
					Monday – Friday from 8h30 – 17h30,<br>
					Saturday from 8h30 – 12h30
				</p>
			</div>
			<div class="footer-col">
				<h4 class="text--gradient" style="display: inline-block;">DONG NAI BRANCH</h4>
				<p><strong>Address:</strong><br>
					Hung Vuong, Nhon Trach,<br>
					Dong Nai, Viet Nam
				</p>
				<p><strong>Operating Time:</strong><br>
					Monday – Friday from tù 8h30 – 17h30,<br>
					Saturday from 8h30 – 12h30
				</p>
			</div>
			<div class="footer-col">
				<!--         <h4 style="color:#0056ff;">CHI NHÁNH HÀ NỘI</h4> -->
				<h4 class="text--gradient" style="display: inline-block;">HA NOI BRANCH</h4>
				<p><strong>Address:</strong><br>
					Vinhomes Times City, 458 Minh Khai,<br>
					Vinh Tuy, Ha Noi
				</p>
				<p><strong>Operating Time:</strong><br>
					Monday – Friday from 8h30 – 17h30,<br>
					Saturday from 8h30 – 12h30
				</p>
			</div>
		</div>

		<!-- Hàng 2: Logo + Liên hệ + Dịch vụ + Mạng xã hội -->
		<div class="footer-bottom">
			<div class="footer-col">
				<img class="footer-logo" src="<?php echo esc_url(wp_get_attachment_url(get_theme_mod('custom_logo'))); ?>" alt="Logo">
				<p>There are no limits to our creativity and capacity for growth. Let us empower you to excel in the digital world.</p>
			</div>
			<div class="footer-col">
				<h4>CONTACT</h4>
				<p><strong>Hotline:</strong><br>0898 - 994 - 298</p>
				<p><strong>Email</strong><br><a href="mailto:info@homenest.com.vn">info@homenest.com.vn</a></p>
				<p><strong>Website</strong><br><a href="https://homenest.com.vn">homenest.com.vn</a></p>
			</div>
			<div class="footer-col">
				<h4>SERVICES</h4>
				<p>Website Design</p>
				<p>Overall Marketing</p>
				<p>Branding</p>
				<p>Software Development</p>
				<p>Domain & Hosting</p>
			</div>
			<div class="footer-col">
				<h4>FOLLOW US</h4>
				<div class="footer-social-icons">
					<!--           <a href="#"><img src="<?php echo get_template_directory_uri(); ?>/assets/facebook.svg" alt="Facebook"></a> -->
					<a href="#"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M24 12c0-6.627-5.373-12-12-12S0 5.373 0 12c0 5.99 4.388 10.954 10.125 11.854V15.47H7.078V12h3.047V9.356c0-3.007 1.791-4.668 4.533-4.668 1.313 0 2.686.234 2.686.234v2.953H15.83c-1.491 0-1.956.925-1.956 1.874V12h3.328l-.532 3.469h-2.796v8.385C19.612 22.954 24 17.99 24 12" fill="#000"/></svg></a>
					<a href="#"><svg  xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" xml:space="preserve"><circle style="fill:#000" cx="256" cy="256" r="256"/><path style="fill:#fff" d="M315.227 109.468H196.772c-48.14 0-87.304 39.164-87.304 87.304v118.455c0 48.138 39.164 87.305 87.305 87.305h118.455c48.138 0 87.305-39.165 87.305-87.305V196.772c-.001-48.14-39.166-87.304-87.306-87.304m57.823 205.76c0 31.934-25.888 57.822-57.822 57.822H196.773c-31.934 0-57.822-25.888-57.822-57.822V196.773c0-31.934 25.888-57.823 57.822-57.823h118.455c31.934 0 57.822 25.89 57.822 57.823z"/><path style="fill:#fff" d="M256 180.202c-41.794 0-75.798 34.004-75.798 75.798 0 41.791 34.004 75.795 75.798 75.795s75.795-34.001 75.795-75.795-34.001-75.798-75.795-75.798m0 122.111c-25.579 0-46.316-20.733-46.316-46.313s20.737-46.316 46.316-46.316 46.313 20.735 46.313 46.316c0 25.579-20.734 46.313-46.313 46.313m94.103-121.539c0 10.03-8.132 18.163-18.163 18.163-10.03 0-18.163-8.133-18.163-18.163s8.133-18.163 18.163-18.163c10.033 0 18.163 8.13 18.163 18.163"/></svg></a>
					<a href="#"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 112.197 112.197" xml:space="preserve"><circle style="fill:#000" cx="56.099" cy="56.098" r="56.098"/><path style="fill:#f1f2f2" d="M90.461 40.316a26.8 26.8 0 0 1-7.702 2.109 13.45 13.45 0 0 0 5.897-7.417 26.8 26.8 0 0 1-8.515 3.253 13.4 13.4 0 0 0-9.79-4.233c-7.404 0-13.409 6.005-13.409 13.409 0 1.051.119 2.074.349 3.056-11.144-.559-21.025-5.897-27.639-14.012a13.35 13.35 0 0 0-1.816 6.742c0 4.651 2.369 8.757 5.965 11.161a13.3 13.3 0 0 1-6.073-1.679l-.001.17c0 6.497 4.624 11.916 10.757 13.147a13.4 13.4 0 0 1-3.532.471c-.866 0-1.705-.083-2.523-.239 1.706 5.326 6.657 9.203 12.526 9.312a26.9 26.9 0 0 1-16.655 5.74c-1.08 0-2.15-.063-3.197-.188a37.93 37.93 0 0 0 20.553 6.025c24.664 0 38.152-20.432 38.152-38.153q0-.872-.039-1.734a27.2 27.2 0 0 0 6.692-6.94"/></svg></a>
					<a href="#"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 473.931 473.931" xml:space="preserve"><circle style="fill:#000" cx="236.966" cy="236.966" r="236.966"/><path style="fill:#000" d="M404.518 69.38c92.541 92.549 92.549 242.593 0 335.142-92.541 92.541-242.593 92.545-335.142 0z"/><path style="fill:#000" d="M469.168 284.426 351.886 167.148l-138.322 15.749-83.669 129.532 156.342 156.338c91.92-19.445 164.185-92.155 182.931-184.341"/><path style="fill:#fff" d="M360.971 191.238c0-19.865-16.093-35.966-35.947-35.966H156.372c-19.85 0-35.94 16.105-35.94 35.966v96.444c0 19.865 16.093 35.966 35.94 35.966h168.649c19.858 0 35.947-16.105 35.947-35.966v-96.444zM216.64 280.146v-90.584l68.695 45.294z"/></svg></a>
				</div>
				<div class="footer-subscribe">
					<h4>Sign Up to Receive Information</h4>
					<input type="email" placeholder="Email">
					<button>→</button>
				</div>
			</div>
		</div>

		<!-- Hàng 3: Các nhánh HomeNest + Copyright -->
		<div class="footer-branches">
			<h4 class="text--gradient">Join with HomeNest</h4>
			<div class="logo-container">
				<div class="footer-col">
					<img src="/wp-content/uploads/2025/07/HomeNest_com_vn.webp" alt="HomeNest Logo 1">
				</div>
				<div class="footer-col">
					<img src="/wp-content/uploads/2025/07/HomeNest_edu_vn.webp" alt="HomeNest Logo 2">
				</div>
				<div class="footer-col">
					<img src="/wp-content/uploads/2025/07/HomeNest_media.webp" alt="HomeNest Logo 3">
				</div>
				<div class="footer-col">
					<img src="/wp-content/uploads/2025/07/HomeNest_tech.webp" alt="HomeNest Logo 4">
				</div>
			</div>
		</div>

		<div class="footer-copyright">
			<p>Copyright © 2023 QuestX. All Rights Reserved. Design by HomeNest</p>
		</div>

	</div>

	<div class="tab-icons">
		<ul class="all-icons">
			<!-- 			Trang chủ -->
			<li>
				<a href="<?php echo esc_url(home_url('/')); ?>" rel="nofollow noopener noreferrer">
					<img src="/wp-content/uploads/2025/05/icon_hn.webp">
					<span class="">Home</span>
				</a>
			</li>

			<!-- 			Hotline -->
			<li><a class="icon-phone" href="tel:0898994298" target="_blank" rel="nofollow noopener noreferrer"><i class="homenest-icon-phone"></i><span class="">Hotline</span></a></li>
			<!-- 			Zalo -->
			<li><a href="https://zalo.me/84708070888" target="_blank" rel="nofollow noopener noreferrer"><i class="homenest-icon-zalo"></i><span class="">Zalo</span></a></li>
			<!-- 			Tiktok -->
			<li><a href="https://www.tiktok.com/@homenest.software" target="_blank" rel="nofollow noopener noreferrer"><i class="homenest-icon-tiktok"></i><span class="">Tiktok</span></a></li>
			<li><a href="https://wa.me/+840898994298" target="_blank" rel="nofollow noopener noreferrer"><i class="homenest-icon-whatsapp"></i><span class="">WhatsApp</span></a></li>
		</ul>
	</div>

	<section class="contact-footer__mobile scrollUp">
		<div class="container">
			<div class="item">
				<a id="btnShowMenuMobile" rel="nofollow noopener noreferrer">
					<div class="icon">
						<i class="homenest-icon-bars"></i>
					</div>
					<span>Menu</span>
				</a>
			</div>
			<div class="item">
				<a href="https://wa.me/+840898994298" target="_blank" rel="nofollow noopener noreferrer" >
					<div class="icon">
						<i class="homenest-icon-whatsapp"></i>
					</div>
					<span>WhatsApp</span>
				</a>
			</div>
			<div class="item call">
				<a href="tel:0898994298" target="_blank" rel="nofollow noopener noreferrer">
					<div class="icon">
						<i class="homenest-icon-phone"></i>
					</div>
					<span>Gọi ngay</span>
				</a>
			</div>
			<div class="item">
				<a href="#" target="_blank" rel="nofollow noopener noreferrer">
					<div class="icon">
						<i class="homenest-icon-messenger"></i>
					</div>
					<span>Messenger</span>
				</a>
			</div>
			<div class="item">
				<a href="https://zalo.me/84708070888" target="_blank" rel="nofollow noopener noreferrer">
					<div class="icon">
						<i class="homenest-icon-zalo"></i>
					</div>
					<span>Zalo</span>
				</a>
			</div>
		</div>
	</section>

	<div class="homenest__scroll-top-page">
		<button id="scrollTopBtn" class="">
			<i class="homenest-icon-rocket"></i>
		</button>
	</div>
	
	
	<div class="homenest__promotion-btn">
        <button class="btn-close">
			<svg fill="#fff" viewBox="-3.5 0 19 19" xmlns="http://www.w3.org/2000/svg" class="cf-icon-svg"><path d="M11.383 13.644A1.03 1.03 0 0 1 9.928 15.1L6 11.172 2.072 15.1a1.03 1.03 0 1 1-1.455-1.456l3.928-3.928L.617 5.79a1.03 1.03 0 1 1 1.455-1.456L6 8.261l3.928-3.928a1.03 1.03 0 0 1 1.455 1.456L7.455 9.716z"/></svg>
        </button>
        <a href="#">
            <img src="/wp-content/uploads/2025/11/khuyen-mai-thuong.png" alt="">
        </a>
    </div>


	

	<?php get_template_part('template-parts/global/popup'); ?>

	<?php wp_footer(); ?>
</footer>
<!-- </body>
</html> -->