<!-- header-main.php -->
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title><?php wp_title(); ?></title>
		<?php wp_head(); ?>
		<!-- Preload all HomeNest font weights -->
		<link rel="preload" href="<?php echo get_template_directory_uri(); ?>/fonts/HomeNest%20Thin.woff2" as="font" type="font/woff2" crossorigin>
		<link rel="preload" href="<?php echo get_template_directory_uri(); ?>/fonts/HomeNest%20Extra%20Light.woff2" as="font" type="font/woff2" crossorigin>
		<link rel="preload" href="<?php echo get_template_directory_uri(); ?>/fonts/HomeNest%20Light.woff2" as="font" type="font/woff2" crossorigin>
		<link rel="preload" href="<?php echo get_template_directory_uri(); ?>/fonts/HomeNest%20Regular.woff2" as="font" type="font/woff2" crossorigin>
		<link rel="preload" href="<?php echo get_template_directory_uri(); ?>/fonts/HomeNest%20Medium.woff2" as="font" type="font/woff2" crossorigin>
		<link rel="preload" href="<?php echo get_template_directory_uri(); ?>/fonts/HomeNest%20Semi%20Bold.woff2" as="font" type="font/woff2" crossorigin>
		<link rel="preload" href="<?php echo get_template_directory_uri(); ?>/fonts/HomeNest%20Bold.woff2" as="font" type="font/woff2" crossorigin>
		<link rel="preload" href="<?php echo get_template_directory_uri(); ?>/fonts/HomeNest%20Extra%20Bold.woff2" as="font" type="font/woff2" crossorigin>
		<link rel="preload" href="<?php echo get_template_directory_uri(); ?>/fonts/HomeNest%20Black.woff2" as="font" type="font/woff2" crossorigin>

		<!-- Preload Anton -->
		<link rel="preload" href="<?php echo get_template_directory_uri(); ?>/fonts/Anton-Regular.woff2" as="font" type="font/woff2" crossorigin>


	</head>
	<body <?php body_class(); ?>>
		<header class="site-header home-header">
			<header id="mainHeader" class="homenest__header">
				<div class="homenest__background-container">
					<div class="logo">

						<?php
						if ( function_exists( 'the_custom_logo' ) && has_custom_logo() ) {
							the_custom_logo();
						} else {
							// Nếu chưa có logo thì hiển thị tên website
							echo '<a href="' . esc_url(home_url('/')) . '">' . get_bloginfo('name') . '</a>';
						}
						?>
					</div>
					<div class="logo-mobile">
						<?php
						if ( function_exists( 'the_custom_logo' ) && has_custom_logo() ) {
							the_custom_logo();
						} else {
							// Nếu chưa có logo thì hiển thị tên website
							echo '<a href="' . esc_url(home_url('/')) . '">' . get_bloginfo('name') . '</a>';
						}
						?>
					</div>
					<!-- MENU -->
					<nav class="menu">
						<?php
						class Custom_Nav_Walker extends Walker_Nav_Menu {
							// Bắt đầu một cấp menu
							function start_lvl(&$output, $depth = 0, $args = null) {
								if ($depth == 0) {
									$output .= '<ul class="submenu">';
								} else {
									$output .= '<ul>';
								}
							}

							// Kết thúc một cấp menu
							function end_lvl(&$output, $depth = 0, $args = null) {
								$output .= '</ul>';
							}

							// Bắt đầu một mục menu
							function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
								$classes = empty($item->classes) ? array() : (array) $item->classes;
								$class_names = join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item, $args));
								$class_names = $class_names ? ' class="' . esc_attr($class_names) . '"' : '';

								$output .= '<li' . $class_names . '>';

								$attributes = '';
								$attributes .= !empty($item->attr_title) ? ' title="' . esc_attr($item->attr_title) . '"' : '';
								$attributes .= !empty($item->target) ? ' target="' . esc_attr($item->target) . '"' : '';
								$attributes .= !empty($item->xfn) ? ' rel="' . esc_attr($item->xfn) . '"' : '';
								$attributes .= !empty($item->url) ? ' href="' . esc_attr($item->url) . '"' : '';

								$item_output = $args->before;
								$item_output .= '<a' . $attributes . '>';
								$item_output .= $args->link_before;

								$title = apply_filters('the_title', $item->title, $item->ID);

								if ($depth == 0) {
									$item_output .= '<span>' . $title . '</span>';
									$item_output .= '<span class="text--gradient active">' . $title . '</span>';

									// Chèn SVG nếu có submenu
									if (in_array('menu-item-has-children', $classes)) {
										$item_output .= '<svg class="dropdown-arrow" xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="url(#gradient-arrow)" viewBox="0 0 320 512">
  <defs>
    <linearGradient id="gradient-arrow" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#020C6A" />
      <stop offset="23.7%" stop-color="#1A85F8" />
      <stop offset="100%" stop-color="#66E5FB" />
    </linearGradient>
  </defs>
  <path d="M31.3 192h257.4c28.5 0 42.9 34.5 22.6 54.6l-128.7 128c-12.5 12.5-32.8 12.5-45.3 0L8.7 246.6C-11.6 226.5 2.8 192 31.3 192z"/>
</svg>';

									}
								} else {
									$item_output .= $title;
								}

								$item_output .= $args->link_after;
								$item_output .= '</a>';
								$item_output .= $args->after;

								$output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
							}

							// Kết thúc một mục menu
							function end_el(&$output, $item, $depth = 0, $args = null) {
								$output .= '</li>';
							}
						}

						// Hiển thị menu chính
						wp_nav_menu(array(
							'theme_location' => 'primary',
							'menu_id'        => 'main-menu',
							'container'      => 'nav',
							'container_class'=> 'main-navigation',
							'menu_class'     => 'main-menu',
							'walker'         => new Custom_Nav_Walker(),
							'fallback_cb'    => false,
						));
						?>
						<div class="space">

						</div>
					</nav>

				</div>
				<div class="homenest__contact-container">
					<div class="phone-container">
						<div class="phone-icon">
							<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" fill="currentColor" class="phonee">
								<path d="M280 0C408.1 0 512 103.9 512 232c0 13.3-10.7 24-24 24s-24-10.7-24-24c0-101.6-82.4-184-184-184c-13.3 0-24-10.7-24-24s10.7-24 24-24zm8 192a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm-32-72c0-13.3 10.7-24 24-24c75.1 0 136 60.9 136 136c0 13.3-10.7 24-24 24s-24-10.7-24-24c0-48.6-39.4-88-88-88c-13.3 0-24-10.7-24-24zM117.5 1.4c19.4-5.3 39.7 4.6 47.4 23.2l40 96c6.8 16.3 2.1 35.2-11.6 46.3L144 207.3c33.3 70.4 90.3 127.4 160.7 160.7L345 318.7c11.2-13.7 30-18.4 46.3-11.6l96 40c18.6 7.7 28.5 28 23.2 47.4l-24 88C481.8 499.9 466 512 448 512C200.6 512 0 311.4 0 64C0 46 12.1 30.2 29.5 25.4l88-24z"/>
							</svg>



						</div>
						<div class="phone">
							<div style="font-size: 0.85rem; opacity: 0.8;">Call us:</div>
							<a href="/contact/" style="font-weight: 700;">0898 - 994 - 298</a>
						</div>
					</div>
					<a href="/lien-he/" class="contact-us">
						<span>Liên hệ</span>
						<div class="arrow-icon">
							<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" width="1em" height="1em" fill="currentColor">
								<path d="M320 32c17.7 0 32 14.3 32 32v256c0 17.7-14.3 32-32 32s-32-14.3-32-32V131.3L73.9 377.4c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 96H96c-17.7 0-32-14.3-32-32s14.3-32 32-32H320z"/>
							</svg>
						</div>
					</a>
					<div class="header-icons">
						<a href="#" class="icon-search">
							<i class="homenest-icon-search"></i>
						</a>

						<hr style="color: #ccc;width: 1px;height: 30px;margin: 0 0px 0 12px;margin-bottom: -10px;opacity: 0.3">


						<a href="#" class="homenest__header--translate--mobile">
							<?php echo do_shortcode( '[polylang_dropdown]' ); ?>
						</a>

						<hr style="color: #ccc;width: 1px;height: 30px;margin: 0 10px 0 0;margin-bottom: -10px;opacity: 0.3">

						<a href="#" class="btn-menu-mobile">
							<button class="contact-btn-mobile" id="contactToggle">
								<i class="homenest-icon-grid-2"></i>
							</button>
						</a>
					</div>
					<div class="social-icon homenest__header__translate">
						<?php echo do_shortcode( '[polylang_dropdown]' ); ?>
					</div>
				</div>


			</header>
		</header>

		<div id="searchOverlay" class="overlay closed">
			<div id="searchPanel" class="search-panel">
				<button class="clear-search" aria-label="Đóng tìm kiếm">✕</button>
				<?php get_template_part('template-parts/search/searchform'); ?>
			</div>
		</div>

		<!-- 	MENU MOBILE	 -->
		<div id="menuMobile" class="prisma__menu-mobile mobile">


			<div class="logo-submenu">
				<?php
				if ( function_exists( 'the_custom_logo' ) && has_custom_logo() ) {
					the_custom_logo();
				} else {
					// Nếu chưa có logo thì hiển thị tên website
					echo '<a href="' . esc_url(home_url('/')) . '">' . get_bloginfo('name') . '</a>';
				}
				?>
			</div>
			<a href="#" class="close-menu">
				<i class="fa-light fa-xmark">
					<svg xmlns="http://www.w3.org/2000/svg" width="20" fill="currentColor" viewBox="0 0 384 512">
						<path d="M342.6 150.6c12.5 12.5 12.5 32.8 0 45.3L245.3 293.3l97.4 97.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L200 338.6l-97.4 97.4c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l97.4-97.4L57.4 195.9c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L200 247.4l97.4-97.4c12.5-12.5 32.8-12.5 45.3 0z"/>
					</svg>
				</i>
			</a>

			<div class="menu-mobile">
				<?php
				wp_nav_menu([
					'menu' => 18,
					'theme_location' => 'primary',
					'container' => false,
					'menu_class' => 'menu-mobile ',
				]);
				?>
			</div>
			<div class="contact-mobile">
				<h3 class="text--gradient">LIÊN HỆ HOMENEST.TECH</h3>
				<p>28 Mai Chí Thọ, Phường An Phú<br>Thành Phố Thủ Đức, Hồ Chí Minh, Việt Nam</p>
				<p><strong>0898 994 298</strong><br>info@homenest.tech</p>
			</div>
			<div class="social-icon">
				<a href="https://www.facebook.com"><i class="fa-brands fa-facebook"></i></a>
				<a href="https://www.instagram.com"><i class="fa-brands fa-instagram"></i></a>
				<a href="https://www.youtube.com"><i class="fa-brands fa-youtube"></i></a>
				<a href="https://www.tiktok.com"><i class="fa-brands fa-tiktok"></i></a>
			</div>
		</div>



<script>
document.addEventListener('DOMContentLoaded', function() {
  // Tìm đến thẻ select của Polylang
  const polylangSwitcher = document.querySelector('.wp-block-polylang-language-switcher select');
  
  if (polylangSwitcher) {
    // Thêm sự kiện 'change'
    polylangSwitcher.addEventListener('change', function() {
      // Lấy URL từ giá trị của option được chọn và chuyển trang
      if (this.value) {
        window.location.href = this.value;
      }
    });
  }
});
</script>

