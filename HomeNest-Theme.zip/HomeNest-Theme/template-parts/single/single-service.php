<?php get_header(); ?>

<?php
// Lấy slug của bài viết hiện tại
$slug = get_post_field('post_name', get_post());

// Đường dẫn tới template con
$template_path = locate_template("template-service/{$slug}.php");

if ($template_path) {
    // Nếu có template riêng cho slug → include vào
    include $template_path;
} else {
    // Nếu không có → fallback về layout mặc định
    get_template_part('template-service/default');
}
?>

<?php get_footer(); ?>
