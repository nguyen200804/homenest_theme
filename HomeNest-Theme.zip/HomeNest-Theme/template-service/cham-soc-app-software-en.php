<?php
/**
 * Template Name: Chăm sóc vận hành app - phần mềm - En
 * Template Post Type: service
 */
get_header(); ?>
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<main>
	<section class="homenest_app_software_section1_hero">
		<div class="homenest_app_software_section1_container">
			<div class="homenest_app_software_section1_badge" data-aos="fade-up" data-aos-delay="600">HomeNest Software</div>

			<h1 class="homenest_app_software_section1_title" data-aos="fade-up" data-aos-delay="600">
				App and Software<br />
				Operation & Maintenance Service
			</h1>

			<div class="homenest_app_software_section1_divider" data-aos="fade-up" data-aos-delay="600"></div>
			<p class="homenest_app_software_section1_subtitle">
				In-depth Daily Support<br />
				Maintain a Steady Pace of Sustainable Development
			</p>
			<a href="#" class="homenest_app_software_section1_button">Contact Now</a>
			<div class="homenest_app_software_section1_note">
				Contact us now to receive consultation and attractive offers.
			</div>
		</div>
	</section>
	<section class="homenest_app_software_section2_wrapper">
		<div class="homenest_app_software_section2_container">
			<div class="homenest_app_software_section2_intro">
				<p class="homenest_app_software_section2_subtitle">— What you need to know about HomeNest services —</p>
				<h2 class="homenest_app_software_section2_title">
					Professional Care Service<br>
					<span>Delivering <span class="highlight">Innovative Solutions.</span></span>
				</h2>
				<p class="homenest_app_software_section2_desc">
					We always provide professional, stable, and fast solutions for our services.
				</p>
			</div>

			<div class="homenest_app_software_section2_grid">
				<!-- Card 1 -->
				<div class="homenest_app_software_section2_card pink" data-aos="fade-right" data-aos-delay="100">
					<div class="homenest_app_software_section2_card_header_wrapper">
						<div class="homenest_app_software_section2_card_header">
							<h3>Impressive Key Figures</h3>
							<svg width="20" fill="#fff" viewBox="0 0 256 256" xmlns="http://www.w3.org/2000/svg"><path d="M228 99.998a12 12 0 0 1-24 .004l-.004-31.027-51.539 51.539a12 12 0 1 1-16.97-16.971l51.538-51.54L156 52a12 12 0 0 1 0-24h.001l59.993.008a12 12 0 0 1 11.998 11.998ZM184 132a12 12 0 0 0-12 12v60H52V84h60a12 12 0 0 0 0-24H48a20.02 20.02 0 0 0-20 20v128a20.02 20.02 0 0 0 20 20h128a20.02 20.02 0 0 0 20-20v-64a12 12 0 0 0-12-12"/></svg>
						</div>
					</div>
					<p>Not only do we deliver high-quality services, but we also provide effective, time-optimizing solutions for businesses.</p>
					<div class="homenest_app_software_section2_stats">
						<div><strong class="count-up" data-target="2000">2000</strong><strong
																							class="count-up-after">+</strong><br><span>Clients</span></div>
						<div><strong class="count-up" data-target="99">99</strong><strong
																						  class="count-up-after">%</strong><br><span>Client Satisfaction</span></div>
					</div>

					<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/photo-4.png" alt="App UI Homenest" />
				</div>

				<div class="homenest_app_software_section2_card-group">
					<!-- Card 2 -->
					<div class="homenest_app_software_section2_card red" data-aos="fade-down" data-aos-delay="100">
						<div class="homenest_app_software_section2_card_header_wrapper">
							<div class="homenest_app_software_section2_card_header">
								<h3>Ensure Stable Operation</h3>
								<svg width="20" fill="#fff" viewBox="0 0 256 256" xmlns="http://www.w3.org/2000/svg"><path d="M228 99.998a12 12 0 0 1-24 .004l-.004-31.027-51.539 51.539a12 12 0 1 1-16.97-16.971l51.538-51.54L156 52a12 12 0 0 1 0-24h.001l59.993.008a12 12 0 0 1 11.998 11.998ZM184 132a12 12 0 0 0-12 12v60H52V84h60a12 12 0 0 0 0-24H48a20.02 20.02 0 0 0-20 20v128a20.02 20.02 0 0 0 20 20h128a20.02 20.02 0 0 0 20-20v-64a12 12 0 0 0-12-12"/></svg>
							</div>
							<p>Regular monitoring, maintenance, and timely issue resolution ensure the application or software runs smoothly without interruption, guaranteeing optimal user experience.</p>
						</div>
						<div class="homenest_app_software_section2_includes">
							<strong>Diverse Industries</strong><br>
							<span>CRM, accounting, administration, warehousing, real estate, etc.</span>
						</div>
						<a href="#">Learn more</a>
					</div>

					<!-- Card 3 -->
					<div class="homenest_app_software_section2_card blue" data-aos="fade-up" data-aos-delay="200">
						<div class="homenest_app_software_section2_card_header_wrapper">
							<div class="homenest_app_software_section2_card_header">
								<h3>Performance Optimization and Flexible Upgrades</h3>
								<svg width="20" fill="#fff" viewBox="0 0 256 256" xmlns="http://www.w3.org/2000/svg"><path d="M228 99.998a12 12 0 0 1-24 .004l-.004-31.027-51.539 51.539a12 12 0 1 1-16.97-16.971l51.538-51.54L156 52a12 12 0 0 1 0-24h.001l59.993.008a12 12 0 0 1 11.998 11.998ZM184 132a12 12 0 0 0-12 12v60H52V84h60a12 12 0 0 0 0-24H48a20.02 20.02 0 0 0-20 20v128a20.02 20.02 0 0 0 20 20h128a20.02 20.02 0 0 0 20-20v-64a12 12 0 0 0-12-12"/></svg>
							</div>
							<p>Services include operational performance optimization, feature upgrades, and new version updates, ensuring the software always meets new requirements and develops sustainably over time.</p>
						</div>
						<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/photo-6-1.png"
							 alt="Graph" />
					</div>
				</div>

				<!-- Card 4 -->
				<div class="homenest_app_software_section2_card dark" data-aos="fade-left" data-aos-delay="300">
					<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/photo-3-3.png" alt="3D Globe"
						 class="homenest_app_software_section2_card_img3d" />
					<div class="homenest_app_software_section2_card_header_wrapper">
						<div class="homenest_app_software_section2_card_header">
							<h3>Cost Savings and Enhanced Management Efficiency</h3>
							<svg width="20" fill="#fff" viewBox="0 0 256 256" xmlns="http://www.w3.org/2000/svg"><path d="M228 99.998a12 12 0 0 1-24 .004l-.004-31.027-51.539 51.539a12 12 0 1 1-16.97-16.971l51.538-51.54L156 52a12 12 0 0 1 0-24h.001l59.993.008a12 12 0 0 1 11.998 11.998ZM184 132a12 12 0 0 0-12 12v60H52V84h60a12 12 0 0 0 0-24H48a20.02 20.02 0 0 0-20 20v128a20.02 20.02 0 0 0 20 20h128a20.02 20.02 0 0 0 20-20v-64a12 12 0 0 0-12-12"/></svg>
						</div>
						<p>HomeNest Software manages and operates the business to minimize risks and save operational and managerial personnel costs, allowing you to focus more on core business development.</p>
					</div>
				</div>
			</div>

			<div class="homenest_app_software_section2_footer">
				Are you looking for a quality solution? <a href="#">Click to learn more now.</a>
			</div>
		</div>
	</section>
	<section class="homenest_app_software_section3_wrapper">
		<div class="homenest_app_software_section3_container">
			<div class="homenest_app_software_section3_grid">
				<!-- Image -->
				<div class="homenest_app_software_section3_image-wrapper">
					<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/photo-1-4.png"
						 alt="3D Illustration" class="homenest_app_software_section3_image" data-aos="fade-right" data-aos-delay="0"/>
				</div>

				<!-- Content -->
				<div class="homenest_app_software_section3_content">
					<span class="homenest_app_software_section3_tagline">— About Our Service —</span>
					<h2 class="homenest_app_software_section3_heading">
						Keep Your Application Stable<br />
						<span class="highlight">With HomeNest Software</span>
					</h2>
					<p class="homenest_app_software_section3_paragraph">
						HomeNest Software specializes in providing app and software care and operation services.
					</p>
					<p class="homenest_app_software_section3_subparagraph">
						With HomeNest Software, you can be completely assured of effective and sustainable software solutions.
					</p>

					<!-- Features -->
					<div class="homenest_app_software_section3_features">
						<ul>
							<li><svg width="20" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path  fill-opacity=".01" d="M0 0h48v48H0z"/><path d="M43 11 16.875 37 5 25.182" stroke="#4cbfff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg> Ensure continuous stable operation</li>
							<li><svg width="20" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path  fill-opacity=".01" d="M0 0h48v48H0z"/><path d="M43 11 16.875 37 5 25.182" stroke="#4cbfff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg> Fast incident resolution</li>
							<li><svg width="20" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path  fill-opacity=".01" d="M0 0h48v48H0z"/><path d="M43 11 16.875 37 5 25.182" stroke="#4cbfff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg> Regular updates and upgrades</li>
						</ul>
						<ul>
							<li><svg width="20" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path  fill-opacity=".01" d="M0 0h48v48H0z"/><path d="M43 11 16.875 37 5 25.182" stroke="#4cbfff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg> Optimize application performance</li>
							<li><svg width="20" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path  fill-opacity=".01" d="M0 0h48v48H0z"/><path d="M43 11 16.875 37 5 25.182" stroke="#4cbfff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg> Save costs and management time</li>
							<li><svg width="20" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path  fill-opacity=".01" d="M0 0h48v48H0z"/><path d="M43 11 16.875 37 5 25.182" stroke="#4cbfff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg> Data safety and security</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="homenest_app_software_section4_wrapper">
		<div class="homenest_app_software_section4_container">
			<div class="homenest_app_software_section4_heading">
				<span class="homenest_app_software_section4_tagline">— Why You Should Choose HomeNest Software —</span>
				<h2>
					HomeNest Software<br />
					<span>Comprehensive App and Software Management Solution.</span>
				</h2>
				<p>	A reliable partner – Building a strong digital foundation for the future with you.</p>
			</div>

			<div class="homenest_app_software_section4_grid">
				<!-- Card -->
				<div class="homenest_app_software_section4_card" data-aos="fade-up" data-aos-delay="0">
					<div class="homenest_app_software_section4_icon">
						<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/icon-1-2.png" alt="icon Homenest" />
					</div>
					<h3>	Experienced Team</h3>
					<p>	We possess a professional and experienced team of technicians, always ready to ensure your system operates stably and efficiently.</p>
				</div>

				<div class="homenest_app_software_section4_card" data-aos="fade-up" data-aos-delay="0">
					<div class="homenest_app_software_section4_icon">
						<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/icon-3.png" alt="icon Homenest" />
					</div>
					<h3>	Flexible Service</h3>
					<p>	Our care and operation service packages are tailored to the specific characteristics and needs of each client, providing optimal and personalized solutions.</p>
				</div>

				<div class="homenest_app_software_section4_card" data-aos="fade-up" data-aos-delay="0">
					<div class="homenest_app_software_section4_icon">
						<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/icon-4.png" alt="icon Homenest" />
					</div>
					<h3>	Optimize Application Performance</h3>
					<p>	By assisting with software care, you can focus resources on core business development, minimizing the time and effort spent on technical management.</p>
				</div>

				<div class="homenest_app_software_section4_card" data-aos="fade-up" data-aos-delay="0">
					<div class="homenest_app_software_section4_icon">
						<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/icon-5.png" alt="icon Homenest" />
					</div>
					<h3>	Save Management Time</h3>
					<p>	Our solution reduces the time and effort you spend on technical oversight, allowing maximum focus on core business development.</p>
				</div>

				<div class="homenest_app_software_section4_card" data-aos="fade-up" data-aos-delay="400">
					<div class="homenest_app_software_section4_icon">
						<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/icon-6.png" alt="icon Homenest" />
					</div>
					<h3>	Fast Incident Resolution</h3>
					<p>	Committed to the fastest possible response and resolution of technical incidents, minimizing disruption and loss for your business.</p>
				</div>

				<div class="homenest_app_software_section4_card" data-aos="fade-up" data-aos-delay="400">
					<div class="homenest_app_software_section4_icon">
						<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/icon-8.png" alt="icon Homenest" />
					</div>
					<h3>	Reasonable Cost</h3>
					<p>	We provide effective operation and care solutions at a competitive cost, delivering maximum value to clients.</p>
				</div>

				<div class="homenest_app_software_section4_card" data-aos="fade-up" data-aos-delay="400">
					<div class="homenest_app_software_section4_icon">
						<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/icon-7.png" alt="icon Homenest" />
					</div>
					<h3>	Transparent Policy</h3>
					<p>	All processes, contracts, and costs are clearly disclosed by us, ensuring clients have complete peace of mind when partnering.</p>
				</div>

				<div class="homenest_app_software_section4_card" data-aos="fade-up" data-aos-delay="400">
					<div class="homenest_app_software_section4_icon">
						<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/icon-2.png" alt="icon Homenest" />
					</div>
					<h3>	Quality Commitment</h3>
					<p>	We always prioritize service quality, partnering with you to ensure your application operates stably, securely, and continues to evolve.</p>
				</div>
			</div>
		</div>
	</section>
	<section class="homenest_app_software_section5_wrapper">
		<div class="homenest_app_software_section5_container">
			<div class="homenest_app_software_section3_content">
				<span class="homenest_app_software_section3_tagline">— Projects —</span>
				<h2 class="homenest_app_software_section3_heading">
					Professional Service<br>
					<span class="highlight">Never Stop Innovating</span>
				</h2>
				<p class="homenest_app_software_section3_paragraph">
					HomeNest Software provides professional software care and operation services.
				</p>
				<p class="homenest_app_software_section3_subparagraph">
					We are committed to accompanying businesses on their digital transformation journey, fostering sustainable development in the Digital Age.
				</p>

				<!-- Features -->
				<div class="homenest_app_software_section5_info">
					<svg width="16" viewBox="0 -64 640 640" fill="#fff" xmlns="http://www.w3.org/2000/svg"><path d="m622.3 271.1-115.2-45c-4.1-1.6-12.6-3.7-22.2 0l-115.2 45c-10.7 4.2-17.7 14-17.7 24.9 0 111.6 68.7 188.8 132.9 213.9 9.6 3.7 18 1.6 22.2 0C558.4 489.9 640 420.5 640 296c0-10.9-7-20.7-17.7-24.9M496 462.4V273.3l95.5 37.3c-5.6 87.1-60.9 135.4-95.5 151.8M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128m96 40c0-2.5.8-4.8 1.1-7.2-2.5-.1-4.9-.8-7.5-.8h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c6.8 0 13.3-1.5 19.2-4-54-42.9-99.2-116.7-99.2-212"/></svg>
					<span>Explore Our Featured Projects</span>
				</div>
				<button href="/case-studies/" class="homenest_app_software_section5_button">Explore Now</button>
			</div>
			<div class="homenest_app_software_section5_image">
				<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/photo-2-1.png"
					 alt="Security illustration" data-aos="fade-left" data-aos-delay="400">
			</div>
		</div>
	</section>
	<section class="homenest_app_software_section6_wrapper">
		<div class="homenest_app_software_section6_container">
			<div class="homenest_app_software_section6_image">
				<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/photo-7.png"
					 alt="Cloud binary illustration" data-aos="fade-right" data-aos-delay="400"/>
			</div>
			<div class="homenest_app_software_section3_content">
				<span class="homenest_app_software_section3_tagline">— Client Testimonials —</span>
				<h2 class="homenest_app_software_section3_heading">
					Continuous Listening<br>
					<span class="highlight">And Improving Service Daily</span>
				</h2>
				<p class="homenest_app_software_section3_paragraph">
					Customer feedback is the driving force that helps HomeNest innovate every day.
				</p>
				<p class="homenest_app_software_section3_subparagraph">
					With HomeNest Software, you can be completely assured of effective and sustainable software solutions in the digital age.
				</p>

				<div class="homenest_app_software_section6_rating-box">
					<div class="homenest_app_software_section6_rating-left">
						<span class="homenest_app_software_section6_rating-number count-up-review" data-target="4.8">0</span>
					</div>
					<div class="homenest_app_software_section6_rating-right">
						<div class="homenest_app_software_section6_rating-stars">
							Service Rating  (<span class="count-up-review" data-target="4.8">0</span>)
							<span class="stars">★★★★★</span>
						</div>
						<div class="homenest_app_software_section6_feedback">
							<svg width="14" fill="#2c63f9" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M12 2C6.5 2 2 6.5 2 12c0 2.3.8 4.5 2.3 6.3l-2 2c-.4.4-.4 1 0 1.4.2.2.4.3.7.3h9c5.5 0 10-4.5 10-10S17.5 2 12 2M8 13c-.6 0-1-.4-1-1s.4-1 1-1 1 .4 1 1-.4 1-1 1m4 0c-.6 0-1-.4-1-1s.4-1 1-1 1 .4 1 1-.4 1-1 1m4 0c-.6 0-1-.4-1-1s.4-1 1-1 1 .4 1 1-.4 1-1 1"/></svg>
							Client Reviews
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="homenest_app_software_section7_wrapper">
		<div class="homenest_app_software_section7_container">
			<p class="homenest_app_software_section7_subtitle">— App and Software Care Service Process —</p>
			<h2 class="homenest_app_software_section7_title">
				The Perfect Solution<br>
				<span class="highlight">Starts with a Professional Process</span>
			</h2>
			<p class="homenest_app_software_section7_desc">
				4 Steps in HomeNest Software's App and Software Care Service Process
			</p>

			<div class="homenest_app_software_section7_steps">
				<div class="homenest_app_software_section7_step">
					<div class="homenest_app_software_section7_step-number">1</div>
					<div class="homenest_app_software_section7_step-content">
						<h3>System Assessment</h3>
						<p>Conduct a comprehensive check and application performance analysis to detect potential issues.</p>
					</div>
				</div>

				<div class="homenest_app_software_section7_step">
					<div class="homenest_app_software_section7_step-number">2</div>
					<div class="homenest_app_software_section7_step-content">
						<h3>Care Plan Development</h3>
						<p>Develop a maintenance, update, and optimization plan tailored to client needs.</p>
					</div>
				</div>

				<div class="homenest_app_software_section7_step">
					<div class="homenest_app_software_section7_step-number">3</div>
					<div class="homenest_app_software_section7_step-content">
						<h3>Maintenance and Support Implementation</h3>
						<p>Perform periodic maintenance, resolve incidents, and quickly apply new version updates as appropriate.</p>
					</div>
				</div>

				<div class="homenest_app_software_section7_step">
					<div class="homenest_app_software_section7_step-number">4</div>
					<div class="homenest_app_software_section7_step-content">
						<h3>Continuous Monitoring and Optimization</h3>
						<p>Monitor operation continuously, evaluate, and adjust to maintain stable and optimal performance.</p>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="homenest_app_software_section8_wrapper">
		<div class="homenest_app_software_section8_container">
			<h2 class="homenest_app_software_section8_title">
				If you have questions about our service<br />
				You can leave your email here.
			</h2>
			<p class="homenest_app_software_section8_subtitle">
				We want to listen and meet your needs
			</p>

			<form class="homenest_app_software_section8_form">
				<div class="homenest_app_software_section8_input_wrapper">
					<span class="homenest_app_software_section8_icon">@</span>
					<input type="email" placeholder="Your Email" required />
				</div>
				<button type="submit">Submit Now</button>
			</form>
		</div>
	</section>
	<section class="homenest_app_software_section9_wrapper">
		<div class="homenest_app_software_section9_container">
			<div class="homenest_app_software_section9_header">
				<p class="homenest_app_software_section9_label">— Other Services —</p>
				<h2 class="homenest_app_software_section9_title">
					Ready with Our Services<br />
					<span class="highlight">Innovate with HomeNest Software.</span>
				</h2>
			</div>

			<div class="homenest_app_software_section9_grid">
				<!-- Row 1: 2 columns -->
				<div class="homenest_app_software_section9_row row-2-cols">
					<div class="homenest_app_software_section9_card" data-aos="fade-right" data-aos-delay="300">
						<div class="homenest_app_software_section9_info">
							<p class="company">HomeNest Software</p>
							<h3>App Design Service</h3>
						</div>
						<div class="homenest_app_software_section9_image"
							 style="background-image: url('https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/photo-10.jpg');">
						</div>
						<a href="/en/dich-vu/thiet-ke-app/" class="read-more-btn">Learn More</a>
					</div>

					<div class="homenest_app_software_section9_card" data-aos="fade-left" data-aos-delay="300">
						<div class="homenest_app_software_section9_info">
							<p class="company">HomeNest Software</p>
							<h3>Software Design Service</h3>
						</div>
						<div class="homenest_app_software_section9_image"
							 style="background-image: url('https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/photo-14-1.jpg');">
						</div>
						<a href="/en/dich-vu/thiet-ke-phan-mem/" class="read-more-btn">Learn More</a>
					</div>
				</div>

				<!-- Row 2: 3 columns -->
				<div class="homenest_app_software_section9_row row-3-cols">
					<div class="homenest_app_software_section9_card" data-aos="fade-right" data-aos-delay="300">
						<div class="homenest_app_software_section9_info">
							<p class="company">HomeNest Software</p>
							<h3>Website Design Service</h3>
						</div>
						<div class="homenest_app_software_section9_image"
							 style="background-image: url('https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/photo-11.jpg');">
						</div>
						<a href="/en/dich-vu/thiet-ke-website/" class="read-more-btn">Learn More</a>
					</div>

					<div class="homenest_app_software_section9_card" data-aos="fade-up" data-aos-delay="300">
						<div class="homenest_app_software_section9_info">
							<p class="company">HomeNest Software</p>
							<h3>Digital Marketing Service</h3>
						</div>
						<div class="homenest_app_software_section9_image"
							 style="background-image: url('https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/photo-12.jpg');">
						</div>
						<a href="/en/dich-vu/digital-marketing/" class="read-more-btn">Learn More</a>
					</div>

					<div class="homenest_app_software_section9_card" data-aos="fade-left" data-aos-delay="300">
						<div class="homenest_app_software_section9_info">
							<p class="company">HomeNest Software</p>
							<h3>Website Care Service</h3>
						</div>
						<div class="homenest_app_software_section9_image"
							 style="background-image: url('https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/blog-2-1.jpg');">
						</div>
						<a href="/en/dich-vu/cham-soc-van-hanh-website/" class="read-more-btn">Learn More</a>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="homenest_app_software_section10_wrapper">
		<div class="homenest_app_software_section10_container">
			<h3 class="homenest_app_software_section10_title">
				Over <span class="highlight">2000+</span> partners are currently collaborating with HomeNest Software
			</h3>

			<div class="homenest_app_software_section10_logos">
				<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/logo-1.png"
					 alt="TALK & ACTION" />
				<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/logo-2.png" alt="Sky Cloud" />
				<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/logo-3.png" alt="JUMPKINS" />
				<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/logo-4.png" alt="TOTB+" />
				<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/logo-5.png" alt="WALK AWAY" />
			</div>
		</div>
	</section>

	<section class="homenest_app_software_section11_wrapper">
		<div class="homenest_app_software_section11_container">
			<p class="homenest_app_software_section11_subtitle">— Service Pricing —</p>
			<h2 class="homenest_app_software_section11_title">
				<span class="highlight"> <span class="gradient">App and Software </span></span><br />
				Care Service Packages.
			</h2>
			<p class="homenest_app_software_section11_desc">
				View detailed pricing for professional App and Software care services at HomeNest Software.
			</p>

			<div class="homenest_app_software_section11_cards" data-aos="fade-up" data-aos-delay="300">
				<!-- BASIC -->
				<div class="homenest_app_software_section11_card">
					<h3>BASIC</h3>
					<p class="terms">TERMS & CONDITION</p>
					<div class="price">
						<span class="currency">$</span><span class="amount">39.99</span><span class="period">Month</span>
					</div>
					<ul class="features">
						<li class="yes">Upgrade to a paid Version</li>
						<li class="yes">Access the Product or Service</li>
						<li class="no">Users who access the Software</li>
						<li class="no">Upgrades and support may require</li>
						<li class="no">This may include volume discounts</li>
					</ul>
					<button class="start-btn">Start Now</button>
				</div>

				<!-- STANDART -->
				<div class="homenest_app_software_section11_card">
					<h3>STANDART</h3>
					<p class="terms">TERMS & CONDITION</p>
					<div class="price">
						<span class="currency">$</span><span class="amount">89.99</span><span class="period">Month</span>
					</div>
					<ul class="features">
						<li class="yes">Upgrade to a paid Version</li>
						<li class="yes">Access the Product or Service</li>
						<li class="yes">Users who access the Software</li>
						<li class="no">Upgrades and support may require</li>
						<li class="no">This may include volume discounts</li>
					</ul>
					<button class="start-btn">Start Now</button>
				</div>

				<!-- PREMIUM -->
				<div class="homenest_app_software_section11_card premium">
					<h3>PREMIUM</h3>
					<p class="terms">TERMS & CONDITION</p>
					<div class="price">
						<span class="currency">$</span><span class="amount">120.99</span><span class="period">Month</span>
					</div>
					<ul class="features">
						<li class="yes">Upgrade to a paid Version</li>
						<li class="yes">Access the Product or Service</li>
						<li class="yes">Users who access the Software</li>
						<li class="yes">Upgrades and support may require</li>
						<li class="yes">This may include volume discounts</li>
					</ul>
					<button class="start-btn">Start Now</button>
				</div>
			</div>
		</div>
	</section>
	<section class="homenest_app_software_section12_wrapper">
		<div class="homenest_app_software_section12_container">
			<div class="homenest_app_software_section12_heading">
				<span class="tagline">— Frequently Asked Questions</span>
				<h2>
					Frequently Asked Questions <span class="highlight">About Our Service</span>
				</h2>
				<p>Common Questions About App and Software Care Service at HomeNest Software</p>
			</div>

			<div class="homenest_app_software_section12_faqs">
				<div class="faq-col">
					<div class="faq-item">
						<h3>What is the response time for incidents?</h3>
						<p>
							HomeNest commits to 24/7 technical support with a fast response time, helping resolve issues promptly to minimize downtime.
						</p>
					</div>
					<div class="faq-item">
						<h3>Does HomeNest guarantee data security?</h3>
						<p>
							We implement advanced security measures and perform periodic backups to protect client data with absolute safety.
						</p>
					</div>
					<div class="faq-item">
						<h3>How can I monitor the operation process?</h3>
						<p>
							HomeNest provides detailed periodic reports on system status, maintenance activities, and performance metrics for easy client monitoring.
						</p>
					</div>
				</div>

				<div class="faq-col">
					<div class="faq-item">
						<h3>How is the service cost calculated?</h3>
						<p>
							The cost is flexibly tailored to the size and needs of each business, is transparent with no hidden fees, ensuring investment effectiveness.
						</p>
					</div>
					<div class="faq-item">
						<h3>Does HomeNest support updates and new feature upgrades?</h3>
						<p>
							Yes, HomeNest supports new technology updates and develops additional features upon request to enhance performance and user experience.
						</p>
					</div>
					<div class="faq-item">
						<h3>Is the service suitable for small businesses and startups?</h3>
						<p>
							Yes, service packages at HomeNest Software are flexibly designed, suitable for everyone from startups to large corporations.
						</p>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="homenest_app_software_section13_wrapper" >
		<div class="homenest_app_software_section13_container" data-aos="fade-up" data-aos-delay="300">
			<h2>
				Continuous innovation and development <br />
				Delivering the best service experience for clients
			</h2>
			<p>We continuously strive, innovate, and develop every day to bring the best services to clients</p>
			<a href="/about-us/" class="homenest_app_software_section13_btn">Discover Now</a>
		</div>
	</section>
	<section class="homenest_app_software_section14">
		<div class="container">
			<!-- LEFT - ARTICLES -->
			<div class="left">
				<p class="homenest_app_software_section7_subtitle">— ARTICLE & NEWS</p>
				<h2 class="homenest_app_software_section7_title">
					Update Article<br>
					<span class="highlight">& More Archives​</span>
				</h2>
				<p class="homenest_app_software_section7_desc">
					Learn about and our news Information.
				</p>

				<div class="articles">
					<!-- Card 1 -->
					<div class="card">
						<div class="image-wrapper">
							<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/photo-11.jpg"
								 alt="Article 1">
							<span class="date">20 Mar</span>
						</div>
						<h4>AI Software that Helps Human Work</h4>
						<p>Single Blog & Archive AI Software that Helps Human Work by Hendrik Morella...</p>
						<a href="#">Read More</a>
					</div>

					<!-- Card 2 -->
					<div class="card">
						<div class="image-wrapper">
							<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/photo-9.jpg"
								 alt="Article 2">
							<span class="date">20 Mar</span>
						</div>
						<h4>Explore to New Tech with Zenith</h4>
						<p>Single Blog & Archive Explore to New Tech with Zenith by Hendrik Morella...</p>
						<a href="#">Read More</a>
					</div>
				</div>
			</div>

			<!-- RIGHT - FORM -->
			<div class="right">
				<h3>Contact us now to receive attractive offers</h3>
				<form>
					<label>Full Name *</label>
					<input type="text" placeholder="Hendrik">
					<small> Enter your first name</small>

					<label>Email Address *</label>
					<input type="email" placeholder="awesomesite@mail.com">
					<small>Example: awesomesite@mail.com</small>

					<label>Additional Notes</label>
					<textarea rows="12" placeholder="Input Message Here"></textarea>

					<button type="submit">Click to Submit</button>
				</form>
			</div>
		</div>
	</section>

	<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
	
</main>

<?php get_footer(); ?>