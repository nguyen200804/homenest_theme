<?php
/**
 * Template Name: Thiết kế app - En
 * Template Post Type: service
 */
get_header();
?>

<main class="service-wrapper">
	<section class="homenest_nexux_hero-banner">
		<div class="homenest_nexux_container">
			<div class="row-section10">
				<div class="col-xxl-12">
					<div class="homenest_nexux_heading mb-43">
						<span class="homenest_nexux_bloom"></span>
						<div class="relative z-5">
							<div class="homenest_nexux_sub-title center">
								<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-left.svg"
									 alt="subtitle">
								<p>HomeNest</p>
								<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-right.svg"
									 alt="subtitle">
							</div>
							<h1 class="homenest_nexux_title text-center wow fadeInUp animated">
								Solution <br>
								Professional App Design
							</h1>
							<p class="homenest_nexux_text text-center letter-spacing-1 wow fadeInUp animated">
								<span class="homenest_nexux_ani-tada"></span>
								Submit your email for detailed service information and consultation.
							</p>
						</div>
					</div>
					<div class="homenest_nexux_form-outer wow fadeInUp animated">
						<div class="homenest_nexux_form-wrap" id="subscribe-form">
							<form action="#" method="post" class="homenest_nexux_form">
								<div id="homenest_nexux_subscribe-content">
									<fieldset>
										<p>
											<input type="email" name="email-form" class="homenest_nexux_input-email"
												   placeholder="Your Email Address" required />
										</p>
									</fieldset>
									<p>
										<button type="submit" class="homenest_nexux_btn">
											<span class="homenest_nexux_overlay s1"></span>
											<span class="homenest_nexux_overlay s2"></span>
											<span class="homenest_nexux_btn-text"><span>Submit</span></span>
										</button>
									</p>
								</div>
							</form>
						</div>
						<div id="homenest_nexux_subscribe-msg" class="mb-20"></div>
					</div>
					<div class="homenest_nexux_banner wow fadeInUp animated">
						<img src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/banner.png" alt="">
					</div>
				</div>
			</div>
		</div>
		<div class="homenest_nexux_img-item item-1">
			<img src="" alt="">
		</div>
	</section>
	<section class="homenest_nexux_section2_container">
		<div class="homenest_nexux_section2_content">
			<div class="homenest_nexux_sub-title center">
				<span class="homenest_nexux_bloom2"></span>
				<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-left.svg" alt="subtitle">
				<p>About Us</p>
				<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-right.svg" alt="subtitle">
			</div>
			<h2 id="revealText">
				<span class="line">HomeNest App Design Services</span><br>
				<span class="line">Deliver Optimal, Custom-Tailored Solutions,</span><br>
				<span class="line">with High Security, empowering businesses to elevate</span><br>
				<span class="line">their brand on the digital platform.</span><br>
</h2>

			<div class="homenest_nexux_section2_button_wrapper">
				<button class="homenest_nexux_section2_button">Learn More ⟶</button>
			</div>
			<div class="homenest_nexux_section2_features_subtext">
				<div class="homenest_nexux_section2_features">
					<span>➕ Personalization</span>
					<span>✍️ Flexible Integration</span>
					<span>✅ Cost Optimization</span>
					<span>⚡ Fast Performance</span>
					<span>📈 Boost Sales</span>
					<span>🧠 High Promotional Effectiveness</span>
					<span>🎨 User-Friendly Interface</span>
				</div>

				<div class="homenest_nexux_section2_subtext">
					<img decoding="async" class="wow 
fadeInUp  animated" data-wow-delay="0"
						 src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/access-net.svg" alt=""
						 style="visibility: visible; animation-name: fadeInUp;">
					<img decoding="async" class="wow fade-up-diagonal animated brighter-image" data-wow-delay="0.1s"
						 src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/mouse-point.svg" alt=""
						 style="visibility: visible;
animation-delay: 0.1s; animation-name: fadeUpDiagonal;">
					<img decoding="async" class="wow fade-up-diagonal animated" data-wow-delay="0.2s"
						 src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/u-will-access.png" alt=""
						 style="visibility: visible; animation-delay: 0.2s; animation-name: fadeUpDiagonal;
width: 80px;">
				</div>
			</div>
		</div>
	</section>
	<section class="homenest_nexux_hero-banner_section3">
		<div class="homenest_nexux_container">
			<div class="row">
				<div class="col-xxl-12">
					<div class="homenest_nexux_heading mb-43">
						<span class="homenest_nexux_bloom"></span>
						<div class="relative z-5">
							<div class="homenest_nexux_sub-title center">
								<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-left.svg"
									 alt="subtitle">
								<p>Projects</p>
								<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-right.svg"
									 alt="subtitle">
							</div>
							<h2 class="homenest_nexux_title text-center wow fadeInUp animated">
								Featured App <br>
								Design Projects
							</h2>
							<p class="homenest_nexux_text text-center letter-spacing-1 wow fadeInUp animated">
								<span class="homenest_nexux_ani-tada"></span>
								Explore our featured app projects designed by HomeNest.
							</p>
						</div>
					</div>
					<div class="homenest_nexux_form-outer wow fadeInUp animated">
						<div id="homenest_nexux_subscribe-msg" class="mb-20"></div>
					</div>
					<div class="swiper-container slider-mobile-app">
						<div class="swiper-wrapper">
							<div class="swiper-slide">
								<div class="image">
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/app-1.png"
										 alt="Billing">
								</div>
							</div>
							<div class="swiper-slide">
								<div class="image">
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/app-2.png"
										 alt="AI Driven">
								</div>
							</div>
							<div class="swiper-slide">
								<div class="image">
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/app-3.png"
										 alt="Talk with Bot">
								</div>
							</div>
							<div class="swiper-slide">
								<div class="image">
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/app-4.png"
										 alt="Help Options">
								</div>
							</div>
							<div class="swiper-slide">
								<div class="image">
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/app-5.png"
										 alt="Spending">
								</div>
							</div>
							<div class="swiper-slide">
								<div class="image">
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/app-1.png"
										 
alt="Billing">
								</div>
							</div>
							<div class="swiper-slide">
								<div class="image">
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/app-2.png"
										 alt="AI Driven">
								</div>
							</div>
							<div class="swiper-slide">
								<div class="image">
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/app-3.png"
										 alt="Talk with Bot">
								</div>
							</div>
							<div class="swiper-slide">
								<div class="image">
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/app-4.png"
										 alt="Help Options">
								</div>
							</div>
							<div class="swiper-slide">
								<div class="image">
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/app-5.png"
										 alt="Spending">
								</div>
							</div>
							<div class="swiper-slide">
								<div class="image">
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/app-1.png"
										 alt="Billing">
								</div>
							</div>
							<div class="swiper-slide">
								<div class="image">
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/app-2.png"
										 alt="AI Driven">
								</div>
							</div>
							<div class="swiper-slide">
								<div class="image">
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/app-3.png"
										 alt="Talk with Bot">
								</div>
							</div>
							<div class="swiper-slide">
								<div class="image">
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/app-4.png"
										 alt="Help Options">
								</div>
							</div>
							<div class="swiper-slide">
								<div class="image">
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/app-5.png"
										 alt="Spending">
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="homenest_nexux_img-item item-1">
			<div class="homenest_nexux_section2_button_wrapper">
				<button class="homenest_nexux_section2_button">Learn More ⟶</button>
			</div>
		</div>
	</section>
	<section class="homenest_nexux_hero-banner_section3">
		<div class="homenest_nexux_container">
			<div class="row">
				<div class="col-xxl-12">
					<div class="homenest_nexux_heading mb-43">
						<span class="homenest_nexux_bloom"></span>
						<div class="relative z-5">
							<div class="homenest_nexux_sub-title center">
								<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-left.svg"
									 alt="subtitle">
								<p>Benefits</p>
								<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-right.svg"
									 alt="subtitle">
							</div>
							<h2 class="homenest_nexux_title text-center wow fadeInUp animated">
								Benefits of App Design <br>
								Brings to Businesses
							</h2>
							<p class="homenest_nexux_text text-center letter-spacing-1 wow fadeInUp animated">
								<span class="homenest_nexux_ani-tada"></span>
								Solutions that app design by HomeNest Software brings to businesses.
							</p>
						</div>
					</div>
					<div class="homenest_nexux_form-outer wow fadeInUp animated">
						<div id="homenest_nexux_subscribe-msg" class="mb-20"></div>
					</div>
				</div>
			</div>
		</div>
		<section class="homenest_nexux_section4_wrapper">
			<div class="homenest_nexux_section4_grid">

				<div class="homenest_nexux_section4_card">
					<div class="section4_icon_text_wrapper">
						<div class="section4_icon">
							<div class="icon style-circle">
								<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/bicon.svg" alt="">
							</div>
						</div>
						<div class="section4_text">
							<h3>Enhanced User Accessibility</h3>
							<p>Thanks to the proliferation of smartphones, app design helps businesses expand their market and effectively reach more potential customers.</p>
						</div>
					</div>
					<div class="homenest_nexux_section4_chart">
						<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/reseach.png" alt="">
					</div>
				</div>

				<div class="homenest_nexux_section4_card">
					<div class="section4_icon_text_wrapper">
						<div class="section4_icon">
							<div class="icon style-circle">
								<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/stack.svg" alt="">
							</div>
						</div>
						<div class="section4_text">
							<h3>Boost Brand Awareness</h3>
							<p>App design is a powerful solution that helps elevate brand recognition, maintain marketing efforts, and enhance customer engagement quality.</p>
						</div>
					</div>
					<div class="homenest_nexux_section4_chat">
						<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/powed.png" alt="">
					</div>
				</div>

				<div class="homenest_nexux_section4_card homenest_nexux_section4_fullwidth">
					<div class="section4_icon_text_wrapper section4_icon_text_column">
						<div class="section4_icon">
							<div class="icon style-circle">
								<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/fan.svg" alt="">
							</div>
						</div>
						<div class="section4_text_3">
							<h3>Effective Solution to Reach Millions 
of Customers</h3>
							<p>App design at HomeNest helps you effectively reach millions of customers and elevate your brand recognition.</p>
						</div>
					</div>
					<div class="homenest_nexux_section4_dashboard">
						<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/dashboard.png" alt="">
					</div>
				</div>

			</div>

		</section>

		<div class="homenest_nexux_section4_cta">
			<div class="homenest_nexux_section4_text">
				<p>Click to receive and experience an app demo from HomeNest Software now.</p>
			</div>
			<div class="homenest_nexux_section4_button">
				<a href="#" class="homenest_nexux_section4_demo_btn">Get Demo</a>
			</div>
		</div>
	</section>
	<section class="homenest_nexux_hero-banner_section3">
		<div class="homenest_nexux_container">
			<div class="row">
				<div class="col-xxl-12">
					<div class="homenest_nexux_heading mb-43">
						<span class="homenest_nexux_bloom"></span>
						<div class="relative z-5">
							<div class="homenest_nexux_sub-title center">
								<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-left.svg"
									 alt="subtitle">
								<p>Why Choose Us?</p>
								<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-right.svg"
									 alt="subtitle">
							</div>
							<h2 class="homenest_nexux_title text-center wow fadeInUp animated">
								Professional App Design
							</h2>
							<p class="homenest_nexux_text text-center letter-spacing-1 wow fadeInUp animated">
								<span class="homenest_nexux_ani-tada"></span>
								What Makes Us Different<br>
								In HomeNest Software's app design services.
							</p>
						</div>
					</div>
					<div class="homenest_nexux_form-outer wow fadeInUp animated">
						<div id="homenest_nexux_subscribe-msg" class="mb-20"></div>
					</div>
				</div>
			</div>
		</div>
		<div class="homenest_nexus_section5_grid">

			<div class="homenest_nexus_section5_card">
				<h3>High Reliability</h3>
				<p>We are committed to on-time project completion, ensuring quality and customer satisfaction from consultation through deployment.</p>
			</div>

			<div class="homenest_nexus_section5_card">
				<h3>Experienced Team</h3>
				<p>Our team of engineers has years of experience in app development, providing optimal solutions tailored to every business need.</p>
			</div>

			<div class="homenest_nexus_section5_card">
				<h3>Cross-Platform Development</h3>
				<p>Applications are flexibly developed for iOS, Android, and Web, maximizing the expansion of your potential customer base.</p>
			</div>

			<div class="homenest_nexus_section5_card">
				<h3>Transparent Commitment</h3>
				<p>All work processes are transparently updated, ensuring clients can effectively monitor every aspect of the project.</p>
			</div>

			<div class="homenest_nexus_section5_card">
				<h3>Cost Optimization</h3>
				<p>We help optimize operational and maintenance budgets, offering suitable service packages while maintaining high effectiveness.</p>
			</div>

			<div class="homenest_nexus_section5_card">
				<h3>High Security</h3>
				<p>Multi-layered security systems 
are integrated, ensuring client data safety and preventing any risk of information leakage.</p>
			</div>
</div>

	</section>
	<section class="homenest_nexux_hero-banner_section3">
		<div class="homenest_nexux_container">
			<div class="row">
				<div class="col-xxl-12">
					<div class="homenest_nexux_heading mb-43">
						<span class="homenest_nexux_bloom"></span>
						<div class="relative z-5">
							<div class="homenest_nexux_sub-title center">
								<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-left.svg"
									 alt="subtitle">
								<p>Subscription</p>
								<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-right.svg"
									 alt="subtitle">
							</div>
							<h2 class="homenest_nexux_title text-center wow fadeInUp animated">
								Get your Package
							</h2>
							<p class="homenest_nexux_text text-center letter-spacing-1 wow fadeInUp animated">
								<span class="homenest_nexux_ani-tada"></span>
								Pick your Plan and Start Unpleas yout Creativty from now
							</p>
						</div>
					</div>
					<div class="homenest_nexux_form-outer wow fadeInUp animated">
						<div id="homenest_nexux_subscribe-msg" class="mb-20"></div>
					</div>
				</div>
			</div>
		</div>
		<section class="homenest_nexux_section6_pricing">
			<div class="homenest_nexux_section6_card basic">
				<div class="homenest_nexux_section6_icon">
					<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/diamond-basic.svg"
						 alt="">
				</div>
				<h3 class="homenest_nexux_section6_title">Basic</h3>
				<p class="homenest_nexux_section6_desc">
					Harnessing the power of artificial intelligence to revolutionize industries and enhance human experiences.
				</p>
				<span class="line"></span>
				<ul class="homenest_nexux_section6_features">
					<li><i class="fa fa-check" style="color: white;"></i> 30+ Features</li>
					<li><i class="fa fa-check" style="color: white;"></i> Priority Support</li>
					<li><i class="fa fa-check" style="color: white;"></i> 4 Team Members</li>
					<li><i class="fa fa-check" style="color: white;"></i> Premium Features</li>
					<li><i class="fa fa-check" style="color: white;"></i> Data Insights</li>
				</ul>
				<div class="homenest_nexux_section6_price">$39.99 <span>/per month</span></div>
				<button class="homenest_nexux_section6_btn">Get Started →</button>
			</div>

			<div class="homenest_nexux_section6_card standard featured">
				<div class="homenest_nexux_section6_icon">
					<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/diamond-standard.svg"
						 alt="">
				</div>
				<h3 class="homenest_nexux_section6_title">Standard</h3>
				<p class="homenest_nexux_section6_desc">
					Harnessing the power of artificial intelligence to revolutionize industries and enhance human experiences.
				</p>
				<span class="line"></span>
				<ul class="homenest_nexux_section6_features">
					<li><i class="fa fa-check" style="color: white;"></i> 30+ Features</li>
					<li><i class="fa fa-check" style="color: white;"></i> Priority Support</li>
					<li><i class="fa fa-check" style="color: white;"></i> 4 Team Members</li>
					<li><i class="fa fa-check" style="color: white;"></i> Premium Features</li>
					<li><i class="fa fa-check" style="color: white;"></i> Data Insights</li>
				</ul>
				<div class="homenest_nexux_section6_price">$69.99 <span>/per month</span></div>
				<button class="homenest_nexux_section6_btn featured">Get Started →</button>
			</div>

			<div class="homenest_nexux_section6_card enterprise">
				<div class="homenest_nexux_section6_icon">
					<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/diamond-enterprise.svg"
						 alt="">
				</div>
				<h3 class="homenest_nexux_section6_title">Enterprise</h3>
				<p class="homenest_nexux_section6_desc">
					Harnessing the power of artificial intelligence to revolutionize industries and enhance human experiences.
				</p>
				<span class="line"></span>
				<ul class="homenest_nexux_section6_features">
					<li><i class="fa fa-check" style="color: white;"></i> 30+ Features</li>
					<li><i class="fa fa-check" style="color: white;"></i> Priority Support</li>
					<li><i class="fa fa-check" style="color: white;"></i> 4 Team Members</li>
					<li><i class="fa fa-check" style="color: white;"></i> Premium Features</li>
					<li><i class="fa fa-check" style="color: white;"></i> Data Insights</li>
				</ul>
				<div class="homenest_nexux_section6_price">$89.99 <span>/per month</span></div>
				<button class="homenest_nexux_section6_btn">Contact Us →</button>
			</div>
		</section>


	</section>
	<section class="homenest_nexux_hero-banner_section3">
		<div class="homenest_nexux_container">
			<div class="row">
				<div class="col-xxl-12">
					<div class="homenest_nexux_heading mb-43">
						<span class="homenest_nexux_bloom"></span>
						<div class="relative z-5">
							<div class="homenest_nexux_sub-title center">
								<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-left.svg"
									 alt="subtitle">
								<p>Frequently Asked Questions</p>
								<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-right.svg"
									 alt="subtitle">
							</div>
							<h2 class="homenest_nexux_title text-center wow fadeInUp animated">
								You Ask <br>
								HomeNest Answers
							</h2>
							<p class="homenest_nexux_text text-center letter-spacing-1 wow fadeInUp animated">
								<span class="homenest_nexux_ani-tada"></span>
								Common questions about professional app design services at HomeNest.
							</p>
						</div>
					</div>
					<div class="homenest_nexux_form-outer wow fadeInUp animated">
						<div id="homenest_nexux_subscribe-msg" class="mb-20"></div>
					</div>
				</div>
			</div>
		</div>
		<div class="homenest_nexux_section7_faq_wrapper">
			<div class="homenest_nexux_section7_faq_item">
				<div class="homenest_nexux_section7_faq_question">
					Does HomeNest offer consultation even if the client has no concrete ideas?
<span class="homenest_nexux_section7_faq_icon">+</span>
				</div>
				<div class="homenest_nexux_section7_faq_answer">
					Yes. HomeNest always partners with clients from the ideation stage and needs analysis to feature consultation, interface design, and developing an application plan suitable for each specific business model.
</div>
			</div>

			<div class="homenest_nexux_section7_faq_item">
				<div class="homenest_nexux_section7_faq_question">
					Do apps designed by HomeNest work on both iOS and Android?
					<span class="homenest_nexux_section7_faq_icon">+</span>
				</div>
				<div class="homenest_nexux_section7_faq_answer">
					Yes.
HomeNest provides cross-platform solutions, allowing the application to run smoothly on both iOS and Android, which helps save development costs.
</div>
			</div>

			<div class="homenest_nexux_section7_faq_item active">
				<div class="homenest_nexux_section7_faq_question">
					How long does it take to complete an App project?
<span class="homenest_nexux_section7_faq_icon">+</span>
				</div>
				<div class="homenest_nexux_section7_faq_answer">
					Depending on the complexity, simple projects usually take about 3–6 weeks.
However, apps integrating many features (payment, location, scheduling, etc.) may take 2–3 months or more.
HomeNest will provide a specific timeline during the consultation process.
</div>
			</div>

			<div class="homenest_nexux_section7_faq_item">
				<div class="homenest_nexux_section7_faq_question">
					Does HomeNest provide warranty and upgrade support after app handover?
					<span class="homenest_nexux_section7_faq_icon">+</span>
				</div>
				<div class="homenest_nexux_section7_faq_answer">
					Yes.
All projects come with a warranty package ranging from 3 to 12 months depending on the scale, along with long-term maintenance services and periodic feature upgrades according to client needs.
</div>
			</div>

			<div class="homenest_nexux_section7_faq_item">
				<div class="homenest_nexux_section7_faq_question">
					Can the app be integrated with other management systems or software?
					<span class="homenest_nexux_section7_faq_icon">+</span>
				</div>
				<div class="homenest_nexux_section7_faq_answer">
					Absolutely.
The app can connect with CRM, ERP, POS, accounting software, booking systems, payment gateways, email/SMS marketing, and more, which helps synchronize data and enhance operational efficiency.
</div>
			</div>

			<div class="homenest_nexux_section7_faq_item">
				<div class="homenest_nexux_section7_faq_question">
					Does HomeNest offer cost-optimized solutions for startups or small businesses?
					<span class="homenest_nexux_section7_faq_icon">+</span>
				</div>
				<div class="homenest_nexux_section7_faq_answer">
					Yes.
HomeNest offers several flexible solution packages, allowing projects to be divided into stages (MVP prototype, later expansion, etc.) to save initial investment costs while ensuring scalability when needed.
</div>
			</div>

			<div class="homenest_nexux_section7_faq_item">
				<div class="homenest_nexux_section7_faq_question">
					What kind of customer support does HomeNest provide after project completion?
<span class="homenest_nexux_section7_faq_icon">+</span>
				</div>
				<div class="homenest_nexux_section7_faq_answer">
					The HomeNest technical team always provides long-term partnership, offering technical support, maintenance, upgrades, and new solution consultation whenever the business needs to expand or update the app.
</div>
			</div>
		</div>


	</section>
	
	
	
	
	<section class="homenest_nexux_section9_wrapper">

		
		<div class="homenest__procedure-section__container">
			<div class="homenest__procedure-section__wrapper">
				<h2 class="homenest__procedure-section__title">
					App Design Process <br>at HomeNest Software
				</h2>
				<p class="homenest__procedure-section__desc">
					Explore HomeNest's professional app design process.
</p>
				<ul class="homenest__procedure-section__contain">

				</ul>
			</div>
		</div>
	</section>
	<section class="homenest_nexux_section10_s-indicator p-mod">
		<div class="homenest_nexux_section10_container">
			<div class="row">
				<div class="col-xxl-6"
					 style="display: flex; flex-direction: column;justify-content: center; align-items: center;">
					<div class="col-xxl-12">
						<div class="homenest_nexux_heading mb-43">
							<span class="homenest_nexux_bloom"></span>
							<div class="relative z-5">
								<div class="homenest_nexux_sub-title center">
									<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-left.svg"
										 alt="subtitle">
									<p>Our Success Metric</p>
									<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-right.svg"
										 alt="subtitle">
								</div>
								<h2 class="homenest_nexux_title_section8 text-center wow fadeInUp animated">
									HomeNest and the value <br>
									We deliver to clients
								</h2>
								<p class="homenest_nexux_text text-center letter-spacing-1 wow fadeInUp animated">
									<span class="homenest_nexux_ani-tada"></span>
									Explore the impressive figures delivered by HomeNest's app design services.
								</p>
							</div>
						</div>
						<div class="homenest_nexux_form-outer wow fadeInUp animated">
							<div id="homenest_nexux_subscribe-msg" class="mb-20"></div>
						</div>
					</div>

					<span class="homenest_nexux_section10_line"></span>

					<div class="homenest_nexux_section10_bot-wrap wow fadeInUp animated" data-wow-delay="0s"
						 style="visibility: visible; animation-delay: 0s; animation-name: fadeInUp;">
						<div class="homenest_nexux_section10_rating-wrap">
							<ul class="homenest_nexux_section10_avatar-list">
								<li>
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/rate-1.jpg"
										 alt="">
								</li>
								<li>
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/rate-2.jpg"
										 alt="">
								</li>
								<li>
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/rate-3.png"
										 alt="">
								</li>
							</ul>
							<div class="homenest_nexux_section10_rating">
								<div class="homenest_nexux_section10_vote">
									<p>4.9/5</p>
									<div class="homenest_nexux_section10_vote-wrap">
										<span class="homenest_nexux_section8_stars">★★★★★</span>
									</div>
								</div>
								<p>99% Satisfied Clients</p>
							</div>
						</div>
					</div>
				</div>

				<div class="col-xxl-6">
					<div class="homenest_nexux_section10_counter-group relative z-5">
						<div class="homenest_nexux_section10_wg-counter">
							<div class="homenest_nexux_section10_counter">
								<span class="number" data-speed="2500" data-to="10" data-inviewport="yes">10</span>
								<span></span><span>+</span>
							</div>
							<p class="homenest_nexux_section10_sub-counter">Years of Experience</p>
						</div>

						<div class="homenest_nexux_section10_wg-counter">
							<div class="homenest_nexux_section10_counter style-2">
								<span class="number" data-speed="2500" data-to="15" data-inviewport="yes">15</span>
								<span></span><span>+</span>
							</div>
							<p class="homenest_nexux_section10_sub-counter">Countries</p>
						</div>

						<div class="homenest_nexux_section10_wg-counter">
							<div class="homenest_nexux_section10_counter style-3">
								<span class="number" data-speed="2500" data-to="250" data-inviewport="yes">250</span>
								<span></span><span>+</span>
							</div>
							<p class="homenest_nexux_section10_sub-counter">Global Partners</p>
						</div>

						<div class="homenest_nexux_section10_wg-counter">
							<div class="homenest_nexux_section10_counter style-4">
								<span class="number" data-speed="2500" data-to="1000" data-inviewport="yes">1000</span>
								<span>+</span>
							</div>
							<p class="homenest_nexux_section10_sub-counter">Completed Projects</p>
						</div>
					</div>
				</div>
			</div>
		</div>

		<span class="homenest_nexux_section10_bloom item-1"></span>
		<div class="homenest_nexux_section10_s-img-item item-1">
			<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/net-10.png" alt="">
		</div>
		<div class="homenest_nexux_section10_s-img-item item-2">
			<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/net-9.png" alt="">
		</div>
	</section>
	<div class="homenest_nexux_section11_s-partner s1">
		<div class="homenest_nexux_section11_tf-container">
			<div class="row">
				<div class="col-xxl-12">
					<p class="homenest_nexux_section11_title">
						Trusted by 500+ Brands &amp;
Companies
					</p>
					<div class="homenest_nexux_section11_partner-group">
						<div class="homenest_nexux_section11_wg-partner wow fadeInLeft animated" data-wow-delay="0s">
							<a href="#">
								<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2025/04/client1.svg"
									 alt="">
							</a>
						</div>
						<div class="homenest_nexux_section11_wg-partner wow fadeInLeft animated" data-wow-delay="0.1s">
							<a href="#">
								<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2025/04/client2.svg"
									 alt="">
							</a>
						</div>
						<div class="homenest_nexux_section11_wg-partner wow fadeInLeft animated" data-wow-delay="0.2s">
							<a href="#">
								<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2025/04/client3.svg"
									 alt="">
							</a>
						</div>
						<div class="homenest_nexux_section11_wg-partner wow fadeInLeft animated" data-wow-delay="0.3s">
							<a href="#">
								<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2025/04/client4.svg"
									 alt="">
							</a>
						</div>
						<div class="homenest_nexux_section11_wg-partner wow fadeInLeft animated" data-wow-delay="0.5s">
							<a href="#">
								<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2025/04/client5.svg"
									 alt="">
							</a>
						</div>
						<div class="homenest_nexux_section11_wg-partner wow fadeInLeft animated" data-wow-delay="0.5s">
							<a href="#">
								<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2025/04/client1.svg"
									 alt="">
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>




<script>
        // ==============================
        // Các quy trình dịch vụ nói chung (Internal)
        // ==============================
        const cacQuyTrinh = 
[ {
                heading: "Requirement intake & solution consultation",
                content: "HomeNest listens and gathers complete information regarding the client's features, interface, usage goals, and more.Our expert team will conduct surveys, analyze the industry, and research users to recommend the most suitable solution and app development direction.",
                linkImg: "/wp-content/uploads/2025/08/761d2291534b7cd6cf9fc1eaccf9f8b6-scaled-1.webp",
            },
            {
                heading: "Contract signing & detailed planning",
                content: 
"Once the ideas and costs are agreed upon, both parties sign the contract, and HomeNest proceeds to create a detailed development plan, allocating tasks for each stage to ensure project progress.",
                linkImg: "/wp-content/uploads/2025/08/761d2291534b7cd6cf9fc1eaccf9f8b6-scaled-1.webp",
            },
            {
                heading: "UI/UX design & feature programming",
        
                content: "The design team builds a modern, user-friendly interface (UI/UX), while programmers develop features, ensuring the app functions well on cross-platforms like iOS and Android.",
                linkImg: "/wp-content/uploads/2025/08/761d2291534b7cd6cf9fc1eaccf9f8b6-scaled-1.webp",
            },
            {
                heading: "Testing & finalization",
        
                content: "The application is rigorously tested for performance, security, and user experience.Any detected errors are quickly resolved; HomeNest is ready to modify and optimize based on client feedback.",
                linkImg: "/wp-content/uploads/2025/08/761d2291534b7cd6cf9fc1eaccf9f8b6-scaled-1.webp",
            },
            {
                heading: "Handover & operation support",
                content: "Upon completion, HomeNest hands over the full source code, usage instructions, and prepares a team for technical support, periodic maintenance, and partnering with the business throughout the app's operation.",
                linkImg: "/wp-content/uploads/2025/08/761d2291534b7cd6cf9fc1eaccf9f8b6-scaled-1.webp",
            },
        ];
    </script>





<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>



</main>

<?php get_footer(); ?>