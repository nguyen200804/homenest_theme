<?php
/**
 * Template Name: Thiết kế website trọn gói
 * Template Post Type: service
 */
get_header(); ?>
<main>
	
	<body>
		
<div class="homenest-web-tron-goi-sector-1">
	<div class="homenest-web-tron-goi-sector-1-bg-1"></div>
	<div class="homenest-web-tron-goi-sector-1-bg-2"></div>
	<div class="homenest-web-tron-goi-sector-1-bg-3"></div>
	<div class="homenest-web-tron-goi-sector-1-bg-4"></div>
	<div class="homenest-web-tron-goi-sector-1-bg-5"></div>
	<div class="homenest-web-tron-goi-sector-1-bg-6"></div>	
	<div class="homenest-web-tron-goi-sector-1-container">

		<!-- Headline Block -->
		<div class="homenest-web-tron-goi-sector-1-container-headline">
			<div class="homenest-web-tron-goi-sector-1-container-headline-text">
				<div class="homenest-web-tron-goi-sector-1-container-headline-text-content">
					<div class="homenest-web-tron-goi-sector-1-container-headline-text-content-1">
						THIẾT KẾ WEBSITE TRỌN GÓI
					</div>
					<div class="homenest-web-tron-goi-sector-1-container-headline-text-content-2" id="pic-1"></div>						
				</div>
				<div class="homenest-web-tron-goi-sector-1-container-headline-text-content">
					<div class="homenest-web-tron-goi-sector-1-container-headline-text-content-2" id="pic-2"></div>
					<div class="homenest-web-tron-goi-sector-1-container-headline-text-content-1 homenest-web-tron-goi-gradient-highlighted-word-2_gradient">
						HOMENEST
					</div>					
				</div>				
			</div>
			<div class="homenest-web-tron-goi-sector-1-container-headline-navi">
				<div class="homenest-web-tron-goi-sector-1-container-headline-navi-content">
					Trang chủ
				</div>
				<div class="homenest-web-tron-goi-sector-1-container-headline-navi-content">
					/
				</div>
				<div class="homenest-web-tron-goi-sector-1-container-headline-navi-content" style="font-weight:700;">
					Thiết kế Website
				</div>
			</div>
		</div>

		<!-- Content Block -->
		<div class="homenest-web-tron-goi-sector-1-container-content">
			<div class="homenest-web-tron-goi-sector-1-container-content-img-wraper">
				<div class="homenest-web-tron-goi-sector-1-container-content-img"></div>
			</div>

			<div class="homenest-web-tron-goi-sector-1-container-content-body">
				<div class="homenest-web-tron-goi-sector-1-container-content-body-title">
					<div class="homenest-web-tron-goi-gradient-highlighted-word-3_gradient">
						<div style="display: inline; background-color: #121113; -webkit-background-clip: text; -webkit-text-fill-color: transparent;">WEBSITE TRỌN GÓI:</div> KHỞI ĐẦU 
					</div>				
					<div class="homenest-web-tron-goi-gradient-highlighted-word-3_gradient">
						VỮNG CHẮC CHO THƯƠNG HIỆU SỐ
					</div>
				</div>

				<div class="homenest-web-tron-goi-sector-1-container-content-body-description">
					<div class="homenest-web-tron-goi-sector-1-container-content-body-description-1">
						Bạn đang cần một website chuyên nghiệp, tối ưu tìm kiếm, có thể sinh ra khách hàng ngay sau khi bàn giao?
					</div>
					<div class="homenest-web-tron-goi-sector-1-container-content-body-description-2">
						HomeNest cung cấp giải pháp Thiết Kế Website Trọn Gói, giúp doanh nghiệp và cá nhân:
					</div>
					<div class="homenest-web-tron-goi-sector-1-container-content-body-description-3">
						<div class="homenest-web-tron-goi-sector-1-container-content-body-description-3-content">
							<div class="homenest-web-tron-goi-sector-1-container-content-body-description-3-content-text">
								Tiết kiệm thời gian, chi phí
							</div>						
						</div>
						<div class="homenest-web-tron-goi-sector-1-container-content-body-description-3-content">
							<div class="homenest-web-tron-goi-sector-1-container-content-body-description-3-content-text">
								Có ngay website sẵn sàng chạy quảng cáo, lên top Google.
							</div>						
						</div>
						<div class="homenest-web-tron-goi-sector-1-container-content-body-description-3-content">
							<div class="homenest-web-tron-goi-sector-1-container-content-body-description-3-content-text">
								Có ngay website sẵn sàng chạy quảng cáo, lên top Google.
							</div>						
						</div>
					</div>
					<div class="homenest-web-tron-goi-sector-1-container-content-body-description-4">
						Một website được xây dựng theo chuẩn SEO &amp; UX UI để vừa thu hút người dùng, vừa được Google đánh giá cao để lên TOP hiệu quả hơn.
					</div>				
				</div>
			</div>
		</div>

		<!-- Stat Block -->
		<div class="homenest-web-tron-goi-sector-1-container-stat">
			<div class="homenest-web-tron-goi-sector-1-container-stat-body">
				<div class="homenest-web-tron-goi-sector-1-container-stat-body-title homenest-web-tron-goi-gradient-highlighted-word-2_gradient">
					NHỮNG CON SỐ BIẾT NÓI
				</div>
				<div class="homenest-web-tron-goi-sector-1-container-stat-body-number">
					<div class="homenest-web-tron-goi-sector-1-container-stat-body-number-item">
						<div class="homenest-web-tron-goi-sector-1-container-stat-body-number-item-1">
							<div class="homenest-web-tron-goi-gradient-highlighted-word-2_gradient">600</div>
							<div style="bottom: 5px; position: relative;">
								+
							</div>
						</div>
						<div class="homenest-web-tron-goi-sector-1-container-stat-body-number-item-2">
							Website đã được HomeNest triển khai.
						</div>
					</div>
					<div class="homenest-web-tron-goi-sector-1-container-stat-body-number-item">
						<div class="homenest-web-tron-goi-sector-1-container-stat-body-number-item-1">
							<div class="homenest-web-tron-goi-gradient-highlighted-word-2_gradient">92 </div>%
						</div>
						<div class="homenest-web-tron-goi-sector-1-container-stat-body-number-item-2">
							Khách hàng quay lại với dịch vụ khác như: SEO, hosting, bảo trì
						</div>
					</div>
					<div class="homenest-web-tron-goi-sector-1-container-stat-body-number-item">
						<div class="homenest-web-tron-goi-sector-1-container-stat-body-number-item-1">
							<div class="homenest-web-tron-goi-gradient-highlighted-word-2_gradient">100 </div>%
						</div>
						<div class="homenest-web-tron-goi-sector-1-container-stat-body-number-item-2">
							Dự án đều có tăng trưởng lượt truy cập sau khi bàn giao
						</div>
					</div>				
				</div>
				<div class="homenest-web-tron-goi-sector-1-container-stat-body-line"></div>
				<div class="homenest-web-tron-goi-sector-1-container-stat-body-footer">
					Được tin tưởng bởi: Luxury Spa, EcomKids, Nhà hàng Vườn Phố, iTech Vietnam...
				</div>
			</div>
			<div class="homenest-web-tron-goi-sector-1-container-stat-img">
			<!-- stat graphic or image -->
			</div>
		</div>
		
	</div>
</div>
		
<div class="homenest-web-tron-goi-sector-2">
  <div class="homenest-web-tron-goi-sector-2-container">
    <div class="homenest-web-tron-goi-sector-2-container-title homenest-web-tron-goi-gradient-highlighted-word-2_gradient">
      AI NÊN CHỌN DỊCH VỤ NÀY?
    </div>

    <div class="homenest-web-tron-goi-sector-2-container-content">
      
      <!-- Item 1 -->
      <div class="homenest-web-tron-goi-sector-2-container-content-item">
        <div class="homenest-web-tron-goi-sector-2-container-content-item-headline">
          Những ai đã từng làm web nhưng không hiệu quả, cần làm lại bài bản
        </div>
      </div>

      <!-- Item 2 -->
      <div class="homenest-web-tron-goi-sector-2-container-content-item">
        <div class="homenest-web-tron-goi-sector-2-container-content-item-headline">
          Doanh nghiệp nhỏ, startup, cá nhân
        </div>
        <div class="homenest-web-tron-goi-sector-2-container-content-item-description">
          <div class="homenest-web-tron-goi-sector-2-container-content-item-description-item">
            Thiếu thời gian làm web
          </div>
          <div class="homenest-web-tron-goi-sector-2-container-content-item-description-item">
             Muốn lên online nhanh để bán hàng
          </div>
          <div class="homenest-web-tron-goi-sector-2-container-content-item-description-item">
             Cần website trông chuyên nghiệp, dễ SEO, dễ chạy quảng cáo
          </div>			
        </div>
      </div>

      <!-- Right image -->
      <div class="homenest-web-tron-goi-sector-2-container-content-img-wraper">
        <div class="homenest-web-tron-goi-sector-2-container-content-img"></div>
      </div>

    </div>
  </div>
</div>

<div class="homenest-web-tron-goi-sector-3">
	<div class="homenest-web-tron-goi-sector-3-container">
		<div class="homenest-web-tron-goi-sector-3-container-title homenest-web-tron-goi-gradient-highlighted-word-3_gradient">
			DỰ ÁN TIÊU BIỂU
		</div>
		<div class="homenest-web-tron-goi-sector-3-container-description">
			Dịch vụ thiết kế Website HomeNest đã thực hiện nhiều dự án tiêu biểu trong các lĩnh vực khác nhau, từ thương mại điện tử, giáo dục đến bất động sản. Các trang web do HomeNest thiết kế luôn nổi bật với giao diện trực quan, thân thiện với người dùng và tích hợp nhiều tính năng hiện đại. Bên cạnh đó, HomeNest luôn chú trọng đến việc tối ưu hóa trải nghiệm người dùng và đảm bảo tính tương thích trên mọi thiết bị. Những dự án này thể hiện sự chuyên nghiệp và sáng tạo, đáp ứng tốt nhu cầu đa dạng của khách hàng.
		</div>		
	</div>
</div>

<div class="homenest-web-tron-goi-sector-4">
	<div class="homenest-web-tron-goi-sector-4-container">
		<div class="homenest-web-tron-goi-sector-4-container-title">
			<div class="homenest-web-tron-goi-gradient-highlighted-word-2_gradient">
				QUY TRÌNH TRIỂN KHAI
				<div style="display:inline; background-color:#212529; -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
					&nbsp;WEBSITE TẠI HOMENEST
				</div>				
			</div>
		</div>	
	</div>
</div>	
		
<div class="homenest-web-tron-goi-sector-5">
	<div class="homenest-web-tron-goi-sector-5-container">
		<div class="homenest-web-tron-goi-sector-5-container-title">
			<div class="homenest-web-tron-goi-gradient-highlighted-word-2_gradient">
				WEBSITE TRỌN GÓI BAO GỒM NHỮNG GÌ?			
			</div>
		</div>
		<div class="homenest-web-tron-goi-sector-5-container-content">
			<div class="homenest-web-tron-goi-sector-5-container-content-text" style="grid-column: 1 / 4; grid-row: 1;">
				Bảo mật SSL, tối ưu tốc độ, tương thích mọi thiết bị
			</div>
			<div class="homenest-web-tron-goi-sector-5-container-content-text" style="grid-column: 1 / 4; grid-row: 2;">
				Tên miền và hosting tốc độ cao
			</div>
			<div class="homenest-web-tron-goi-sector-5-container-content-text" style="grid-column: 2 / 5; grid-row: 3;">
				Cấu trúc semantic, Sche, heading rõ ràng
			</div>
			<div class="homenest-web-tron-goi-sector-5-container-content-text" style="grid-column: 2 / 5; grid-row: 4;">
				Thiết kế giao diện độc quyền hoặc tùy chỉnh theo mẫu
			</div>
			<div class="homenest-web-tron-goi-sector-5-container-content-text" style="grid-column: 3 / 6; grid-row: 5;">
				Nội dung mẫu ( giới thiệu, dịch vụ, liên hệ,..) chuẩn Google AI
			</div>
			<div class="homenest-web-tron-goi-sector-5-container-content-text" style="grid-column: 3 / 6; grid-row: 6;">
				Tích hợp sẵn: Zalo chat, popup, form, bản đồ, social, sản phẩm, blog,...
			</div>
			<div class="homenest-web-tron-goi-sector-5-container-content-img-wraper-1"></div>
			<div class="homenest-web-tron-goi-sector-5-container-content-img-wraper-2"></div>
			<div class="homenest-web-tron-goi-sector-5-container-content-img-wraper-3"></div>
			<div class="homenest-web-tron-goi-sector-5-container-content-img-wraper-4"></div>
		</div>			
	</div>
</div>		

	</body>
	<?php
	if ( have_posts() ) :
	while ( have_posts() ) : the_post();
	the_content();
	endwhile;
	endif;
	?>
<script>

	
	
</script>


		
</main>
<?php get_footer(); ?>
