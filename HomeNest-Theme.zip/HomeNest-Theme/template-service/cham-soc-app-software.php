<?php
/**
 * Template Name: Chăm sóc vận hành app - phần mềm
 * Template Post Type: service
 */
get_header(); ?>
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<main>
	<section class="homenest_app_software_section1_hero">
		<div class="homenest_app_software_section1_container">
			<div class="homenest_app_software_section1_badge" data-aos="fade-up" data-aos-delay="600">HomeNest Software</div>

			<h1 class="homenest_app_software_section1_title" data-aos="fade-up" data-aos-delay="600">
				Dịch vụ chăm sóc vận hành<br />
				App và phần mềm
			</h1>

			<div class="homenest_app_software_section1_divider" data-aos="fade-up" data-aos-delay="600"></div>
			<p class="homenest_app_software_section1_subtitle">
				Hỗ trợ chuyên sâu từng ngày<br />
				Giữ vững nhịp phát triển bền lâu
			</p>
			<a href="#" class="homenest_app_software_section1_button">Liên hệ ngay</a>
			<div class="homenest_app_software_section1_note">
				Liên hệ ngay để nhận được tư vấn và ưu đãi hấp dẫn
			</div>
		</div>
	</section>
	<section class="homenest_app_software_section2_wrapper">
		<div class="homenest_app_software_section2_container">
			<div class="homenest_app_software_section2_intro">
				<p class="homenest_app_software_section2_subtitle">— Những điều bạn cần biết về dịch vụ tại HomeNest —</p>
				<h2 class="homenest_app_software_section2_title">
					Dịch vụ chăm sóc chuyên nghiệp<br>
					<span>Mang đến giải pháp <span class="highlight">sáng tạo.</span></span>
				</h2>
				<p class="homenest_app_software_section2_desc">
					Chúng tôi luôn mang đến các giải pháp chuyên nghiệp, ổn định, nhanh chóng cho dịch vụ của mình.
				</p>
			</div>

			<div class="homenest_app_software_section2_grid">
				<!-- Card 1 -->
				<div class="homenest_app_software_section2_card pink" data-aos="fade-right" data-aos-delay="100">
					<div class="homenest_app_software_section2_card_header_wrapper">
						<div class="homenest_app_software_section2_card_header">
							<h3>Các con số ấn tượng</h3>
							<svg width="20" fill="#fff" viewBox="0 0 256 256" xmlns="http://www.w3.org/2000/svg"><path d="M228 99.998a12 12 0 0 1-24 .004l-.004-31.027-51.539 51.539a12 12 0 1 1-16.97-16.971l51.538-51.54L156 52a12 12 0 0 1 0-24h.001l59.993.008a12 12 0 0 1 11.998 11.998ZM184 132a12 12 0 0 0-12 12v60H52V84h60a12 12 0 0 0 0-24H48a20.02 20.02 0 0 0-20 20v128a20.02 20.02 0 0 0 20 20h128a20.02 20.02 0 0 0 20-20v-64a12 12 0 0 0-12-12"/></svg>
						</div>
					</div>
					<p>Không chỉ mang đến dịch vụ chất lượng cao, chúng tôi còn mang đến giải pháp hiệu quả, tối ưu thời gian cho doanh nghiệp.</p>
					<div class="homenest_app_software_section2_stats">
						<div><strong class="count-up" data-target="2000">2000</strong><strong
																							class="count-up-after">+</strong><br><span>Khách hàng</span></div>
						<div><strong class="count-up" data-target="99">99</strong><strong
																						  class="count-up-after">%</strong><br><span>Hài lòng từ khách hàng</span></div>
					</div>

					<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/photo-4.png" alt="App UI Homenest" />
				</div>

				<div class="homenest_app_software_section2_card-group">
					<!-- Card 2 -->
					<div class="homenest_app_software_section2_card red" data-aos="fade-down" data-aos-delay="100">
						<div class="homenest_app_software_section2_card_header_wrapper">
							<div class="homenest_app_software_section2_card_header">
								<h3>Đảm bảo vận hành ổn định</h3>
								<svg width="20" fill="#fff" viewBox="0 0 256 256" xmlns="http://www.w3.org/2000/svg"><path d="M228 99.998a12 12 0 0 1-24 .004l-.004-31.027-51.539 51.539a12 12 0 1 1-16.97-16.971l51.538-51.54L156 52a12 12 0 0 1 0-24h.001l59.993.008a12 12 0 0 1 11.998 11.998ZM184 132a12 12 0 0 0-12 12v60H52V84h60a12 12 0 0 0 0-24H48a20.02 20.02 0 0 0-20 20v128a20.02 20.02 0 0 0 20 20h128a20.02 20.02 0 0 0 20-20v-64a12 12 0 0 0-12-12"/></svg>
							</div>
							<p>Theo dõi, báo trì thường xuyên và xử lý sự cố kịp thời, giúp ứng dụng hoặc phần mềm hoạt động mượt mà, không gián đoạn, đảm bảo trải nghiệm người dùng luôn tối ưu.</p>
						</div>
						<div class="homenest_app_software_section2_includes">
							<strong>Đa dạng lĩnh vực</strong><br>
							<span>CRM, kế toán, quản trị, kho bãi, bất động sản...</span>
						</div>
						<a href="#">Tìm hiểu thêm</a>
					</div>

					<!-- Card 3 -->
					<div class="homenest_app_software_section2_card blue" data-aos="fade-up" data-aos-delay="200">
						<div class="homenest_app_software_section2_card_header_wrapper">
							<div class="homenest_app_software_section2_card_header">
								<h3>Tối ưu hiệu suất và nâng cấp linh hoạt</h3>
								<svg width="20" fill="#fff" viewBox="0 0 256 256" xmlns="http://www.w3.org/2000/svg"><path d="M228 99.998a12 12 0 0 1-24 .004l-.004-31.027-51.539 51.539a12 12 0 1 1-16.97-16.971l51.538-51.54L156 52a12 12 0 0 1 0-24h.001l59.993.008a12 12 0 0 1 11.998 11.998ZM184 132a12 12 0 0 0-12 12v60H52V84h60a12 12 0 0 0 0-24H48a20.02 20.02 0 0 0-20 20v128a20.02 20.02 0 0 0 20 20h128a20.02 20.02 0 0 0 20-20v-64a12 12 0 0 0-12-12"/></svg>
							</div>
							<p>Dịch vụ bao gồm tối ưu hiệu suất vận hành, nâng cấp các tính năng và cập nhật phiên bản mới, giúp phần mềm luôn đáp ứng các yêu cầu mới, phát triển bền vững theo thời gian.</p>
						</div>
						<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/photo-6-1.png"
							 alt="Graph" />
					</div>
				</div>

				<!-- Card 4 -->
				<div class="homenest_app_software_section2_card dark" data-aos="fade-left" data-aos-delay="300">
					<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/photo-3-3.png" alt="3D Globe"
						 class="homenest_app_software_section2_card_img3d" />
					<div class="homenest_app_software_section2_card_header_wrapper">
						<div class="homenest_app_software_section2_card_header">
							<h3>Tiết kiệm và nâng cao hiệu quả quản lý</h3>
							<svg width="20" fill="#fff" viewBox="0 0 256 256" xmlns="http://www.w3.org/2000/svg"><path d="M228 99.998a12 12 0 0 1-24 .004l-.004-31.027-51.539 51.539a12 12 0 1 1-16.97-16.971l51.538-51.54L156 52a12 12 0 0 1 0-24h.001l59.993.008a12 12 0 0 1 11.998 11.998ZM184 132a12 12 0 0 0-12 12v60H52V84h60a12 12 0 0 0 0-24H48a20.02 20.02 0 0 0-20 20v128a20.02 20.02 0 0 0 20 20h128a20.02 20.02 0 0 0 20-20v-64a12 12 0 0 0-12-12"/></svg>
						</div>
						<p>HomeNest Software chăm sóc và vận hành doanh nghiệp giảm thiểu rủi ro, tiết kiệm chi phí vận hành và nhân sự quản lý, từ đó tập trung hơn vào phát triển kinh doanh cốt lõi.</p>
					</div>
				</div>
			</div>

			<div class="homenest_app_software_section2_footer">
				Bạn đang càn một giải pháp chất lượng? <a href="#">Click để tìm hiểu ngay</a>
			</div>
		</div>
	</section>
	<section class="homenest_app_software_section3_wrapper">
		<div class="homenest_app_software_section3_container">
			<div class="homenest_app_software_section3_grid">
				<!-- Image -->
				<div class="homenest_app_software_section3_image-wrapper">
					<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/photo-1-4.png"
						 alt="3D Illustration" class="homenest_app_software_section3_image" data-aos="fade-right" data-aos-delay="0"/>
				</div>

				<!-- Content -->
				<div class="homenest_app_software_section3_content">
					<span class="homenest_app_software_section3_tagline">— Về dịch vụ của chúng tôi —</span>
					<h2 class="homenest_app_software_section3_heading">
						Giữ cho ứng dụng luôn ổn định<br />
						<span class="highlight">Cùng HomeNest Software</span>
					</h2>
					<p class="homenest_app_software_section3_paragraph">
						HomeNest Software chuyên cung cấp dịch vụ chăm sóc và vận hành app, phần mềm.
					</p>
					<p class="homenest_app_software_section3_subparagraph">
						Với HomeNest Software, bạn hoàn toàn yên tâm về giải pháp phần mềm hiệu quả và bền vững.
					</p>

					<!-- Features -->
					<div class="homenest_app_software_section3_features">
						<ul>
							<li><svg width="20" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path  fill-opacity=".01" d="M0 0h48v48H0z"/><path d="M43 11 16.875 37 5 25.182" stroke="#4cbfff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg> Đảm bảo hoạt động ổn định liên tục</li>
							<li><svg width="20" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path  fill-opacity=".01" d="M0 0h48v48H0z"/><path d="M43 11 16.875 37 5 25.182" stroke="#4cbfff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg> Xử lý sự cố nhanh chóng</li>
							<li><svg width="20" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path  fill-opacity=".01" d="M0 0h48v48H0z"/><path d="M43 11 16.875 37 5 25.182" stroke="#4cbfff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg> Cập nhật và nâng cấp thường xuyên</li>
						</ul>
						<ul>
							<li><svg width="20" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path  fill-opacity=".01" d="M0 0h48v48H0z"/><path d="M43 11 16.875 37 5 25.182" stroke="#4cbfff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg> Tối ưu hiệu suất ứng dụng</li>
							<li><svg width="20" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path  fill-opacity=".01" d="M0 0h48v48H0z"/><path d="M43 11 16.875 37 5 25.182" stroke="#4cbfff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg> Tiết kiệm chi phí và thời gian quản lý</li>
							<li><svg width="20" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path  fill-opacity=".01" d="M0 0h48v48H0z"/><path d="M43 11 16.875 37 5 25.182" stroke="#4cbfff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg> An toàn dữ liệu và bảo mật</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="homenest_app_software_section4_wrapper">
		<div class="homenest_app_software_section4_container">
			<div class="homenest_app_software_section4_heading">
				<span class="homenest_app_software_section4_tagline">— Tại sao bạn nên chọn HomeNest Software —</span>
				<h2>
					HomeNest Software<br />
					<span>Giải pháp quản lý phần mềm, app toàn diện.</span>
				</h2>
				<p>Đổi tác đáng tin cậy – Cùng bạn xây dựng nền tảng số vững mạnh cho tương lai.</p>
			</div>

			<div class="homenest_app_software_section4_grid">
				<!-- Card -->
				<div class="homenest_app_software_section4_card" data-aos="fade-up" data-aos-delay="0">
					<div class="homenest_app_software_section4_icon">
						<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/icon-1-2.png" alt="icon Homenest" />
					</div>
					<h3>Đội ngũ giàu kinh nghiệm</h3>
					<p>Sở hữu đội ngũ kỹ thuật viên chuyên nghiệp và giàu kinh nghiệm, luôn sẵn sàng hỗ trợ đảm bảo hệ thống của bạn vận hành ổn định và hiệu quả.</p>
				</div>

				<div class="homenest_app_software_section4_card" data-aos="fade-up" data-aos-delay="0">
					<div class="homenest_app_software_section4_icon">
						<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/icon-3.png" alt="icon Homenest" />
					</div>
					<h3>Dịch vụ linh hoạt</h3>
					<p>Gói dịch vụ chăm sóc và vận hành phù hợp với đặc thù và nhu cầu riêng của từng khách hàng, mang lại giải pháp tối ưu và cá nhân hóa.</p>
				</div>

				<div class="homenest_app_software_section4_card" data-aos="fade-up" data-aos-delay="0">
					<div class="homenest_app_software_section4_icon">
						<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/icon-4.png" alt="icon Homenest" />
					</div>
					<h3>Tối ưu hóa hiệu suất ứng dụng</h3>
					<p>Giúp bạn chăm sóc phần mềm, bạn có thể tập trung nguồn lực vào phát triển kinh doanh cốt lõi, giảm thiểu thời gian và công sức quản lý kỹ thuật.</p>
				</div>

				<div class="homenest_app_software_section4_card" data-aos="fade-up" data-aos-delay="0">
					<div class="homenest_app_software_section4_icon">
						<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/icon-5.png" alt="icon Homenest" />
					</div>
					<h3>Tiết kiệm thời gian quản lý</h3>
					<p>Sở hữu đội ngũ kỹ thuật viên chuyên nghiệp và giàu kinh nghiệm, luôn sẵn sàng hỗ trợ đảm bảo hệ thống của bạn vận hành ổn định và hiệu quả.</p>
				</div>

				<div class="homenest_app_software_section4_card" data-aos="fade-up" data-aos-delay="400">
					<div class="homenest_app_software_section4_icon">
						<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/icon-6.png" alt="icon Homenest" />
					</div>
					<h3>Xử lý sự cố nhanh chóng</h3>
					<p>Cam kết phản ứng và khắc phục các sự cố kỹ thuật một cách nhanh nhất, giúp giảm thiểu gián đoạn và tổn thất cho doanh nghiệp.</p>
				</div>

				<div class="homenest_app_software_section4_card" data-aos="fade-up" data-aos-delay="400">
					<div class="homenest_app_software_section4_icon">
						<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/icon-8.png" alt="icon Homenest" />
					</div>
					<h3>Chi phí hợp lý</h3>
					<p>Chúng tôi mang đến giải pháp chăm sóc vận hành hiệu quả với mức chi phí cạnh tranh, mang lại giá trị tối đa cho khách hàng.</p>
				</div>

				<div class="homenest_app_software_section4_card" data-aos="fade-up" data-aos-delay="400">
					<div class="homenest_app_software_section4_icon">
						<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/icon-7.png" alt="icon Homenest" />
					</div>
					<h3>Chính sách minh bạch</h3>
					<p>Mọi quy trình, hợp đồng và chi phí đều được chúng tôi công khai rõ ràng, đảm bảo khách hàng hoàn toàn yên tâm khi hợp tác.</p>
				</div>

				<div class="homenest_app_software_section4_card" data-aos="fade-up" data-aos-delay="400">
					<div class="homenest_app_software_section4_icon">
						<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/icon-2.png" alt="icon Homenest" />
					</div>
					<h3>Cam kết chất lượng</h3>
					<p>Luôn đặt chất lượng dịch vụ lên hàng đầu, đồng hành cùng bạn đảm bảo ứng dụng được vận hành ổn định, an toàn và liên tục phát triển.</p>
				</div>
			</div>
		</div>
	</section>
	<section class="homenest_app_software_section5_wrapper">
		<div class="homenest_app_software_section5_container">
			<div class="homenest_app_software_section3_content">
				<span class="homenest_app_software_section3_tagline">— Dự án —</span>
				<h2 class="homenest_app_software_section3_heading">
					Dịch vụ chuyên nghiệp<br>
					<span class="highlight">Không ngừng sáng tạo</span>
				</h2>
				<p class="homenest_app_software_section3_paragraph">
					HomeNest Software cung cấp dịch vụ chăm sóc và vận hành phần mềm chuyên nghiệp.
				</p>
				<p class="homenest_app_software_section3_subparagraph">
					chúng tôi cam kết đồng hành cùng doanh nghiệp trong hành trình chuyển đổi số, thúc đẩy phát triển bền vững trong Kỷ nguyên số.
				</p>

				<!-- Features -->
				<div class="homenest_app_software_section5_info">
					<svg width="16" viewBox="0 -64 640 640" fill="#fff" xmlns="http://www.w3.org/2000/svg"><path d="m622.3 271.1-115.2-45c-4.1-1.6-12.6-3.7-22.2 0l-115.2 45c-10.7 4.2-17.7 14-17.7 24.9 0 111.6 68.7 188.8 132.9 213.9 9.6 3.7 18 1.6 22.2 0C558.4 489.9 640 420.5 640 296c0-10.9-7-20.7-17.7-24.9M496 462.4V273.3l95.5 37.3c-5.6 87.1-60.9 135.4-95.5 151.8M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128m96 40c0-2.5.8-4.8 1.1-7.2-2.5-.1-4.9-.8-7.5-.8h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c6.8 0 13.3-1.5 19.2-4-54-42.9-99.2-116.7-99.2-212"/></svg>
					<span>Khám phá các dự án nổi bật của chúng tôi</span>
				</div>
				<button href="/case-studies/" class="homenest_app_software_section5_button">Khám phá ngay</button>
			</div>
			<div class="homenest_app_software_section5_image">
				<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/photo-2-1.png"
					 alt="Security illustration" data-aos="fade-left" data-aos-delay="400">
			</div>
		</div>
	</section>
	<section class="homenest_app_software_section6_wrapper">
		<div class="homenest_app_software_section6_container">
			<div class="homenest_app_software_section6_image">
				<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/photo-7.png"
					 alt="Cloud binary illustration" data-aos="fade-right" data-aos-delay="400"/>
			</div>
			<div class="homenest_app_software_section3_content">
				<span class="homenest_app_software_section3_tagline">— Đánh giá từ khách hàng —</span>
				<h2 class="homenest_app_software_section3_heading">
					Không ngừng lắng nghe<br>
					<span class="highlight">Và cải thiện dịch vụ mỗi ngày</span>
				</h2>
				<p class="homenest_app_software_section3_paragraph">
					Lời đánh giá của khách hàng là động lực giúp HomeNest sáng tạo mỗi ngày.
				</p>
				<p class="homenest_app_software_section3_subparagraph">
					Với HomeNest Software, bạn hoàn toàn yên tâm về giải pháp phần mềm hiệu quả và bền vững trong thời đại số.
				</p>

				<div class="homenest_app_software_section6_rating-box">
					<div class="homenest_app_software_section6_rating-left">
						<span class="homenest_app_software_section6_rating-number count-up-review" data-target="4.8">0</span>
					</div>
					<div class="homenest_app_software_section6_rating-right">
						<div class="homenest_app_software_section6_rating-stars">
							Đánh giá dịch vụ (<span class="count-up-review" data-target="4.8">0</span>)
							<span class="stars">★★★★★</span>
						</div>
						<div class="homenest_app_software_section6_feedback">
							<svg width="14" fill="#2c63f9" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M12 2C6.5 2 2 6.5 2 12c0 2.3.8 4.5 2.3 6.3l-2 2c-.4.4-.4 1 0 1.4.2.2.4.3.7.3h9c5.5 0 10-4.5 10-10S17.5 2 12 2M8 13c-.6 0-1-.4-1-1s.4-1 1-1 1 .4 1 1-.4 1-1 1m4 0c-.6 0-1-.4-1-1s.4-1 1-1 1 .4 1 1-.4 1-1 1m4 0c-.6 0-1-.4-1-1s.4-1 1-1 1 .4 1 1-.4 1-1 1"/></svg>
							Các đánh giá từ khách hàng
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="homenest_app_software_section7_wrapper">
		<div class="homenest_app_software_section7_container">
			<p class="homenest_app_software_section7_subtitle">— Quy trình dịch vụ chăm sóc app và phần mềm —</p>
			<h2 class="homenest_app_software_section7_title">
				Giải pháp hoàn hảo<br>
				<span class="highlight">Bắt đầu bằng quy trình chuyên nghiệp</span>
			</h2>
			<p class="homenest_app_software_section7_desc">
				4 bước quy trình dịch vụ chăm sóc app và phần mềm tại HomeNest Software
			</p>

			<div class="homenest_app_software_section7_steps">
				<div class="homenest_app_software_section7_step">
					<div class="homenest_app_software_section7_step-number">1</div>
					<div class="homenest_app_software_section7_step-content">
						<h3>Đánh giá hệ thống</h3>
						<p>Kiểm tra tổng thể và phân tích hiệu suất ứng dụng để phát hiện các vấn đề tiềm ẩn.</p>
					</div>
				</div>

				<div class="homenest_app_software_section7_step">
					<div class="homenest_app_software_section7_step-number">2</div>
					<div class="homenest_app_software_section7_step-content">
						<h3>Lập kế hoạch chăm sóc</h3>
						<p>Xây dựng kế hoạch bảo trì, cập nhật và tối ưu phù hợp với nhu cầu khách hàng.</p>
					</div>
				</div>

				<div class="homenest_app_software_section7_step">
					<div class="homenest_app_software_section7_step-number">3</div>
					<div class="homenest_app_software_section7_step-content">
						<h3>Thực hiện bảo trì và hỗ trợ</h3>
						<p>Bảo trì định kỳ, xử lý các sự cố và cập nhật phiên bản mới phù hợp và nhanh chóng.</p>
					</div>
				</div>

				<div class="homenest_app_software_section7_step">
					<div class="homenest_app_software_section7_step-number">4</div>
					<div class="homenest_app_software_section7_step-content">
						<h3>Giám sát và tối ưu liên tục</h3>
						<p>Theo dõi vận hành liên tục, đánh giá và điều chỉnh để duy trì hiệu suất ổn định và tối ưu.</p>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="homenest_app_software_section8_wrapper">
		<div class="homenest_app_software_section8_container">
			<h2 class="homenest_app_software_section8_title">
				Nếu bạn có câu hỏi về dịch vụ của chúng tôi<br />
				Bạn có thể để lại email ở đây.
			</h2>
			<p class="homenest_app_software_section8_subtitle">
				Chúng tôi muốn lắng nghe và đáp ứng nhu cầu của bạn
			</p>

			<form class="homenest_app_software_section8_form">
				<div class="homenest_app_software_section8_input_wrapper">
					<span class="homenest_app_software_section8_icon">@</span>
					<input type="email" placeholder="Email của bạn" required />
				</div>
				<button type="submit">Gửi ngay</button>
			</form>
		</div>
	</section>
	<section class="homenest_app_software_section9_wrapper">
		<div class="homenest_app_software_section9_container">
			<div class="homenest_app_software_section9_header">
				<p class="homenest_app_software_section9_label">— Dịch vụ khác —</p>
				<h2 class="homenest_app_software_section9_title">
					Sẵn sàng với các dịch vụ<br />
					<span class="highlight">Sáng tạo cùng HomeNest Software.</span>
				</h2>
			</div>

			<div class="homenest_app_software_section9_grid">
				<!-- Row 1: 2 columns -->
				<div class="homenest_app_software_section9_row row-2-cols">
					<div class="homenest_app_software_section9_card" data-aos="fade-right" data-aos-delay="300">
						<div class="homenest_app_software_section9_info">
							<p class="company">HomeNest Software</p>
							<h3>Dịch vụ thiết kế App</h3>
						</div>
						<div class="homenest_app_software_section9_image"
							 style="background-image: url('https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/photo-10.jpg');">
						</div>
						<a href="/dich-vu/thiet-ke-app/" class="read-more-btn">Tìm hiểu thêm</a>
					</div>

					<div class="homenest_app_software_section9_card" data-aos="fade-left" data-aos-delay="300">
						<div class="homenest_app_software_section9_info">
							<p class="company">HomeNest Software</p>
							<h3>Dịch vụ thiết kế phần mềm</h3>
						</div>
						<div class="homenest_app_software_section9_image"
							 style="background-image: url('https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/photo-14-1.jpg');">
						</div>
						<a href="/dich-vu/thiet-ke-phan-mem/" class="read-more-btn">Tìm hiểu thêm</a>
					</div>
				</div>

				<!-- Row 2: 3 columns -->
				<div class="homenest_app_software_section9_row row-3-cols">
					<div class="homenest_app_software_section9_card" data-aos="fade-right" data-aos-delay="300">
						<div class="homenest_app_software_section9_info">
							<p class="company">HomeNest Software</p>
							<h3>Dịch vụ thiết kế Website</h3>
						</div>
						<div class="homenest_app_software_section9_image"
							 style="background-image: url('https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/photo-11.jpg');">
						</div>
						<a href="/dich-vu/thiet-ke-website/" class="read-more-btn">Tìm hiểu thêm</a>
					</div>

					<div class="homenest_app_software_section9_card" data-aos="fade-up" data-aos-delay="300">
						<div class="homenest_app_software_section9_info">
							<p class="company">HomeNest Software</p>
							<h3>Dịch vụ Digital Marketing</h3>
						</div>
						<div class="homenest_app_software_section9_image"
							 style="background-image: url('https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/photo-12.jpg');">
						</div>
						<a href="/dich-vu/digital-marketing/" class="read-more-btn">Tìm hiểu thêm</a>
					</div>

					<div class="homenest_app_software_section9_card" data-aos="fade-left" data-aos-delay="300">
						<div class="homenest_app_software_section9_info">
							<p class="company">HomeNest Software</p>
							<h3>Dịch vụ chăm sóc Website</h3>
						</div>
						<div class="homenest_app_software_section9_image"
							 style="background-image: url('https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/blog-2-1.jpg');">
						</div>
						<a href="/dich-vu/cham-soc-van-hanh-website/" class="read-more-btn">Tìm hiểu thêm</a>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="homenest_app_software_section10_wrapper">
		<div class="homenest_app_software_section10_container">
			<h3 class="homenest_app_software_section10_title">
				Hơn <span class="highlight">2000+</span> đối tác đã và đang đồng hành cùng HomeNest Software
			</h3>

			<div class="homenest_app_software_section10_logos">
				<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/logo-1.png"
					 alt="TALK & ACTION" />
				<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/logo-2.png" alt="Sky Cloud" />
				<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/logo-3.png" alt="JUMPKINS" />
				<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/logo-4.png" alt="TOTB+" />
				<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/logo-5.png" alt="WALK AWAY" />
			</div>
		</div>
	</section>

	<section class="homenest_app_software_section11_wrapper">
		<div class="homenest_app_software_section11_container">
			<p class="homenest_app_software_section11_subtitle">— Bảng giá dịch vụ —</p>
			<h2 class="homenest_app_software_section11_title">
				Các gói dịch vụ <br />
				<span class="highlight">Chăm sóc <span class="gradient">App, phần mềm.</span></span>
			</h2>
			<p class="homenest_app_software_section11_desc">
				Tham khảo chi tiết bảng giá dịch vụ chăm sóc App, phần mềm chuyên nghiệp tại HomeNest Software
			</p>

			<div class="homenest_app_software_section11_cards" data-aos="fade-up" data-aos-delay="300">
				<!-- BASIC -->
				<div class="homenest_app_software_section11_card">
					<h3>BASIC</h3>
					<p class="terms">TERMS & CONDITION</p>
					<div class="price">
						<span class="currency">$</span><span class="amount">39.99</span><span class="period">Month</span>
					</div>
					<ul class="features">
						<li class="yes">Upgrade to a paid Version</li>
						<li class="yes">Access the Product or Service</li>
						<li class="no">Users who access the Software</li>
						<li class="no">Upgrades and support may require</li>
						<li class="no">This may include volume discounts</li>
					</ul>
					<button class="start-btn">Start Now</button>
				</div>

				<!-- STANDART -->
				<div class="homenest_app_software_section11_card">
					<h3>STANDART</h3>
					<p class="terms">TERMS & CONDITION</p>
					<div class="price">
						<span class="currency">$</span><span class="amount">89.99</span><span class="period">Month</span>
					</div>
					<ul class="features">
						<li class="yes">Upgrade to a paid Version</li>
						<li class="yes">Access the Product or Service</li>
						<li class="yes">Users who access the Software</li>
						<li class="no">Upgrades and support may require</li>
						<li class="no">This may include volume discounts</li>
					</ul>
					<button class="start-btn">Start Now</button>
				</div>

				<!-- PREMIUM -->
				<div class="homenest_app_software_section11_card premium">
					<h3>PREMIUM</h3>
					<p class="terms">TERMS & CONDITION</p>
					<div class="price">
						<span class="currency">$</span><span class="amount">120.99</span><span class="period">Month</span>
					</div>
					<ul class="features">
						<li class="yes">Upgrade to a paid Version</li>
						<li class="yes">Access the Product or Service</li>
						<li class="yes">Users who access the Software</li>
						<li class="yes">Upgrades and support may require</li>
						<li class="yes">This may include volume discounts</li>
					</ul>
					<button class="start-btn">Start Now</button>
				</div>
			</div>
		</div>
	</section>
	<section class="homenest_app_software_section12_wrapper">
		<div class="homenest_app_software_section12_container">
			<div class="homenest_app_software_section12_heading">
				<span class="tagline">— Các câu hỏi thường gặp</span>
				<h2>
					Các câu hỏi thường gặp<span class="highlight"> về dịch vụ của chúng tôi</span>
				</h2>
				<p>Các câu hỏi phổ biến về dịch vụ chăm sóc App và phần mềm tại HomeNest Software</p>
			</div>

			<div class="homenest_app_software_section12_faqs">
				<div class="faq-col">
					<div class="faq-item">
						<h3>Thời gian phản hồi khi có sự cố là bao lâu?</h3>
						<p>
							Homenest cam kết hỗ trợ kỹ thuật 24/7 với thời gian phản hồi nhanh chóng, giúp xử lý sự cố kịp thời, giảm thiểu tối đa thời gian gián đoạn.
						</p>
					</div>
					<div class="faq-item">
						<h3>HomeNest có đảm bảo bảo mật dữ liệu không?</h3>
						<p>
							Chúng tôi áp dụng các biện pháp bảo mật tiên tiến và sao lưu định kỳ để bảo vệ dữ liệu khách hàng an toàn tuyệt đối.
						</p>
					</div>
					<div class="faq-item">
						<h3>Tôi có thể theo dõi quá trình vận hành như thế nào?</h3>
						<p>
							Homenest cung cấp báo cáo định kỳ chi tiết về tình trạng hệ thống, hoạt động bảo trì và các chỉ số hiệu suất để khách hàng dễ dàng theo dõi.
						</p>
					</div>
				</div>

				<div class="faq-col">
					<div class="faq-item">
						<h3>Chi phí dịch vụ được tính như thế nào?</h3>
						<p>
							Chi phí được thiết kế linh hoạt phù hợp với quy mô và nhu cầu từng doanh nghiệp, minh bạch và không phát sinh, đảm bảo hiệu quả đầu tư.
						</p>
					</div>
					<div class="faq-item">
						<h3>HomeNest có hỗ trợ cập nhật và nâng cấp tính năng mới không?</h3>
						<p>
							Có, Homenest hỗ trợ cập nhật công nghệ mới và phát triển thêm tính năng theo yêu cầu nhằm nâng cao hiệu suất và trải nghiệm người dùng.
						</p>
					</div>
					<div class="faq-item">
						<h3>Dịch vụ có phù hợp với doanh nghiệp nhỏ và startup không?</h3>
						<p>
							Có, các gói dịch vụ tại HomeNest Software được thiết kế linh hoạt, phù hợp từ các startup đến các tập đoàn lớn.
						</p>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="homenest_app_software_section13_wrapper" >
		<div class="homenest_app_software_section13_container" data-aos="fade-up" data-aos-delay="300">
			<h2>
				Không ngừng sáng tạo và đổi mới <br />
				Đem lại trải nghiệm dịch vụ tốt nhất cho khách hàng
			</h2>
			<p>Chúng tôi không ngừng nỗ lực, sáng tạo và đổi mới mỗi ngày để mang lại các dịch vụ tốt nhất cho khách hàng</p>
			<a href="/about-us/" class="homenest_app_software_section13_btn">Khám phá ngay</a>
		</div>
	</section>
	<section class="homenest_app_software_section14">
		<div class="container">
			<!-- LEFT - ARTICLES -->
			<div class="left">
				<p class="homenest_app_software_section7_subtitle">— ARTICLE & NEWS</p>
				<h2 class="homenest_app_software_section7_title">
					Update Article<br>
					<span class="highlight">& More Archives​</span>
				</h2>
				<p class="homenest_app_software_section7_desc">
					Learn about and our news Information.
				</p>

				<div class="articles">
					<!-- Card 1 -->
					<div class="card">
						<div class="image-wrapper">
							<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/photo-11.jpg"
								 alt="Article 1">
							<span class="date">20 Mar</span>
						</div>
						<h4>AI Software that Helps Human Work</h4>
						<p>Single Blog & Archive AI Software that Helps Human Work by Hendrik Morella...</p>
						<a href="#">Read More</a>
					</div>

					<!-- Card 2 -->
					<div class="card">
						<div class="image-wrapper">
							<img src="https://hrkit.rometheme.pro/zenith/wp-content/uploads/sites/69/2023/03/photo-9.jpg"
								 alt="Article 2">
							<span class="date">20 Mar</span>
						</div>
						<h4>Explore to New Tech with Zenith</h4>
						<p>Single Blog & Archive Explore to New Tech with Zenith by Hendrik Morella...</p>
						<a href="#">Read More</a>
					</div>
				</div>
			</div>

			<!-- RIGHT - FORM -->
			<div class="right">
				<h3>Liên hệ ngay để nhận ưu đãi hấp dẫn</h3>
				<form>
					<label>Họ và tên *</label>
					<input type="text" placeholder="Hendrik">
					<small>Enter your first name</small>

					<label>Địa chỉ Email *</label>
					<input type="email" placeholder="awesomesite@mail.com">
					<small>Example: awesomesite@mail.com</small>

					<label>Ghi chú thêm</label>
					<textarea rows="12" placeholder="Input Message Here"></textarea>

					<button type="submit">Nhấn để gửi</button>
				</form>
			</div>
		</div>
	</section>

	<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
	
</main>

<?php get_footer(); ?>