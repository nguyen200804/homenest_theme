<?php
/**
 * Template Name: Digital Marketing
 * Template Post Type: service
 */
get_header(); ?>

<main>
	<section class="section1">
		<section class="section1_col1 background_caro">
			<div class="sub_title ">
				<svg aria-hidden="true" class="sub_title_icon e-font-icon-svg e-fas-circle" viewBox="0 0 512 512"
					 xmlns="http://www.w3.org/2000/svg">
					<path d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8z"></path>
				</svg>

				<span>Dịch vụ Digital Marketing</span>
			</div>

			<h1 class="section1_col1_main_title first">
				HomeNest
				<div class="section1_col1_main_title_highligt promt_font">
					<span class="main_title_highligt"> Digital</span>
					<span class="section1_col1_main_title_highligt2"> Marketing.</span>
				</div>
			</h1>

			<p class="section1_col1_content">Không vẽ vời lý thuyết. Chúng tôi tập trung vào các chỉ số tăng trưởng thực tế (ROI), giúp doanh nghiệp tiếp cận đúng khách hàng, đúng thời điểm với ngân sách tối ưu nhất.</p>

			<div class="section1_col1_list_btt">
				<a href="#" class="button_gradient section1_col1_button_white section1_col1_button">
					Tìm hiểu thêm
					<svg aria-hidden="true"
						 class="button_gradient_icon button_white_icon e-font-icon-svg e-fas-arrow-circle-right"
						 viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
						<path
							  d="M256 8c137 0 248 111 248 248S393 504 256 504 8 393 8 256 119 8 256 8zm-28.9 143.6l75.5 72.4H120c-13.3 0-24 10.7-24 24v16c0 13.3 10.7 24 24 24h182.6l-75.5 72.4c-9.7 9.3-9.9 24.8-.4 34.3l11 10.9c9.4 9.4 24.6 9.4 33.9 0L404.3 273c9.4-9.4 9.4-24.6 0-33.9L271.6 106.3c-9.4-9.4-24.6-9.4-33.9 0l-11 10.9c-9.5 9.6-9.3 25.1.4 34.4z">
						</path>
					</svg>
				</a>

				<a href="#" class="button_gradient section1_col1_button">
					Liên hệ ngay
					<svg aria-hidden="true" class="button_gradient_icon  e-font-icon-svg e-fas-arrow-circle-right"
						 viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
						<path
							  d="M256 8c137 0 248 111 248 248S393 504 256 504 8 393 8 256 119 8 256 8zm-28.9 143.6l75.5 72.4H120c-13.3 0-24 10.7-24 24v16c0 13.3 10.7 24 24 24h182.6l-75.5 72.4c-9.7 9.3-9.9 24.8-.4 34.3l11 10.9c9.4 9.4 24.6 9.4 33.9 0L404.3 273c9.4-9.4 9.4-24.6 0-33.9L271.6 106.3c-9.4-9.4-24.6-9.4-33.9 0l-11 10.9c-9.5 9.6-9.3 25.1.4 34.4z">
						</path>
					</svg>
				</a>
			</div>

<!-- 			<div class="section1_col1_play_btt">
				<div class="section1_col1_play_btt_wrap_icon">
					<i class="fas fa-play section1_col1_play_btt_icon"></i>
					<span class="section1_col1_play_btt_wrap_icon_animation "></span>
					<span class="section1_col1_play_btt_wrap_icon_animation delay1"></span>
					<span class="section1_col1_play_btt_wrap_icon_animation delay2"></span>
					<span class="section1_col1_play_btt_wrap_icon_animation delay3"></span>
				</div>
				CLICK FOR PORTFOLIO
			</div> -->

			<section class="section1_col1_list_counter">
				<div class="section1_col1_counter1 section1_col1_counter background_gradient">
					<div class="section1_col1_counter_icon icon1">
						<svg class="section1_up_right_icon" width="800px" height="800px" color="white"
							 viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill="none" stroke="#000000"
							 stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
							 class="feather feather-arrow-up-right">
							<line x1="7" y1="17" x2="17" y2="7"></line>
							<polyline points="7 7 17 7 17 17"></polyline>
						</svg>
					</div>

					<div class="section1_col1_counter1_align_text">
						<div class="section1_col1_counter1_value orbitron_font">
							1000+
						</div>
						<div class="section1_col1_counter1_content">
							Dự án
						</div>
					</div>
				</div>

				<div class="section1_col1_counter2 section1_col1_counter">
					<div class="section1_col1_counter_icon">
						<svg class="section1_up_right_icon" width="800px" height="800px" color="white"
							 viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill="none" stroke="#000000"
							 stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
							 class="feather feather-arrow-up-right">
							<line x1="7" y1="17" x2="17" y2="7"></line>
							<polyline points="7 7 17 7 17 17"></polyline>
						</svg>
					</div>

					<div class="section1_col1_counter2_value orbitron_font">
						50
					</div>


					<div class="section1_col1_counter2_content">
						LĨNH VỰC
					</div>

				</div>

				<div class="section1_col1_counter3 section1_col1_counter">
					<div class="section1_col1_counter_icon">
						<svg class="section1_up_right_icon" width="800px" height="800px" color="white"
							 viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill="none" stroke="#000000"
							 stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
							 class="feather feather-arrow-up-right">
							<line x1="7" y1="17" x2="17" y2="7"></line>
							<polyline points="7 7 17 7 17 17"></polyline>
						</svg>
					</div>

					<div class="section1_col1_counter3_value orbitron_font">
						+ <span class="section1_col1_counter3_value_value">300</span>
					</div>


					<div class="section1_col1_counter3_content">
						ĐỐI TÁC
					</div>
				</div>
			</section>
		</section>

		<section class="section1_col2 background_gradient">
			<section class="section1_col2_wrap_wrap">
				<section class="section1_col2_wrap box2">
					<div class="section1_col2_wrap_img">
						<div class="section1_col2_img">
							<img class="section1_col2_image1 box2" loading="lazy" decoding="async" src="/wp-content/uploads/2025/08/Image2.jpg" alt="Homenest" title="Homenest">
						</div>
					</div>

					<div class="section1_col2_hidden_box2">
						<h3 class="section1_col2_title">Phát triển toàn diện</h3>

						<div class="section1_col2_text">
							<div class="section1_col2_text1a">
								<svg aria-hidden="true" class="e-font-icon-svg e-fab-diaspora" viewBox="0 0 512 512"
									 xmlns="http://www.w3.org/2000/svg">
									<path
										  d="M251.64 354.55c-1.4 0-88 119.9-88.7 119.9S76.34 414 76 413.25s86.6-125.7 86.6-127.4c0-2.2-129.6-44-137.6-47.1-1.3-.5 31.4-101.8 31.7-102.1.6-.7 144.4 47 145.5 47 .4 0 .9-.6 1-1.3.4-2 1-148.6 1.7-149.6.8-1.2 104.5-.7 105.1-.3 1.5 1 3.5 156.1 6.1 156.1 1.4 0 138.7-47 139.3-46.3.8.9 31.9 102.2 31.5 102.6-.9.9-140.2 47.1-140.6 48.8-.3 1.4 82.8 122.1 82.5 122.9s-85.5 63.5-86.3 63.5c-1-.2-89-125.5-90.9-125.5z">
									</path>
								</svg>
							</div>

							<div class="section1_col2_text1b">
								Phân tích hành vi chuyên sâu, cá nhân hóa thông điệp và tối đa hóa hiệu suất chuyển đổi cho doanh nghiệp
							</div>
						</div>
					</div>
				</section>

				<div class="section1_col2_wrap">
					<div class="section1_col2_wrap_img">
						<div class="section1_col2_img">
							<img class="section1_col2_image1" loading="lazy" decoding="async"
								 src="/wp-content/uploads/2025/08/four-female-partners-sitting-at-desk-and-discussin-2024-12-13-13-45-03-utc.jpg" alt="Homenest" title="Homenest">
						</div>
						<img class="section1_col2_image2" loading="lazy" decoding="async"
							 src="/wp-content/uploads/2025/08/satisfied-young-woman-reads-interesting-invitation-2025-01-23-21-30-28-utc-2.png" alt="Homenest" title="Homenest">
					</div>


					<h3 class="section1_col2_title">Phát triển toàn diện</h3>

					<div class="section1_col2_text">
						<div class="section1_col2_text1a">
							<svg aria-hidden="true" class="e-font-icon-svg e-fab-diaspora" viewBox="0 0 512 512"
								 xmlns="http://www.w3.org/2000/svg">
								<path
									  d="M251.64 354.55c-1.4 0-88 119.9-88.7 119.9S76.34 414 76 413.25s86.6-125.7 86.6-127.4c0-2.2-129.6-44-137.6-47.1-1.3-.5 31.4-101.8 31.7-102.1.6-.7 144.4 47 145.5 47 .4 0 .9-.6 1-1.3.4-2 1-148.6 1.7-149.6.8-1.2 104.5-.7 105.1-.3 1.5 1 3.5 156.1 6.1 156.1 1.4 0 138.7-47 139.3-46.3.8.9 31.9 102.2 31.5 102.6-.9.9-140.2 47.1-140.6 48.8-.3 1.4 82.8 122.1 82.5 122.9s-85.5 63.5-86.3 63.5c-1-.2-89-125.5-90.9-125.5z">
								</path>
							</svg>
						</div>

						<div class="section1_col2_text1b">
							Phân tích hành vi chuyên sâu, cá nhân hóa thông điệp và tối đa hóa hiệu suất chuyển đổi cho doanh nghiệp
						</div>
					</div>
				</div>
			</section>
		</section>
	</section>

	<section class="section2">
		<section class="section2_row1">
			<section class="section2_row1_col1">
				<div class="sub_title ">
					<svg aria-hidden="true" class="sub_title_icon e-font-icon-svg e-fas-circle" viewBox="0 0 512 512"
						 xmlns="http://www.w3.org/2000/svg">
						<path d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8z"></path>
					</svg>

					<span>DỊCH VỤ</span>
				</div>

				<h2 class="section1_col1_main_title">
					Giải pháp Digital Marketing mà
					<span class="main_title_highligt"> HomeNest</span>
					cung cấp
				</h2>
			</section>


			<section class="section2_row1_col2">
				Cung cấp bộ công cụ tiếp thị toàn diện để xây dựng thương hiệu, sáng tạo nội dung đến tối ưu hiệu suất quảng cáo đa kênh.

				<a href="#" class="section2_row1_col2_button button_gradient">
					Tìm hiểu thêm
					<svg aria-hidden="true" class="button_gradient_icon  e-font-icon-svg e-fas-arrow-circle-right"
						 viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
						<path
							  d="M256 8c137 0 248 111 248 248S393 504 256 504 8 393 8 256 119 8 256 8zm-28.9 143.6l75.5 72.4H120c-13.3 0-24 10.7-24 24v16c0 13.3 10.7 24 24 24h182.6l-75.5 72.4c-9.7 9.3-9.9 24.8-.4 34.3l11 10.9c9.4 9.4 24.6 9.4 33.9 0L404.3 273c9.4-9.4 9.4-24.6 0-33.9L271.6 106.3c-9.4-9.4-24.6-9.4-33.9 0l-11 10.9c-9.5 9.6-9.3 25.1.4 34.4z">
						</path>
					</svg>
				</a>
			</section>
		</section>

		<section class="section2_row2">
			<div class="section2_row2_item ">
				<h3 class="section2_row2_title">Social Media</h3>

				<p class="section2_row2_content">Xây dựng chiến lược nội dung đa kênh sáng tạo và nhất quán.</p>

				<div class="section2_row2_item_stack">
					<div class="section2_row2_item_stack1">
					</div>
					<div class="section2_row2_item_stack2">
					</div>
					<div class="section2_row2_item_stack_icon">
						<i class="fas fa-share-alt section2_row2_item_stack_icon_icon"></i>
					</div>

					<div class="section2_row2_img">
						<img class="section2_row2_image" loading="lazy" decoding="async"
							 src="/wp-content/uploads/2025/08/person-studying-digital-marketing-online-2025-02-11-13-58-52-utc-1536x1024-1.jpg" alt="Homenest" title="Homenest">
					</div>
				</div>
			</div>

			<div class="section2_row2_item middle background_gradient ">
				<h3 class="section2_row2_title middle ">SEO tổng thể</h3>

				<p class="section2_row2_content">Chiến lược phủ sóng từ khóa toàn diện theo hành trình khách hàng.</p>

				<div class="section2_row2_item_stack">
					<div class="section2_row2_item_stack1">
					</div>
					<div class="section2_row2_item_stack2">
					</div>
					<div class="section2_row2_item_stack_icon middle ">
						<i class="fas fa-bullseye section2_row2_item_stack_icon_icon"></i>
					</div>

					<div class="section2_row2_img">
						<img class="section2_row2_image" loading="lazy" decoding="async"
							 src="/wp-content/uploads/2025/08/four-female-partners-sitting-at-desk-and-discussin-2024-12-13-13-45-03-utc-1536x1024-1.jpg" alt="Homenest" title="Homenest">
					</div>
				</div>
			</div>

			<div class="section2_row2_item">
				<h3 class="section2_row2_title">Nhận diện thương hiệu</h3>

				<p class="section2_row2_content">Hệ thống hóa ngôn ngữ hình ảnh chuyên nghiệp và đồng bộ với thương hiệu.</p>

				<div class="section2_row2_item_stack">
					<div class="section2_row2_item_stack1">
					</div>
					<div class="section2_row2_item_stack2">
					</div>
					<div class="section2_row2_item_stack_icon">
						<i class="fas fa-tag section2_row2_item_stack_icon_icon"></i>
					</div>

					<div class="section2_row2_img">
						<img class="section2_row2_image" loading="lazy" decoding="async"
							 src="/wp-content/uploads/2025/08/brainstorming-session-2025-02-11-13-52-36-utc-1536x1025-1.jpg" alt="Homenest" title="Homenest">
					</div>
				</div>
			</div>
		</section>
	</section>

	<section class="section3">
		<section class="section2_row1">
			<section class="section2_row1_col1">
				<div class="sub_title ">
					<svg aria-hidden="true" class="sub_title_icon e-font-icon-svg e-fas-circle" viewBox="0 0 512 512"
						 xmlns="http://www.w3.org/2000/svg">
						<path d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8z"></path>
					</svg>

					<span>Giải pháp của chúng tôi</span>
				</div>

				<h2 class="section1_col1_main_title">
					Bứt phá tăng trưởng nhờ giải pháp số
					<span class="main_title_highligt">đỉnh cao.</span>
				</h2>
			</section>


			<section class="section2_row1_col2">
				HomeNest mang đến giải pháp Digital toàn diện giúp doanh nghiệp mở rộng thị phần, nâng tầm vị thế thương hiệu và bứt phá doanh số trong kỷ nguyên số.

				<a href="#" class="section2_row1_col2_button button_gradient">
					Tìm hiểu thêm
					<svg aria-hidden="true" class="button_gradient_icon  e-font-icon-svg e-fas-arrow-circle-right"
						 viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
						<path
							  d="M256 8c137 0 248 111 248 248S393 504 256 504 8 393 8 256 119 8 256 8zm-28.9 143.6l75.5 72.4H120c-13.3 0-24 10.7-24 24v16c0 13.3 10.7 24 24 24h182.6l-75.5 72.4c-9.7 9.3-9.9 24.8-.4 34.3l11 10.9c9.4 9.4 24.6 9.4 33.9 0L404.3 273c9.4-9.4 9.4-24.6 0-33.9L271.6 106.3c-9.4-9.4-24.6-9.4-33.9 0l-11 10.9c-9.5 9.6-9.3 25.1.4 34.4z">
						</path>
					</svg>
				</a>
			</section>
		</section>

		<section class="section3_row2">
			<div class="section3_row2_col1">
				<div class="section3_row2_col1_img">
					<img class="section3_row2_col1_image" loading="lazy" decoding="async"
						 src="/wp-content/uploads/2025/08/Frame-1321315563-1.png" alt="Homenest" title="Homenest">
				</div>

				<h3 class="section3_row2_col1_title">Phân tích dữ liệu & Báo cáo minh bạch</h3>
			</div>

			<div class="section3_row2_col2">
				<div class="section3_row2_col2_img">
					<img class="section3_row2_col2_image" loading="lazy" decoding="async"
						 src="/wp-content/uploads/2025/08/Frame-1000006299.png" alt="Homenest" title="Homenest">
				</div>

				<h3 class="section3_row2_col2_title">Phân tích dữ liệu & Báo cáo minh bạch</h3>

				<p class="section3_row2_col2_content">HomeNest cung cấp hệ thống báo cáo trực quan theo thời gian thực, giúp bạn nắm bắt chính xác các chỉ số tăng trưởng, hành vi khách hàng và tối ưu hóa ROI tức thì.</p>
			</div>
		</section>
	</section>

	<section class="section4 ">
		<div class="section4_text_wrapper">
			<div class="section4_text orbitron_font">
				<!-- 2 thẻ span viết liên tục để tránh tạo khoảng trắng giữa 2 thẻ làm hiệu ứng bị giật thay vào đó sẽ dùng thêm padding right -->
				<span>HomeNest Software 
					<svg aria-hidden="true" class="star_icon e-font-icon-svg e-fab-diaspora" viewBox="0 0 512 512"
						 xmlns="http://www.w3.org/2000/svg">
						<path
							  d="M251.64 354.55c-1.4 0-88 119.9-88.7 119.9S76.34 414 76 413.25s86.6-125.7 86.6-127.4c0-2.2-129.6-44-137.6-47.1-1.3-.5 31.4-101.8 31.7-102.1.6-.7 144.4 47 145.5 47 .4 0 .9-.6 1-1.3.4-2 1-148.6 1.7-149.6.8-1.2 104.5-.7 105.1-.3 1.5 1 3.5 156.1 6.1 156.1 1.4 0 138.7-47 139.3-46.3.8.9 31.9 102.2 31.5 102.6-.9.9-140.2 47.1-140.6 48.8-.3 1.4 82.8 122.1 82.5 122.9s-85.5 63.5-86.3 63.5c-1-.2-89-125.5-90.9-125.5z">
						</path>
					</svg>
					Digital Marketing
					<svg aria-hidden="true" class="star_icon e-font-icon-svg e-fab-diaspora" viewBox="0 0 512 512"
						 xmlns="http://www.w3.org/2000/svg">
						<path
							  d="M251.64 354.55c-1.4 0-88 119.9-88.7 119.9S76.34 414 76 413.25s86.6-125.7 86.6-127.4c0-2.2-129.6-44-137.6-47.1-1.3-.5 31.4-101.8 31.7-102.1.6-.7 144.4 47 145.5 47 .4 0 .9-.6 1-1.3.4-2 1-148.6 1.7-149.6.8-1.2 104.5-.7 105.1-.3 1.5 1 3.5 156.1 6.1 156.1 1.4 0 138.7-47 139.3-46.3.8.9 31.9 102.2 31.5 102.6-.9.9-140.2 47.1-140.6 48.8-.3 1.4 82.8 122.1 82.5 122.9s-85.5 63.5-86.3 63.5c-1-.2-89-125.5-90.9-125.5z">
						</path>
					</svg>
					HomeNest Software 
					<svg aria-hidden="true" class="star_icon e-font-icon-svg e-fab-diaspora" viewBox="0 0 512 512"
						 xmlns="http://www.w3.org/2000/svg">
						<path
							  d="M251.64 354.55c-1.4 0-88 119.9-88.7 119.9S76.34 414 76 413.25s86.6-125.7 86.6-127.4c0-2.2-129.6-44-137.6-47.1-1.3-.5 31.4-101.8 31.7-102.1.6-.7 144.4 47 145.5 47 .4 0 .9-.6 1-1.3.4-2 1-148.6 1.7-149.6.8-1.2 104.5-.7 105.1-.3 1.5 1 3.5 156.1 6.1 156.1 1.4 0 138.7-47 139.3-46.3.8.9 31.9 102.2 31.5 102.6-.9.9-140.2 47.1-140.6 48.8-.3 1.4 82.8 122.1 82.5 122.9s-85.5 63.5-86.3 63.5c-1-.2-89-125.5-90.9-125.5z">
						</path>
					</svg></span><span>Digital Marketing
				<svg aria-hidden="true" class="star_icon e-font-icon-svg e-fab-diaspora" viewBox="0 0 512 512"
					 xmlns="http://www.w3.org/2000/svg">
					<path
						  d="M251.64 354.55c-1.4 0-88 119.9-88.7 119.9S76.34 414 76 413.25s86.6-125.7 86.6-127.4c0-2.2-129.6-44-137.6-47.1-1.3-.5 31.4-101.8 31.7-102.1.6-.7 144.4 47 145.5 47 .4 0 .9-.6 1-1.3.4-2 1-148.6 1.7-149.6.8-1.2 104.5-.7 105.1-.3 1.5 1 3.5 156.1 6.1 156.1 1.4 0 138.7-47 139.3-46.3.8.9 31.9 102.2 31.5 102.6-.9.9-140.2 47.1-140.6 48.8-.3 1.4 82.8 122.1 82.5 122.9s-85.5 63.5-86.3 63.5c-1-.2-89-125.5-90.9-125.5z">
					</path>
				</svg>
				HomeNest Software 
				<svg aria-hidden="true" class="star_icon e-font-icon-svg e-fab-diaspora" viewBox="0 0 512 512"
					 xmlns="http://www.w3.org/2000/svg">
					<path
						  d="M251.64 354.55c-1.4 0-88 119.9-88.7 119.9S76.34 414 76 413.25s86.6-125.7 86.6-127.4c0-2.2-129.6-44-137.6-47.1-1.3-.5 31.4-101.8 31.7-102.1.6-.7 144.4 47 145.5 47 .4 0 .9-.6 1-1.3.4-2 1-148.6 1.7-149.6.8-1.2 104.5-.7 105.1-.3 1.5 1 3.5 156.1 6.1 156.1 1.4 0 138.7-47 139.3-46.3.8.9 31.9 102.2 31.5 102.6-.9.9-140.2 47.1-140.6 48.8-.3 1.4 82.8 122.1 82.5 122.9s-85.5 63.5-86.3 63.5c-1-.2-89-125.5-90.9-125.5z">
					</path>
				</svg>
				Digital Marketing
				<svg aria-hidden="true" class="star_icon e-font-icon-svg e-fab-diaspora" viewBox="0 0 512 512"
					 xmlns="http://www.w3.org/2000/svg">
					<path
						  d="M251.64 354.55c-1.4 0-88 119.9-88.7 119.9S76.34 414 76 413.25s86.6-125.7 86.6-127.4c0-2.2-129.6-44-137.6-47.1-1.3-.5 31.4-101.8 31.7-102.1.6-.7 144.4 47 145.5 47 .4 0 .9-.6 1-1.3.4-2 1-148.6 1.7-149.6.8-1.2 104.5-.7 105.1-.3 1.5 1 3.5 156.1 6.1 156.1 1.4 0 138.7-47 139.3-46.3.8.9 31.9 102.2 31.5 102.6-.9.9-140.2 47.1-140.6 48.8-.3 1.4 82.8 122.1 82.5 122.9s-85.5 63.5-86.3 63.5c-1-.2-89-125.5-90.9-125.5z">
					</path>
				</svg>
				</span>
			</div>
			<div class="section4_layout layout_left"></div>
			<div class="section4_layout layout_right"></div>
		</div>


	</section>

	<section class="section5 background_caro">
		<section class="section5_row1">
			<div class="sub_title section5_row1_sub_title ">
				<svg aria-hidden="true" class="sub_title_icon e-font-icon-svg e-fas-circle" viewBox="0 0 512 512"
					 xmlns="http://www.w3.org/2000/svg">
					<path d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8z"></path>
				</svg>

				<span>Dịch vụ chi tiết</span>
			</div>

			<h2 class="section5_row1_main_title">
				Giải Pháp
				<span class="main_title_highligt"> Số Toàn Diện </span> 
				Cho Kỷ Nguyên Mới
			</h2>
		</section>

		<section class="section5_row2">
			<section class=" section5_row2_col1 ">
				<div class="section5_row2_item ">
					<div class="section5_row2_icon">
						<i class="fas fa-rocket"></i>
					</div>

					<div class="section5_row2_item_row2">
						<h3 class=" section2_row2_title">Digital Marketing</h3>

						<p class="section2_row2_content">Xây dựng kế hoạch tiếp thị số đa kênh bài bản, giúp doanh nghiệp tiếp cận đúng khách hàng mục tiêu.</p>

						<div class="button_gradient section2_row2_btt">
							Tìm hiểu thêm
							<svg aria-hidden="true"
								 class="button_gradient_icon e-font-icon-svg e-fas-arrow-circle-right"
								 viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
								<path
									  d="M256 8c137 0 248 111 248 248S393 504 256 504 8 393 8 256 119 8 256 8zm-28.9 143.6l75.5 72.4H120c-13.3 0-24 10.7-24 24v16c0 13.3 10.7 24 24 24h182.6l-75.5 72.4c-9.7 9.3-9.9 24.8-.4 34.3l11 10.9c9.4 9.4 24.6 9.4 33.9 0L404.3 273c9.4-9.4 9.4-24.6 0-33.9L271.6 106.3c-9.4-9.4-24.6-9.4-33.9 0l-11 10.9c-9.5 9.6-9.3 25.1.4 34.4z">
								</path>
							</svg>
						</div>
					</div>
				</div>

				<div class="section5_row2_item ">
					<div class="section5_row2_icon">
						<i class="fas fa-volume-up"></i>
					</div>

					<div class="section5_row2_item_row2">
						<h3 class=" section2_row2_title">Nhận diện thương hiệu</h3>

						<p class="section2_row2_content">Kiến tạo diện mạo độc đáo và chuyên nghiệp. Từ Logo đến hệ thống nhận diện.</p>

						<div class="button_gradient section2_row2_btt">
							Tìm hiểu thêm
							<svg aria-hidden="true"
								 class="button_gradient_icon e-font-icon-svg e-fas-arrow-circle-right"
								 viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
								<path
									  d="M256 8c137 0 248 111 248 248S393 504 256 504 8 393 8 256 119 8 256 8zm-28.9 143.6l75.5 72.4H120c-13.3 0-24 10.7-24 24v16c0 13.3 10.7 24 24 24h182.6l-75.5 72.4c-9.7 9.3-9.9 24.8-.4 34.3l11 10.9c9.4 9.4 24.6 9.4 33.9 0L404.3 273c9.4-9.4 9.4-24.6 0-33.9L271.6 106.3c-9.4-9.4-24.6-9.4-33.9 0l-11 10.9c-9.5 9.6-9.3 25.1.4 34.4z">
								</path>
							</svg>
						</div>
					</div>
				</div>

				<div class="section5_row2_item ">
					<div class="section5_row2_icon">
						<i class="fas fa-chart-line"></i>
					</div>

					<div class="section5_row2_item_row2">
						<h3 class=" section2_row2_title">Quảng cáo</h3>

						<p class="section2_row2_content">Triển khai các chiến dịch quảng cáo tối ưu trên Facebook, Google, TikTok.</p>

						<div class="button_gradient section2_row2_btt">
							Tìm hiểu thêm
							<svg aria-hidden="true"
								 class="button_gradient_icon e-font-icon-svg e-fas-arrow-circle-right"
								 viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
								<path
									  d="M256 8c137 0 248 111 248 248S393 504 256 504 8 393 8 256 119 8 256 8zm-28.9 143.6l75.5 72.4H120c-13.3 0-24 10.7-24 24v16c0 13.3 10.7 24 24 24h182.6l-75.5 72.4c-9.7 9.3-9.9 24.8-.4 34.3l11 10.9c9.4 9.4 24.6 9.4 33.9 0L404.3 273c9.4-9.4 9.4-24.6 0-33.9L271.6 106.3c-9.4-9.4-24.6-9.4-33.9 0l-11 10.9c-9.5 9.6-9.3 25.1.4 34.4z">
								</path>
							</svg>
						</div>
					</div>
				</div>
				
				
				<div class="section5_row2_item ">
					<div class="section5_row2_icon">
						<i class="fas fa-bullseye"></i>
					</div>

					<div class="section5_row2_item_row2">
						<h3 class=" section2_row2_title">SEO tổng thể</h3>

						<p class="section2_row2_content">Đưa website lên Top Google an toàn với giải pháp SEO mũ trắng. Phủ rộng hàng nghìn từ khóa, thu hút traffic tự nhiên.</p>

						<div class="button_gradient section2_row2_btt">
							Tìm hiểu thêm
							<svg aria-hidden="true"
								 class="button_gradient_icon e-font-icon-svg e-fas-arrow-circle-right"
								 viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
								<path
									  d="M256 8c137 0 248 111 248 248S393 504 256 504 8 393 8 256 119 8 256 8zm-28.9 143.6l75.5 72.4H120c-13.3 0-24 10.7-24 24v16c0 13.3 10.7 24 24 24h182.6l-75.5 72.4c-9.7 9.3-9.9 24.8-.4 34.3l11 10.9c9.4 9.4 24.6 9.4 33.9 0L404.3 273c9.4-9.4 9.4-24.6 0-33.9L271.6 106.3c-9.4-9.4-24.6-9.4-33.9 0l-11 10.9c-9.5 9.6-9.3 25.1.4 34.4z">
								</path>
							</svg>
						</div>
					</div>
				</div>
			</section>

			
		</section>
	</section>

	<section class="section6 ">
		<section class="section2_row1">
			<section class="section2_row1_col1">
				<div class="sub_title ">
					<svg aria-hidden="true" class="sub_title_icon e-font-icon-svg e-fas-circle" viewBox="0 0 512 512"
						 xmlns="http://www.w3.org/2000/svg">
						<path d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8z"></path>
					</svg>

					<span>Các con số ấn tượng</span>
				</div>

				<h2 class="section1_col1_main_title">
					HomeNest và hành trình
					<span class="main_title_highligt"> kiến tạo </span>
					giá trị.
				</h2>
			</section>


			<section class="section2_row1_col2">
				Tự hào là đối tác tin cậy của hàng ngàn doanh nghiệp, chúng tôi không ngừng nỗ lực để mang lại những giải pháp Marketing & Công nghệ tối ưu nhất

				<a href="#" class="section2_row1_col2_button button_gradient">
					Tìm hiểu thêm
					<svg aria-hidden="true" class="button_gradient_icon  e-font-icon-svg e-fas-arrow-circle-right"
						 viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
						<path
							  d="M256 8c137 0 248 111 248 248S393 504 256 504 8 393 8 256 119 8 256 8zm-28.9 143.6l75.5 72.4H120c-13.3 0-24 10.7-24 24v16c0 13.3 10.7 24 24 24h182.6l-75.5 72.4c-9.7 9.3-9.9 24.8-.4 34.3l11 10.9c9.4 9.4 24.6 9.4 33.9 0L404.3 273c9.4-9.4 9.4-24.6 0-33.9L271.6 106.3c-9.4-9.4-24.6-9.4-33.9 0l-11 10.9c-9.5 9.6-9.3 25.1.4 34.4z">
						</path>
					</svg>
				</a>
			</section>
		</section>

		<section class="section6_row2">
			<div class="section6_row2_item">
				<div class="section6_row2_item_icon">
					<i class="fas fa-users"></i>
				</div>

				<div class="section6_row2_item_text">
					<h2 class="section6_row2_item_text_value">
						<span class="section6_row2_item_text_value_HC">10</span>+
					</h2>
					<h4 class="section6_row2_item_text_content">Năm kinh nghiệm</h4>
				</div>
			</div>

			<div class="section6_row2_item second">
				<div class="section6_row2_item_icon second">
					<i class="fas fa-check"></i>
				</div>

				<div class="section6_row2_item_text">
					<h2 class="section6_row2_item_text_value">
						<span class="section6_row2_item_text_value_integer_PD">2</span><span
																							  class="section6_row2_item_text_value_decimal_PD">000</span>+
					</h2>
					<h4 class="section6_row2_item_text_content">Dự án thành công</h4>
				</div>
			</div>

			<div class="section6_row2_item">
				<div class="section6_row2_item_icon">
					<i class="fas fa-star-half-alt"></i>
				</div>

				<div class="section6_row2_item_text">
					<h2 class="section6_row2_item_text_value">
						<span class="section6_row2_item_text_value_integer_CR">50</span><span
																							  class="section6_row2_item_text_value_decimal_CR"></span>+
					</h2>
					<h4 class="section6_row2_item_text_content">Nhân sự tài năng</h4>
				</div>
			</div>

			<div class="section6_row2_item">
				<div class="section6_row2_item_icon">
					<i class="fas fa-award"></i>
				</div>

				<div class="section6_row2_item_text">
					<h2 class="section6_row2_item_text_value">
						<span class="section6_row2_item_text_value_YE">99</span>%
					</h2>
					<h4 class="section6_row2_item_text_content">Tỷ lệ hài lòng</h4>
				</div>
			</div>

		</section>
	</section>

	<section class="section7">
		<section class="section7_col1 background_gradient">
			<section class="section1_col2_wrap_wrap">
				<section class="section1_col2_wrap box2">
					<div class="section1_col2_wrap_img">
						<div class="section1_col2_img">
							<img class="section1_col2_image1 box2" loading="lazy" decoding="async" src="/wp-content/uploads/2025/08/Image2.jpg" alt="Homenest" title="Homenest">
						</div>
					</div>

					<div class="section1_col2_hidden_box2">
						<h3 class="section1_col2_title">Quy trình Digital Marketing tinh gọn</h3>

						<div class="section1_col2_text">
							<div class="section1_col2_text1a">
								<svg aria-hidden="true" class="e-font-icon-svg e-fab-diaspora" viewBox="0 0 512 512"
									 xmlns="http://www.w3.org/2000/svg">
									<path
										  d="M251.64 354.55c-1.4 0-88 119.9-88.7 119.9S76.34 414 76 413.25s86.6-125.7 86.6-127.4c0-2.2-129.6-44-137.6-47.1-1.3-.5 31.4-101.8 31.7-102.1.6-.7 144.4 47 145.5 47 .4 0 .9-.6 1-1.3.4-2 1-148.6 1.7-149.6.8-1.2 104.5-.7 105.1-.3 1.5 1 3.5 156.1 6.1 156.1 1.4 0 138.7-47 139.3-46.3.8.9 31.9 102.2 31.5 102.6-.9.9-140.2 47.1-140.6 48.8-.3 1.4 82.8 122.1 82.5 122.9s-85.5 63.5-86.3 63.5c-1-.2-89-125.5-90.9-125.5z">
									</path>
								</svg>
							</div>

							<div class="section1_col2_text1b">
								Chúng tôi loại bỏ các bước thừa để tập trung tối đa vào việc tối ưu chi phí và mang lại tăng trưởng bền vững cho doanh nghiệp.
							</div>
						</div>
					</div>
				</section>

				<div class="section1_col2_wrap">
					<div class="section1_col2_wrap_img">
						<div class="section1_col2_img">
							<img class="section1_col2_image1" loading="lazy" decoding="async"
								 src="/wp-content/uploads/2025/08/four-female-partners-sitting-at-desk-and-discussin-2024-12-13-13-45-03-utc.jpg" alt="Homenest" title="Homenest">
						</div>
						<img class="section1_col2_image2" loading="lazy" decoding="async"
							 src="/wp-content/uploads/2025/08/surprised-female-model-searches-information-online-2025-01-24-01-56-11-utc-1.png" alt="Homenest" title="Homenest">
					</div>


					<h3 class="section1_col2_title">Quy trình Digital Marketing tinh gọn</h3>

					<div class="section1_col2_text">
						<div class="section1_col2_text1a">
							<svg aria-hidden="true" class="e-font-icon-svg e-fab-diaspora" viewBox="0 0 512 512"
								 xmlns="http://www.w3.org/2000/svg">
								<path
									  d="M251.64 354.55c-1.4 0-88 119.9-88.7 119.9S76.34 414 76 413.25s86.6-125.7 86.6-127.4c0-2.2-129.6-44-137.6-47.1-1.3-.5 31.4-101.8 31.7-102.1.6-.7 144.4 47 145.5 47 .4 0 .9-.6 1-1.3.4-2 1-148.6 1.7-149.6.8-1.2 104.5-.7 105.1-.3 1.5 1 3.5 156.1 6.1 156.1 1.4 0 138.7-47 139.3-46.3.8.9 31.9 102.2 31.5 102.6-.9.9-140.2 47.1-140.6 48.8-.3 1.4 82.8 122.1 82.5 122.9s-85.5 63.5-86.3 63.5c-1-.2-89-125.5-90.9-125.5z">
								</path>
							</svg>
						</div>

						<div class="section1_col2_text1b">
							Chúng tôi loại bỏ các bước thừa để tập trung tối đa vào việc tối ưu chi phí và mang lại tăng trưởng bền vững cho doanh nghiệp.
						</div>
					</div>
				</div>
			</section>
		</section>

		<section class="section7_col2 background_caro ">
			<div class="sub_title ">
				<svg aria-hidden="true" class="sub_title_icon e-font-icon-svg e-fas-circle" viewBox="0 0 512 512"
					 xmlns="http://www.w3.org/2000/svg">
					<path d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8z"></path>
				</svg>

				<span>Quy trình làm việc</span>
			</div>

			<h2 class="section1_col1_main_title">
				Quy trình dịch vụ tại
				<span class="main_title_highligt"> HomeNest</span>
			</h2>

			<div class="section7_col2_list_item">
				<div class="section7_col2_item">
					<h3 class="section7_col2_item_number">01.</h3>

					<div class="section7_col2_item_text">
						<h3 class="section7_col2_item_text_title">Tư vấn & Phân tích</h3>

						<p class="section7_col2_item_text_content">Lắng nghe mục tiêu doanh nghiệp, khảo sát hiện trạng thương hiệu và phân tích đối thủ để tìm ra điểm nghẽn.</p>
					</div>

					<div class="section7_col2_item_icon"><svg class="section7_up_right_icon" width="800px"
															  height="800px" color="white" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"
															  fill="none" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
															  class="feather feather-arrow-up-right">
						<line x1="7" y1="17" x2="17" y2="7"></line>
						<polyline points="7 7 17 7 17 17"></polyline>
						</svg></div>
				</div>

				<div class="section7_col2_item">
					<h3 class="section7_col2_item_number">02.</h3>

					<div class="section7_col2_item_text">
						<h3 class="section7_col2_item_text_title">Hoạch định chiến lược</h3>

						<p class="section7_col2_item_text_content">Xây dựng kế hoạch tổng thể, xác định KPI cam kết, phân bổ ngân sách và lựa chọn kênh truyền thông tối ưu nhất.</p>
					</div>

					<div class="section7_col2_item_icon"><svg class="section7_up_right_icon" width="800px"
															  height="800px" color="white" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"
															  fill="none" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
															  class="feather feather-arrow-up-right">
						<line x1="7" y1="17" x2="17" y2="7"></line>
						<polyline points="7 7 17 7 17 17"></polyline>
						</svg></div>
				</div>

				<div class="section7_col2_item">
					<h3 class="section7_col2_item_number">03.</h3>

					<div class="section7_col2_item_text">
						<h3 class="section7_col2_item_text_title">Thực thi đa kênh</h3>

						<p class="section7_col2_item_text_content">Sản xuất nội dung sáng tạo, tối ưu hạ tầng Web/App và vận hành các chiến dịch quảng cáo bám sát mục tiêu.</p>
					</div>

					<div class="section7_col2_item_icon"><svg class="section7_up_right_icon" width="800px"
															  height="800px" color="white" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"
															  fill="none" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
															  class="feather feather-arrow-up-right">
						<line x1="7" y1="17" x2="17" y2="7"></line>
						<polyline points="7 7 17 7 17 17"></polyline>
						</svg></div>
				</div>

				<div class="section7_col2_item">
					<h3 class="section7_col2_item_number">04.</h3>

					<div class="section7_col2_item_text">
						<h3 class="section7_col2_item_text_title">Đo lường & Tối ưu</h3>

						<p class="section7_col2_item_text_content">Theo dõi chỉ số Real-time, liên tục điều chỉnh để tối đa hiệu quả chi phí và báo cáo minh bạch định kỳ.</p>
					</div>

					<div class="section7_col2_item_icon"><svg class="section7_up_right_icon" width="800px"
															  height="800px" color="white" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"
															  fill="none" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
															  class="feather feather-arrow-up-right">
						<line x1="7" y1="17" x2="17" y2="7"></line>
						<polyline points="7 7 17 7 17 17"></polyline>
						</svg></div>
				</div>

			</div>
		</section>
	</section>

	<section class="section8">
		<section class="section8_row1">
			<div class="sub_title section8_row1_sub_title ">
				<svg aria-hidden="true" class="sub_title_icon e-font-icon-svg e-fas-circle" viewBox="0 0 512 512"
					 xmlns="http://www.w3.org/2000/svg">
					<path d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8z"></path>
				</svg>

				<span>FAQS</span>
			</div>

			<h2 class="section8_row1_main_title">
				Góc
				<span class="main_title_highligt"> giải đáp </span>
				thắc mắc nhanh
			</h2>
		</section>

		<section class="section8_row2">
			<section class="section8_row2_col section8_row2_col1">
				<div class="section8_row2_col_item">
					<div class="section8_row2_col_item_question">
						<div class="section8_row2_col_item_question_icon">+</div>
						<p class="section8_row2_col_item_question_content orbitron_font">HomeNest khác biệt gì so với các Agency quảng cáo thông thường?</p>
					</div>

					<p class="section8_row2_col_item_answer">Điểm khác biệt lớn nhất của HomeNest là tư duy "Tech-Driven Marketing". Vì xuất thân là đơn vị phát triển phần mềm/App, chúng tôi không chỉ chạy quảng cáo mà còn có khả năng tối ưu sâu về kỹ thuật (tốc độ Web, trải nghiệm App, hệ thống CRM) để đảm bảo khách hàng vào là muốn ở lại và mua hàng.</p>
				</div>

				<div class="section8_row2_col_item">
					<div class="section8_row2_col_item_question">
						<div class="section8_row2_col_item_question_icon">+</div>
						<p class="section8_row2_col_item_question_content orbitron_font">Doanh nghiệp nhỏ (SME) hoặc Start-up có phù hợp với dịch vụ của HomeNest không?</p>
					</div>

					<p class="section8_row2_col_item_answer">Hoàn toàn phù hợp. HomeNest thiết kế các gói giải pháp linh hoạt dựa trên ngân sách và giai đoạn phát triển của từng doanh nghiệp, từ giai đoạn mới thâm nhập thị trường đến giai đoạn mở rộng quy mô (Scale-up).</p>
				</div>

				<div class="section8_row2_col_item">
					<div class="section8_row2_col_item_question">
						<div class="section8_row2_col_item_question_icon">+</div>
						<p class="section8_row2_col_item_question_content orbitron_font">Ngân sách chạy quảng cáo tối thiểu là bao nhiêu?</p>
					</div>

					<p class="section8_row2_col_item_answer">HomeNest không áp đặt một mức ngân sách cứng nhắc. Chúng tôi sẽ phân tích mục tiêu kinh doanh của bạn để đề xuất mức ngân sách tối ưu nhất. Mọi chi phí đều được minh bạch và tập trung vào chỉ số ROI (Lợi nhuận trên chi phí đầu tư).</p>
				</div>
			</section>

			<section class="section8_row2_col section8_row2_col2">
				<div class="section8_row2_col_item">
					<div class="section8_row2_col_item_question">
						<div class="section8_row2_col_item_question_icon">+</div>
						<p class="section8_row2_col_item_question_content orbitron_font">HomeNest có cam kết về doanh số bán hàng không?</p>
					</div>

					<p class="section8_row2_col_item_answer">Chúng tôi cam kết các chỉ số hiệu quả cụ thể (KPIs) như: Lượng khách hàng tiềm năng (Leads), Lượng truy cập (Traffic), Tỷ lệ chuyển đổi... Chúng tôi đồng hành cùng bộ phận Sale của bạn để tối ưu hóa tỷ lệ chốt đơn từ các Leads này.</p>
				</div>

				<div class="section8_row2_col_item">
					<div class="section8_row2_col_item_question">
						<div class="section8_row2_col_item_question_icon">+</div>
						<p class="section8_row2_col_item_question_content orbitron_font">Làm sao tôi theo dõi được hiệu quả làm việc của HomeNest?</p>
					</div>

					<p class="section8_row2_col_item_answer">Chúng tôi đề cao sự minh bạch. Bạn sẽ nhận được báo cáo định kỳ (Tuần/Tháng) với các số liệu rõ ràng. Ngoài ra, HomeNest có thể thiết lập các Dashboard (bảng dữ liệu) để bạn xem kết quả theo thời gian thực (Real-time). there</p>
				</div>

				<div class="section8_row2_col_item">
					<div class="section8_row2_col_item_question">
						<div class="section8_row2_col_item_question_icon">+</div>
						<p class="section8_row2_col_item_question_content orbitron_font">Tôi có cần cung cấp hình ảnh hay nội dung bài viết không?</p>
					</div>

					<p class="section8_row2_col_item_answer">HomeNest có đội ngũ Content và Design chuyên nghiệp để phụ trách toàn bộ việc sản xuất nội dung. Tuy nhiên, nếu bạn đã có sẵn tư liệu sản phẩm, chúng tôi sẽ phối hợp để sử dụng chúng một cách hiệu quả nhất.</p>
				</div>
			</section>
		</section>
	</section>

	<section class="section9">
		<section class="section2_row1">
			<section class="section2_row1_col1">
				<div class="sub_title ">
					<svg aria-hidden="true" class="sub_title_icon e-font-icon-svg e-fas-circle" viewBox="0 0 512 512"
						 xmlns="http://www.w3.org/2000/svg">
						<path d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8z"></path>
					</svg>

					<span>Góc nhìn Chuyên gia</span>
				</div>

				<h2 class="section1_col1_main_title">
					Xu hướng &
					<span class="main_title_highligt"> Câu chuyện Thành công.</span>
					
				</h2>
			</section>


			<section class="section2_row1_col2">
				Cập nhật những xu hướng Digital Marketing mới nhất, bài học thực chiến và phân tích chuyên sâu giúp doanh nghiệp tối ưu hóa hiệu quả kinh doanh.

				<a href="#" class="section2_row1_col2_button button_gradient">
					Tìm hiểu thêm
					<svg aria-hidden="true" class="button_gradient_icon  e-font-icon-svg e-fas-arrow-circle-right"
						 viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
						<path
							  d="M256 8c137 0 248 111 248 248S393 504 256 504 8 393 8 256 119 8 256 8zm-28.9 143.6l75.5 72.4H120c-13.3 0-24 10.7-24 24v16c0 13.3 10.7 24 24 24h182.6l-75.5 72.4c-9.7 9.3-9.9 24.8-.4 34.3l11 10.9c9.4 9.4 24.6 9.4 33.9 0L404.3 273c9.4-9.4 9.4-24.6 0-33.9L271.6 106.3c-9.4-9.4-24.6-9.4-33.9 0l-11 10.9c-9.5 9.6-9.3 25.1.4 34.4z">
						</path>
					</svg>
				</a>
			</section>
		</section>

		<section class="section9_row2">
			<?php
/**
 * Lấy 3 bài post từ danh mục 'wiki-software' và hiển thị theo cấu trúc tùy chỉnh mới.
 */

// ⚠️ CHỈ ĐỊNH SLUG CỦA DANH MỤC
$category_slug = 'wiki-marketing'; 

// 1. Định nghĩa tham số truy vấn
$args = array(
	'post_type'      => 'post',
	'post_status'    => 'publish',
	'posts_per_page' => 4, 
	'orderby'        => 'date',
	'order'          => 'DESC',

	// Điều kiện truy vấn theo Taxonomy
	'tax_query' => array(
		array(
			'taxonomy' => 'category', 
			'field'    => 'slug',   
			'terms'    => $category_slug, 
		),
	),
);

// 2. Tạo đối tượng WP_Query
$the_query = new WP_Query( $args );

// 3. Vòng lặp để hiển thị các bài post
if ( $the_query->have_posts() ) {

	while ( $the_query->have_posts() ) {
		$the_query->the_post();

		// Lấy danh mục đầu tiên của bài viết
		$categories = get_the_category();
		$first_category = !empty($categories) ? $categories[0] : null;
		$category_name = $first_category ? $first_category->name : 'Uncategorized';
		
		// Lấy URL ảnh đại diện
		$featured_image_url = has_post_thumbnail() ? get_the_post_thumbnail_url(get_the_ID(), 'full') : 'https://placehold.co/600x400/CCCCCC/333333?text=No+Image';
		
		// Lấy tiêu đề và URL bài viết
		$post_title = get_the_title();
		$post_url = get_the_permalink();
		$post_date = get_the_date( 'F j, Y' ); // Định dạng: April 25, 2025

		// Lấy nội dung tóm tắt (20 từ)
		// Dùng get_the_excerpt() nếu có, nếu không thì lấy nội dung và cắt ngắn
		$excerpt_raw = get_the_excerpt() ?: get_the_content();
		// Cắt ngắn chuỗi thành 20 từ, thêm dấu "..."
		$excerpt_20_words = wp_trim_words( $excerpt_raw, 20, '...' );


		// --- BẮT ĐẦU CẤU TRÚC ITEM MỚI ---
?>

<div class="section9_row2_item">
	<div class="section9_row2_item_row1">

		<div class="section9_row2_item_img">
			<!-- Danh mục (Category) -->
			<div class="section9_row2_item_img_category"><?php echo esc_html( $category_name ); ?></div>

			<!-- Ảnh đại diện -->
			<img class="section9_row2_item_image" loading="lazy" decoding="async"
				 src="<?php echo esc_url( $featured_image_url ); ?>"
				 alt="<?php echo esc_attr( $post_title ); ?>"
				 title="<?php echo esc_attr( $post_title ); ?>">
		</div>

		<!-- Ngày tháng -->
		<div class="section9_row2_item_calendar">
			<i class="fas fa-calendar section9_row2_item_calendar_icon"></i>
			<?php echo esc_html( $post_date ); ?>
		</div>
	</div>

	<div class="section9_row2_item_row2">
		<!-- Tiêu đề -->
		<h3 class="section9_row2_item_title">
			<a href="<?php echo esc_url( $post_url ); ?>"><?php echo esc_html( $post_title ); ?></a>
		</h3>

		<!-- Nội dung tóm tắt 20 từ -->
		<p class="section9_row2_item_content"><?php echo esc_html( $excerpt_20_words ); ?></p>

		<!-- Nút "Learn more" -->
		<a href="<?php echo esc_url( $post_url ); ?>" class="section9_row2_item_btt button_gradient">
			Xem thêm
		</a>
	</div>
</div>

<?php
		// --- KẾT THÚC CẤU TRÚC ITEM MỚI ---
	}

	// 4. Đặt lại dữ liệu Post toàn cục (RẤT QUAN TRỌNG)
	wp_reset_postdata();

} else {
	// Trường hợp không tìm thấy bài viết
	echo '<p>Không tìm thấy bài viết nào trong danh mục "' . esc_html( $category_slug ) . '".</p>';
}
?>
		</section>
	</section>


</main>

<?php get_footer(); ?>