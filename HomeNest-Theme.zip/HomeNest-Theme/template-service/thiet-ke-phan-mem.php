<?php
/**
 * Template Name: Thiết kế phần mềm
 * Template Post Type: service
 */
get_header();
?>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post();
?>


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?"
rel="stylesheet">
<body>
	<section class="hero-section">
		<img class="hero-bg" src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/hero-gradient-3.jpg" alt="Hero background">
		<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/hero-left-shape-3-1.png"
			 alt="Hero Left Shape" class="hero-img-abs d-none d-lg-block">
		<div class="container hero-content-center text-center">
			<h1 class="display-1 fw-bold text-black mb-33 hero-title hero-title2">HomeNest <i class="fw-light"
																						   style="">Software</i></h1>
			<h2 class="display-1 fw-bold text-black mb-3 hero-title">Vững nền tảng, sáng tương lai</h2>
			<b class="mb-3 text-secondary fw-light fs-5 hero-desc-animate hero-desc"
			   style="font-family: 'Urbanist', serif;">Dịch vụ thiết kế phần mềm trọn gói<br>Giải pháp tối ưu hiệu suất cho doanh nghiệp.</b>
			<div class="d-flex justify-content-center gap-4 mb-4">
				<a href="#"
				   class="btn btn-lg btn-custom-blue px-5 py-3 fw-bold shadow-lg rounded-5 btn-animate-up btn-live">Trải nghiệm Demo</a>
				<a href="#"
				   class="btn 
btn-lg btn-custom-outline px-5 py-3 fw-bold shadow-lg rounded-5 btn-custom-blue btn-animate-up">Nhận báo giá ngay</a>
			</div>

			<div class="d-flex justify-content-center align-items-center gap-3 flex-wrap mt-3 platform-logos-animate">
				<a href="#" class="text-center text-decoration-none logo-link">
					<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/windows8/windows8-original.svg"
						 alt="Windows" class="mb-2">
					<div class="text-secondary fs-6">Windows</div>
				</a>
				<a href="#" class="text-center text-decoration-none logo-link">
					<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/firefox/firefox-original.svg"
						 alt="Firefox" class="mb-2">
					<div class="text-secondary fs-6">Firefox</div>
				</a>
				<a href="#" class="text-center text-decoration-none logo-link">
					<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/chrome/chrome-original.svg"
						 alt="Chrome" class="mb-2">
					<div class="text-secondary fs-6">Chrome</div>
				</a>
				<a href="#" class="text-center text-decoration-none logo-link">
					<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/apple/apple-original.svg" alt="macOS"
						 class="mb-2">
					<div class="text-secondary fs-6">macOS</div>
				</a>
				<a href="#" class="text-center text-decoration-none logo-link">
					<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/linux/linux-original.svg" alt="Linux"
						 class="mb-2">
					<div class="text-secondary fs-6">Linux</div>
				</a>
			</div>
			<div class="text-center mt-5 position-relative">
				<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/hero-img-3-1.png"
					 alt="Hero Image Bottom" class="img-fluid w-100">
				<div class="tp-hero-3-border-wrap d-none d-md-block">
					<span class="redius-shape-1"></span>
					<span class="redius-shape-2"></span>
					<span class="redius-shape-3"></span>
				</div>
				<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/hero-img-3-1-3.png" alt="pen"
					 class="img-pen 
d-none d-md-block">
				<svg class="svg-line d-none d-md-block" width="64" height="202" viewBox="0 0 64 202" fill="none"
					 xmlns="http://www.w3.org/2000/svg">
					<path class="svg-animate-path"
						  d="M63.0029 7.94799C45.0715 -0.936415 14.5884 -8.38783 36.1059 32.8816C63.0029 84.4681 71.2089 85.3283 36.1059 75.8707C1.00293 66.4131 15.5915 92.2063 36.1059 118C56.6205 143.794 57.0764 169.587 28.3558 152.391C-0.364664 135.195 1.00293 144.653 28.3558 179.904C55.7087 215.155 22.4293 195.38 1.00293 196.24"
						  stroke="#202124" stroke-width="2"></path>
				</svg>
			</div>
		</div>
	</section>
	<div class="stats-container container mt-5">
		<div class="row justify-content-center gx-0 team-members">
			<div class="col-md-4 text-center">
				<div class="stat-item">
					<div class="stat-number">300<span>+</span></div>
					<div class="stat-label">Dự án</div>
				</div>
				<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/counter-shape-4.png"
					 alt="Counter Shape" class="counter-shape-img d-none d-md-block">
			</div>
			<div class="col-md-4 text-center">
				<div class="stat-item">
					<div class="stat-number">30<span>+</span></div>
					<div class="stat-label">Lĩnh vực</div>
				</div>
			</div>
			<div class="col-md-4 text-center">
				<div class="stat-item">
					<div class="stat-number">99<span>%</span></div>
					<div class="stat-label">Hài lòng từ khách hàng</div>
				</div>
				<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/counter-shape-2.png"
					 alt="Counter Shape 2" class="counter-shape-img-2 
">
				<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/counter-shape-1.png"
					 alt="Counter Shape 1" class="counter-shape-img-1 ">
			</div>
		</div>
	</div>

	<div class="container py-5 section-ac">
		<div class="d-flex flex-column flex-md-row align-items-center justify-content-between mb-4">
			<h2 class="mb-3 mb-md-0 text-center text-md-start text-accounting title-slide-left">
				Giải pháp tối ưu vận hành
				<br />
				cho
				<span class="italic-playfair">
					mọi quy mô.
</span>
			</h2>
			<a href="#" class="btn btn-custom btn-custom-blue btn-slide-right">Tìm hiểu thêm</a>
		</div>
		<div class="row g-4 mb-4">
			<div class="col-12 col-md-8 card-crm">
				<div class="gradient-card position-relative card-slide-left">
					<img alt="CRM management icon showing a dashboard with customer relationship management elements"
						 class="control-icon" height="64"
						 src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/sv-icon-3-1.png" width="64" />
					<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/service-shape-3-1.png"
						 alt="Service Shape" class="service-shape-img ">
					<p class="gradient-label">
						PHẦN MỀM QUẢN LÝ CRM
					</p>
					<h3 class="gradient-title text-white mt-5">
						Xây dựng nền tảng quản trị khách hàng và tối ưu hiệu suất kinh doanh bền vững
					</h3>
					<button class="btn-gradient text-white fs-5 mt-4" type="button">
						Tìm hiểu thêm
					</button>
				</div>
			</div>
			<div class="col-12 col-md-4 right-card">
				<div class="feature-card card-slide-right">
					<svg fill="none" height="53" viewBox="0 0 66 53" width="66" xmlns="http://www.w3.org/2000/svg">
						<path
							  d="M10.5323 8.40774C4.17742 10.9497 1 12.2206 1 13.8C1 15.3794 4.17742 16.6503 10.5323 19.1923L19.5194 
22.7871C25.8742 25.329 29.0516 26.6 33 26.6C36.9484 26.6 40.1258 25.329 46.4806 22.7871L55.4677 19.1923C61.8226 16.6503 65 15.3794 65 13.8C65 12.2206 61.8226 10.9497 55.4677 8.40774L46.4806 4.8129C40.1258 2.27097 36.9484 1 33 1C29.9474 1 27.3556 1.7597 23.4 3.27909"
							  stroke="CurrentColor" stroke-linecap="round" stroke-width="1.5">
						</path>
						<path
							  d="M13.0516 20.2002L10.5323 21.2079C4.17742 23.7499 1 25.0208 1 26.6002C1 28.1795 4.17742 29.4505 10.5323 31.9925L19.5194 35.5873C25.8742 38.1292 29.0516 39.4002 33 39.4002C36.9484 39.4002 40.1258 38.1292 46.4806 35.5873L55.4677 31.9925C61.8226 29.4505 65 28.1795 65 26.6002C65 25.0208 61.8226 23.7499 55.4677 21.2079L52.9484 20.2002"
							  stroke="CurrentColor" stroke-width="1.5">
						</path>
						<path
							  d="M55.4677 44.7923C61.8226 42.2503 65 40.9794 65 39.4C65 37.8206 61.8226 36.5497 55.4677 34.0077L52.9484 33M13.0516 33L10.5323 34.0077C4.17742 36.5497 1 37.8206 1 39.4C1 40.9794 4.17742 
42.2503 10.5323 44.7923L19.5194 48.3871C25.8742 50.929 29.0516 52.2 33 52.2C36.0526 52.2 38.6444 51.4403 42.6 49.9209"
							  stroke="CurrentColor" stroke-linecap="round" stroke-width="1.5">
						</path>
					</svg>
					<p class="feature-label">
						PHẦN MỀM HỆ THỐNG ERP
					</p>
					<h3 class="feature-title">
						Chuyển đổi số thành công với hệ thống ERP
					</h3>
					<div class="learn-more-wrapper">
						Tìm hiểu thêm
						<svg width="24" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="m17.707 9.293-5-5a.999.999 0 1 0-1.414 1.414L14.586 9H3a1 1 0 1 0 0 2h11.586l-3.293 3.293a.999.999 0 1 0 1.414 1.414l5-5a1 1 0 0 0 0-1.414"/></svg>
					</div>
				</div>
			</div>
		</div>
		<div class="row g-4">
			<div class="col-12 col-md-4 sales-card">
				<div class="feature-card card-slide-up">
					<svg fill="none" height="56" viewBox="0 0 56 56" width="56" xmlns="http://www.w3.org/2000/svg">
						<path
							  d="M15.0303 22.0693C14.7374 21.7764 14.2626 21.7764 13.9697 22.0693C13.6768 22.3622 13.6768 22.837 13.9697 23.1299L15.0303 22.0693ZM20.6908 28.7904L21.2211 
28.26V28.26L20.6908 28.7904ZM24.5091 28.7904L25.0394 29.3207L24.5091 28.7904ZM28.7907 24.5088L28.2604 23.9785L28.2604 23.9785L28.7907 24.5088ZM32.6091 24.5088L33.1394 23.9785V23.9785L32.6091 24.5088ZM41.4998 33.3995V34.1495C41.914 34.1495 42.2498 33.8137 42.2498 33.3995H41.4998ZM42.2498 26.6496C42.2498 26.2354 41.914 25.8996 41.4998 25.8996C41.0856 25.8996 40.7498 26.2354 40.7498 26.6496H42.2498ZM34.7498 32.6495C34.3356 32.6495 33.9998 32.9853 33.9998 33.3995C33.9998 33.8137 34.3356 34.1495 34.7498 34.1495V32.6495ZM13.9697 23.1299L20.1604 29.3207L21.2211 28.26L15.0303 22.0693L13.9697 23.1299ZM25.0394 29.3207L29.321 25.0391L28.2604 23.9785L23.9788 28.26L25.0394 29.3207ZM32.0787 25.0391L40.9695 33.9299L42.0301 32.8692L33.1394 23.9785L32.0787 25.0391ZM42.2498 33.3995V26.6496H40.7498V33.3995H42.2498ZM41.4998 32.6495H34.7498V34.1495H41.4998V32.6495ZM29.321 25.0391C30.0825 24.2776 31.3172 24.2776 32.0787 25.0391L33.1394 23.9785C31.7921 22.6312 29.6077 22.6312 28.2604 23.9785L29.321 25.0391ZM20.1604 29.3207C21.5077 30.668 23.6921 30.668 25.0394 29.3207L23.9788 28.26C23.2173 29.0216 21.9826 29.0216 21.2211 28.26L20.1604 29.3207Z"
							  fill="CurrentColor">
						</path>
						<circle cx="46.9007" cy="9.09994" r="8.09994" stroke="CurrentColor" stroke-width="1.5">
						</circle>
						<path
							  d="M54.9996 23.9498V27.9998C54.9996 40.7276 54.9996 47.0915 51.0456 51.0456C47.0915 54.9996 40.7276 
54.9996 27.9998 54.9996C15.272 54.9996 8.90806 54.9996 4.95403 51.0456C1 47.0915 1 40.7276 1 27.9998C1 24.9533 1 22.2714 1.05422 19.8999M32.0498 1H27.9998C15.272 1 8.90806 1 4.95403 4.95403C3.76357 6.14449 2.93152 7.5534 2.34999 9.28867"
							  stroke="CurrentColor" stroke-linecap="round" stroke-width="1.5">
						</path>
					</svg>
					<p class="feature-label">
						PHẦN MỀM QUẢN LÝ DỰ ÁN
					</p>
					<h3 class="feature-title">
						Giải pháp giúp số hóa toàn bộ vòng đời dự án
					</h3>
					<div class="learn-more-wrapper">
						Tìm hiểu thêm
						<svg width="24" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="m17.707 9.293-5-5a.999.999 0 1 0-1.414 1.414L14.586 9H3a1 1 0 1 0 0 2h11.586l-3.293 3.293a.999.999 0 1 0 1.414 1.414l5-5a1 1 0 0 0 0-1.414"/></svg>
					</div>
				</div>
			</div>
			<div class="col-12 col-md-4 invoice-card">
				<div class="feature-card card-slide-up">
					<svg fill="none" height="48" viewBox="0 0 52 48" width="52" xmlns="http://www.w3.org/2000/svg">
						<path
							  d="M51 6.62001C51 4.63217 
49.0236 2.80248 45.7074 1.34903C42.7708 0.0619693 39.75 2.51698 39.75 5.72523V13.7748M51 6.62001C51 9.61027 46.5278 12.2426 39.75 13.7748M51 6.62001V14.4762M1 6.62001C1 4.63217 2.97638 2.80248 6.29262 1.34903C9.22923 0.0619696 12.25 2.51698 12.25 5.72523V13.7748M1 6.62001V38.4345C1 43.1651 12.1929 47 26 47C39.8071 47 51 43.1651 51 38.4345V24.4835M1 6.62001C1 9.61027 5.47222 12.2426 12.25 13.7748M12.25 13.7748C16.1947 14.6665 20.9205 15.1856 26 15.1856C31.0795 15.1856 35.8053 14.6665 39.75 13.7748"
							  stroke="currentcolor" stroke-linecap="round" stroke-width="1.5">
						</path>
						<path
							  d="M44.7539 24.4847C44.7539 26.5573 43.075 28.2374 41.0039 28.2374C38.9328 28.2374 37.2539 26.5573 37.2539 24.4847C37.2539 22.4121 38.9328 20.7319 41.0039 20.7319C43.075 20.7319 44.7539 22.4121 44.7539 24.4847Z"
							  stroke="currentcolor" stroke-width="1.5">
						</path>
						<path
							  d="M48.4961 41.9963L42.257 36.621C40.245 34.8875 37.2487 34.7149 35.034 36.2048L34.4569 36.5931C32.9179 37.6285 30.8241 37.4549 29.4939 36.1816L21.1912 
28.2335C19.5341 26.6471 16.8758 26.5624 15.1121 28.0397L11.7219 30.8794L2.24609 39.7535"
							  stroke="currentcolor" stroke-linecap="round" stroke-width="1.5">
						</path>
					</svg>
					<p class="feature-label">
						PHẦN MỀM HRM
					</p>
					<h3 class="feature-title">
						Giải pháp quản trị nhân sự & Tiền lương Chuyên sâu
					</h3>
					<div class="learn-more-wrapper">
						Tìm hiểu thêm
						<svg width="24" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="m17.707 9.293-5-5a.999.999 0 1 0-1.414 1.414L14.586 9H3a1 1 0 1 0 0 2h11.586l-3.293 3.293a.999.999 0 1 0 1.414 1.414l5-5a1 1 0 0 0 0-1.414"/></svg>
					</div>
				</div>
			</div>
			<div class="col-12 col-md-4 visibility-card">
				<div class="feature-card card-slide-up">
					<svg fill="none" height="56" viewBox="0 0 56 56" width="56" xmlns="http://www.w3.org/2000/svg">
						<path
							  d="M11.125 53.8111L11.6018 53.2322H11.6018L11.125 53.8111ZM9.67571 52.6175L10.1525 52.0386H10.1525L9.67571 52.6175ZM46.3243 52.6175L45.8475 52.0386L46.3243 52.6175ZM44.875 53.8111L44.3982 53.2322L44.875 53.8111ZM50.1757 52.6175L49.6989 53.1965L49.6989 53.1965L50.1757 52.6175ZM5.82429 52.6175L5.3475 52.0386L5.82429 52.6175ZM48.8818 1.43904L48.6577 2.15476L48.8818 1.43904ZM54.5261 6.66855L55.2307 6.41151V6.41151L54.5261 6.66855ZM7.11817 1.43904L7.3423 
2.15476L7.11817 1.43904ZM1.47386 6.66855L2.17844 6.92558L1.47386 6.66855ZM54.25 14.5C54.25 14.9142 54.5858 15.25 55 15.25C55.4142 15.25 55.75 14.9142 55.75 14.5H54.25ZM55.75 25.3C55.75 24.8858 55.4142 24.55 55 24.55C54.5858 24.55 54.25 24.8858 54.25 25.3H55.75ZM1.75 46.9C1.75 46.4858 1.41421 46.15 1 46.15C0.585786 46.15 0.25 46.4858 0.25 46.9H1.75ZM0.25 36.1C0.25 36.5142 0.585786 36.85 1 36.85C1.41421 36.85 1.75 36.5142 1.75 36.1H0.25ZM13.7351 1.75H42.2649V0.25H13.7351V1.75ZM11.6018 53.2322L10.1525 52.0386L9.19892 53.1965L10.6482 54.3901L11.6018 53.2322ZM45.8475 52.0386L44.3982 53.2322L45.3518 54.3901L46.8011 53.1965L45.8475 52.0386ZM50.6525 52.0386C49.2773 50.9061 47.2227 50.9061 45.8475 52.0386L46.8011 53.1965C47.6224 52.5201 48.8776 52.5201 49.6989 53.1965L50.6525 52.0386ZM38.6018 53.2322C36.4001 51.4189 33.0999 51.4189 30.8982 53.2322L31.8518 54.3901C33.4996 53.033 36.0004 53.033 37.6482 54.3901L38.6018 53.2322ZM25.1018 53.2322C22.9001 51.4189 19.5999 51.4189 17.3982 53.2322L18.3518 54.3901C19.9996 53.033 22.5004 53.033 24.1482 54.3901L25.1018 53.2322ZM10.1525 52.0386C8.77733 
50.9061 6.72267 50.9061 5.3475 52.0386L6.30108 53.1965C7.12237 52.5201 8.37763 52.5201 9.19892 53.1965L10.1525 52.0386ZM10.6482 54.3901C12.8499 56.2033 16.1501 56.2033 18.3518 54.3901L17.3982 53.2322C15.7504 54.5893 13.2496 54.5893 11.6018 53.2322L10.6482 54.3901ZM37.6482 54.3901C39.8499 56.2033 43.1501 56.2033 45.3518 54.3901L44.3982 53.2322C42.7504 54.5893 40.2496 54.5893 38.6018 53.2322L37.6482 54.3901ZM24.1482 54.3901C26.3499 56.2033 29.6501 56.2033 31.8518 54.3901L30.8982 53.2322C29.2504 54.5893 26.7496 54.5893 25.1018 53.2322L24.1482 54.3901ZM0.25 50.6103C0.25 52.1242 1.22269 53.2532 2.42305 53.7527C3.62151 54.2513 5.12794 54.1626 6.30108 53.1965L5.3475 52.0386C4.65134 52.6119 3.74563 52.6783 2.99926 52.3677C2.25481 52.058 1.75 51.4137 1.75 50.6103H0.25ZM54.25 50.6103C54.25 51.4137 53.7452 52.058 53.0007 52.3677C52.2544 52.6783 51.3487 52.6119 50.6525 52.0386L49.6989 53.1965C50.8721 54.1626 52.3785 54.2513 53.5769 53.7527C54.7773 53.2532 55.75 52.1242 55.75 50.6103H54.25ZM42.2649 1.75C45.7983 1.75 47.3929 1.75867 48.6577 
2.15476L49.106 0.723313C47.5669 0.241331 45.6848 0.25 42.2649 0.25V1.75ZM55.75 12.7992C55.75 9.64279 55.7614 7.8662 55.2307 6.41151L53.8216 6.92558C54.2386 8.06875 54.25 9.51329 54.25 12.7992H55.75ZM48.6577 2.15476C51.1096 2.92259 53.0086 4.69724 53.8216 6.92558L55.2307 6.41151C54.2465 3.71358 51.9711 1.62057 49.106 0.723313L48.6577 2.15476ZM13.7351 0.25C10.3152 0.25 8.43312 0.241331 6.89403 0.723313L7.3423 2.15476C8.60713 1.75867 10.2017 1.75 13.7351 1.75V0.25ZM1.75 12.7992C1.75 9.51329 1.7614 8.06875 2.17844 6.92558L0.769283 6.41151C0.238596 7.8662 0.25 9.64279 0.25 12.7992H1.75ZM6.89403 0.723313C4.02888 1.62057 1.75351 3.71358 0.769283 6.41151L2.17844 6.92558C2.99136 4.69724 4.89044 2.92259 7.3423 2.15476L6.89403 0.723313ZM54.25 12.7992V14.5H55.75V12.7992H54.25ZM54.25 25.3V50.6103H55.75V25.3H54.25ZM1.75 50.6103V46.9H0.25V50.6103H1.75ZM1.75 36.1V12.7992H0.25V36.1H1.75Z"
							  fill="CurrentColor">
						</path>
						<path
							  d="M21.0604 25.7002C20.7846 25.3913 20.3104 25.3644 20.0015 25.6403C19.6925 25.9162 19.6657 26.3903 19.9415 26.6993L21.0604 25.7002ZM24.7867 30.9998L24.2272 31.4993C24.3695 31.6586 24.573 31.7498 24.7867 31.7498C25.0003 31.7498 25.2038 31.6586 25.3461 
31.4993L24.7867 30.9998ZM36.0604 19.4993C36.3363 19.1903 36.3095 18.7162 36.0005 18.4403C35.6915 18.1644 35.2174 18.1913 34.9415 18.5002L36.0604 19.4993ZM19.9415 26.6993L24.2272 31.4993L25.3461 30.5002L21.0604 25.7002L19.9415 26.6993ZM25.3461 31.4993L36.0604 19.4993L34.9415 18.5002L24.2272 30.5002L25.3461 31.4993Z"
							  fill="CurrentColor">
						</path>
						<path d="M14.5 41.5H19M41.5 41.5H28" stroke="CurrentColor" stroke-linecap="round"
							  stroke-width="1.5">
						</path>
					</svg>
					<p class="feature-label">
						PHẦM MỀM LOGISTICS
					</p>
					<h3 class="feature-title">
						Giải pháp số hóa chuỗi cung ứng & Điều phối đội xe.
</h3>
					<div class="learn-more-wrapper">
						Tìm hiểu thêm
						<svg width="24" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="m17.707 9.293-5-5a.999.999 0 1 0-1.414 1.414L14.586 9H3a1 1 0 1 0 0 2h11.586l-3.293 3.293a.999.999 0 1 0 1.414 1.414l5-5a1 1 0 0 0 0-1.414"/></svg>
					</div>
				</div>
			</div>
		</div>
	</div>

	<section class="rated-section">
		<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/rate-shape-2.png" 
			 alt="Rate Shape" class="rate-shape-rotating">
		<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/rate-shape-1.png" 
			 alt="Rate Shape Static" class="rate-shape-static">
		<div class="container">
			<div class="row">
				<div class="col-12 text-center">
					<div class="stars-container">
						<svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
							<path
								  d="M17.6007 2.16169L20.2414 7.48279C20.6015 8.20839 21.5617 8.93399 22.3619 9.05493L27.1432 9.86114C30.204 10.3852 30.9242 12.6023 28.7236 14.8194L25.0027 18.5684C24.3825 19.1932 24.0224 20.4227 24.2224 21.3096L25.2828 25.9655C26.123 29.6339 
24.1825 31.0649 20.9616 29.1501L16.4804 26.4694C15.6602 25.9857 14.3398 25.9857 13.5196 26.4694L9.0384 29.1501C5.81755 31.0649 3.87702 29.6339 4.71725 25.9655L5.77759 21.3096C5.97764 20.4429 5.61751 19.2134 4.99735 18.5684L1.27639 14.8194C-0.92419 12.6023 -0.204043 10.365 2.85677 9.86114L7.63806 9.05493C8.43828 8.91384 9.39853 8.20839 9.75862 7.48279L12.3993 2.16169C13.8197 -0.720565 16.1803 -0.720565 17.6007 2.16169Z"
								  fill="url(#tp-1)" fill-opacity="0.3"></path>
							<defs>
								<linearGradient id="tp-1" x1="15" y1="0" x2="15" y2="30" gradientUnits="userSpaceOnUse">
									<stop offset="0" stop-color="white"></stop>
									<stop offset="1" stop-color="white" stop-opacity="0"></stop>
								</linearGradient>
							</defs>
						</svg>
						<svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
							<path
								  d="M17.6007 2.16169L20.2414 7.48279C20.6015 8.20839 21.5617 8.93399 22.3619 9.05493L27.1432 9.86114C30.204 10.3852 30.9242 12.6023 28.7236 14.8194L25.0027 18.5684C24.3825 19.1932 24.0224 20.4227 24.2224 21.3096L25.2828 25.9655C26.123 29.6339 24.1825 31.0649 20.9616 29.1501L16.4804 26.4694C15.6602 25.9857 14.3398 25.9857 13.5196 26.4694L9.0384 29.1501C5.81755 31.0649 3.87702 29.6339 4.71725 
25.9655L5.77759 21.3096C5.97764 20.4429 5.61751 19.2134 4.99735 18.5684L1.27639 14.8194C-0.92419 12.6023 -0.204043 10.365 2.85677 9.86114L7.63806 9.05493C8.43828 8.91384 9.39853 8.20839 9.75862 7.48279L12.3993 2.16169C13.8197 -0.720565 16.1803 -0.720565 17.6007 2.16169Z"
								  fill="url(#tp-2)" fill-opacity="0.3"></path>
							<defs>
								<linearGradient id="tp-2" x1="15" y1="0" x2="15" y2="30" gradientUnits="userSpaceOnUse">
									<stop offset="0" stop-color="white"></stop>
									<stop offset="1" stop-color="white" stop-opacity="0"></stop>
								</linearGradient>
							</defs>
						</svg>
						<svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
							<path
								  d="M17.6007 2.16169L20.2414 7.48279C20.6015 8.20839 21.5617 8.93399 22.3619 9.05493L27.1432 9.86114C30.204 10.3852 30.9242 12.6023 28.7236 14.8194L25.0027 18.5684C24.3825 19.1932 24.0224 20.4227 24.2224 21.3096L25.2828 25.9655C26.123 29.6339 24.1825 31.0649 20.9616 29.1501L16.4804 26.4694C15.6602 25.9857 14.3398 25.9857 13.5196 26.4694L9.0384 29.1501C5.81755 31.0649 3.87702 29.6339 4.71725 25.9655L5.77759 21.3096C5.97764 20.4429 5.61751 19.2134 4.99735 18.5684L1.27639 14.8194C-0.92419 12.6023 -0.204043 10.365 2.85677 9.86114L7.63806 9.05493C8.43828 8.91384 
9.39853 8.20839 9.75862 7.48279L12.3993 2.16169C13.8197 -0.720565 16.1803 -0.720565 17.6007 2.16169Z"
								  fill="url(#tp-3)" fill-opacity="0.3"></path>
							<defs>
								<linearGradient id="tp-3" x1="15" y1="0" x2="15" y2="30" gradientUnits="userSpaceOnUse">
									<stop offset="0" stop-color="white"></stop>
									<stop offset="1" stop-color="white" stop-opacity="0"></stop>
								</linearGradient>
							</defs>
						</svg>
						<svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
							<path
								  d="M17.6007 2.16169L20.2414 7.48279C20.6015 8.20839 21.5617 8.93399 22.3619 9.05493L27.1432 9.86114C30.204 10.3852 30.9242 12.6023 28.7236 14.8194L25.0027 18.5684C24.3825 19.1932 24.0224 20.4227 24.2224 21.3096L25.2828 25.9655C26.123 29.6339 24.1825 31.0649 20.9616 29.1501L16.4804 26.4694C15.6602 25.9857 14.3398 25.9857 13.5196 26.4694L9.0384 29.1501C5.81755 31.0649 3.87702 29.6339 4.71725 25.9655L5.77759 21.3096C5.97764 20.4429 5.61751 19.2134 4.99735 18.5684L1.27639 14.8194C-0.92419 12.6023 -0.204043 10.365 2.85677 9.86114L7.63806 9.05493C8.43828 8.91384 9.39853 8.20839 9.75862 7.48279L12.3993 2.16169C13.8197 -0.720565 16.1803 -0.720565 17.6007 2.16169Z"
								  fill="url(#tp-4)" fill-opacity="0.3"></path>
							<defs>
								<linearGradient id="tp-4" x1="15" 
y1="0" x2="15" y2="30" gradientUnits="userSpaceOnUse">
									<stop offset="0" stop-color="white"></stop>
									<stop offset="1" stop-color="white" stop-opacity="0"></stop>
								</linearGradient>
							</defs>
						</svg>
						<svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
							<path
								  d="M17.6007 2.16169L20.2414 7.48279C20.6015 8.20839 21.5617 8.93399 22.3619 9.05493L27.1432 9.86114C30.204 10.3852 30.9242 12.6023 28.7236 14.8194L25.0027 18.5684C24.3825 19.1932 24.0224 20.4227 24.2224 21.3096L25.2828 25.9655C26.123 29.6339 24.1825 31.0649 20.9616 29.1501L16.4804 26.4694C15.6602 25.9857 14.3398 25.9857 13.5196 26.4694L9.0384 29.1501C5.81755 31.0649 3.87702 29.6339 4.71725 25.9655L5.77759 21.3096C5.97764 20.4429 5.61751 19.2134 4.99735 18.5684L1.27639 14.8194C-0.92419 12.6023 -0.204043 10.365 2.85677 9.86114L7.63806 9.05493C8.43828 8.91384 9.39853 8.20839 9.75862 7.48279L12.3993 2.16169C13.8197 -0.720565 16.1803 -0.720565 17.6007 2.16169Z"
								  fill="url(#tp-5)" fill-opacity="0.3"></path>
							<defs>
								<linearGradient id="tp-5" x1="15" y1="0" x2="15" y2="30" gradientUnits="userSpaceOnUse">
									<stop offset="0" stop-color="white"></stop>
									<stop offset="1" stop-color="white" stop-opacity="0"></stop>
								</linearGradient>
							</defs>
						</svg>
					</div>
					<h2 class="rated-title">
						Những đánh giá
						<span class="italic-text"> về HomeNest 
<br> Đánh giá từ</span> 
						khách hàng
						<span class="rating-score">4.9/5</span>
					</h2>
					<button class="btn-rated btn-custom-blue btn-custom-white">Trải nghiệm ngay</button>

					<div class="row mt-5">
						<div class="col-md-4 text-center">
							<div class="review-card">
								<div class="stars-row">
									<svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg>
									<svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 
0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg>
									<svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 
0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg>
									<svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg>
									<svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 
0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg>
								</div>
								<p class="review-text">"Dịch vụ hỗ trợ rất chuyên nghiệp"</p>
								<div class="review-logo">
									<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/rate-logo-1.png"
										 alt="Company Logo 1" class="logo-img">
								</div>
							</div>
						</div>

						<div class="col-md-4 text-center">
							<div class="review-card">
								<div class="stars-row">
									<svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg>
									<svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg>
									<svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg>
									<svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg>
									<svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg>
								</div>
								<p class="review-text">"Phần mềm được cá nhân hóa cho mỗi doanh nghiệp"</p>
								<div class="review-logo">
									<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/rate-logo-2.png"
										 alt="Company Logo 2" class="logo-img">
								</div>
							</div>
						</div>

						<div class="col-md-4 text-center">
							<div class="review-card">
								<div class="stars-row">
									<svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg>
									<svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg>
									<svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg>
									<svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg>
									<svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg>
								</div>
								<p class="review-text">"Đội ngũ hỗ trợ 24/7 rất nhiệt tình"</p>
								<div class="review-logo">
									<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/rate-logo-3.png"
										 alt="Company Logo 3" class="logo-img">
								</div>
							</div>
						</div>
					</div>
					<div class="rated-img-wrapper">
						<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/rated-img.png"
							 alt="Rated Illustration" class="rated-img-parallax d-none d-md-block" />
					</div>
				</div>
			</div>
		</div>
	</section>

	<div
		 class="container py-5 d-flex flex-column flex-md-row align-items-center justify-content-between manage-cards-wrapper">
		<div class="left manage-cards-image-container flex-shrink-0 card-slide-left">
			<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/card-bg.png"
				 alt="User Onboarding Workshop ca" class="main-img" />
			<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/card-shape-1.png"
				 alt="Circular orange sync arrows icon" class="icon-img" width="64" height="64" />
			<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/card-img-1.png" alt="Card Overlay"
				 class="card-img-overlay d-none d-md-block" />
			<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/card-img-4.png" alt="Card Overlay 4"
				 class="card-img-overlay-4 " />
			<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/card-img-2.png" alt="Card Overlay 2"
				 class="card-img-overlay-2 d-none d-md-block" />
			<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/card-img-3.png" alt="Card Overlay 3"
				 class="card-img-overlay-3 d-none d-md-block" />
		</div>
		<div class="right text-center text-md-start card-slide-right">
			<h2 class="manage-cards-title">
				Giải pháp quản lý<em class="all-your-c">cho</em> doanh nghiệp
			</h2>
			<p 
class="mt-3 manage-cards-text">
				HomeNest cung cấp phần mềm tùy chỉnh chuyên sâu giúp tôi ưu vận hành – Bảo mật tối đa – Linh hoạt mở rộng.
Đối tác công nghệ tin cậy giúp doanh nghiệp vững vàng vị thế và bứt phá doanh thu.
</p>
			<button type="button" class="btn btn-manage-cards mt-4 btn-custom-blue">
				Trải nghiệm ngay
			</button>
		</div>
	</div>
	<main
		  class="container py-5 d-flex flex-column flex-md-row align-items-center justify-content-center gap-4 gap-md-5">
		<div class="text-start card-slide-left">
			<div class="heading-title fs-2 fs-md-1 mb-3">
				Tại sao <em style="font-weight: 400;">bạn</em> nên chọn chúng tôi
			</div>
			<div class="text-p text-secondary mb-4" style="font-size: 1rem;">
				Tại HomeNest, chúng tôi cam kết mang lại những giá trị bền vững thông qua các giải pháp được cá nhân hóa sâu sắc:
			</div>
			<div class="feature-list">
				<div class="feature-yellow">
					<span class="icon-circle" aria-hidden="true">
						<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="none" stroke="currentColor"
							 stroke-linecap="round" stroke-linejoin="round" stroke-width="3" viewBox="0 0 24 24">
							<path d="M20 6L9 17l-5-5"></path>
						</svg>
					</span>
					Tối ưu hiệu suất
				</div>
				<div class="feature-blue">
					<span class="icon-circle" aria-hidden="true">
						<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="none" stroke="currentColor"
							 stroke-linecap="round" stroke-linejoin="round" stroke-width="3" viewBox="0 0 24 24">
							<path 
d="M20 6L9 17l-5-5"></path>
						</svg>
					</span>
					Dễ dàng nâng cấp
				</div>
				<div class="feature-green">
					<span class="icon-circle" aria-hidden="true">
						<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="none" stroke="currentColor"
							 stroke-linecap="round" stroke-linejoin="round" stroke-width="3" viewBox="0 0 24 24">
							<path d="M20 6L9 17l-5-5"></path>
						</svg>
					</span>
					Bảo mật cao
				</div>
			</div>
		</div>
		<div class="dashboard-image-wrapper flex-shrink-0 card-slide-right">
			<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/sale-1-1.png"
				 alt="Dashboard UI with colorful rounded corners in green, purple, and pink, showing a sidebar with Solarius logo and a main panel with today's plan, weekly report, and other cards, plus a floating white card showing total invoice 520 with a yellow bar chart"
				 class="dashboard-img" width="600" height="400" />
			<div class="overlay-img-wrapper">
				<img decoding="async" src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/sale-2-1.png"
					 alt="Animated sale icon floating over dashboard image" />
			</div>
		</div>
	</main>
	<section class="testi-section">
		<div class="container d-flex justify-content-between align-items-center testi-header-row">
			<h2 class="testi-main-title mb-0" style=" 
font-weight: 400; ">Khách hàng <br>
				<span style=" font-weight: 700; ">nói gì về chúng tôi</span>
			</h2>
			<div class="testi-btn-group">
				<button class="testi-btn testi-btn-prev" aria-label="Previous testimonials">
					<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 30.725 30.725" xml:space="preserve"><path d="M24.078 26.457a2.5 2.5 0 0 1-1.77 4.267 2.5 2.5 0 0 1-1.768-.731L5.914 15.362 20.543.732a2.499 2.499 0 1 1 3.535 3.536L12.984 15.362z"/></svg>
				</button>
				<button class="testi-btn testi-btn-next" aria-label="Next testimonials">
					<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 30.729 30.729" xml:space="preserve"><path d="M24.813 15.366 10.185 29.997a2.5 2.5 0 0 1-1.768.731 2.5 2.5 0 0 1-1.769-4.267l11.095-11.096L6.649 4.268A2.501 2.501 0 0 1 10.185.732z"/></svg>
				</button>
			</div>
		</div>
		<div class="testi-carousel-wrapper">
			<div class="testi-carousel">
				<div class="testi-card">
					<div class="testi-card-left">
						<div class="tp-testimonial-3-review">
							<span><svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 
0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg></span>
							<span><svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg></span>
							<span><svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg></span>
							<span><svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg></span>
							<span><svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" 
style="fill:gold"/></svg></span>
						</div>
						<p class="tp-rep-content">"Giải pháp ERP do HomeNest thiết kế đã giúp chúng tôi tự động hóa 90% quy trình thủ công, đặc biệt là khâu kho vận và kế toán.”</p>
						<h5 class="tp-rep-name">Nguyễn Hoàng Long </h5>
						<span class="tp-rep-desi">Giám đốc vận hành</span>
					</div>
					<div class="testi-card-right d-none d-md-block">
						<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/testi-3-4.jpg"
							 alt="Testimonial 1" class="testi-card-right-img">
					</div>
				</div>
				<div class="testi-card">
					<div class="testi-card-left">
						<div class="tp-testimonial-3-review">
							<span><svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 
1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg></span>
							<span><svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg></span>
							<span><svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg></span>
							<span><svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg></span>
							<span><svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg></span>
						</div>
						<p class="tp-rep-content">“HomeNest là đơn vị duy nhất thấu hiểu và tùy chỉnh phần mềm đáp ứng chính xác 100% nghiệp vụ đặc thù của chúng tôi.”</p>
						<h5 class="tp-rep-name">Trần Khánh Linh </h5>
						<span class="tp-rep-desi">Quản lý dự án</span>
					</div>
					<div class="testi-card-right d-none 
d-md-block">
						<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/testi-3-2.png"
							 alt="Testimonial 2" class="testi-card-right-img">
					</div>
				</div>
				<div class="testi-card">
					<div class="testi-card-left">
						<div class="tp-testimonial-3-review">
							<span><svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg></span>
							<span><svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 
0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg></span>
							<span><svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg></span>
							<span><svg 
fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg></span>
							<span><svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" 
style="fill:gold"/></svg></span>
						</div>
						<p class="tp-rep-content">“Hệ thống chạy rất ổn định suốt 3 năm qua.
Điều chúng tôi hài lòng nhất là dịch vụ hỗ trợ của HomeNest.”</p>
						<h5 class="tp-rep-name">Lê Minh Quân </h5>
						<span class="tp-rep-desi">CEO</span>
					</div>
					<div class="testi-card-right d-none d-md-block">
						<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/testi-3-3.png"
							 alt="Testimonial 3" class="testi-card-right-img">
					</div>
				</div>
				<div class="testi-card">
					<div class="testi-card-left">
						<div class="tp-testimonial-3-review">
							<span><svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg></span>
							<span><svg fill="gold" width="24" viewBox="0 0 24 24" 
data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg></span>
							<span><svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 
2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg></span>
							<span><svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg></span>
							<span><svg fill="gold" width="24" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M22 9.81a1 1 0 0 0-.83-.69l-5.7-.78-2.59-4.81a1 
1 0 0 0-1.76 0L8.57 8.34l-5.7.78a1 1 0 0 0-.82.69 1 1 0 0 0 .28 1l4.09 3.73-1 5.24a1 1 0 0 0 1.46 1.12L12 18.38l5.12 2.52a1 1 0 0 0 .44.1 1 1 0 0 0 1-1.18l-1-5.24 4.09-3.73A1 1 0 0 0 22 9.81" style="fill:gold"/></svg></span>
						</div>
						<p class="tp-rep-content">“Tôi đánh giá cao HomeNest.
Việc tích hợp API với hệ thống kế toán cũ diễn ra suôn sẻ, không gây gián đoạn hoạt động kinh doanh.”</p>
						<h5 class="tp-rep-name">Phạm Minh Trí </h5>
						<span class="tp-rep-desi">CEO</span>
					</div>
					<div class="testi-card-right d-none d-md-block">
						<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/testi-3-5.png"
							 alt="Testimonial 4" class="testi-card-right-img">
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="integration-section">
		<div class="container">
			<div class="row align-items-center integration-header-row">
				<div class="col-md-8">
					<div class="integration-content slide-up-on-scroll">
						<span class="integration-label">KHẢ NĂNG TÍCH HỢP</span>
						<h2 class="integration-title">Tích hợp dễ dàng <br>
							<span style=" font-weight: 400;font-style: italic;
">Không giới hạn</span></h2>
					</div>
				</div>
				<div class="col-md-4 text-end">
					<button class="btn-integration btn-custom-blue btn-slide-right">Tìm hiểu thêm</button>
				</div>
			</div>
			<div class="double">
				<div class="integration-logos-row integration-logos-row-1">
					<div class="integration-logos-track">
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-1.png"
								 alt="Integration 1">
						</div>
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-2.png"
								 alt="Integration 2">
						</div>
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-3.png"
								 alt="Integration 3">
						</div>
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-4.png"
								 alt="Integration 4">
						</div>
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-5.png"
								 alt="Integration 5">
						</div>
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-6.png"
								 alt="Integration 6">
						</div>
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-7.png"
								 alt="Integration 7">
						</div>
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-8.png"
								 alt="Integration 8">
						</div>
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-1.png"
								 alt="Integration 1">
						</div>
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-2.png"
								 alt="Integration 2">
						</div>
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-3.png"
								 alt="Integration 3">
						</div>
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-4.png"
								 alt="Integration 4">
						</div>
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-5.png"
								 alt="Integration 5">
						</div>
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-6.png"
								 alt="Integration 6">
						</div>
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-7.png"
								 alt="Integration 7">
						</div>
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-8.png"
								 alt="Integration 8">
						</div>
					</div>
				</div>

				<div class="integration-logos-row integration-logos-row-2">
					<div class="integration-logos-track">
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-8.png"
								 alt="Integration 8">
						</div>
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-7.png"
								 alt="Integration 7">
						</div>
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-6.png"
								 alt="Integration 6">
						</div>
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-5.png"
								 alt="Integration 5">
						</div>
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-4.png"
								 alt="Integration 4">
						</div>
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-3.png"
								 alt="Integration 3">
						</div>
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-2.png"
								 alt="Integration 2">
						</div>
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-1.png"
								 alt="Integration 1">
						</div>
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-8.png"
								 alt="Integration 8">
						</div>
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-7.png"
								 alt="Integration 7">
						</div>
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-6.png"
								 alt="Integration 6">
						</div>
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-5.png"
								 alt="Integration 5">
						</div>
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-4.png"
								 alt="Integration 4">
						</div>
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-3.png"
								 alt="Integration 3">
						</div>
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-2.png"
								 alt="Integration 2">
						</div>
						<div class="integration-logo-item">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/integration-1.png"
								 alt="Integration 1">
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="latest-news-section">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-12 text-center">
					<h2 class="latest-news-title">Kiến thức & Xu hướng <span style=" font-weight: 400;
"><br>Thiết kế Phần mềm</span></h2>
				</div>
			</div>

			<div class="row mt-5">
				<?php
				/**
 * Lấy 3 bài post từ danh mục 'wiki-software' và hiển thị theo cấu trúc tùy chỉnh,
 * sử dụng số thứ tự cho class CSS.
 */

				// ⚠️ CHỈ ĐỊNH SLUG CỦA DANH MỤC
				$category_slug = 'wiki-software'; 

				// 1. Định nghĩa tham số truy vấn
				$args = array(
					'post_type'      => 'post',
					'post_status'    => 'publish',
					'posts_per_page' => 3, 
					'orderby'        => 'date',
					'order'          => 'DESC',

					// Điều kiện truy vấn theo Taxonomy
					'tax_query' => array(
						array(
							'taxonomy' => 
'category', 
							'field'    => 'slug',    
							'terms'    => $category_slug, 
						),
					),
				);

				// 2. Tạo đối tượng WP_Query
				$the_query = new WP_Query( $args );

				// KHỞI TẠO BIẾN ĐẾM (COUNTER)
				$counter = 0;

				// 3. Vòng lặp để hiển thị các bài post
				if ( $the_query->have_posts() ) {

					// echo '<div class="row">';
while ( $the_query->have_posts() ) {
						$the_query->the_post();

						// TĂNG BIẾN ĐẾM SAU MỖI VÒNG LẶP
						$counter++;
// Lấy dữ liệu tác giả
						$author_id = get_the_author_meta('ID');
						$author_avatar_url = get_avatar_url($author_id); 
						$author_name = get_the_author();
// Lấy danh mục đầu tiên của bài viết
						$categories = get_the_category();
						$first_category = !empty($categories) ? $categories[0] : null;
$category_name = $first_category ? $first_category->name : 'Uncategorized';

						// --- BẮT ĐẦU CẤU TRÚC ITEM ---
				?>

				<div class="col-xl-4 col-lg-4 col-md-6 col-12 mb-4">
					<div class="blog-card">

						<div class="blog-thumb">
							<a href="<?php the_permalink(); ?>">
								<?php 
						if ( has_post_thumbnail() ) {
							the_post_thumbnail( 'full', array(
								'alt' => get_the_title(),
								'class' => 'blog-image',
							) );
} 
								?>
							</a>
						</div>

						<div class="blog-meta">
							<div class="blog-category category-color-<?php echo esc_attr( $counter ); ?>">
								<span><?php echo esc_html( $category_name );
?></span>
							</div>
							<div class="blog-date">
								<span><?php echo get_the_date( 'F j, Y' ); ?></span> 
							</div>
						</div>

						<div class="blog-title-box">
							<a class="blog-title" href="<?php the_permalink(); ?>"><?php the_title();
?></a>
						</div>

						<div class="blog-author-info">
							<div class="blog-avatar">
								<img src="<?php echo esc_url( $author_avatar_url ); ?>"
									 alt="<?php echo esc_attr( $author_name ); ?>" class="avatar">
							</div>
							<div class="author-info">
								<h5 class="author-name"><?php echo esc_html( $author_name );
?></h5>
							</div>
						</div>
					</div>
				</div>

				<?php
						// --- KẾT THÚC CẤU TRÚC ITEM ---
					}

					// 4. Đặt lại dữ liệu Post toàn cục (RẤT QUAN TRỌNG)
					wp_reset_postdata();
} else {
					echo '<p>Không tìm thấy bài viết nào trong danh mục "' . esc_html( $category_slug ) . '".</p>';
}
				?>
			</div>
			
			
		</div>
		
		
		
	</section>

	<section class="early-access-section">
		<div class="container early-access-container">
			<div class="row align-items-center early-access-row">
				<div class="col-md-9">
					<h2 class="early-access-title">Chuyển đổi số nhanh chóng <span class="text-early">hiệu quả tức thì.</span>
					</h2>

					</div>
				<div class="col-md-3 text-end mb-5">
					<button class="btn-early-access btn-custom-blue">Liên hệ ngay</button>
				</div>
				<div class="browser-logos-wrapper">
					<div class="browser-logo-item">
						<a href="#">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/browser-icon-1.png"
								 alt="Windows">
						</a>
						<p>Windows</p>
					</div>
					<div class="browser-logo-item">
						<a href="#">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/browser-icon-2.png"
								 alt="Firefox">
						</a>
						<p>Firefox</p>
					</div>
					<div class="browser-logo-item">
						<a href="#">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/browser-icon-3.png"
								 alt="Chrome">
						</a>
						<p>Chrome</p>
					</div>
					<div class="browser-logo-item">
						<a href="#">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/browser-icon-4.png"
								 alt="macOS">
						</a>
						<p>macOS</p>
					</div>
					<div class="browser-logo-item">
						<a href="#">
							<img src="https://wp.storebuild.shop/softec/wp-content/uploads/2023/05/browser-icon-5.png"
								 alt="Linux">
						</a>
						<p>Linux</p>
					</div>
				</div>
			</div>

			<div class="footer-slider-track">
				<div class="footer-slide-item">
					<svg fill="#65666A" width="24" viewBox="0 0 24 24" data-name="Line Color" xmlns="http://www.w3.org/2000/svg" class="icon line-color"><path style="fill:none;stroke:#65666a;stroke-linecap:round;stroke-linejoin:round;stroke-width:2" d="m5 12 5 5 9-9"/></svg>
					<span>Trải nghiệm demo miễn phí</span>
				</div>
				<div class="footer-slide-item">
					<svg fill="#65666A" width="24" viewBox="0 0 24 24" data-name="Line Color" xmlns="http://www.w3.org/2000/svg" class="icon line-color"><path style="fill:none;stroke:#65666a;stroke-linecap:round;stroke-linejoin:round;stroke-width:2" d="m5 12 5 5 9-9"/></svg>
					<span>Hỗ trợ 
24/7</span>
				</div>
				<div class="footer-slide-item">
					<svg fill="#65666A" width="24" viewBox="0 0 24 24" data-name="Line Color" xmlns="http://www.w3.org/2000/svg" class="icon line-color"><path style="fill:none;stroke:#65666a;stroke-linecap:round;stroke-linejoin:round;stroke-width:2" d="m5 12 5 5 9-9"/></svg>
					<span>Vận hành nhanh chóng</span>
				</div>
				<div class="footer-slide-item">
					<svg fill="#65666A" width="24" viewBox="0 0 24 24" data-name="Line Color" xmlns="http://www.w3.org/2000/svg" class="icon line-color"><path style="fill:none;stroke:#65666a;stroke-linecap:round;stroke-linejoin:round;stroke-width:2" d="m5 12 5 5 9-9"/></svg>
					<span>Tất cả tính năng trong một</span>
				</div>
				<div class="footer-slide-item">
					<svg fill="#65666A" width="24" viewBox="0 0 24 24" data-name="Line Color" xmlns="http://www.w3.org/2000/svg" class="icon line-color"><path style="fill:none;stroke:#65666a;stroke-linecap:round;stroke-linejoin:round;stroke-width:2" d="m5 12 5 5 9-9"/></svg>
					<span>Khả năng bảo mật cao</span>
				</div>
				<div class="footer-slide-item">
					<svg fill="#65666A" width="24" viewBox="0 0 24 24" data-name="Line Color" xmlns="http://www.w3.org/2000/svg" class="icon line-color"><path style="fill:none;stroke:#65666a;stroke-linecap:round;stroke-linejoin:round;stroke-width:2" d="m5 12 5 5 9-9"/></svg>
					<span>Tích hợp và mở rộng dễ dàng</span>
				</div>
				<div class="footer-slide-item">
					<svg fill="#65666A" width="24" viewBox="0 
0 24 24" data-name="Line Color" xmlns="http://www.w3.org/2000/svg" class="icon line-color"><path style="fill:none;stroke:#65666a;stroke-linecap:round;stroke-linejoin:round;stroke-width:2" d="m5 12 5 5 9-9"/></svg>
					<span>Trải nghiệm demo miễn phí</span>
				</div>
				<div class="footer-slide-item">
					<svg fill="#65666A" width="24" viewBox="0 0 24 24" data-name="Line Color" xmlns="http://www.w3.org/2000/svg" class="icon line-color"><path style="fill:none;stroke:#65666a;stroke-linecap:round;stroke-linejoin:round;stroke-width:2" d="m5 12 5 5 9-9"/></svg>
					<span>Hỗ trợ 24/7</span>
				</div>
				<div class="footer-slide-item">
					<svg fill="#65666A" width="24" viewBox="0 0 24 24" data-name="Line Color" xmlns="http://www.w3.org/2000/svg" class="icon line-color"><path style="fill:none;stroke:#65666a;stroke-linecap:round;stroke-linejoin:round;stroke-width:2" d="m5 12 5 5 9-9"/></svg>
					<span>Vận hành nhanh chóng</span>
				</div>
				<div class="footer-slide-item">
					<svg fill="#65666A" width="24" viewBox="0 0 24 24" data-name="Line Color" xmlns="http://www.w3.org/2000/svg" class="icon line-color"><path style="fill:none;stroke:#65666a;stroke-linecap:round;stroke-linejoin:round;stroke-width:2" d="m5 12 5 5 9-9"/></svg>
					<span>Tất cả tính năng trong một</span>
				</div>
				<div class="footer-slide-item">
					<svg fill="#65666A" width="24" viewBox="0 0 24 24" data-name="Line Color" xmlns="http://www.w3.org/2000/svg" class="icon line-color"><path style="fill:none;stroke:#65666a;stroke-linecap:round;stroke-linejoin:round;stroke-width:2" d="m5 12 5 5 9-9"/></svg>
					<span>Khả 
năng bảo mật cao</span>
				</div>
				<div class="footer-slide-item">
					<svg fill="#65666A" width="24" viewBox="0 0 24 24" data-name="Line Color" xmlns="http://www.w3.org/2000/svg" class="icon line-color"><path style="fill:none;stroke:#65666a;stroke-linecap:round;stroke-linejoin:round;stroke-width:2" d="m5 12 5 5 9-9"/></svg><i class="fas fa-check"></i>
					<span>Tích hợp và mở rộng dễ dàng</span>
				</div>
			</div>
		</div>
	</section>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>





</body>
<?php endwhile;
endif; ?>
<?php get_footer(); ?>