<?php
/**
 * Template Name: Thiết kế website - En
 * Template Post Type: service
 */
get_header(); ?>


<body>
	<div class="service-wrapper">
		<div class="homenest__website-design__section1">
			<div class="homenest__website-design__section1-wrapper">
				<div class="homenest__website-design__hero-sup fadeInLeft-Webdesign">
					<img src=" /wp-content/uploads/2025/05/stars.svg" alt>
					<p>Introducing the multipurpose</p>
				</div>
				<h1 class="homenest__website-design__section1__title fadeInUp-Webdesign">
					Website Design<br>
					Service
				</h1>
				<p class="homenest__website-design__section1__des fadeInLeft-Webdesign">
					Modern website design, SEO-ready, optimized for user experience.
				</p>
				<div class="homenest__website-design__section1__wrap-btn fadeInRight-Webdesign">
					<div class="homenest__website-design__section1__wrap-btn--get">
						<img src=" /wp-content/uploads/2025/05/9e4463d8-978b-434c-a262-32735b1878e7-removebg-preview.webp"
							 alt>
						<a href="#">Contact Now!</a>
					</div>
					<div class="homenest__website-design__section1__wrap-btn--demos">
						<a href="/project/">Learn More</a>
					</div>
				</div>

				<div class="homenest__website-design__section1__grid">
					<div class="homenest__website-design__section1__grid-1 fadeInUp-Webdesign">
						<div class="homenest__website-design__section1__grid--img">
							<img src=" /wp-content/uploads/2025/05/gl-1.webp" alt>
						</div>
					</div>
					<div class="homenest__website-design__section1__grid-2 fadeInUp-Webdesign">
						<div class="homenest__website-design__section1__grid--img">
							<img src=" /wp-content/uploads/2025/05/gl-2.webp" alt>
						</div>
					</div>
					<div class="homenest__website-design__section1__grid-3">
						<div class="homenest__website-design__section1__grid--img fadeInUp-Webdesign">
							<img src=" /wp-content/uploads/2025/05/gl-3.webp" alt>
						</div>
					</div>
					<div class="homenest__website-design__section1__grid-4 fadeInUp-Webdesign">
						<div class="homenest__website-design__section1__grid--img">
							<img src=" /wp-content/uploads/2025/05/gl-4.webp" alt>
						</div>
					</div>
					<div class="homenest__website-design__section1__grid-5 fadeInUp-Webdesign">
						<div class="homenest__website-design__section1__grid--img">
							<img src=" /wp-content/uploads/2025/05/gl-5.webp" alt>
						</div>
					</div>
				</div>

				<div class="homenest__website-design__section1__brand">
					<p id="homenest__website-design__section1__hover-text">HomeNest
					</p>
				</div>
			</div>
		</div>

		<div class="homenest__website-design__section2">
			<canvas class="homenest__website-design__section2--canvas"
					id="homenest__website-design__section2--canvas"></canvas>
			<div class="homenest__website-design__section2-wrapper">
				<div class="homenest__website-design__section2__video">
					<video autoplay muted loop playsinline src=" /wp-content/uploads/2025/05/video_sup-1.mp4"></video>
				</div>

				<div class="homenest__website-design__section2__title ">
					<span>What makes us different?</span>
					<p>Our modern design service, exceptional speed and optimal experience <br>
						<a class="homenest__website-design__highlight-link">help you stand out 
						</a>in the market.
					</p>
				</div>

				<div class="homenest__website-design__section2__grid">
					<div class="homenest__website-design__section2__grid-1">
						<div class="homenest__website-design__section2__wrap-card">
							<div class="homenest__website-design__section2__wrap-card__img">
								<img class="img-overlay" src=" /wp-content/uploads/2025/05/item-1.webp" alt="Thiết kế website chuyên nghiệp homenest">
								<img class="img-background" src=" /wp-content/uploads/2025/05/item-1-2.webp" alt="Thiết kế website chuyên nghiệp homenest 1">
							</div>
							<h6 class="homenest__website-design__section2--title-card">
								<span style="color: #ab003a;">Diverse & Creative </span> <br>Design
							</h6>
						</div>
					</div>
					<div class="homenest__website-design__section2__grid-2">
						<div class="homenest__website-design__section2__wrap-card-2">
							<div class="homenest__website-design__section2__grid-2__img">
								<img class="img-zoom-in-out-1" src=" /wp-content/uploads/2025/05/item-2.webp" alt="Thiết kế website chuyên nghiệp homenest 2">
								<img class="img-zoom-in-out-2" src=" /wp-content/uploads/2025/05/item-2-2.webp" alt="Thiết kế website chuyên nghiệp homenest 3">
							</div>
							<h6 class="homenest__website-design__section2--title-card">
								SEO-Ready <br> Structure
							</h6>
						</div>
					</div>
					<div class="homenest__website-design__section2__grid-3">
						<div class="wrap-card3">
							<div class="wrap-card3__num-wrap">
								<p class="numb">50</p>
								<img class="rotating-plus" src=" /wp-content/uploads/2025/05/plus.svg" alt="Thiết kế website chuyên nghiệp homenest 4" >
							</div>
							<hr style="border: none; height: 1px;background-color: #e9e9e9; opacity: 0.4;">
							<h6 class="title-card-3" style="color: white;">
								Industries</h6>
						</div>
					</div>
					<div class="homenest__website-design__section2__grid-4">
						<div class="website-design__section2__grid-4__video">
							<video autoplay muted loop playsinline src=" /wp-content/uploads/2025/05/robot.mp4"></video>
							<img src=" /wp-content/uploads/2025/05/stars.webp" alt>
						</div>
						<div class="website-design__section2__grid-4__img">
							<img src=" /wp-content/uploads/2025/05/z6627033053412_622e7b0e6d98945f9af9fd6fcc9aa66a.webp"
								 alt="Thiết kế website chuyên nghiệp homenest 5">
							<img src=" /wp-content/uploads/2025/05/z6627032940827_373612a20499774486e7688d63196500.webp"
								 alt="Thiết kế website chuyên nghiệp homenest 6">
							<img src=" /wp-content/uploads/2025/05/z6627032885818_f81e64dcaa8f63831fab1fc2137d8604.webp"
								 alt="Thiết kế website chuyên nghiệp homenest 7">
						</div>
						<div class="website-design__section2__grid-4__title">
							<h6>Modern website design aligned with trends</h6>
						</div>
					</div>
					<div class="homenest__website-design__section2__grid-5">
						<div class="website-design__section2__grid-5__wrap">
							<div class="website-design__section2__grid-5__wrap--content">
								<div class="website-design__section2__grid-5__wrap--content-img">
									<img class="move-right" src=" /wp-content/uploads/2025/05/item-5.webp" alt="Thiết kế website chuyên nghiệp homenest 8">
									<img class="move-left" src=" /wp-content/uploads/2025/05/item-5-2.webp" alt="Thiết kế website chuyên nghiệp homenest 9">
								</div>
								<div class="website-design__section2__grid-5__wrap--content-text">
									<p>Fast Loading Speed</p>
								</div>
							</div>
						</div>
					</div>
					<div class="homenest__website-design__section2__grid-6">
						<div class="section2__grid-6__wrap">
							<div class="section2__grid-6__wrap--img">
								<img src=" /wp-content/uploads/2025/05/item-6.svg" alt="Thiết kế website chuyên nghiệp homenest 10">
							</div>

							<div class="section2__grid-6__wrap--text">
								<p>
									Professional, Impressive Website Design
								</p>
							</div>
						</div>
					</div>
					<div class="homenest__website-design__section2__grid-7">
						<div class="website-design__section2__grid-7__wrap">
							<div class="website-design__section2__grid-7__wrap--content">
								<div class="website-design__section2__grid-7__wrap--content-img">
									<img src=" /wp-content/uploads/2025/05/item-9-2.webp" alt class="img-top-left">
									<img src=" /wp-content/uploads/2025/05/item-9.webp" alt class="img-middle">
									<img src=" /wp-content/uploads/2025/05/item-9-3.webp" alt class="img-bottom-right">
								</div>
								<div class="website-design__section2__grid-7__wrap--content-text">
									<p>Transparent, Trustworthy Warranty Policy</p>
								</div>
							</div>
						</div>

					</div>
					<div class="homenest__website-design__section2__grid-8">
						<div class="section2__grid-8__wrap">
							<div class="section2__grid-8__wrap--img">
								<img src=" /wp-content/uploads/2025/05/item-8.svg" alt="Thiết kế website chuyên nghiệp homenest 11">
								<div class="badge">60+</div>
							</div>
							<div class="section2__grid-8__wrap--text">
								<p>
									User-Friendly Interface
								</p>
							</div>
						</div>

					</div>
					<div class="homenest__website-design__section2__grid-9">
						<div class="section2__grid-9__wrapper">
							<div class="section2__grid-9__wrapper--content">
								<div class="section2__grid-9__wrapper--content-numb">
									<p class="numb">5</p>
									<img class="rotating-plus" src=" /wp-content/uploads/2025/05/item-7-2.webp" alt="Thiết kế website chuyên nghiệp homenest 12">
								</div>

								<div class="section2__grid-9__wrapper--content-text">
									<p>24/7  <br>
									<p style="opacity: 0.5;">Support <br>& Updates</p>
								</div>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>
	</div>

	<div class="homenest__website-design__section3">
		<div class="homenest__website-design__section3-wrapper">
			<div class="homenest__website-design__section3--text-run__header">
				<div class="text-run"><img src=" /wp-content/uploads/2025/05/speed.webp" alt="Thiết kế website chuyên nghiệp homenest 13">
					<div class="wrap-clock"><img src=" /wp-content/uploads/2025/05/arrow.webp" alt="Thiết kế website chuyên nghiệp homenest 14">
					</div>
				</div>
				<div class="homenest__website-design__section3__title">
					<span>Professional Landing Page Design</span>
					<p>Professional Landing <a class="homenest__website-design__highlight-link"> Page Design Solution</a><br> Helping you optimize landing pages, increase conversions, and boost revenue.</p>
				</div>

			</div>
			<div class="homenest__website-design__section3--content">
				<img class src=" /wp-content/uploads/2025/05/bg-sc2.webp" alt="">
				<img class="fadeInUp-Webdesign" src=" /wp-content/uploads/2025/05/daaa.webp" alt="Thiết kế website chuyên nghiệp homenest 15">
				<img class="fadeInRight-Webdesign" src=" /wp-content/uploads/2025/05/eqq.webp" alt="Thiết kế website chuyên nghiệp homenest 16">
				<img class="fadeInUp-Webdesign" src=" /wp-content/uploads/2025/05/ajsdjasd.webp" alt="Thiết kế website chuyên nghiệp homenest 17">
				<img class="fadeInLeft-Webdesign" src=" /wp-content/uploads/2025/05/jkas.webp" alt="Thiết kế website chuyên nghiệp homenest 18">
				<img class="fadeInRight-Webdesign" src=" /wp-content/uploads/2025/05/kjjiasd.webp" alt="Thiết kế website chuyên nghiệp homenest 19">
			</div>
			<div class="homenest__website-design__section3--footer">
				<a class="homenest__website-design__section3--footer-btn fadeInUp-Webdesign" href="/contact/">
					Contact Now!</a>
			</div>
		</div>
	</div>

	<div class="homenest__website-design__section4">
		<div class="homenest__website-design__section4-wrapper">
			<div class="homenest__website-design__section4__title fadeInLeft-Webdesign">
				<h2><span>
					HomeNest - Website Design
					</span></h2>
				<p>
					Professional website design service, an effective solution for everything you need for your online business.
				</p>
			</div>
			<div class="homenest__website-design__section4--video-content">
				<div class="homenest__website-design__section4--video-content-video">
					<img src=" /wp-content/uploads/2025/05/jsjjsj.webp" alt="">
					<a id="open-popup-video" data-video-url="https://www.youtube.com/embed/askvjHBrbIQ"
					   href="#"></a>
				</div>
				<img src=" /wp-content/uploads/2025/05/blob1-1.png" alt="">
				<img src=" /wp-content/uploads/2025/05/blob2.webp" alt="">

			</div>
			<!-- Popup Overlay -->
			<div id="popup-overlay" class="homenest__website-design__section4__popup-overlay">
				<div class="popup-content">
					<button class="homenest__website-design__section4__close-popup" id="close-popup" aria-label="Đóng popup thiết kế web"></button>
					<iframe id="video-frame" class="video-frame" src="" frameborder="0"
							allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
							allowfullscreen></iframe>
				</div>
			</div>
			<p class="section4-text">HomeNest - Effective Digital Transformation Solution.</p>

		</div>

		<div class="homenest__website-design__section5">
			<div class="homenest__website-design__section5-wrapper">
				<div class="homenest__website-design__section5--title">
					<div class="homenest__website-design__section5--title-num">
						<span class="homenest__website-design__section5--title-num-count">
							<span class="digit" data-value="1">
								<span>0</span>
								<span>1</span>
								<span>2</span>
							</span>
							<span class="digit" data-value="5">
								<span>0</span>
								<span>1</span>
								<span>2</span>
								<span>3</span>
								<span>4</span>
								<span>5</span>
							</span>
							<span class="digit" data-value="5">
								<span>0</span>
								<span>1</span>
								<span>2</span>
								<span>3</span>
								<span>4</span>
								<span>5</span>
							</span>
							<span class="digit" data-value="0">
								<span>0+</span>
							</span>
							</div>
						<div class="homenest__website-design__section5--title-img">
							<img src=" /wp-content/uploads/2025/05/demos-badge.webp" alt="Thiết kế website chuyên nghiệp homenest 15">
						</div>
					</div>
					<div class="homenest__website-design__section5--title-text">
						<h2>Real-World Case Studies<br> For every industry & niche
						</h2>
					</div>

				</div>
			</div>

			<section id="project" class="homenest__archive-project__show-project">
				<div class="project-archive">
					<!-- Form lọc -->


					<?php
					// Assuming this is within a WordPress theme or plugin file
					echo do_shortcode('[tim-kiem-du-an-va-chon-nganh]');
					echo do_shortcode('[tat-ca-danh-muc-du-an]');
					echo do_shortcode('[tat-ca-du-an]');
					?>

				</div>
			</section>
			<div class="homenest__website-design__section7">
				<div class="homenest__website-design__section7-wrapper">
					<div class="homenest__website-design__section7--title">
						<div class="homenest__website-design__section5--title-num">
							<span class="homenest__website-design__section5--title-num-count">
								<span class="digit" data-value="2">
									<span>0</span>
									<span>1</span>
									<span>2</span>
								</span>
								<span class="digit" data-value="5">
									<span>0</span>
									<span>1</span>
									<span>2</span>
									<span>3</span>
									<span>4</span>
									<span>5</span>
								</span>
								<span class="digit" data-value="0">
									<span>0+</span>
								</span>
							</span>
						</div>
						<h2>
							Specialized websites for various industries
						</h2>
					</div>
					<div class="homenest__website-design__section7--category">
						<ul class="homenest__website-design__section7--category-grid">
							<li class="category-item">Real Estate</li>
							<li class="category-item">Tourism</li>
							<li class="category-item">Finance - Insurance</li>
							<li class="category-item">Education - Training</li>
							<li class="category-item">Healthcare</li>
							<li class="category-item">Restaurants</li>
							<li class="category-item">Hotels</li>
							<li class="category-item">E-commerce</li>
							<li class="category-item">Interior Design</li>
							<li class="category-item">Logistics</li>
							<li class="category-item">Industrial</li>
							<li class="category-item">Agriculture - Food</li>
							<li class="category-item">Spa - Beauty</li>
							<li class="category-item">Transportation Services</li>
							<li class="category-item">Automotive - Motorcycles</li>
							<li class="category-item">Cosmetics</li>
							<li class="category-item">Repair Services</li>
							<li class="category-item">Pet Care Services</li>
							<li class="category-item">Consulting Services</li>
						</ul>
					</div>

					<div class="homenest__website-design__section7--content">
						<div class="homenest__website-design__section7--content-left">
							<p class="sup">
								Programming Languages
							</p>
							<h2 class="section7--content-left__title">
								<span>
									Popular programming languages
								</span>
							</h2>
							<p class="section7--content-left__title-sup">
								Below are 8 of the most popular website design languages today.
							</p>
							<div class="list-wrap">
								<ul>
									<li>HTML</li>
									<li>CSS</li>
									<li>JavaScript</li>
									<li>NodeJS</li>
								</ul>

								<ul>
									<li>PHP</li>
									<li>Python</li>
									<li>Java</li>
									<li>Framework</li>
								</ul>
							</div>
						</div>
						<div class="homenest__website-design__section7--content-right">
							<div class="section7--content-right__wrap">
								<div class="content">
									<div class="section7--content-right__wrap-header">
										<img src=" /wp-content/uploads/2025/05/part1.webp" alt="">
									</div>
									<div class="section7--content-right__wrap-body">
										<img src=" /wp-content/uploads/2025/05/part2.svg" alt="">
										<img src=" /wp-content/uploads/2025/05/part3.webp" alt="">
									</div>

								</div>
								<img class="fadeInUp-Webdesign" src=" /wp-content/uploads/2025/05/2-1.webp" alt="">
								<img class="fadeInUp-Webdesign" src=" /wp-content/uploads/2025/05/3-1.webp" alt="">
							</div>
						</div>
					</div>

					<div class="homenest__website-design__section7--footer">
						<div class="homenest__website-design__section7--footer-wapper">
							<span href="#" class="open-tooltip">
							</span>
							<div class="homenest__website-design__section7--footer-main-content">
								<h2 class="section7__footer--title">
									Website Design Process
									<span>
										at HomeNest
									</span>
								</h2>

								<div class="content-wrap fadeInUp-Webdesign">
									<div class="content-wrap-item">
										<div class="img-wrap">
											<span class="item-num">1</span>
											<img src=" /wp-content/uploads/2025/05/check-1.svg" alt="">
										</div>
										<div class="item-cont">
											<p class="step">Step 1</p>
											<h6 class="item-title">Consultation</h6>
										</div>
									</div>
									<img src=" /wp-content/uploads/2025/05/step.svg" alt="">
									<div class="content-wrap-item">
										<div class="img-wrap">
											<span class="item-num">2</span>
											<img src=" /wp-content/uploads/2025/05/check-1.svg" alt="">
										</div>
										<div class="item-cont">
											<p class="step">Step 2</p>
											<h6 class="item-title">Design and Development</h6>
										</div>
									</div>
									<img src=" /wp-content/uploads/2025/05/step.svg" alt="">
									<div class="content-wrap-item">
										<div class="img-wrap">
											<span class="item-num">3</span>
											<img src=" /wp-content/uploads/2025/05/check-1.svg" alt="">
										</div>
										<div class="item-cont">
											<p class="step">Step 3</p>
											<h6 class="item-title">Product Handover</h6>
										</div>
									</div>
								</div>
							</div>

							<div class="section7__footer--tooltip">
								<h3 class="tooltip-title">Detailed Service <span>Process</span></h3>
								<p>
									At HomeNest, the website design process is clear: First, we take client requirements. Next, we design the interface and program the necessary features. Then, we perform thorough testing to ensure the website functions well. Finally, we hand over the website and provide support for issue resolution.
								</p>
								<a href="#" id="open-popup-video" class="btn-play-tooltip">
									Click to Learn More
								</a>
							</div>
						</div>
					</div>
				</div>

			</div>
		</div>
		<div class="homenest__website-design__section8">
			<div class="homenest__website-design__section8-wrapper">
				<div class="homenest__website-design__section8--logo">
					<img src=" /wp-content/uploads/2025/05/logo-1.webp" alt="">
					<img src=" /wp-content/uploads/2025/05/logo-2.webp" alt="">
				</div>

				<h2 class="homenest__website-design__section8--title">Website Design <span>Service</span> <br> Using Pre-designed Templates
				</h2>

				<div class="homenest__website-design__section8--content">
					<div class="box fadeInLeft-Webdesign">
						<img src=" /wp-content/uploads/2025/05/icon1.svg" alt="icon">
						<h6>
							Get <br>
							AI-powered <br>
							images instantly
						</h6>
					</div>
					<img class="fadeInUp-Webdesign" src=" /wp-content/uploads/2025/05/1-13.webp" alt="">
					<img class="fadeInLeft-Webdesign" src=" /wp-content/uploads/2025/05/2-2.webp" alt="">
					<img class="fadeInRight-Webdesign" src=" /wp-content/uploads/2025/05/3-2.webp" alt="">
					<img class="fadeInUp-Webdesign" src=" /wp-content/uploads/2025/05/4-1.webp" alt="">
					<div class="box fadeInUp-Webdesign">
						<img src=" /wp-content/uploads/2025/05/icon3.svg" alt="icon">
						<h6>
							Create <br>
							AI-written Texts <br>
							in few click
						</h6>
					</div>
					<img src=" /wp-content/uploads/2025/05/6.webp" alt="">
					<div class="box fadeInRight-Webdesign">
						<img src=" /wp-content/uploads/2025/05/icon2.svg" alt="icon">
						<h6>
							Install <br>
							AI chat-bot <br>
							on your website
						</h6>
					</div>
				</div>
				<div class="homenest__website-design__section8--btn-wrap fadeInUp-Webdesign">
					<a class="homenest__website-design__section8--footer-btn" href="#">Learn More</a>
				</div>
			</div>
		</div>

		<div class="homenest__website-design__section9">
			<div class="homenest__website-design__section9-wrapper">
				<h2 class="homenest__website-design__section9--title"><span>Website Templates You Can Explore</span></h2>
				<p class="homenest__website-design__section9--title-decs">
					Diverse colors highlighting various fields, up-to-date design, SEO-ready, feature-rich, at a reasonable cost.
				</p>
			</div>
		</div>

		<?php
		// Lấy danh sách dự án từ CPT "project"
		$args = array(
			'post_type' => 'project',
			'posts_per_page' => 10
		);

		$query = new WP_Query($args);
		$projects = [];

		if ($query->have_posts()) {
			while ($query->have_posts()) {
				$query->the_post();
				$projects[] = [
					'image' => get_the_post_thumbnail_url(get_the_ID(), 'full'),
					'link'  => get_permalink(get_the_ID()),
				];
			}
			wp_reset_postdata();
		}
		?>

		<section class="homenest__web-services__intigration">

			<div class="intigration__st-marquee">
				<div class="intigration-marquee">
					<div class="intigration-container">
						<?php foreach ($projects as $project): ?>
						<div class="intigration-item">
							<a href="<?php echo esc_url($project['link']); ?>">
								<img src="<?php echo esc_url($project['image']); ?>" alt="Dự án">
							</a>
						</div>
						<?php endforeach; ?>
					</div>
				</div>
			</div>

			<!-- Nếu muốn tạo 2 dòng chạy khác nhau -->
			<div class="intigration__nd-marquee">
				<div class="intigration-marquee">
					<div class="intigration-container">
						<?php foreach ($projects as $project): ?>
						<div class="intigration-item">
							<a href="<?php echo esc_url($project['link']); ?>">
								<img src="<?php echo esc_url($project['image']); ?>" alt="Dự án">
							</a>
						</div>
						<?php endforeach; ?>
					</div>
				</div>
			</div>

		</section>

		<div class="homenest__website-design__section11">
			<div class="homenest__website-design__section11-wrapper">
				<div class="homenest__website-design__section11--header">
					<div class="section11--header-left">
						<p class="sup">
							CRITERIA
						</p>
						<h2 class="section11--header-left__title">Website Design <span>at HomeNest</span>
						</h2>
						<div class="experience-descr">
							<p>We always prioritize quality in every product; each website designed by HomeNest must meet the following criteria before being handed over to the client.</p>
						</div>
					</div>
					<div class="section11--header-right">
						<ul class="section11--header-right--list">
							<li class="list-item">
								<img src=" /wp-content/uploads/2025/05/score.webp" alt="image">
								<p class="title">Pingdom Score</p>
							</li>
							<li class="list-item">
								<h6>Elementra</h6>
								<div class="progress">
									<div class="progress-done" style="width: 92%;height: 10px; opacity: 1;">
									</div>
								</div>
							</li>
							<li class="list-item">
								<h6>Other Themes</h6>
								<div class="progress">
									<div class="progress-done" style="width: 36%; opacity: 1;">
									</div>
								</div>
							</li>
						</ul>
					</div>
				</div>

				<div class="homenest__website-design__section11--body fadeInUp-Webdesign">
					<div class="homenest__website-design__section11--body-item1">
						<div class="homenest__website-design__section11--box">
							<span class="box-image">
								<img src=" /wp-content/uploads/2025/05/1-1-1.webp" alt="">
							</span>
							<h4 class="box-title">
								Excellent Responsiveness
							</h4>
						</div>
					</div>
					<div class="homenest__website-design__section11--body-item2">
						<div class="homenest__website-design__section11--box">
							<span class="box-image">
								<img src=" /wp-content/uploads/2025/05/2-3.webp" alt="">
							</span>
							<h4 class="box-title">
								User-Friendly Interface
							</h4>
						</div>
					</div>
					<div class="homenest__website-design__section11--body-item3">
						<div class="homenest__website-design__section11--box">
							<span class="box-image">
								<img src=" /wp-content/uploads/2025/05/3-3.webp" alt="">
							</span>
							<h4 class="box-title">
								Robust Security
							</h4>
						</div>
					</div>
					<div class="homenest__website-design__section11--body-item4">
						<div class="homenest__website-design__section11--box">
							<span class="box-image">
								<img src=" /wp-content/uploads/2025/05/4-2.webp" alt="">
							</span>
							<h4 class="box-title">
								Fast Loading Speed
							</h4>
						</div>
					</div>
				</div>
			</div>
		</div>


		<section class="homenest__professional_website_hn-pricing-section">
			<h2 class="homenest__professional_website_hn-pricing-title"> PROFESSIONAL <span class="homenest__professional_website_heading-highlight">WEBSITE DESIGN</span> PRICE LIST</h2>
			<div class="homenest__professional_website_pricing-section">
				<button class="homenest__professional_website_scroll-btn left" onclick="scrollCards(-1)">
					<svg xmlns="http://www.w3.org/2000/svg" width="31" height="24" viewBox="0 0 31 24" fill="none">
						<path d="M26 12H6" stroke="#0900FF" stroke-width="2" stroke-linecap="round"
							  stroke-linejoin="round"></path>
						<path d="M12.5938 19L5.8125 12L12.5938 5" stroke="#0900FF" stroke-width="2"
							  stroke-linecap="round" stroke-linejoin="round"></path>
					</svg>
				</button>

				<!-- Scrollable Wrapper -->
				<div class="homenest__professional_website_hn-pricing-cards-wrapper">
					<div class="homenest__professional_website_hn-pricing-cards">
					</div>
					<button class="homenest__professional_website_scroll-btn right" onclick="scrollCards(1)">
						<svg xmlns="http://www.w3.org/2000/svg" width="31" height="24" viewBox="0 0 31 24" fill="none">
							<path d="M5 12L25 12" stroke="#0900FF" stroke-width="2" stroke-linecap="round"
								  stroke-linejoin="round"></path>
							<path d="M18.4063 5L25.1875 12L18.4062 19" stroke="#0900FF" stroke-width="2"
								  stroke-linecap="round" stroke-linejoin="round"></path>
						</svg>
					</button>
				</div>
			</div>
		</section>


		<div class="homenest__website-design__section12">
			<div class="homenest__website-design__section12-wrapper">
				<div class="homenest__website-design__section12--icon fadeInUp-Webdesign">
					<img src=" /wp-content/uploads/2025/05/icon.webp" alt="">
				</div>
				<h2 class="homenest__website-design__section12--title">
					<span>Service Commitments</span>
				</h2>

				<div class="installation-gallery">
					<img src=" /wp-content/uploads/2025/05/1-14.webp" alt="">
					<img class="fadeInLeft-Webdesign" src=" /wp-content/uploads/2025/05/2-4.webp" alt="">
					<img class="fadeInRight-Webdesign" src=" /wp-content/uploads/2025/05/3-4.webp" alt="">
					<img class="fadeInUp-Webdesign" src=" /wp-content/uploads/2025/05/4-3.webp" alt="">
					<img src=" /wp-content/uploads/2025/05/5-1.webp" alt="">
					<img src=" /wp-content/uploads/2025/05/6-1.webp" alt="">
				</div>

				<div class="installation-info">

					<div class="info-item">
						<div class="img-wrap">
							<img src=" /wp-content/uploads/2025/05/icon1-1.svg" alt="">
						</div>
						<h3 class="info-title">
							Tailored to Needs
						</h3>
						<p class="info-descr">
							Websites are custom-designed, ensuring they accurately reflect the client's brand and business goals.
						</p>
					</div>

					<div class="info-item">
						<div class="img-wrap">
							<img src=" /wp-content/uploads/2025/05/icon2-1.svg" alt="">
						</div>
						<h3 class="info-title">
							On-Time Delivery
						</h3>
						<p class="info-descr">
							Committed to completion within the agreed timeline and cost, with no hidden fees.
						</p>
					</div>

					<div class="info-item">
						<div class="img-wrap">
							<img src=" /wp-content/uploads/2025/05/icon3-1.svg" alt="">
						</div>
						<h3 class="info-title">
							Lifetime Support
						</h3>
						<p class="info-descr">
							Our professional team provides repair, maintenance, and upgrade support after handover, ensuring clients can develop their business with peace of mind.
						</p>
					</div>
				</div>
			</div>
		</div>

		


		<div class="homenest__website-design__section14">
			<div class="marquee-wrapper">
				<div class="marquee-box-one">
					<div class="marquee-content-one">
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/1-16.webp" alt="icon">
							<p>Cookie Notice</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/2-5.webp" alt="icon">
							<p>GDPR Compliance</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/3-5.webp" alt="icon">
							<p>Figma Source Files</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/4-4.webp" alt="icon">
							<p>Detailed Docs</p>
						</div>

						<!-- content-dublicate -->
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/5-2.webp" alt="icon">
							<p>Multilingual Support</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/6-2.webp" alt="icon">
							<p>Fast & Lightweight</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/7.webp" alt="icon">
							<p>Fully Responsive</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/8.webp" alt="icon">
							<p>One-Click Updates</p>
						</div>

					</div>
					<div class="marquee-content-one">
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/1-16.webp" alt="icon">
							<p>Cookie Notice</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/2-5.webp" alt="icon">
							<p>GDPR Compliance</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/3-5.webp" alt="icon">
							<p>Figma Source Files</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/4-4.webp" alt="icon">
							<p>Detailed Docs</p>
						</div>

						<!-- content-dublicate -->
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/5-2.webp" alt="icon">
							<p>Multilingual Support</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/6-2.webp" alt="icon">
							<p>Fast & Lightweight</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/7.webp" alt="icon">
							<p>Fully Responsive</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/8.webp" alt="icon">
							<p>One-Click Updates</p>
						</div>

					</div> <!-- marquee-content -->
				</div> <!-- marquee-box-one -->

				<div class="marquee-box-two">
					<div class="marquee-content-two">
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/5-2.webp" alt="icon">
							<p>Lifetime Updates</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/5-2.webp" alt="icon">
							<p>Excellent Support</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/5-2.webp" alt="icon">
							<p>Flexible Theme Options</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/r4.webp" alt="icon">
							<p>AI Fully-Equipped</p>
						</div>

						<!-- content-dublicate -->
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/r5.webp" alt="icon">
							<p>Newsletter Integration & Popups</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/5-2.webp" alt="icon">
							<p>Subscription Forms & Dialogs</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/r6.webp" alt="icon">
							<p>Template Library</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/r8.webp" alt="icon">
							<p>Translation Ready</p>
						</div>

					</div>
					<div class="marquee-content-two">
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/r1.webp" alt="icon">
							<p>Lifetime Updates</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/r2.webp" alt="icon">
							<p>Excellent Support</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/r3.webp" alt="icon">
							<p>Flexible Theme Options</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/r4.webp" alt="icon">
							<p>AI Fully-Equipped</p>
						</div>

						<!-- content-dublicate -->
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/r5.webp" alt="icon">
							<p>Newsletter Integration & Popups</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/r6.webp" alt="icon">
							<p>Subscription Forms & Dialogs</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/r7.webp" alt="icon">
							<p>Template Library</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/r8.webp" alt="icon">
							<p>Translation Ready</p>
						</div>

					</div> <!-- marquee-content -->
				</div> <!-- marquee-box-two -->
			</div> <!-- marquee -->
		</div>

		<div class="homenest__website-design__section15">
			<div class="homenest__website-design__section15-wrapper">
				<div class="homenest__website-design__section15--head">
					<div class="item fadeInUp-Webdesign">
						<div class="content-wrap">
							<p class="sup">Why Choose Us</p>

							<h2 class="section_title">
								<span>
									HomeNest
									<br>
									Professional Website Design
								</span>
							</h2>
							<p class="desc">
								In the age of technology, a website is an indispensable competitive advantage for every business. HomeNest is proud to be a professional website design unit, committed to providing you with quality products, dedicated support, and sustainable development solutions.
							</p>

							<div class="homenest__website-design__section15--btn-wrap">
								<a class="homenest__website-design__section15--btn" href="#">Discover Now!</a>
							</div>

						</div>
					</div>
					<div class="item ">
						<div class="img-wrap">
							<img src=" /wp-content/uploads/2025/05/1-17.webp" alt="1">
							<img src=" /wp-content/uploads/2025/05/2-6.webp" alt="2">
							<img class="fadeInLeft-Webdesign" src=" /wp-content/uploads/2025/05/3-6.webp" alt="3" </div>
						</div>
					</div>
				</div>
			</div>

			<div class="homenest__website-design__section15--content">
				<div class="homenest__website-design__section15--content-left">
					<div class="item-1">
						<ul class="list">
							<li class="list-item">HTML</li>
							<li class="list-item">CSS</li>
							<li class="list-item">JavaScript</li>
							<li class="list-item">PHP</li>
							<li class="list-item">Python</li>
						</ul>
					</div>
					<div class="item-2">
						<div>
							<h4 class="item-title">Mobile Friendly</h4>
							<p class="item-descr">Guaranteed user-friendliness, helps boost user experience</p>
						</div>
						<img src=" /wp-content/uploads/2025/05/item2.webp" alt="image">
					</div>
					<div class="item-3">
						<h4 class="item-title">Visually Stunning Website</h4>
						<p class="item-descr">Attract potential customers right after the first visit</p>
						<img src=" /wp-content/uploads/2025/05/item3.webp" alt="image">
					</div>
					<div class="item-4">
						<h3 class="item-title">
							Dedicated 24/7 Support
							<br>
							<span>
								Never worry about errors.
							</span>
						</h3>
						<p class="item-descr">Clear and transparent warranty policy, quick resolution, ensuring you never lose customers. </p>
					</div>
				</div>
				<div class="homenest__website-design__section15--content-right">
					<div class="item-wrap">
						<p class="sup">
							CONTACT NOW
						</p>
						<h2 class="section_title">
							<span>
								Contact Us for Website Design Today
							</span>
						</h2>
					</div>

					<div class="item-wrap">
						<ul class="list fadeInUp-Webdesign">
							<li class="list-item">
								<h3 class="item-title">
									SEO-Ready Website
								</h3>
								<p class="item-descr">Easy optimization, quickly achieve high rankings!</p>
							</li>
							<li class="list-item">
								<h3 class="item-title">
									Unique Design
								</h3>
								<p class="item-descr">Exclusive design, strongly reflecting the brand identity</p>
							</li>
							<li class="list-item">
								<h3 class="item-title">
									Transparent Policy
								</h3>
								<p class="item-descr">Guaranteed transparent policy, reasonable pricing, clear warranty</p>
							</li>
						</ul>
						<div class="homenest__website-design__section15--btn-wrap-footer fadeInLeft-Webdesign">
							<a class="homenest__website-design__section15--footer-btn" href="#">Contact Now!</a>
						</div>
					</div>
				</div>
			</div>



			<div class="homenest__web-design__popular-question">
				<div class="container__about-us">
					<div class="header">
						<div class="popular-questions">
							<p style="color: #111 !important; font-weight: 500;">FAQ</p>
						</div>
						<h2 class="homenest__website-design__section12--title">
							<span>Popular Questions</span>
						</h2>
					</div>

					<div class="divider"></div>

					<div class="faq-item">
						<div class="question-header">
							<div class="question-number">01</div>
							<div class="question-label">Question 1</div>
						</div>
						<div class="question">
							<p>What benefits does website design at HomeNest bring to my business?</p>
							<div class="button-container">
								<button class="toggle-button minus" aria-label="Thu gọn nội dung">−</button>
							</div>
						</div>
						<div class="answer">
							HomeNest helps businesses build a professional online presence, reach new customers, increase revenue, and enhance brand reputation.
						</div>
					</div>

					<div class="divider"></div>

					<div class="faq-item">
						<div class="question-header">
							<div class="question-number">02</div>
							<div class="question-label">Question 2</div>
						</div>
						<div class="question">
							<p>What is the cost of website design at HomeNest, and are there any additional fees?</p>
							<div class="button-container">
								<button class="toggle-button" aria-label="Hiển thị câu trả lời">+</button>
							</div>
						</div>
						<div class="answer hidden">
							HomeNest offers various service packages to suit every budget, with a commitment to transparent pricing and no hidden fees.
						</div>
					</div>

					<div class="divider"></div>

					<div class="faq-item">
						<div class="question-header">
							<div class="question-number">03</div>
							<div class="question-label">Question 3</div>
						</div>
						<div class="question">
							<p>How long does it take to complete a website at HomeNest?</p>
							<div class="button-container">
								<button class="toggle-button" aria-label="Hiển thị câu trả lời">+</button>
							</div>
						</div>
						<div class="answer hidden">
							The completion time depends on the specific requirements of each project; HomeNest is always committed to meeting deadlines and delivering on time.
						</div>
					</div>

					<div class="divider"></div>

					<div class="faq-item">
						<div class="question-header">
							<div class="question-number">04</div>
							<div class="question-label">Question 4</div>
						</div>
						<div class="question">
							<p>Can I update content myself on a website designed by HomeNest?</p>
							<div class="button-container">
								<button class="toggle-button" aria-label="Hiển thị câu trả lời">+</button>
							</div>
						</div>
						<div class="answer hidden">
							Yes, HomeNest designs an easy-to-use administration system, allowing clients to easily update content, products, and articles.
						</div>
					</div>

					<div class="divider"></div>

					<div class="faq-item">
						<div class="question-header">
							<div class="question-number">05</div>
							<div class="question-label">Question 5</div>
						</div>
						<div class="question">
							<p>How does HomeNest provide support, warranty, and website upgrades?</p>
							<div class="button-container">
								<button class="toggle-button" aria-label="Hiển thị câu trả lời">+</button>
							</div>
						</div>
						<div class="answer hidden">
							HomeNest provides 24/7 technical support, long-term warranty, and is ready to upgrade and expand features according to the business's development needs.
						</div>
					</div>

					<div class="divider"></div>
				</div>
			</div>
		</div>
	</div>
		<script src="https://cdn.jsdelivr.net/npm/curtainsjs@8.0.2/dist/curtains.min.js"></script>
<!-- 		<script src="./main.js"></script> -->
<script>
        // ==============================
        // Dữ liệu bảng giá thiết kế website (Internal)
        // ==============================
        const pricingPlans = [
            {
                tag: "Basic",
				title: "The Basic Package",
                color: "#2db5b1",
                description: "at HomeNest provides a professional website with a simple design.",
                features: [
                    "Diverse pre-made interface",
                    "Full basic functionality",
                    "SEO-ready design",
                    "Google SEO support tools",
                    "Website administration guide",
                    "Live chat, fanpage, Google Map support, etc.",
                    "Free SSL security for the first year",
                ],
                hiddenFeatures: [
                    "Source code and hosting domain handover upon completion",
                    "Completion time within 5 working days",
                ],
                price: "8.000.000",
                typeClass: "basic",
            },
            {
                tag: "Golden",
				title: "The Golden Package",
                color: "#fd7401",
                description: "at HomeNest provides a premium website with a sophisticated design.",
                features: [
                    "Interface based on template or custom request",
                    "Advanced functionality",
                    "Bilingual website",
                    "SEO-ready design",
                    "Google SEO support tools",
                    "Figma design: 1",
                    "UI/UX compliant interface",
                ],
                hiddenFeatures: [
                    "	UI/UX compliant interface",
                    "	Source code and hosting domain handover upon completion",
                    "	Live chat, fanpage, Google Map support, etc.",
                    "	Free SSL security for the first year",
                    "	Free .com or .net domain for the first year",
                    "	Completion time within 15 – 20 days",
                ],
                price: "16.000.000",
                typeClass: "golden",
            },
            {
                tag: "Diamond",
				title: "The Diamond Package",
                color: "#020c6a",
                description: "at HomeNest provides an ultimate website with a flawless design.",
                features: [
                    "Exclusive interface based on brand identity",
                    "On-demand functionality",
                    "Multilingual website",
                    "SEO-ready design",
                    "Google SEO support tools",
                    "Figma design: 2",
                    "UI/UX compliant interface",
                ],
                hiddenFeatures: [
                    "SEO optimization",
					"SEO content writing guide",
					"SEO-compliant content: 5 articles",
					"Guide on internal and external linking",
					"Website administration guide",
					"Source code and hosting domain handover upon completion",
					"Free hosting package for the first year",
					"Live Chat, Call Now Fanpage button, interactive Google Map",
					"Free SSL security for the first year",
					"Free .com or .net domain for the first year",
                ],
                price: "40.000.000",
                typeClass: "diamond",
            },
            {
                tag: "Platinum",
				title: "The Platinum Package ",
                color: "#972295",
                description: "at HomeNest provides an optimized website with a luxurious design.",
                features: [
                    "Exclusive interface based on brand identity",
					"On-demand functionality",
					"Multilingual website",
					"SEO-ready design",
					"Google SEO support tools",
					"Figma design: 3",
					"UI/UX compliant interface",
                ],
                hiddenFeatures: [
                    "SEO optimization",
					"SEO content writing guide",
					"SEO-compliant content: 10 articles",
					"Guide on internal and external linking",
					"Website administration guide",
					"Source code and hosting domain handover upon completion",
					"Free hosting package for the first year",
					"Live Chat, Call Now Fanpage button, interactive Google Map",
					"Free SSL security for the first year",
					"Free .com or .net domain for the first year",
					"Big data processing",
					"Facebook Ads or Google Ads advertising guide",
					"E-commerce website and system",
                ],
                price: "Flexible",
                typeClass: "platinum",
            },
        ];
	const textViewMore = 'View More';
	const textCollapse = 'Collapse';
	const textConsult = 'Consult Now';
	const textQuote = '*Contact us now for free consultation';
    </script>
		</body>
	<?php get_footer(); ?>