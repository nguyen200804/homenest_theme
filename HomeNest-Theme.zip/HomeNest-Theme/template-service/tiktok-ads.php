<?php


/* Font declarations */

/* Apply font to all elements */
get_header(); ?>
<style>
	* {
		font-family: 'HomeNest', sans-serif;
	}

	.text-gradient {
		background-image: linear-gradient(to right, #020C6A 0%, #1A85F8 calc(clamp(0%, var(--x), 56%)), #66E5FB calc(clamp(0%, var(--x), 100%)), #a1a1a178 var(--x));
		-webkit-text-fill-color: transparent;
		-webkit-background-clip: text;
		background-size: 100%;
	}

	.tiktok-ads-hero {
		padding: 80px 20px;
		display: flex;
		align-items: center;
		width: 88%;
		gap: 200px;
	}

	.tiktok-ads-content {
		flex: 1;
		width: 77%;
	}

	.tiktok-ads-title {
		font-family: 'HomeNest', sans-serif;
		font-weight: 900;
		letter-spacing: -0.02em;
		font-size: 48px;
		margin-bottom: 10px;
		line-height: 1.2;
	}

	.tiktok-ads-subtitle {
		font-size: 53px;
		font-weight: 700;
		background: linear-gradient(to right, #020C6A 0%, #1A85F8 56.7%, #66E5FB 100%);
		-webkit-background-clip: text;
		-webkit-text-fill-color: transparent;
		background-clip: text;
		color: transparent;
		margin-bottom: 20px;
	}

	.tiktok-ads-description {
		font-family: 'HomeNest', sans-serif;
		font-weight: 400;
		font-size: 18px;
		color: black;
		margin-bottom: 40px;
        line-height: 32px;
        padding-right: 180px;
	}

	.tiktok-ads-features {
		display: flex;
		flex-direction: column;
		gap: 15px;
	}

	.feature-item {
		display: flex;
		align-items: center;
		gap: 10px;
	}

	.feature-icon {
		width: 24px;
		height: 24px;
		display: flex;
		align-items: center;
		justify-content: center;
		color: #00A3FF;
	}

	.tiktok-ads-subtitle h2 {}

	.feature-text {
		font-family: 'HomeNest', sans-serif;
		font-weight: 500;
		font-size: 16px;
		color: #333;
	}

	.tiktok-ads-image {
		flex: 1;
		max-width: 500px;
		position: relative;
	}

	.tiktok-ads-image img {
		width: 600px;
		height: auto;
		position: relative;
		right: 80px;
	}

	.register-button {
		font-family: 'HomeNest', sans-serif;
		font-weight: 700;
		letter-spacing: 0.02em;
		display: inline-block;
		background: linear-gradient(92.16deg, #2F3FCF 0%, #1A85F8 56.7%, #66E5FB 100%);
		color: white;
		padding: 15px 30px;
		border-radius: 30px;
		text-decoration: none;
		font-weight: 600;
		margin-top: 30px;
		transition: all 0.3s ease;
	}

	.register-button:hover {
		transform: translateY(-3px);
		box-shadow: 0 10px 20px rgba(0, 163, 255, 0.2);
	}

	.floating-contact {
		position: fixed;
		right: 20px;
		top: 50%;
		transform: translateY(-50%);
		display: flex;
		flex-direction: column;
		gap: 10px;
	}

	.contact-icon {
		width: 50px;
		height: 50px;
		background: white;
		border-radius: 50%;
		display: flex;
		align-items: center;
		justify-content: center;
		box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
		transition: all 0.3s ease;
	}

	.contact-icon:hover {
		transform: translateY(-3px);
		box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
	}

	.contact-icon img {
		width: 30px;
		height: 30px;
	}

	@keyframes float {
		0% {
			transform: translateY(0);
		}

		50% {
			transform: translateY(-20px);
		}

		100% {
			transform: translateY(0);
		}
	}

	@media (max-width: 768px) {

		.tiktok-ads-title {
			font-size: 32px;
		}

		.tiktok-ads-subtitle {
			font-size: 24px;
		}

		.tiktok-ads-image img {
			width: 100%;
			right: 0;
		}
	}

	/* Font loading detection */
	.fonts-loaded {
		opacity: 1;
		transition: opacity 0.3s ease;
	}

	.fonts-failed {
		font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
	}

	.tiktok-advantages {
		padding: 80px 131px;
		background: #f8f9fa;
		position: relative;
		overflow: hidden;
		display: flex;
		gap: 80px;
		max-width: 100vw;
	}

	.tiktok-advantages img {
        position: absolute;
    right: 0;
    left: 71%;
    bottom: -29%;
    padding: 20px;
	}

	.tiktok-advantages-title {
		font-size: 50px;
		font-weight: 900;
		text-align: left;
		margin-bottom: 60px;
		line-height: 1.4;
		width: 90%;
		-webkit-background-clip: text;
		-webkit-text-fill-color: transparent;
	}



	.advantages-grid {
		display: grid;
		grid-template-columns: repeat(2, 1fr);
		gap: 40px;
		max-width: 61%;
		margin: 0 auto;
	}

	.advantage-item {
		gap: 20px;
		align-items: flex-start;
		margin: 0 auto;
		border-radius: 13px;
		margin-bottom: 20px;
		box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
		padding: 20px;
	}

	.advantage-icon {
		width: 50px;
		height: 50px;
		flex-shrink: 0;
	}

	.advantage-icon img {
		width: 100%;
		height: 100%;
		object-fit: contain;
	}

	.advantage-content h3 {
		font-size: 22px;
		font-weight: 700;
		margin-bottom: 15px;
		background: black;
		-webkit-background-clip: text;
		-webkit-text-fill-color: transparent;
	}

	.advantage-content p {
		font-size: 19px;
		line-height: 1.6;
		color: black;
	}

	@media (max-width: 768px) {
		.advantages-grid {
			grid-template-columns: 1fr;
			gap: 30px;
		}

		.faq-img1 {
			display: none;
		}

		.faq-img {
			display: flex;
			margin: 0 auto;
			width: 100% !important;
			flex-direction: unset !important;
		}
	}

	/* Service Categories Section (New Addition) */
	.service-categories-title {
		font-size: 45px;
		font-weight: 700;
		color: #1a1a1a;
		margin-bottom: 30px;
		text-transform: uppercase;
		text-align: center;
		text-align: left;
		width: 89%;
		margin: 0 auto;
	}

	.service-categories-subtitle {
		font-size: 18px;
		color: #666;
		margin-bottom: 40px;
		text-align: center;
	}

	.service-categories {
		display: flex;
		justify-content: space-around;
		flex-wrap: wrap;
		gap: 20px;
		width: 89%;
		margin: 0 auto;
		margin-left: 55px;
	}

	.service-category {
		flex: 1;
		padding: 42px;
		min-width: 300px;
		transition: transform 0.3s ease, box-shadow 0.3s ease;
		padding-right: 10px;
		height: 300px;
        padding-right: 50px;
	}

	.service-category-border {
		border-right: 1px solid #e3dcdc;
		border-left: 1px solid #e3dcdc;
	}

	.service-category h3 {
		font-size: 21px;
		color: #1a1a1a;
		margin: 15px 0 10px;
		font-weight: 600;
	}

	.service-category p {
		font-size: 18px;
		color: black;
		line-height: 1.8;
		margin: 0;
	}

	.service-icon {
		font-size: 40px;
		color: #00aaff;
		margin-bottom: 15px;
	}

	/* Why Choose Section */
	.why-choose {
		background: white;
		position: relative;
		overflow: hidden;
		max-width: 100%;
        margin-bottom: 40px;
	}

	.why-choose-header {
		max-width: 100%;
		margin: 0 auto;
		display: flex;
		justify-content: center;
		align-items: center;
	}

	.why-choose-title {
		font-size: 48px;
		font-weight: 900;
		line-height: 1.2;
		margin-left: -260px;
		/* width: 58%; */
		width: 100%;
		padding-left: 20%;
	}

	.why-choose-title span {
		background: linear-gradient(to right, #020C6A 0%, #1A85F8 56.7%, #66E5FB 100%);
		-webkit-background-clip: text;
		-webkit-text-fill-color: transparent;
	}

	.floating-image {
		width: 230px;
		height: auto;
		position: relative;
		animation: float 3s ease-in-out infinite;
		left: 250px;
	}

	.why-choose-grid {
		display: flex;
		grid-template-columns: repeat(2, 1fr);
		justify-content: center;
		align-items: stretch;
		gap: 40px;
		max-width: 100%;
		margin-bottom: 50px;

	}

	.why-choose-item {
		background: white;
		border-radius: 20px;
		display: flex;
		justify-content: center;
		align-items: stretch;
		width: 20%;
	}

	.item-header {
		align-items: flex-start;
		gap: 20px;
		margin-bottom: 20px;
	}

	.item-icon {
        width: 96%;
        height: 60%;
		border-radius: 18px;
	}

	.item-title {
		font-size: 21px;
		font-weight: 700;
		margin-top: 10px;
		margin-bottom: 10px;
		background: black;
		-webkit-background-clip: text;
		-webkit-text-fill-color: transparent;
	}

	.item-text {
		font-size: 18px;
		line-height: 1.6;
		font-weight: 400;
		color: black;
	}

	@media (max-width: 768px) {
		.why-choose-header {
			flex-direction: column;
			align-items: center;
			text-align: center;
			gap: 30px;
			a
		}

                .item-icon {
            width: 365px !important;
            height: 67%;
            border-radius: 18px;
        }

		.process-steps {
			display: flex;
			flex-direction: column;
			gap: 40px;
			width: 100% !important;
		}

		.floating-image {
			width: 60%;
			height: auto;
			animation: float 3s ease-in-out infinite;
			display: none;
		}

		.why-choose-grid {
			flex-direction: column;
			margin-left: 0;
			justify-content: center;
			display: flex;
			align-items: center;
			gap: 0;
			margin-bottom: 0;
		}
	}

	/* Pricing Section */
	.pricing-section {
		padding: 80px 0;
		background: #fff;
	}

	.pricing-container {
		max-width: 1400px;
		margin: 0 auto;
		padding: 0 20px;
	}

	.pricing-header {
		display: flex;
		flex-direction: column;
		margin-bottom: 50px;
		margin-left: 40px;
	}

	.pricing-title-wrapper {
		display: flex;
		flex-direction: column;
		gap: 5px;
	}

	.pricing-title {
		font-size: 45px;
		font-weight: 900;
		color: #1A1A1A;
		margin: 0;
	}

	.pricing-subtitle {
		font-size: 45px;
		font-weight: 900;
		background: linear-gradient(to right, #020C6A, #1A85F8, #66E5FB);
		/* Gradient from image */
		-webkit-background-clip: text;
		-webkit-text-fill-color: transparent;
		background-clip: text;
		color: transparent;
		/* For Firefox */
		margin: 0;
	}

	.pricing-grid {
		display: grid;
		grid-template-columns: repeat(4, 1fr);
		/* 4 columns for desktop */
		gap: 24px;
		padding: 0 40px;
	}

	.pricing-item {
		background: #FFFFFF;
		border-radius: 16px;
		overflow: hidden;
		box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
		transition: transform 0.3s ease;
	}

	.pricing-item:hover {
		transform: translateY(-10px);
	}

	.pricing-item-header {
		padding: 15px;
		text-align: center;
		position: relative;
		height: 150px;
		/* Adjust height as needed */
		display: flex;
		justify-content: center;
		align-items: center;
		margin-top: 36px;
		border-radius: 14px;
		background-size: cover;
		background-position: center;
	}

	.pricing-name {
		font-size: 21px;
		font-weight: 700;
		color: #FFFFFF;
		margin: 0;
	}


	.pricing-content {
		padding: 32px;
	}

	.pricing-features {
		margin-bottom: 32px;
	}

	.pricing-feature {
		display: flex;
		align-items: center;
		gap: 12px;
		margin-bottom: 16px;
		color: #666666;
		font-size: 15px;
	}

	.pricing-feature i {
		color: #1A85F8;
		font-size: 18px;
	}

	.pricing-price {
		font-size: 24px;
		font-weight: 700;
		color: #1A85F8;
		margin: 20px 0;
		text-align: center;
	}

	.pricing-item.basic .pricing-price {
		color: #1A85F8;
	}

	.pricing-item.golden .pricing-price {
		color: #FFA500;
	}

	.pricing-item.diamond .pricing-price {
		color: #1E90FF;
	}

	.pricing-item.platinum .pricing-price {
		color: #9932CC;
	}

	.pricing-button {
		display: inline-block;
		width: 100%;
		padding: 16px;
		text-align: center;
		background: linear-gradient(to right, #020C6A, #1A85F8, #66E5FB);
		/* Button gradient */
		color: #FFFFFF;
		border-radius: 30px;
		text-decoration: none;
		font-weight: 600;
		transition: all 0.3s ease;
	}

	.pricing-button:hover {
		transform: translateY(-3px);
		box-shadow: 0 10px 20px rgba(26, 133, 248, 0.2);
	}

	@media (max-width: 1200px) {
		.pricing-grid {
			grid-template-columns: repeat(2, 1fr);
			gap: 20px;
			padding: 0 20px;
		}
	}

	@media (max-width: 768px) {
		.pricing-grid {
			grid-template-columns: 1fr;
			padding: 0 20px;
		}

		.pricing-title,
		.pricing-subtitle {
			font-size: 32px;
		}

		.pricing-header {
			max-width: 100%;
			width: 100%;
			margin: 0 auto;
		}

		.pricing-title-wrapper {
			align-items: center;
		}

		.pricing-price {
			font-size: 20px;
		}

		.pricing-feature {
			font-size: 14px;
		}
	}

	/* Styles for the TikTok Ads Pricing Section */
	.tiktok-ads-pricing-section {
		padding: 80px 80px;
		text-align: center;
		max-width: 100%;
	}

	.tiktok-ads-pricing-section .pricing-title {
		font-size: 47px;
		font-weight: 900;
		margin-bottom: 40px;
		background: linear-gradient(to left, #020C6A 0%, #1A85F8 56.7%, #66E5FB 100%);
		-webkit-background-clip: text;
		-webkit-text-fill-color: transparent;
		background-clip: text;
		/* margin-right: 753px; */
		text-fill-color: transparent;
	}

	.tiktok-ads-pricing-section .pricing-cards-container {
		display: flex;
		-webkit-overflow-scrolling: touch;
		-ms-overflow-style: none;
		justify-content: center;
		align-items: stretch;
	}

	/* Ẩn thanh scroll trên Chrome/Safari */
	.tiktok-ads-pricing-section .pricing-cards-container::-webkit-scrollbar {
		display: none;
	}

	/* Thêm nút điều hướng */
	.pricing-nav {
		display: flex;
		justify-content: space-between;
		position: absolute;
		width: 100%;
		top: 50%;
		transform: translateY(-50%);
		padding: 0 20px;
		pointer-events: none;
	}

	.pricing-nav button {
		width: 40px;
		height: 40px;
		border-radius: 50%;
		background: white;
		border: none;
		box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
		cursor: pointer;
		pointer-events: auto;
		transition: all 0.3s ease;
	}

	.pricing-nav button:hover {
		background: #f8f9fa;
		transform: scale(1.1);
	}

	.tiktok-ads-pricing-section .pricing-card {
		background-color: #F0F2F4;
		border-radius: 15px;
		padding: 22px;
		text-align: left;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		width: 20%;
		border: 1px solid #DDDDDD;
	}



	.tiktok-ads-pricing-section .package-title {
		font-size: 20px;
		font-weight: 700;
		margin-bottom: 15px;
		padding: 16px 15px;
		border-radius: 8px;
		color: white;
		text-align: center;
	}

	.tiktok-ads-pricing-section .basic .package-title {
		background-image: url(https://homenest.com.vn/wp-content/uploads/2025/01/image-5.png);
		background-size: cover;
		background-position: center;
		width: 50%;
		margin-left: -37px;
	}

	.tiktok-ads-pricing-section .golden .package-title {
		background-image: url(https://homenest.com.vn/wp-content/uploads/2025/01/image-1-1.png);
		background-size: cover;
		background-position: center;
		width: 60%;
		margin-left: -37px;
	}

	.tiktok-ads-pricing-section .diamond .package-title {
		background-image: url(https://homenest.com.vn/wp-content/uploads/2025/01/image-2-1.png);
		background-size: cover;
		background-position: center;
		width: 60%;
		margin-left: -37px;
	}

	.tiktok-ads-pricing-section .platinum .package-title {
		background-image: url(https://homenest.com.vn/wp-content/uploads/2025/01/image-3-1.png);
		background-size: cover;
		background-position: center;
		width: 70%;
		margin-left: -37px;
	}

	.tiktok-ads-pricing-section .package-description {
		font-size: 20px;
		color: #555;
		margin-bottom: 20px;
		min-height: 60px;
		position: relative;
		padding-bottom: 20px;
		/* Thêm padding bottom */
	}

	.tiktok-ads-pricing-section .package-description::after {
		content: '';
		position: absolute;
		bottom: 0;
		left: 0;
		width: 100%;
		height: 5px;
		background-color: rgba(255, 255, 255, 0.6);
		opacity: 0.6;
		/* Điều chỉnh độ trong suốt */
	}

	.tiktok-ads-pricing-section .package-features {
		list-style: none;
		padding: 0;
		margin-bottom: 20px;
		position: relative;
		/* Thêm position relative */
	}

	.tiktok-ads-pricing-section .package-features::after {
		content: '';
		position: absolute;
		bottom: -10px;
		/* Điều chỉnh khoảng cách với phần giá */
		left: 0;
		width: 100%;
		height: 1px;
		background-color: #ffffff;
		opacity: 0.6;
		/* Điều chỉnh độ trong suốt */
	}

	.tiktok-ads-pricing-section .package-features li {
		margin-bottom: 10px;
		color: #333;
		font-size: 20px;
		display: flex;
		align-items: center;
	}

	.tiktok-ads-pricing-section .package-features li i {
		color: #1A85F8;
		margin-right: 8px;
		font-size: 14px;
	}

	.tiktok-ads-pricing-section .package-price {
		font-size: 35px;
		font-weight: 700;
		margin-bottom: 20px;
	}

	.tiktok-ads-pricing-section .basic .package-price {
		color: #1A85F8;
	}

	.tiktok-ads-pricing-section .golden .package-price {
		color: #FFA500;
	}

	.tiktok-ads-pricing-section .diamond .package-price {
		color: #1E90FF;
	}

	.tiktok-ads-pricing-section .platinum .package-price {
		color: #9932CC;
	}

	.tiktok-ads-pricing-section .consultation-button {
		display: block;
		width: 50%;
		padding: 18px 15px;
		background: linear-gradient(to right, #020C6A, #1A85F8);
		color: white;
		text-align: center;
		border-radius: 14px;
		text-decoration: none;
		font-size: 16px;
		border: 1px solid black;
		font-weight: 600;
	}

	@media (max-width: 1200px) {
		.tiktok-ads-pricing-section .pricing-cards-container {
			gap: 20px;
		}
	}

	@media (max-width: 992px) {
		.tiktok-ads-pricing-section .pricing-cards-container {
			flex-direction: column;
			align-items: center;
		}

		.tiktok-ads-pricing-section .pricing-card {
			width: 80%;
			max-width: 400px;
		}
	}

	@media (max-width: 576px) {
		.tiktok-ads-pricing-section .pricing-title {
			font-size: 28px;
		}

		.tiktok-ads-pricing-section .pricing-card {
			width: 130%;
		}

		.service-categories-section {
			position: relative;
			overflow: hidden;
			max-width: 100%;
			max-height: 100%;
		}

	}


	.step-image {
		width: 30%;
	}

	.back-img {
		position: absolute;
		bottom: 0;
		/* dùng top: 0 nếu muốn ở góc trên */
		left: 0;
		z-index: -1;
		/* đẩy ảnh ra sau nội dung */
		opacity: 0.1;
		/* tuỳ chỉnh độ mờ để không làm rối nền */
	}

	.back-img img {
		max-width: 300px;
		/* tuỳ chỉnh kích thước ảnh */
		height: auto;
	}

	.service-categories-title1 {
		background: linear-gradient(to right, #020C6A, #1A85F8, #66E5FB);
		-webkit-background-clip: text;
		-webkit-text-fill-color: transparent;
		background-clip: text;
		color: transparent;
		font-weight: 1000;
		position: relative;
		top: 0px;
		font-size: 52px;
		margin: 0 auto;
		width: 89%;
		margin-bottom: 50px;
		/* (tùy chọn) làm đậm hơn nếu muốn */
	}

	@media (max-width: 576px) {
		.service-category {
			max-width: 100%;
			margin: 0px 33px;
			padding: 0;
			border:0;
		}


		.faq-container {
			max-width: 100%;
			background-image: url(https://homenest.com.vn/wp-content/uploads/2024/11/Frame-1.png);
			background-position: left;
			background-repeat: no-repeat;
			background-size: contain;
		}
	}

	/* Quy Trình Section */
	.quy-trinh-section {
		padding: 80px 0;
		background: #fff;
		display: flex;
		gap: 45px;
	}

	.section-container {
		max-width: 1400px;
		margin: 0 auto;
		padding: 0 20px;
		width: 60%;
	}

	.section-header {
		text-align: left;
		margin-bottom: 60px;
	}

	.section-logo {
		font-size: 140px;
		font-weight: 900;
		color: white;
		-webkit-text-stroke: 1px #1A85F8;
		margin-bottom: 0px;
		margin-top: 0px;
	}

	.section-title {
		font-size: 35px;
		font-weight: 700;
		color: #333;
		margin-bottom: 10px;
	}

	.section-subtitle {
		font-size: 35px;
		font-weight: 700;
		background: linear-gradient(to right, #020C6A, #1A85F8, #66E5FB);
		-webkit-background-clip: text;
		-webkit-text-fill-color: transparent;
		margin: 0;
	}

	.process-step {
		display: flex;
		gap: 30px;
		align-items: flex-start;
	}

	div#page {
		overflow: hidden;
	}

	.step-content h4 {
		font-size: 24px;
        font-weight: 700;
        margin-bottom: 15px;
        background: linear-gradient(to right, #020C6A, #1A85F8, #66E5FB);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
	}

	.step-content p {
		font-size: 20px;
		line-height: 1.6;
		color: #666;
	}

	@media (max-width: 768px) {
		.section-logo {
			font-size: 35px;
		}

		.section-title,
		.section-subtitle {
			font-size: 28px;
		}
		.homenest__professional_website_question-header {
			display: grid;
			grid-template-columns: 30px 1.5fr 40px !important;
			align-items: center;
			padding: 10px 0;
			cursor: pointer;
			gap: 10px;
			margin-bottom: -35px;
		}
		.homenest__professional_website_answer {
			padding: 0px 30px !important;
		}
		div#homenest__professional_website_faq-container {
			width: 100%;
			/* margin: 0 auto; */
		}

		.step-number {
			font-size: 50px;
		}

		.step-content h4 {
			font-size: 20px;
		}
	}
</style>
<script>
	// Add font loading detection
	document.addEventListener('DOMContentLoaded', function () {
		if ('fonts' in document) {
			Promise.all([
				document.fonts.load('300 1em HomeNest'),
				document.fonts.load('400 1em HomeNest'),
				document.fonts.load('500 1em HomeNest'),
				document.fonts.load('700 1em HomeNest'),
				document.fonts.load('900 1em HomeNest')
			]).then(function () {
				document.documentElement.classList.add('fonts-loaded');
			}).catch(function () {
				document.documentElement.classList.add('fonts-failed');
			});
		}
	});

	// Add carousel functionality
	const pricingGrid = document.querySelector('.pricing-grid');
	const prevButton = document.querySelector('.arrow.prev');
	const nextButton = document.querySelector('.arrow.next');

	prevButton.addEventListener('click', () => {
		pricingGrid.scrollBy({
			left: -330,
			behavior: 'smooth'
		});
	});

	nextButton.addEventListener('click', () => {
		pricingGrid.scrollBy({
			left: 330,
			behavior: 'smooth'
		});
	});

	// Thêm vào phần script
	document.addEventListener('DOMContentLoaded', function () {
		const container = document.querySelector('.pricing-cards-container');
		const prevBtn = document.querySelector('.prev-btn');
		const nextBtn = document.querySelector('.next-btn');

		if (prevBtn && nextBtn) {
			prevBtn.addEventListener('click', () => {
				container.scrollBy({
					left: -300,
					behavior: 'smooth'
				});
			});

			nextBtn.addEventListener('click', () => {
				container.scrollBy({
					left: 300,
					behavior: 'smooth'
				});
			});
		}
	});

	// JavaScript để xử lý sự kiện click
	document.addEventListener('DOMContentLoaded', function () {
		const faqItems = document.querySelectorAll('.faq-item');

		faqItems.forEach(item => {
			const header = item.querySelector('.faq-header');

			header.addEventListener('click', () => {
				// Đóng tất cả các item khác
				faqItems.forEach(otherItem => {
					if (otherItem !== item) {
						otherItem.classList.remove('active');
					}
				});

				// Toggle active cho item được click
				item.classList.toggle('active');
			});
		});
	});
</script>
<style>
	.pricing-header {
		position: relative;
		text-align: center;
		margin-bottom: 40px;
	}

	.nav-button {
		position: absolute;
		top: 50%;
		transform: translateY(-50%);
		width: 40px;
		height: 40px;
		border: none;
		border-radius: 50%;
		background: #fff;
		color: #1a85f8;
		font-size: 20px;
		cursor: pointer;
		box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
		transition: all 0.3s ease;
		z-index: 2;
	}

	.nav-button:hover {
		background: #1a85f8;
		color: #fff;
	}

	.prev {
		left: -93px;
		top: 500px;
	}

	.next {
		right: -51px;
		top: 500px;
	}

	.pricing-carousel {
		display: flex;
		justify-content: center;
		align-items: center;
		max-width: 100%;
	}

	.pricing-cards-container {
		display: flex;
		transition: transform 0.3s ease;
		gap: 20px;
	}

	.pricing-card {
		flex: 0 0 300px;

	}

	@media (max-width: 768px) {
		.pricing-card {
			flex: 0 0 280px;
		}

		.nav-button {
			width: 30px;
			height: 30px;
			font-size: 16px;
		}
	}

	.card {
		position: relative;
		transition: transform 0.5s, opacity 0.5s;
	}

	@keyframes cardMove {
		0% {
			transform: translateX(0);
			opacity: 1;
		}

		50% {
			transform: translateX(-100%);
			opacity: 0;
		}

		51% {
			transform: translateX(100%);
		}

		100% {
			transform: translateX(0);
			opacity: 1;
		}
	}
</style>
<div class="homenest-tiktokads-container">
	<div class="tiktok-ads-hero">
		<div class="tiktok-ads-content">
			<h1 class="tiktok-ads-title">Dịch vụ quảng cáo</h1>
			<h2 class="tiktok-ads-subtitle">Tiktok ads của homenest</h2>

			<p class="tiktok-ads-description">
				HomeNest cung cấp dịch vụ quảng cáo TikTok Ads chuyên nghiệp, giúp doanh nghiệp tiếp cận chính xác đối
				tượng khách hàng với các chiến dịch được thiết kế và tối ưu hóa theo từng mục tiêu cụ thể. Với kinh
				nghiệm chuyên sâu, HomeNest cam kết mang lại hiệu quả cao và tối đa hóa lợi nhuận từ ngân sách quảng cáo
				của bạn.
			</p>

			<div class="tiktok-ads-features">
				<div class="feature-item">
					<!-- Cập nhật HTML -->
					<div class="feature-item">
						<div class="feature-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="20" height="25" viewBox="0 0 24 25"
								 fill="none">
								<path d="M10 3.85352H3V10.8535H10V3.85352Z" stroke="#1A85F8" stroke-width="2"
									  stroke-linecap="round" stroke-linejoin="round"></path>
								<path d="M21 3.85352H14V10.8535H21V3.85352Z" stroke="#1A85F8" stroke-width="2"
									  stroke-linecap="round" stroke-linejoin="round"></path>
								<path d="M21 14.8535H14V21.8535H21V14.8535Z" stroke="#1A85F8" stroke-width="2"
									  stroke-linecap="round" stroke-linejoin="round"></path>
								<path d="M10 14.8535H3V21.8535H10V14.8535Z" stroke="#1A85F8" stroke-width="2"
									  stroke-linecap="round" stroke-linejoin="round"></path>
							</svg>
						</div>
						<div class="feature-text"><strong>Đối tác chính thức của <span style="color: blue;">Facebook
							</span>tại Việt Nam</strong></div>
					</div>
				</div>
				<div class="feature-item">
					<div class="feature-icon">
						<svg xmlns="http://www.w3.org/2000/svg" width="20" height="25" viewBox="0 0 24 25" fill="none">
							<path d="M10 3.85352H3V10.8535H10V3.85352Z" stroke="#1A85F8" stroke-width="2"
								  stroke-linecap="round" stroke-linejoin="round"></path>
							<path d="M21 3.85352H14V10.8535H21V3.85352Z" stroke="#1A85F8" stroke-width="2"
								  stroke-linecap="round" stroke-linejoin="round"></path>
							<path d="M21 14.8535H14V21.8535H21V14.8535Z" stroke="#1A85F8" stroke-width="2"
								  stroke-linecap="round" stroke-linejoin="round"></path>
							<path d="M10 14.8535H3V21.8535H10V14.8535Z" stroke="#1A85F8" stroke-width="2"
								  stroke-linecap="round" stroke-linejoin="round"></path>
						</svg>
					</div>
					<div class="feature-text"><strong>Ngân sách tiết kiệm nhất</strong></div>
				</div>
				<div class="feature-item">
					<div class="feature-icon">
						<svg xmlns="http://www.w3.org/2000/svg" width="20" height="25" viewBox="0 0 24 25" fill="none">
							<path d="M10 3.85352H3V10.8535H10V3.85352Z" stroke="#1A85F8" stroke-width="2"
								  stroke-linecap="round" stroke-linejoin="round"></path>
							<path d="M21 3.85352H14V10.8535H21V3.85352Z" stroke="#1A85F8" stroke-width="2"
								  stroke-linecap="round" stroke-linejoin="round"></path>
							<path d="M21 14.8535H14V21.8535H21V14.8535Z" stroke="#1A85F8" stroke-width="2"
								  stroke-linecap="round" stroke-linejoin="round"></path>
							<path d="M10 14.8535H3V21.8535H10V14.8535Z" stroke="#1A85F8" stroke-width="2"
								  stroke-linecap="round" stroke-linejoin="round"></path>
						</svg>
					</div>
					<div class="feature-text"><strong>Triển khai nhanh chóng, toàn diện</strong></div>
				</div>
				<div class="feature-item">
					<div class="feature-icon">
						<svg xmlns="http://www.w3.org/2000/svg" width="20" height="25" viewBox="0 0 24 25" fill="none">
							<path d="M10 3.85352H3V10.8535H10V3.85352Z" stroke="#1A85F8" stroke-width="2"
								  stroke-linecap="round" stroke-linejoin="round"></path>
							<path d="M21 3.85352H14V10.8535H21V3.85352Z" stroke="#1A85F8" stroke-width="2"
								  stroke-linecap="round" stroke-linejoin="round"></path>
							<path d="M21 14.8535H14V21.8535H21V14.8535Z" stroke="#1A85F8" stroke-width="2"
								  stroke-linecap="round" stroke-linejoin="round"></path>
							<path d="M10 14.8535H3V21.8535H10V14.8535Z" stroke="#1A85F8" stroke-width="2"
								  stroke-linecap="round" stroke-linejoin="round"></path>
						</svg>
					</div>
					<div class="feature-text"><strong>Bùng nổ doanh số từ Facebook</strong></div>
				</div>
			</div>

			<a href="#" class="register-button">Đăng ký nhận báo giá</a>
		</div>

		<div class="tiktok-ads-image">
			<img src="https://homenest.com.vn/wp-content/uploads/2024/11/Group-1266-1.webp"
				 alt="TikTok Ads Illustration">
		</div>
	</div>
	<section class="tiktok-advantages">
		<img src="/wp-content/uploads/2025/06/1-1.svg"
			 alt="">
		<h2 class="tiktok-advantages-title scrollTextEffect">
			<span class="text-gradient">
				Tầm quan trọng của TikTok trong chiến lược Makerting<br> hiện đại
			</span>
		</h2>


		<div class="advantages-grid">
			<div class="advantage-item">
				<span class="elementor-icon">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="60"
						 height="72" viewBox="0 0 72 72" fill="none">
						<mask id="mask0_3507_35021" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0"
							  width="72" height="72">
							<rect width="72" height="72" fill="url(#pattern0_3507_35021)"></rect>
						</mask>
						<g mask="url(#mask0_3507_35021)">
							<rect x="-48" y="-61" width="164" height="173" fill="url(#paint0_linear_3507_35021)"></rect>
						</g>
						<defs>
							<pattern id="pattern0_3507_35021" patternContentUnits="objectBoundingBox" width="1"
									 height="1">
								<use xlink:href="#image0_3507_35021" transform="scale(0.00195312)"></use>
							</pattern>
							<linearGradient id="paint0_linear_3507_35021" x1="-48" y1="-20.6333" x2="116.112"
											y2="-20.4204" gradientUnits="userSpaceOnUse">
								<stop stop-color="#020C6A"></stop>
								<stop offset="0.3" stop-color="#1A85F8"></stop>
								<stop offset="1" stop-color="#66E5FB"></stop>
							</linearGradient>
							<image id="image0_3507_35021" width="512" height="512"
								   xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAAAXNSR0IArs4c6QAAIABJREFUeAHsvQX8P0W1/3/uVa+iYIvdgY167cTuDkxEsbsTUUSuid2N3YqKidgBitioCIpid2H+7v+/z8sun/2+v/t+7+ycM7Ozu+c8Hp/Hvj8bE685M3Nm5oSIkyMwTwQuICJ3FpH9ROTtInKkiBwjIr8Vkb+LyP9X4N8vReRTVRkfLCI7ZG6W64nIm0XkOBH5R4HY5GivE0Tk1zWfHCYibxKRJ4rI7UTk7Jnbw7NzBBwBR8ARCETglCJyGxF5nYj8aAYT2E9E5GqBdde8dnoR+cAM8MohIHxbRF4sIghL/6kB3b91BBwBR8AR0CNwGRF5Sb2yzzEJ5MyDlfi19RCtTWEnEfm6T/5Ru0EIaE8XEXaanBwBR8ARcAQyIsDq+GAR+d+ZT2BsSZ8xEa5vnDl2OYS1f1VCwBuqY6aLJWojT9YRcAQcAUegRuBCIvLhhU1crDSt6VIi8v8WhmNKgQAsOX46i3VDeXqOgCPgCCwdgVOJyL4i8rcFTlo/TND4T1sgjikFgCbt34nI/Spe/Y8EbeZJOgKOgCOwOAQuXGvxN4PsEq/WK8uPuAAQdfYfynuHiMjZFtdTvcKOgCPgCBgicEcR+ZNPVnJRQ0xJ6nDHNKkAgKBwvIhcw7jdPDlHwBFwBBaBwEMXoOQXuqI8k3GLL02PIhRn6/ew5ECIdXIEHAFHwBEIQIDz02f7CvWkFWoKHQAcJFlPdp5eN6ZYqjwygO/9FUfAEXAEFo8AzlZ8MtnCYP8EHHFJtwLIzmMPSdCOnqQj4Ag4ArNBYB+f/LeZmH4lImdI1LoHOtbbYJ1a6MRU8E6J2tKTdQQcAUdg0gjs5RPSNhMSMQt2S9iieAL8mmO+DeaphYDU3h0Tsosn7Qg4Ao5AGgRw6btEG/91Ew5Bea6aBuptUj2diLzPhYCsQsDP3URwGx70fxwBR2DBCLAS/Z5PQvILETm0ikj3QBHB8VFOuk7t0pZASkuNBrhOGEtxHz8BHlAoJ4d7Xo6AI1AkAi9POPl/U0SeLyK7i8hla7/6RA50cgRWESAEMw6XrigidxeRV4rIsQl58+GrBfD/HQFHwBFYEgJXSqCN/mcRea6IXGJJQHpdkyHAUQx+/v9pLAzg4OqcyUrtCTsCjoAjUDACJxORIwwHVSKzHZAwel7BUHrRMiBwHhF5kyG/crTwtgzl9iwcAUfAESgOgTsbDqbfEZFdi6uhF2iOCFxfRFDks9IN+O85guR1cgQcAUdgHQJ4++N83mIQfWflOfA06zLy+45AAgTOKiJfMOLf9yQonyfpCDgCjkCxCNzKaPB8hWtTF9vGcy/YqUXEIqYCDoJcX2Xu3OL1cwQcgZMQwAxKu/p/i0/+J+HpP8ZBAMuBzxjwMu6vnRwBR8ARmD0CaD7/WzlofllE3Jxv9qwyiQqeUURw3KQRaH/r/DyJtvZCOgKOgBKBxysHS8z8LqAsg3/uCFgicC2D0NW3tiyQp+UIOAKOQIkIsHrXrJYeXWKlvEyLR+A1Sr7GxNDJEXAEHIHZIkBkO832P65qTzFbdLxiU0bgbCJygkII+NmUK+9ldwQcAUegD4FbKgZIdg0e1JeBP3cERkTghUr+vtiIZfesHQFHwBFIisBzFAMkq6vTJi2dJ+4I6BC4pIK/EXDvo8vev3YEHAFHoFwEDlYMkG8vt1peMkfgJAS+ruBxAlc5OQKOgCMwSwSOUQyOe80SEa/U3BB4loLHPzQ3MLw+joAj4AiAAHb7GgXAiziMjsAEELiZQgBAQHZyBBwBR2B2CJxDMTD+Q0ROPjtEvEJzROCCCj7Hx4WTI+AIOAKzQ4AVfKz9/9GzQ8MrNFcECHONf/8YXv9fd289V7bwejkCy0aAsKcxgyLffGXZ0HntJ4bAnxS8vtPE6urFdQQcAUegF4GrKwbFz/am7i84AuUg8HMFr+NQyMkRcAQcgVkhcA3FoEjENSdHYCoI4NUvdrfr7FOppJfTEXAEHIFQBFwACEPqP0Xk/CJyYxHB9PHh1WTyZBF5RvX5U0TksbXDmBuJyMVF5L/CkjV/i3zxXEc5cGBDuSgf5dy//p+y30VELi8iS9radgHAnN08QUfAEZgyAi4AdLfeqUXkBiKC/fjhIvLXgatHLCQIsPRSEbltQm+JpxeR3UXk5bVOxj8HlpMV8Y+rSI5vEJG7iwhhoedKLgDMtWW9Xo6AIxCFgAsAW7ChKX6TagWNd8O/RUykm7aXmZg/LiJ3E5EdtrKM+rWjiOwpIoeKyL+My0kd0O24h4iQz5zIBYA5tabXxRFwBNQIuABw4jY4W+U/TTCZdgkFfxCR50Wsts9X7yhotNm7yrPuHvk8V0TOquayMhJwAaCMdvBSOAKOQCEILFkAOI2I7CMiv8008a9OtH+vJteXVZP6zj28cJ5K/+DARKv91TJ1/c/xx7NF5Iw95Sz9sQsApbeQl88RcASyIrBUAeAW1Tb6j0aa+FcnWXYEHtbhVZGjAgSUofoHq+lb/f9LEblzVu60zcwFAFs8PTVHwBGYOAJLEwDOLCLvLWTiX52YDxORJrYCDpqOKrScBMfBhfTUyAWAqbWYl9cRcASSIrAkAeBqtcb76sRb0v9/EZHXiEiMNn/OeuBU55pJOdM+cRcA7DH1FB0BR2DCCCxFAHjQiGfoOSfmnHlhgfDQCfG+CwATaiwvqiPgCKRHYAkCABr+OSfGpeWFk6H/SM+q6hxcAFBD6Ak4Ao7AnBCYswDApISDnKVNyGPUF2sGvCWWTC4AlNw6XjZHwBHIjsCcBYDn+OSfVfhB2CqZXAAouXW8bI6AI5AdgbkKAI/3yT/r5N/sOjwmOweHZ+gCQDhW/qYj4AgsAIE5CgC3quzn/9cFgFEEAHC/Q6H9xgWAQhvGi+UIOALjIDA3AeC8I3r2a1bBS7/+ueXPYByu7s7VBYBuXPyuI+AILBSBOQkAp6gj4qWcgPGG97HKLe4LK6W3p7bC7T6/Cq/7wSqIznGF7DwQ4Q+HPe1yPrH27f++KqTxTxKXk0iIY4VEXteVXQBYh4zfdwQcgUUiMCcB4HGJJrVjRGRvEbl0oLkbvvsfKCKfS1SedQLOZ0TkASLCLkgIXVBEOLP/dqJyIiCVRC4AlNQaXhZHwBEYHYG5CADnT+Az/0gRQZ9AY+OOS993J5pgEQT+n4i8scrjUgpOon43FpEvGZeTYEcXUpTL+lMXAKwR9fQcAUdg0gjMRQA4yHDyIjgPK2lLu/bdqkA63zcsI5P/EdWxw+UNuQ9BYA8R+Y1hOQ82LJ82KRcAtAj6946AIzArBOYgAFzBcML6iohcIFEL71iH9V23hR96H037Z4oIOg8piEA/hxpiet0UhYxI0wWACND8E0fAEZgvAnMQAN5vNFmxi0AI3tSEjwK27kMn/PZ7bKuzSk9NCBevjCxju7z8/kTqwgam7wJAIFD+miPgCCwDgakLACjmWdj8v0NETp6xyTlzH7rVjjIiOgU5CeuG1Qk95v8r5yz0mrxcAFgDjN92BByBZSIwdQEAM7eYCan9DSvUU47Q/GcTESbYE3rq8NvaCmGnEcqIXsCBPeVrY7nu91tHKPtqli4ArCLi/zsCjsCiEZiyAHAqA6c/2MOfeWQOOL2I3E5EXiQi2OgfIiLvFJFnV5r5N8p0LLEJAnA+XCkE/LXyQXDaTZlkeOYCQAaQPQtHwBGYDgJTFgBur5yUODq49nSaatSS7hKwU7Fu9d/c33PUGoi4ADByA3j2joAjUBYCUxYAXq8UAPjeKRwBnCE1k3nMFU+JY5ILAGOi73k7Ao5AcQhMVQDgbPqnignpnwM85hXXaCMV6DQi8nMF5n8UkZONVHaydQFgRPA9a0fAESgPgakKAHi+i1mFNt9g4uY0HAHiCTQYxlwtHRcNLb0LAEMR8/cdAUdg1ghMVQC4p3Iiym1ONxcmOruI/EuB/UNHBMIFgBHB96wdAUegPASmKgA8VzEJEfzGKR6Bzyqwf0l8tuovXQBQQ+gJOAKOwJwQmKoA8FHFJHTAnBpwhLrso8D+wyOUt8nSBYAGCb86Ao6AI1C5aZ2qAHCsYhK6pbe8CoFbKLD/nipn3ccuAOjw868dAUdgZghMVQAgYl+MEhrfpAr2MzPWWFudiyqwZxIei1wAGAt5z9cRcASKRGCKAgA++2P9/xOEZ0xTtCKZYGChdlYIAMQ/GItcABgLec/XEXAEikRgigIArntjV/+/K7IVplUoYhLE4v+nEavqAsCI4HvWjoAjUB4CUxQAzqKYgMZcgZbX+nElOqcC/zEFMBcA4trbv3IEHIGZIjBFAeAMigkID4BOOgRw5hO7A/BDXdaqr10AUMHnHzsCjsDcEJiiAIBL2tgJiO9OPbdGzFyfmynw/3rmsrazcwGgjYb/dgQcgcUjMEUBgEb7i2ISutDiW10HwBMU2B+sy1r1tQsAKvj8Y0fAEZgbAlMVAI5WTEJ3nFsjZq7PRxTYvyhzWdvZuQDQRsN/OwKOwOIRmKoA8EnFJIQbYac4BDChJKpf7BGMxwKIw92/cgQcAUfAHIGpCgCsJGMnocPMUVxOgtdV4E57XX1EqHwHYETwPWtHwBEoD4GpCgD3VU5ErgcQx4tvVuD+bxFBgXMscgFgLOQ9X0fAESgSgakKAITzjd0B4DsU2ZyGIXA6ETlBgfvhw7Izf9sFAHNIPUFHwBGYMgJTFQA4i/69YjIiJPB/TLnhRij7IxR4I3Q9dYQyt7N0AaCNhv92BByBxSMwVQGAhjtIOSER1c4pDAF8J/xCifdVw7JK9pYLAMmg9YQdAUdgighMWQC4t3JCcmXAcI59lBLr46sdgP8Mzy7Jmy4AJIHVE3UEHIGpIjBlAYCYACiWaXQBbjTVhstY7jOJyK+UOD8zY3nXZeUCwDpk/L4j4AgsEoEpCwA02MeVE9N3ROS/Ftny4ZV+jRJjQjdfIjy7ZG+6AJAMWk/YEXAEpojA1AWA3ZWTE7sHj5tiw2Uq8zVFhAlcs8vyiUxl7cvGBYA+hPy5IzAAAc70zi8ibKNil/1YEXmaiDzD/yaDwZsUg/tnBvBKqldZvf9SUQcmtr+KyPlSFXDC6e4oIt9XYgu+ty4EA40A8GIf0yYzpmFt8hgRuaeIXFtEzlEI/82iGBcUkUeKyAdF5E8Gg4NmZeHf6lZmWvxKEADoVPsa8OFnK+H15LPooXaVeIMBrhyxjK381yCiEQC0fcW/H3eswoLlrSKC4vCZG4bwaxgCrLL2FBEGSe12oHeEcTuCJf6lCABnrITSPxtMVmPbqYf1xjxv0d8teKWkwEsuANi0qQVfjJnGP0TkffXOdZ7eNNFcTiEiD6q2Un5sNBiM2eiet33nL0UAoHsdYMCjWBSwZbh02lUZbrnpa98oaPVPm7oAYD8GNG091esRInLLpXf4rvqjHPZNg0F1qozh5e4fLEoSAM4gIr814NffiMiS4wScXUSOM8CR/nODroFlxHsuAPT36aWOeyiqXnRE3iwma7b7CZfqW/3eWfoGg5IEADoQ2vx9ZQ55zrn16YvpkfkKgre/LxthiI5QaeQCgE3/COlDU3yHOBf3Ko1pc5bnnCKCd7QpNp6XOX+7lSYAnEpEvmvEv/gX4AhsKURdta6Vmz6IcvB5CwTOBYD8Y0TDE1O6YhnFWLIoQrv/B0aD55Qa28saPyiUJgDQYa9s4B2w4Yl3L8QyAC19TZjfBq/mep9CR04XAOL7etO2S7l+SkSIfrkIuriBq8+lMIbXc2sQKVEAoMO+0FCQxRSuFDO2FIMRERFfbogXZ6mlRll0AWCr7/o41o/FV5cgBJzLUOnHmaqfqeaEUakCAA5sfmg4qb1ypkIAgs3LDHH6Y6Fb/43g5ALAssYni7H2CyKCbsws6TQi8i3DAcACcE9jOp20VAGAznp9Y0XWN87sOACnR9TJsr/do/BR0gUA2/a25J2S0+J4bJb0euMBoORG9LLZd/6SBQA67P7G/P0BEdlhBiMBlj7oN1j2CXYSSicXAGzb3JJ/Sk+rVL2W6D53e+MBoPQG9PLZd/7SBYCTVUqBHzHm80+KCD4Hpkp4TUTBybI/sE2KUFE6uQBg2+6WPFR6WpgIXrh0Bg8t306VvePxxoNA6Q3o5bPv/KULAPQHJmtr65ajK7/iu4R2toLeI3DXUcb9/ucigvnwFMgFAPsxYEnj6semwOQhZXyW8SCwJCbwum4NIlMQAOgPl6kj/lm23a9FBG+ZU6GrJLD0waf6VacCgLsCNt31sexLU0qrlMiW0d2OSEh/MRYA/lVvK7620pYmoAphgf1vGhhotMCnIgDQWTjy+n/GfP/3Ogx2dGfM9OFelZdEymo50ILl7pnKb5WNZgeAMOc+pk0DA8LRY757pDHP039Is1Qz16B+sp8hKMfUMZc5V3SaJgKsYmMnhikJALTOfRV13YQR2vQlmgqh6c9guKnssc8eOkF21wgAxEhwmh4C5xORJ4rI7w37wU2nB8OJJWZA4MwuttM33/2z2lJ99EQUf6baVrnKvSQBAEz3NuD/ph+0r18rLIjQuatgPCjntcto9RsMp0guAEyx1WzKfCYReY1Rf8AaaJKE5KIdBIi45iFTJ9n8nYVemgAACM8x6Add/Qgf+CWYC92iCuNNVMOuMmrvvbiTi6Zx0wWAabRTylI+sNoR4Mha0w9YAO+cspCp0j5QWXHOEVEmcpoPAksUADjDs1oNdA0kOA4Zw4/4Kasohs83doDUrt9LJn7+6QLAfMYtTU0eoJwH6RP30xRgrG+1pn/3HKvgnm8yBJYoAAAmQsCLDAaC9gTZ/o0r4usla7XtE76siHAM0S6D5W92TSat/KS0AnAdgO15bsp3XqXsK++cWuUvoqww54lTHwCm1mY5yrtUAaDB9inKftE3yb5DRLC8SUWE8UU7HZO8vrLEPkeRcA7kOwBzaEWbOqC4/jtFn8EMeFLz4R0UlWXguJYN7p5KYQgsXQCgOZhAYyfHkO9+KSJ7JGj3XUWEiGUhZYh9Z58E5R4rSRcAxkK+zHwfp+w75y2zWt2loiPHDgI/mpq00w2B3+1AwAWAE0G5v4FyUF//QnsY7XwtcdZPnAOtMtOm8qLoNLcjPxcAtJw3r+/xYPm/inmRgGOTIY0CIPHVneaJgAsAW+16IxEhpO2miVH7DEuBBynCC18pQwRPbKavuwXLbH65ADCbpjSryJcV/R1lwsnQ+xUVxZOY0zwRcAFg23a9hIigwKed6Pu+/7aI3GzbrDf+hx7BCyo/Bv9OXLZjReTiG0sy3YcuAEy37VKV/NWK/vSEVIVKkS5RzPoGpXXPb5yiQJ5mEQi4ALB9M2Djm8qJzmof+3AVmvdS2xfhpDtE2XtMhp0JykWdz3pSzvP74QLA/NpUW6N9FfPi07WZ5/z+S4qKXjlnQT2vrAi4ANANN+fsrLhXJ+wU/+NXH2uBVaUizAjZKUiR52qar1iAZ08XALp5fcl3cWm92hdC/5/U0bhGAODc0WmeCLgAsLld75ogeNa6AYYgXQTTuryIfEQxMK1Lv+v+30Rkz80QzOapCwCzaUqzijxE0c9cADBrBk9oLARcAOhH/pIi8l3FQNE18ZZwD12Hy/VXfzZvuAAwm6Y0q4gLAAEDm+8AmPFbcQm5ABDWJDvVIUZLmLgtyoAnszOEVX02b7kAMJumNKuICwAuAJgx0xQTcgFgWKvdTkQIiGUxCY+RxglVaNQphvId1krdb7sA0I3Lku+6ABAwmPkOwHy7iAsAw9v2bCKC9v4YE7gmz2/1WBwMR2JaX7gAMK32ylFaFwACBjIXAHKw4jh5uAAQh/t/VqZ5DxeRvwb0H82kbfEtvgP+R0SwbFgyuQCw5NbvrrsLAAEDmAsA3cwzh7suAOha8fwi8vGAPmQxkcek8QMRoY2dRFwAcC5YRcAFgIDBa0oCwKlE5Doigpcm4rJj/niMiBC96Vci8n0ROazewn2miNxaRM6xyhWB/xMN6qKV57i7Vw5UXiYiH6u8u32lCvyCNzUiTf2mzvsIEXlL5cVtbxHZrTB7axcAAht7w2vwwb1F5A8BfSlmEo/5hlX/ASKyw4ZyL+3RHASAk4nIFaudp0eLyOtXxjfGHMY63NtiRoqZ2p1FBCE1lvBNcUcReX6dJmPn0bUeTJPfN0QEpdL9qrEVp3Gnic1shO9cAAgYtEoXANjaRDmLYCsoOcUMmEdVIVUfLyLnCmDC/65jySNUxOSFvTeOX/A9z1bymHS1yDpQ78+NWfAC80Y3AIc6OPaJ4QurbxA4mSSctkXgF4p2GdNDIgLm1UWEGPbEaYjhk59UR0B4rttlW0g6/+MdjoyOi8zr7/UC6/aFLXa6KusCQEAjlyoAYJpFSEfCrcZ0iq5vGLw/VDtjaTMMEzVOYb5pmBf5s1tA1LWTtzPL+Bs78C4cQu4dmbGcU8oKRz65XAm324nJAQ1/VolO2yOg0dfYcfvkkt9hzLltgpDPnxeRG3aUntU7z9o8pf3N2PxIETl1R34l3HIBIKDBSxMA6BhsubLFrmXQdd8TJvJNtXtWjhRYVa171+L+9+qji9ydAmk/tvyEiXbqRoBV2x4ioll1DmkXdpSIYeDUjQBHg7GhX1kU5N6pQ4jURKoL4R2OCYhDcdlqh+EQxTgQkhfHLxwllEYuAAQ0fEkCwAUSSKmbGDhlzPXVfBmg2ObLeYZ29oD2Xy1n8z8DIwOr03oETl9h9IzqeOkfCpwbvLuu6LQQM8BpMwJ4c+zCL+QeIZxzEcGfnpMh6mNTb3RF6MfN/6mvRKUtSVB1ASCg8UsRAFDYiz0DS83YlumjVHOhTCMOKxv8wceWH30Ip34ECDOsCcm92j7sfj1MRE7Rn7W/ISJ3UvA4x345CIW7wxXlXOWRUv9HH6EUHRUXAAIYrgQBgLPNnJLq2J0HDdtcuKMAGVvfR+QYGWeUB22q2W5lJ4EohewsOIUj8EoFj783PJvoN3etjjV/qihjbP8d6zsUBW8VjZbdhy4ABDBdroloXbM+OaCMYzFyynzZerzWOlAM7x+kwPcThuVYUlJodX9mAO4cD3HOzxGY0zAE2OX68QCsV/v0s4dlN/htVsMlmZCu1j/V/xyvsjMzJrkAENAxxhQAHhhQvlQMWkK6CAGXSdxD8E8QW1d2Zc6duHxzTR5FwZuIyNs3mK/+sbLjPjADD8wVY+qFEm8sf/Pd7gnBQTchpTKzpt45vkUH4RYJ8e1L2gWAgM4xlgAAYyxp239dhzte4ayorwPw/LoBPLCubNzHvthJhwBmZletJ5v7186lWBku3X2vDtUTv2YLfxP/9j2LdRTWV3aU4TgP78t/7s9Z5HAEMga5ABDAgGMIAOdZuGS82uk/ndC+m8mHM7nVPEP/Z5V6pjF6r+fpCPQgwMQSa/4H/+NKOQVxLPFRRZ8L7ZtTeQ/vgvh1yU0uAAQwYW4BgK1RJrypMG+ucuKpMBUdrMQbD3hOjkBJCDCOHKrka1zgpqDHKsuVa8zJmc+rUwDdk6YLAAGMmFsAwDNeTsabSl64Odb49d7UF3CspMGBoxrOWp0cgVIQuK+Sp+kPuMq2Jvow7sA1/W2O37JTc01rsHvScwEggBFzCgA4wbF07Tu3jvKeHoaOfcwWvsYfADj/vPKFj2MhJ0dgbARQnNXyM+fzKTwAaqxu5jaerdbnq4kwX8ePLgAUJgA8KqA8q0yztP/x35+C0DbXYokTozOkKJyn6QgEIkBAL43ZX9MHnhSY35DXcJyl0Uloyjbn622GAKp81wWAgEE/1w4AXs1YRVoxN/719623lfCydZYqbCUe2fBJjZ//2MiBXeVDU5/zQiL8ESL4jFUI4IuIyC1F5OUigqJc13cx996mZPp1n9POMeVZ/eaLrhS4DmK/nxiBC9aKe6s8OfR/xgbGC2t6n1Efoz7sUBDyGVfQeA5lF+9i9ZiDTg7OxIbWe937v60skXCmhDfWi9fYcJRBUCHKYDluEwMhF7kAEMAkuQQAPEOtY8Ah9wk8sWfAVhLmPRoPYZQJBx4PCjDXOl0tjPzToI440EjlT/vjBuUDl+/Ug1Gujuz5OAI4zbIKvvSyBHCyM4Hd+5CxrOtdFhPslBI3YBPhLXJ/EdHEM8HzJI7YTrspozomCOMgJn1dZR567wo9+Vk9dgEgoMFyCQAW0jG+tIeeQ7Mj8OcAHFaZ+OsicuGBnMj2fWyc7Xb+Dx6Yb+jrV4nAoV2u9m8UnVDESnGOGloff2/+COArgZ0+zUTX5lvCBp8zAWwah1tN+Y6JEKx3ixSMOEYZOvazK8A5flPe2Gsq64vVZnUBIKCxhjLBKsgh/9OJtZqxX1FE0mNba4hP/NeKyA4hFet4B3eu2jPKT3Wka3ULRcPYjtv13ZfcQsCqaTydFgIIlncQESIidvFd7L39WnlY/tQG+mHhcLbIArHb+dkBOH1IRM4cmRfHn1ohgPExB7kAEMAUOQQArbtOLAe0UjtCCNtYOP/oGjxYYRBD+xoGnIl5kcbLIRrOqULx4to3ZkekC7P2vcPqHQF3GmTAQAtOAv58dKXL8901/bTNc0N/M/GkcEjDkZ22v2u95SEw3bnSEThyDW4oJ6K/gwdWfChoiJ0A7RiCPkdqcgFgDTO0O04OAeAJAeVol2n1N3bsloQCHz7AiUJ4n9pnu3UEtpcq60xAmVREqNlVjK3+ZyBkt+ZFIkKsBxQlEQDRkB77j50gvFAuNcwuAz+C9C4FtAW8gIIbimdEnUSxDd0SKz5cTYcJkPxSEDy+mt+Q/59hXCiEqNuKCEeJ9EH0r85qnAdtNqSOq+/e3bg8Xcm5ABDQSDkEgLcElGOVQZr/WbGfrKt1C7+HtUBTh5grDpNSEasFdjtiyjWHb1DWZLJ5axWmFeESK5I5ErsxbKO/SkSOqFbWnH/Pof1i6vDihA2MSWFMmfiGo9E+JbyERY9OmjJr+AkFxtTkAkA1NpaZAAAgAElEQVQAY+YQABh8YjtIDkZJxYicj5dab8yglhSjvK8dPldbl8TqfqTioaHpItwRhRBdDwurlD7cpvCc8/mU7apZ4CCETpXerBjfUpk7t7F0ASCggXIIABrN+NzuI9sMpP2tOQbg29T0ggD+mMIAb1lGzEzZOp1apD6299lOx3rFEo+pp4UNOyZ6KUljXotJ81TpkQpeI1hSanIBIKCBcggAGvvRKcej15y1vyZ176idG019gE9VfhxNpfAVn6JZsTw5JKCvp8Kq5HTvlQLwlTQ1WvH4N5gq3VzBc5/MUGkXAAIaKIcAoAlHS/yAqRIKOLGDI06MUhP2uLHlW8J3KDQ+s3AdlD0MTGzn3JZoxqembyn60SVTFy5h+nhGjeWdTyQsV5O0CwABDZRDANCYjAx1/NM0fglX9BdiO0gqe+U2Li4AhLXPh6vdEmsrkXY7xPxGMfZ5Cv6K5cupfZdDAFhneheC1VR2mbp4VBPZFb2J1OQCQMAAkUMAwJd+SGfoegfvdVMljaY9PgtSkwsA4XzJII8TlBKIyf8Nij7V1c/mei+HAIDjrlj87lICQ0WWQaPjhPCamlwACGDMHAIAduGxHQRFkykSjnw0ZjK3z1BpFwCG8SXa5GObbKHsZxHZMbY/Tu27HAIAGu2xuLwkQz9PlQV6MrH1flyqQrXSdQEgoIFyCABvDCjHOkbKoSzS4hmzn3dV1BkscpwNugAwfACDH8e0ECA627q+4ve3xyaHAEBAnVjsfzjReBrauCI4T0pNLgAEMGYOAUDTEHjwQst5avSFAOzXDRqE58SeOzW5ABA3cHN+qXWnGtO2GqXSdbw29/s5BICbKvo6+F83hhlG/kazqGNMj41FMKTamnnnhUMyGvtdjcOZHAKAVlrMYRNv2YY3Uw4IB1kWZkNaLgDECQAM2k/bgGuKR0S11Pibn/tEv65+OQQAnGqtyz/kfg6beEuexMupJjojVhM5yAWAAMbMIQDghYvY0yGdoesdPJrlCB5hwZTE8daYBVH/XHoPLgDE8yTtxIo8BxHyVWNK29WnlnIvhwAAD7CVr8GUNp4KEU1QU9dcCzoXAAIaKocAAGN/IKAsm5gKu9Extl2HdkrM9zbVo+8Zq7xcvuk1AgAe8/6trGsfFqU/ZxXE9m9KuoyI/HHhOGv4IJcAoDXJJPphqgiglvyJ50JNe/BtLudHLgAENFYuAYAtTC3j5PDqpeksVzXwv55zO1AjABBJka1PbIHfISIaU08tX4z5PT4uLq9hmg3fnq+KVomgNWb9xsob9+Gvq8ICM258UIFBLgHgCooyNhg/fQMvlPAIXazfK+t5dMaFnAsAAY2VSwA4tUEM6b+JyOVK6AkdZSDcpsUkSJjiXKQVAFbLidtm9B8QDogzgGBwsIgcWocIxhx0rD8CUtE+mrPLZqBevf6iMs0jRrolEcmPVeFqXhb/U15iBozVFk2+uC+GP1CqfI6IMGDfsBYs21hqgs7kEgAor7a9UI4jdG+JxO6EJqhbw7eEhs9FLgAEDCC5BAAanbCkDSPEXgkPbB3bWsuQO4nIYQZ1IzpfThMzawFAi2OO75lY2Uk6yqC92jzM4E/aFoSwrLEiaZer+f1rEXlsAkHFor59aUxFAMC2vcE79ooF0MX6AMn8/OQi8l6Dup0gIjk9u7oAENBoOQUAFPksVmDfKMgrG0p/Go9/7YHi/pk79hIFgAbiU1Q6DHuLCKuudhtofn/W4ByXwfb9hmWiPqywz9BUfILXqQgAO1aKoQhaGh7iW3aqSjF9Ru/q1QZ1ol7s8uQkFwACGi6nAEDjc66n7SB8z4qblfeYhEvWdxnV50cigjCRk5YsADQ4E0zH0rzunUofDgSBsugfTRocxUxBebZpj67rVAQAyo5Q2WCvuaIDcZ4uMDLfe65RfdCV2Tlz2V0ACGi83AKA1S4AnYuzZUwMxyBWkG8NwDd0EGAiyk0uAJyI+H0N25H2jjVz2te4HEycU5/8aaEpCQC4iv6NUTt+u0MfItcYAd8QCTN0/Op7D97OTS4ABDRgbgEAJrBkLJwg5ZYs2erT2sK2OwyCzBgDtQsAW0MS25PtNtH+fthW0kG/7m2cP2azuXeUgioa8dKUBACqZ9mW6DztEoGZ5hOOoSx3oogZMMZCzQWAgEFlDAEAZsAcRDvINt8fKyJ4p8pBKLF81bDsBAway8mRCwBbHIMApnFv2vBic+VY4XZbyW/8heWEhW5Mkzda9gipc6GpCQDwEhYOTXtorygGXjNTY1ovbugH18hU9tVsXAAIYMIxBAAaCv/XlgpYOTrJpSq79x8HYDqkw8OkY5ELANsiz4rZcuDGbPXq22ax3X9XFJG/GPLUMQVayWxX6YE3piYAUL2LVFYXtP+QsWDTu6R1h4G4DX39XLV56KZyDH2GDspY5AJAAAOOJQDAFDDHUIba9D7uhrFBT7GdTnQ/y4GaeuAdMUfQn3Ud0AWA7ZE5nYhgZbKJz4Y8QzBdtzt1IRH5lWFeaKAz8cyNpigA0AaaCaiLx1gwPaOKQ8EWvTVdT0R+aciLlJ+d0jG2/htsNPh7MKAGxYRXFOkwnepids09gulY2WRjl28tqFA3jkBOnxDbkKRdAOhGiZXQTwz5kiOqs61kdQ4D//HtPsJREkG35khTFQBoizcY8lHT3ocbmgmyWMI/hLVb798ZljGWp10ACGC+MXcAaNhzJpA86SiY0VwtlnPq71ihWZ73Nx2YwfrSyrJZfO4CwHoUOe75Q0D/adq079o+l0dT/EjDtAmWdeP1VZn8kykLAJypo83fxx9DnzPB3lrZsihPfyxB2Tj3L4EfXQAIaNyxBQB4GCURy/OypjOhWIXFwdBtKKTiBxi4Lm7K0b4iad9S2XGtPncBYDOS11FGsWy3O79xe4uXP8tBl23he2yuxuSfTlkAAHyOZSyPehq+ou3xq3LGiBa+baKFF2Vj4i2BXACYiAAAs9zcWBO66SRcUYxC6TCEiMRnqQjWLgcddq+QQmR6xwWAfqAJdtRuQ+1vy6MFypLTt3o/WmnemLoAACoEjMIZjpZ/ur4ntkOoHxGOHV+RqByU7WlpWCAqVRcAAhq6hB2ApnXx0c4k2cXk2nuk+/IN0jLKeKz6/5Qof8pf2mDtAkDDeZuvT0nIExq+ftnmYs/m6RwEABrjBsY7Squ8g79+AnKtI8xSf56Ql3EZnEIBe119+u67ABDQ2CUJADQoDlRSCQF0GLx0PXBFkxZTrC8HYLXa4Yb8/+Q+bh3huQsAYaAzqL02MX8M4SXeRdEVV9RLoLkIALQV5/ZYKw1t79D30S9CYOWoqSGOIKzilawrB0cRpfGjCwABjFaaAADT3s/YP3sX036rDr3JdhhKK13vWN17fNMTC7u6ABDeIFispB5EQ/nt0wZBh8JrPv6bcxIAQPMmiXSe2vyDvxJMl9mS/3vi8Q2vgWOaM6/jUBcAAhq+RAGABt0zgWlKu4Pk+M1OxsPXcWcB910AGNYIBJ9KYRUyhBfRKJ9yZL9hiJ/49twEAGqF3b21X5EhfGT1bsnBplwAmLAAQCfhzOyPAXWwYmbLdJC67xwz2mX8xgWA4WDjCprIjZa8EpoWYWJLiBA3HDXdF3MUAEBk1wSeRUN5SfseixuOGkomFwACBqpSdwAaxsIeG5t+LcPm/D6HW+IGH83VBYA49C5emTphh52Tp/BJwISxRJqrAEBb4hBq7F2loXzM4uaOE2BEFwACBqnSBYCmk3wxoC5DGTnF+7iRHSu4z9A+6QLAUMS23ic4S+qz1YY/URoLNWPdKuF8fs1ZAKCVcAyFUmfT3iVfMWNFaXoK5AJAAFNNQQCA2fB/jR/skjvH20TkNFPoGXUZXQDQNRbBWVIrkJJ+aFRBXW3K/XruAgDIY2lCHBPLqJDWY+VnOlxal8s1ulgMHgug0JZFszWlrX5Mp2EliPliSTawIc3nAkAISpvfeXRioZRJYem0BAGgaWOUA1Pa6seMbwihz1oxnW7KW/LVdwACBqep7AC0GQ1vfYcG1C2G2Yd+g1b2ZdqFm9BvFwBsGuuARLy4r03xJp/KkgQAGgtvfW9MxFNDxzeEkRtNlINcAAhgoikKAPAjq+37jGhKgxYsPgTaDjem1k9cALBpMXiRmBNDB9d178Nbe9sUbRapLE0AaBrt9rXjsnV8kvr+uwyjqjZ1ynl1ASBgUJqqANAwEgp3nwuop2Vnwff2TZsCTPjqAoBt42H2+XslLxI05la2xZp8aksVAGi4s46gIMgRK4urqZMLAAGD0dQFAJgUBcEnisgJAfXVCAKszIjvfeap94y6/C4A2DckZl2vilDmQtP/RTPiLUtklywAgCM7TMRJwbxYM36FfIu3y/NbNt6IabkAEMAwcxAAGh47Vz1BhzD60He+LyLXbzKayRUvXkNxaN6nczmtRwBeZBv/8A2WAoSG/kIluD6mOk7CwZBTNwJLFwAaVPAASZ+Fb5p+aHX92YCIgk15Sr8uRgD4lIIhblh6K0aU79oi8k0FJu1Oxa4CHq9OGVGO0j85UIHRHLYIc7XPjnU42JuJCOe6XC83cf2RXNiRz2sUfEqEz7nRZQ2PPdHwR5cJXwRzo30UfIPVw2Tog4qK3mMytRxWUIK34Ief6H/tCX3I73dXOwoXGJbtpN7+hAKbKXgCm1RjeGHXIqDZqdpvbarTfsCxwN2UXlIJKoUgOlciSNGQ8b797qSUcN+kqOikJJ0ITmX19djKTh9Xqu0G3vSbbVs8vc2ZGEB+OgCTVbxuPGdwvG5FIYA55Cr/hf6PED9n+q9aYY8t/FBMvlfvRM0ZF+r22QGYrGL34CmBg5S7WoHQ/znbXgKhuPc/IoIryy5s2ApjRYzXNSbHuRPuPLtwCL1HjHEnRyAHAkQGDeXL1ff+vJDQyXggZaHz3Q1YsbC59wQd+sTw2JmUuhKEbJ4M3WVDo692iK7/OVNaChG3+mpVFK57VhXmbP8R9aS/tChrGuc1/xQRjlicHIEcCFxZOb4tzZUy4/ketRIqQgHHdRfN0VAF5YHuR9dcF3pvKvFc/g9yIuaFVqzrvQ8V1HBelPQIoKGuMZn8Wvoieg6OwEkIoKCm8ZGPt86TnZSa/5g7Ajhn0xxvEoJ+UvzCljUORLom99B7aCY7LQMBghaF8kXXe89bBkxey4IQOEzJsx5ToaDGTFwUjnq7xq3Qex9IXL4kyb9DWWk8mC1tmyhJQxSe6KOUfEIncmGx8EaeYfGeruRbjq12myEuXqVtEbiNiOCwLXSy73qPwG6TI+yLuyoz5N4PReQSk6u5FzgUgfsrFWPgJQTFU4Vm6O85AkYIYK42ZCzrehdPei4EGDVIgcncwiA2DMrgk9QHY1DW+iGn0+AHmjjnTvNBYKcqjvfLDQZQ+APb2lLpwiJCuGhcHB9cKXd+q3af+pe67lyZBLjPNt9zReROM3J9Wmq7WJWLduua2IfcYycAD3GTOuO1AnCm6WAKidMfJu8hvND1LlFmJ0sahxmrYBBg57reUSbLCxQc16HYs2r1Q9q8gflgSXT5esL/gbLzYz6FT4xdS6qcl2UbBDjHb/Oi5jfCBNvFc/TwuQ1oM/5nBxHBAu4YQ75gQTBZYuuCoCKajrH67a+rFRIuY5Gw8BrIUUPKPzrl9UTk4jPpnDDppes6YY6UEjt2bpjwUYL5uIiw2lltT83/HyukZ2CCiG24lbvnVUxQOCOyX8wqEZ/+2BATnOqdIvJFETlKRIir/re6PX5XOW/BcctXROR9FZ9zvu07Ef3MhXa3pTBLu7PjSTthEox765T9k7QZAxjfLjMTV9D0xV3qxSJRLFPjd9/KTwuOoeg3fzUe346O7PP9nJvxDY37w9WBcOz/CXqB8woGSCbRqRCr0ueIyJFG21Jjt0OT/zVGbgCsXZD4jzPu+E39Vq9M3Aikm4gyYaf+7Mr2+liDclE3+jAxOtjadNoWAezaV9tpqv+jrIYQy84tvkmm4oCMCR+B6fMJFhljtiWLisnTztUZFyuMMYFMlTerKRQ9SiQ6LyvwI2aK/VtHBh0LFSLnpeKtTel+uENPgH62/wbPkpvSC332y0rh8hkdeY/cFKNmz5Y93ktDMZzSe9+pd7Zidp5yNAo7F5yRTwnT0LKy64eTuFnQ/WbaSE1jHiIiKHyVQjhiQhpuyje3K44xiHM/Fj1I6bjIoj2IJcE2/XlF5EWZy4MTnDfUW61jtUFJ+d7AwNTLgidSpcHOYUlh2s9dBQ16/4zHN3aaZxUUidUoWs6pGLSEdPHxzTnt2MSZVHO2WwIuKcowVuQ/9Cc0ga5SYJEiFntoOdHpYLv4jGMzfQH5Wyo8h+Kf8z2EvscUcCzAjiuWMznrnjsv9HVmRwRD+PHMG44ztLHCNiJkoTWem1lz5/eykXrG6ZTRvHLjlDO/X4jI0qMxchTw5QX0v1eNqJj2wJnpMHX10Y/Oaet/dazGqc/cpTcaFYW7nMTk/+IFDD5ERxzDTIrJf666FF2DUMw9bJ5RPByjfXL2tU15cSxloXgZg3/Ob7BSOPkmIBI8e/QCxjdMQTGVnjWhuW1tLpGT+UPzemamVkRR5NUL6BxYX+yYCdN2Nmz7f3oB+Ibydd97XxURzmiXSoSlRlmyD6epPyd+Ry4hgC3xqePVV/4ficg5l9JpUCjBnr8PlKk/J8RtSkI793ULwPGTIsIqfAx6/QLwte5nmA6WpBSbm28uUJmHYsNtjWtp6eXYCZiTmeW69iM65OKEZo4DLD0mrQN37Pucy6cgJv/SFNJSYE0dx9pW5swxRZ2WkCaOhqbkK8O6j3IcsASdgLcn3AnYbwH9j2PN2W/7r+tcxNXWhoKdwmBqvRPA5P/GmXcOLBnGDJmKc5ETZo5x6r6D/w88zC2V8EqH3wRtNLjU7aRNn50A6mpJc5/84Ql4o1QfC5Zt2ZsW3tRYMWgZseTvUZCyIDoaHa7kumrLhlQ8ZiholCqJPaGth39/opdEnBQtmfATMFdnQQ2PE/7dSieAsbJJd47Xr4nIVZbcIbrqzhkvinPY08+x0amTVgjAFet7ZowPnsd272KOzPfw5zBXHhyjXjilWrobYY6xOM+2jh0wRnuuy1MrBCB4P2/Gfe8nle4bx4pWglLmYTFPdvgLeHLlghKtyHWMNuX7sSaCDCAHzRATtsI+VQftKMH1JTss1qZcmL6+pdJ5uVt9Ln622tYXofditUe/187YZTb9lfDPTiKnqY+2UPya8ji2ruyxQgCTPx4t16U75fuYEBPYaSxdpkn2OyaDa9WexghQMadztKFCwKnqePJT7gTtsnO2TnRAVkS4si2J7mo4CHGs9bBqZwtTwhAiuhxuhue6SuwLZBSC0Zze+e9qUiCwGCauY3p0bPdNi99DdQKY/HHwZZF3CWngIZMjRKIEouzuZIDAmSt77GtXugK4uiW8LAyDhjgSZ8o//Pzje96asUIVA5k8PpIgfxS08DqVEjvSZmWLm1R2dXDhi4/rkiVh/J5btDXKrTtF8v3pq50BtKstytGkgW06iqPsQly18uWPqRqrUbYj2XVDWY/YAqzCUlnn4DFwndtgNKFx88oxINhxbHB8JUAR8wBe5Q+BCmcp+IF/bu16+3yRGJf2GbtBtMs9K8UwFOBeUoc9T90/CSyVQuAMFQJY6OFdsOFTq+tfqgUk5sOp8cNMGCdsTxWRu9cxE8bwV1IaP8+qPAgfxHu2Ys4mnT4hgBUhK+Xmfavrm0e0qy+ZMZgEtRizU/Vwo0riVlpTHspysIjgfItV1hBCSYmJ1nrn7YWtQpy/EkCeZhCmGpt7BAfCXjsNR4BxJsUK/F091gFM/iwQNDze9S1KxGMGCxveAv5F8QikMr1D6aWL6JTsPnQxuOYesd1LOGvvqvOY9ziKsPCr8DjjSuwTyQMMgpc1KAs7NuwUaXiu/S3bo/evd7VwH9x+ZvGb7fQ9XNEqquURxizaoJ3Gu9cIAYynKZxssaPBkamTI2COQC4hgK3ZFHGuX+GT/0k8gQ8KzvvfKiJo57YHrdjfeGW0JlbuQ1ZJRG1DCLEU8ijDo0SEyTsWm9zffa8+chq682HdflNLL4cQwDhKOGlrnmC3yyf/qXHcxMqbUghgsGLy5+zKunOwxbf0wZC2u1W9tf13Y4w5R+UsPQVR7pBzUs7ur5yiAHWauPCemp97BOkLJcRkjkmnFALgZYudttXx8YOF6xbNkU8WWycUp1g5rjKh9n+USb6YIN0+XYO5NyTKeEQT+2ECbJs2Z1s7Nd2sVo5r8myuCB8ojsUqHQ4pN3oSv0+IY1MnyytWJ3sNqaS/+39e6izbgLQ4DkAvwDrdUIVDb1ZHwAyBVDsB1p1D63zIDLAREsL5zIMzrFpxXpVj8m0gRCl1t8rU6HqVlvPFjbf7mzw2Xa820YieHKUs3SHRpnZdfTYFd7xo+Vu7IV7Fwf93BDoRKF0IyBWSuBOckW9evzrj/0GC1UaXgMbEsjR6SCZsu/DW3PvYSGGlp8ofJQsBOUMST7X9vNyJEShVCCDQxBIJe3ImZGvztU2TDrbbSyOUDLHV34RLqc84ZnNb7XCOLVEIwLOmu9QNb0N/MyECCAEptFpjB1Cc7iyRsAMfw4U0Ht2WSBw/YHUQy6djfsdOgB8HhHMtjm7GbK923q8Z4dgrHCl/c5EIlCIEPGmR6J+o5EUI4fZAkeM3pnFLNj1iJZYD5xR5vHqhfSW22iUIAVjDWJq4xmLh3zkC2yEwthDwhO1KtIwbKcyWQiecrywD4rW1xH1tKFYlvrfE45u1jRnwYEwhwJ2YBTSQvzIuAmMIAZx3E3RmacRKIIUL0yET1SOWBvpKffEtkSp2wJB2iH33r3VchJVq+b8bEBhDCCCa5NL9mGxoEn9UEgI5hQAmfzSyl0isCGIHfovv8CuAy+al09hCmLYtcZvsk8swLs4pBBD4ydtnWPv42yMjgBBwYOIJismf8LFLJEJtagd+zfdEG7vCEoHvqLNlCGVNm2i+vUNHvfzWZgRy9MGhodM3l9ifOgIZEUgpBDD5PyBjXUrK6l4jT/74F1iq5n8XHxB0SDP5tr/9rYgQs4LQ0bu0zPUIkUw+BPpBsEYAa3+n/f1dNyvratreeymFgGf15u4vOAKFI5BCCCCK2j0Kr3eq4jHxjqHtTzx6YjTg8veUqSo30XR3MDAHPF5E7jcAWzwvovdi6ZaYnQyn4QikEAKW6sdkOPr+RfEIWOoE/LteBRVf6QQFxMnPscYrv9WV4zdE5Pm1gHXFyqnQeeoATQmqM6skP61oF1b0p4tEY+fax/xqO8b8/6XIMvhnIpY6AUv1Y+J8NGMEUGJ5rIiweo8ZnPjmjyJyixlj1Fe1VDoV36/b5lx9BfDnaxG4fQRfc4xFkCYt0besTEE5ZnCKQ+DeIvKPCD5oxkMidHK85+QIzBaBW0fGn//cwsOa4tu/GSisrt8Ukdu5YxGTvsYk/KGBbYRAbEn7D8y/i4+eblmgBaZFoKjvRLTDt0WEcNNOjsDsEcBzHPbjR/d0FLb7PyMiN5k9IpsrCF6WgX2I3sf5MUczTnYIsI0fGs76KXbZnpQSQsh7evpU16Tfvve9k1LzH7EI0K/2FJGvBbTFV6u+je6Fe/eLRdu/mzQCaDqjzc8W5utE5CVVIJt9ai3oM026ZnaFZ7JuD9Ka3wxKF7Irmqe0ggAKkqzEcbDT1U4Icrdc+cby37NWwt0f1uTdVZ6ue+h9ONkgcO5qx3Ovyo4fRUHc+OK7g98oMZ/TJgtPxRFwBOaKAFHbfqkc0JtB/l0igsa6U3oEMNu7c6XVz5Y6Qu3e1W7WdTKt9B6u5Jfd08PjOTgCjoAj4Aj0IfA45WDeTP6v9y3/Pqhn8/y0G3YgGn7YdD1gNkh4RRwBR8ARmCgCnCUeZyAAvNcn/4lyQHyxNeG5D4rP1r90BBwBR8ARsECAs+JNK7WQZ0f4tr9FU0wuDZTQQvij651vTa62XmBHwBFwBGaGwMGKQZyBHW3/i8wME69OGAIa98Q/DcvC33IEHAFHwBFIgQBKZBqnIggAD01RME9zEgigB9C1ug+59+tJ1NAL6Qg4Ao7ATBG4i2IAZ5DHpe/JZ4qNV6sfAaw9Qib7rncwI3RyBBwBR8ARGAmBdygGcAZ1PC46LRcBnBJ1Te4h9/Bh4OQIOAKOgCMwEgI/VwzghHZ1z2IjNVwh2e6q4J8fF1IHL4Yj4Ag4AotD4PyKwZsVnkWAmcWBPrMK4142ZLXf9c4XZoaFV8cRcAQcgckgcCfF4E20RY/qN5mmTlbQNyt4iOMnJ0fAEXAEHIERENDEFj9yhPJ6lmUhsJMyHgDmpwSgcnIEHAFHwBHIjMCbFKu352Uuq2dXHgJE2uza2h9y7ycich/3IFle43qJHAFHYN4IcAY7ZLBuv3u3eUPjtetBgJDAlqGjCVd7yZ48/bEj4Ag4Ao6AEQLHKgSAKxmVwZOZJgJEHGwLhBa/TxCRe08TDi+1I+AIOALTQkAT/vds06qql9YYgUclEAAaIeItVXjjUxqX15NzBBwBR8ARaCHwF8UgvmMrHf+5PATQAWkm7BTXD3twqeUxldfYEXAE8iHwb8UgTghhp+Ui8EQF74QKDB8XkVMvF2KvuSPgCDgC6RDAFWvoYLz6nu8ApGuXKaRsEUJ6lae6/v+ge5ucAjt4GR0BR2BqCPxKIQCcfWqV9fKaIvBfIvIbBf90Tfbr7u1jWnJPzBFwBBwBR0B+qBjAr+L4LR4BwkCvm7Qt7+N18gaLR9sBcAQcAUfAEIHPKgbwPQzL4UlNEwECQbFFbznZr0uL3aozThMmL7Uj4Ag4AuUh8EbF4P3i8qozuRKdRUQeLCJvF5FPiQia73uLyGUnVJNTiMirFHy0bsLvuv+SCeHiRXUEHAFHoGgE9lMM3F8vumZlF46V8/1F5Pcb8EcomJKexeYO/JkAACAASURBVBVF5G0iogkv3TXpt+9htUL4YSdHwBFwBBwBJQK33TABtQfedb8vqMx/qZ+/NBD3n4nILhME6XwicmsR2V9Evh9Y13U8tnr/XRPEw4vsCDgCjkBxCJxbOTg/obgalV+ghw/E/CgRIereVImYAbcyFATYBXDBc6rc4OV2BByBohBglbm6ygr9/zgROXlRtSm7MKcVkd9F4P1OEWEinTLtICIvi6h7Fy++YMpAeNkdAUfAESgFgdcrB+W7lFKRCZRD4z8ffY05kAaDRhhAz8A9Uc6BG7wOjoAjMCoCt1MKAEQU9MAtYU34HSXWT53BTgBI7avEAUHgWmGQ+1uOgCPgCDgC6xBgW/rvygEZ0zWnzQhcVYlxs/rlOGDqbpg5ztD6DzhgM9z+1BFwBOaKAGZU5xARvNHtLiKPqFahT6+UpRgUXiEib64UhbBx5/ezKl/irJywt76ZiFxCRE4zV2Ai64X5VjPBxFz/ISKXicx7KZ+9W4lxu11+JCK3mDhw5xWRvykw+eLE6+/FdwQcgQAEcDRyhcq++L71hP5lgxUrg+kxIvImEXlgPXlNXckqAMq1r1xfMRA3E9N3ReQMa3NY9oOLiwjubBusrK6fq83thipinrU2L2QSHpNersAE4YF4BE6OgCMwMwQuVmlLP0REPiAif1YMEkMG2h+LyHNFhK3apQkD7Kj8wADnQ9wqoLMnare7+/j4tyKCMue9q631y4vI2UTkVHUo3fOICE56cDzEzhh83k4PF7vPq7z5nbOz5GlvXm2lLO1yhfxeqlMg+ittfCkRQXi/k4jcp/57TLWz8tiVPxZP8MZtat0JdkH5fmnjXFpu9tRVCMDMbONrAtSEDBoh7xwtIg9YWCxyBogQbPreoQ2dthC4sRGufbhrn+OVEOc9OYmdiz8o8LlpzsKOkNf566MeLCdeWU3en6wm8p8a7iah+8POHS6oMdF8UC0g+E7eCI29xCyRQh8vIt9UDALagW/T978WEUKRnnoBjcN2Knb9m/AIecZW90UWgFdIFU/XseIOwXCsd/5V68mE1M3qHXb5YuvLqncuhDLuTarKPKU68jy4Oppk7InFxeI7dopQOH1YvYPEUayTI2CCAFuSnL+jPGbBrKnTQOkq9+rIBOiBidzLqD3cUcuJwGuCLaXm6XXp/1JEzjSQbzSvs7JdV5a++ywepkr4MUCJmQUGuhwIX331HfP5X2rLDXSm3BPjVLluxHJz3oTN+ZcKZ/RNnYyz3DOPiGHqrDlbPNygfb6RuqATSB8dlk28VPKzJ2bEF8udWCymJgBw5HEDEXlNZZWE3kZsvUv4jqMDnFNxdOvkCGxE4OaVP/CvTZzhm07HNjmKVnMldme0GuucJy+ZMDctfUXX8HPXlQA+uegZinFhKgLA1WsLprG39bva2uIeDq6eNJIiaS4+9XwiELieiBym6OAWzJkiDUyQ5uwC99nKNsNyY6m0m4icoMQvBc8OTTOXhv2BCqw4ny6VTl/7HilVv2koP4S8T6Cm94sICz531VwqZ2YoFwplr1J07BBmG/sdVsl3zYDlGFnQfl9VtB++2pdIrPz/qsBtbJ5u54/zrByk2Rm8fY4CDsyD8M2vnhEftHliyG/8rOB8zZ2uDWSgqb/OObKl17MhTJf7XSRePBHOkVBQisUTnwJLI5Sjprztv9rWaIEPdTA0tM3Rp6EPreYd+j88WgrhCfMdBsdnoXWfynvoOuyfWbG0FJ5YZDlwOjEV5rQo5z9F5MozbGm818Xig4LQUmgnEdFsY8dinOO7OyZuxD0VPPa/hSjkXrQ226M8Odpkqnn8sQ4ChWms00wR4Nzn+AV2BJwXzc15Btq9sYPNt2bK36vVQqMbE9FYnLq+w9U1Dl+6nuW+hzVHyl2A9yrqibOusQkBRhtIK3ebjp3f76rjkUe7G+exWTdN/tdUdOixGVOb/3vSQDpaqpdVtOWRo5U6T8ac8x6kwGcdr2FrfaHaRSvuXUvwiol3uBS0g4hQ33VY9N3Hx8KYhF8QrbVMXx3n/BwB7pZjNqDnbY8ASh9zZtq+uqEENhe6nKItj5gLCCv1uFJ9zqs5t97EQ7hjbhPKmPjwt95l2FSG1Wd/qgMHtctl8RtN8dW8hvyP06qxCA3/uZr0DWkDi3c/KiIXGKshPV9bBAhCYcEUIWmgcIUUiXMegplgE7yXiKAZ3PzdQUTuVyln4djktbVJombV0Vcutr7nYv5ySUVbftuWrUZNDV0I+Jq27Wt/zXM0x9cRPMWK8+MjrTo5CrA+u8UZTixenLeffR1YGe4/XFH22DrP+TssZ4h3kPK4KQNbeBb3TNgxsC1n25XzIxxrsIUYQ6yq+P5pibZYMZ9iJffM2hri63XoYbRhUYShI6M4iMtVlOW+UNvO/k9tUYBSUQlCxIUVbcnW9ViEFQo+GhAMMUdEUPxZFTXt87Vp6iNrf/fscDCJgPWOtUIZeg+sTOGxt2f040/ZThkIGGXGy+ChlWCCP4pcEwPuasHJgoitoQkChJ7EmETUy1y4Lykf2hWB22miCBDG15JhGcBfWIe8DB0gh0DHZIEiFwOwZbm1aeFIhghdWFSMtdIhVnxsPRBuxiB8lGv8F8TWV/MduyWx7qUJ+YvjIVZP7CAgTGJ/jaIVq2QETX4T8ldTxubbr1RR6c5h0LAIaE2aMVf8549JCJQx5bb8hp1MdkAZu1CmJKYCEf3wrLj6x310Jj5U74L+ZKSdpJD6M/ZhUuuhisfkcEXerBRCGnrdOwQIemsdGSvnlhBxCko810PRiPgJeD3j7DEXIXisa6O++2N4AmTyt5ro+upn9fzYTO5T2S2zss4hHO11lUz4MQVvgT0KqmNSznGCXUN2e9hRZIf1GiKys0Hl2QlF4ZQFELtimLKivFuKLwt28M5iUE9PIjMC2MTHMBGDN9vnhAgei8ibbSirAd46Hc7KXlrpM5wnA0B48IotP0pyOYlt/Kmt/L8nIuyy5CJL/xwIpU+vHLzEhIg9t3L1CW5jk0XArHV9C+HibbU+E9vh7FLmJPr9dao2wrc/5qjsIq0ra+r7OKO6Qs7Ke142CKC5HOoYg21+rAfYziyBiMtdesRCdkleVB2PnDExYJoz5lgdjZgq3XnEQSpmEGSlddaYiiq+YbImyE9Medd9Q5wPdEWGEBPLuvRC7u87JLNE77IaDylr6DsE03myiPz3CBN+H0SMhyigvk5ECPIVWier9/CzMKbFRx8+/nwNAreplbDWMcJvqqApjxERFIJKo3PVSnrryl7KfTDE8iHVeZlm2/h8GRv1AyMMTLE88D4RwXvgGMTWfahgHlo/zqJXzRfX1Q0hH4E/NO2u99AzGpvYOteujOlbuMi99NiVGZA/eli3qBVkWYR0tU+qeyx4SlCOHgCXv4rWMBMUPrLZWkeJCO1q7pU48bdbjDKmYmbrdDkvS3F0ggVDbFmv2gYz4W8mU81ORWz9hn7Htjmr11TCWijEKAsOLXvI+5wh9+36sJILSWvdOwQOKoU4rlxXznX34QGUe281A5M3zudRPkURcV19re8j6HtwoVJ6wMzLgQIiCk/WTJwqPVZW1pMuykex5b1tJv7I6XsiFgtWe1rFOSs4USRNNWjjAIrdsy7iLPsoBT+BPfb3pRD1eUNgfVgtEx2VnYO5EThwRKBV/g7tWywiUyx25tYuXh8DBHAwFMqYJbzHedndDerdJPEWRf053klNV5vA6h+LljOlBmJg+mw7p3KIhRlil3Ijbl81fYRdntJwZDcHfad11id4UXz+BqFoYLMV/zoWCp9StnMIj6AImkMRunjAvYBpEUCPIYQhS3qHM96HGsESs83ZYIHnxZR014STWFMHzZVVNiZWpRJmr6lcGuMIqq0Dwtkt3gQ1eLLaLpXQbWCseFblt+MV1Tb1s2tnVFaOk0qt97pyXa8+7tW0d9+3uMee447KOkz9/ggIXEQ5aPUxccrn2PZqiUk2tow4pUlB56/CL39EUa7Y+oR+h2Im2Jdi1bKpDVDes1YKbHBCf6TRCSCf5n7sld0ep+kgwNEAfgu0Sp+b+AWHTIzRTo5AEgQ4L93EgCU/Y2C/hxIVfDrE1hFnQDgbsSI80OEVstTwq0z8KPlZ+8y3wm9dOnhdQzkttp03fYe/f5Q0tZMAuwdO00QAM8IXJ+QxfAW0d5umiZKXukgEWMFsGuBKf8YWL77tYwk/A5o6Xis249Z3TPwvKPisH1e+nAOXbtXSgnS7n4QeTmXWxU6Qhof49m7bldhvTA0BdnDwd6Dlha7vf2DkonpqmHp5EyMw5R2ApqPgSlRjO83Ktklr6JWAS7GENjm2vyWa+KH0hX91wgPPhRigtSv1ofwR8j7uknO6BJ9Le5ZYDxZU9OkUx05E68zpKr1EfL1MxggQmS9kkCr9HbRmYzsHIWhj64d73qFEObG+KGmrn9UxK1kiNmJqyfnmHOmctfvX2PZO8R27K07zQuAmGywnNDz0CeNjx3mh7rUZjMCNFJMfEfFYAbO9ykoRl6mYMZ2hDnKBBitb5CjKoDWMo6RUWtl0Kkz6Ymg/BQbki2lQCDGp3ifRwLA6qKCghhZxE56ZiHn8ESUNO+ODayEE//ma0NMh9S7tHTT2n2Dg6W4V85j/2ZGYgjJlaW04hfIQEwJX0jF8semb1xfgbGsK+HsZAxB4nIJB3xWQ/uorrH5R3EvRMeg0CCND6YYKDMjzoIAMd6miP6YMsNIeMHDI4tSPwBVFhLPVNna5fxMjxGkcBPD0d+PanJEVe4rIfLgWJoyxNV8xbjs5AmoEiLMdy5ya828KThSsTyvy7yo3q9yhXrRYgWmcxqBhfpkNLYGCF1EOu8prfQ+FPXcluqExVh6hwY+LX+t2CEmPtvKz/5UGyfDvrrWZ7epuJP8fksi3BS6FLS1RKOv1M2DlWcwYAaKn/UEx+FloLuNp7C6VljnHCSGDZsg7b4xoMwLYhKS97h221VcHc+rGmfq6b6zvs73f5aEuAo7FfUK0RY0QGNOW7DxpCKET6xHcE+PSGw10YpLcwYPKrIWV3ccQ3Rv6M66+LXVhSM9S4Zewyt7f1zb11gMGYjw3Iel/szK5wZUnQTcIGnLNrdcW94uY2DEDV/ONZRxrGJm2adLWXNHAHdqudzTIG5/9bcrpZhmHIcRWd4pHAD0WXNtqeC/0W4K+xBLmmISu3aRpzvh2idgMZvodUf42YdbVdghXlg6aGHPxH9KVV8w9jhVZyDmtQQB/ymhObgIXhaih28ZrspvUbVbKm3DZ9OyEBMpLONT4mKJM7fJ+aWBLYL6j2Q0hb8KnNttyTzSqR7tO636zlewrgYENvub1HK6x6Tux3t04rgoNSgM/X35NPZd2e+fKffjvI/skQsObqmBHWJBYEFY2sWXpGgPYZXTqQIBBEU3oLtBW72FGdvaONOZ6C219zXYUrmpTEKsbJu/V9on5/2YDC8h2akw+7W8YdInoZnne105/9ffbRATByckOgc8Y8MFqO7X/f5CiqEMVyhj/0HNYOj3ZoE3ZHdJ6Hm3awXK3ibFmtyZhv56IAKY+nx/Y6B9dkHkFSintQWno70ckZDS0cS20szE7HEL44F9VDBqKS6730ZmwjIo4BKe5v/sAZd/YxAMfVowxhFseuoVNWR4/9wYLqB9HIpvaZcgzrJ8sojZiIs1u0JC8172Lu+CpuegOaLb4V4gEtg6sTfe1ijnxJc73JVrinBlvwqHv2SUTFxezOQulLGzchxA2tn11H/P5v2rFr1inR0OwWOq7rM5StDFKW7G7jPRZdJdiynXUUhuyrjfb/zGC0yasUbq00A24qYjQpzflFfoMz51ONQIfigQ11pnMlIDXnk8jbaJYmZruF9mG7Q7zzoGFxC+/pZJOuyza3+iqXGpgffz14Qic1YDvVtuabVpNzIoDlGXCOddSaXcldqtt2fyPNcEeBqBajHOUCR4LdUpmUOxyk8D5QqzdNX6550xnbnmHaxh56FVr/x+KL0IGk97Q8rXfRzGPFcAQ2luZZzt/i98fFBGc1jjlQQA9FIt2a6ehcdzCjoT2aAovnUulVyRoz3bbooSnNRd8llEZ2e1h/ls0XVsBJkpccybCl7aZd+hvttJw8ZuLUOQMsdvdVI+h3tawCAhVHt2Ur/YZMQp84s/FaVv5EOJZ23bt75mAYgnfEoQKbqcX8xvBf4nEIuKHBvj1YY5ZpkYIQGcNHbS+fEKer5ojL67d91cAiTOVuRJbkCEMtOmdT44AznOV5R5qEkgVsdfVrro24bjpGeUlf6dxEMAkeFP7DHnGkaJmYri3QVkY03Ic2Y3TWptzRYAe0l6ad/Ezw0QeSygWWggrWCss0az9JNw1ZmRst86RWAFYhEK95Qjg0DE0NvrsWsQoXz0l4+DBwEP7oLy61MF6BNbqzBIHOpqJoPmWVeGqd8jODNfc5CgCZbMmvdgrgbiWSs8xwG8I7vhW0QgBOFfj2HJInl3vvnapDY5XJM2W8RxNZliBaHz+NwyGw5mxJietjf5eER2CjnyoQWds8Nt0ZWfFwrQoopr+yQoCmGdtaqu+ZwicnAtr+woRC/vy6ntONMihOjArcEz2X/A/zgDDPoxXnzNWaUgToK0pCwqBl9YUYqrfEuihASHmepWpVnxDua380VtovG4o5sZHF1Oa8rx9Y+rrH7KVdrSSp/r48Ksigt6BUxkIaLwBYkGCz3ctsWOn2fVqeO6B2oJM+Hvcvzc45L5qnD2xYGNBoC0zi77F0Z4K4LA7n5tfZQ0ebQYsIXKZJnLg8YqegIMgvm/jYflbYx6mqJZ/ugaB+yjamqBSFvR8RRka3vysUv/Aoh5jpmGx69lgOfSK/hA2/rF0AYUlW1NWdqIW5wpa03HwQz8nwhriHwYDCQxFvOyx6aHKumj85RNo5zfK/JuOuXo999jAev7bIKDZerdwxoIfAo2bbviL73GmtVSir4+lxNv0b3ZwmMhj6ZEG4w1m1IsiTKeaBhh6xf57LoRHw1hfCKu4YZ5SAmHLvFq2If/fWlkJhIAU5oEXVJbLP7dF4KUKPtvHoCj7KvJv+sMcdZmGQPtMAwwbLDVXFNJjd5XRQSIaoSZ/dgEWpQugOa/VThBDGDTlu5xBWq38WUlcNGVhB6b9fUWHsBic8RR4pKIMXZ2Zs0qnchDQRKTEbE9D6IL8Sslf31VMOpqyl/It+hO5wjp39efVe89QAIO7YSbx1TSH/I954iIIiUkz8c0hfjbRqiy3vjQezFIw3RsUnYHIeRZEdDXSGtIJN71L8BmnchCI9blPG2vOfUFAo3/Q8BhKjEsmJtwGi5grfhMIJBbzbdc3aORjWRJL+JLoSjf0HnOiVSjj2Dpk+Y6z1FBQVt9j0iTW9lQJ948vUtR/FQ/+/4rSjjkFlg9T1BGlKEu6l9Exy/MsC+VpqRBgu1YTnEUTqwGzNVy5dvXF0HtfMDA/VAE48sdEEtXG8iBWCj4YiCMSinvfe9+pTEPxMBlD51GatlM2LMFmT0R+62uIdc+nHAMARRNLibXB6D0FcozGRpvjIWu6iIGvgMUp6lg3gmF6uLlu+H/ola1aJo5YQtF2aJ6r7y89GIxGfwMsWS2jhAlhjmcZRwDl0lh6oZI3cDIWq4sQW+bs3+GlbrVDhP4/VQsAPMf9XlHvPnxulb0VN2eo2eVhZZCCWLlpvAai1+BUBgI3UvQlvPZp6B2KvOnHH9BkPoNv/9vg+PPNKzjQt1+sbJdmjD1BYRWAJ1OtUvdcdNxWmmjrX43N+9TCADMR5rBzxf79tFsQj/4L16oaHYcdE9XgMopBgi3n2UvniXC3TpbAUc2APfSKn4pYOp2B6R87oEslVusaF/BNWxN5cZVI+60KvmjS5hrrkIwyaUzcyXv2O40PVzTSS1ZbvdD/mcBYbeK0qM1YKX+/vDAsNP7RU0UyRH9EI5hwlOA0PgL474/tS0TajCWUd2Pz5TsmvyUTHg81+PHtpl1gzu8/ZZAHCoF4q42h8yn1UxifmuONmPyL/2Y/RQPlinEfCyKa5ziGsAjoE9NRtOZNsfXu+g6Fmpg68E1Km1iNieItuirq97Ij8E0Fbz1aUdpDFPnC13dQ5D31T3F4pN0eB8M+/QkmTwuPoO9XAK61Ppq1a2hN5Ccm1xIJN7RocP5OOUDETpjNd0SoKiVELb7zm3INvaYUAHADO7Q8zfuEsHYaFwEU+DS7ODeILD6+JVgZNrww9EoIWU3UwchiF/EZR2cWCtAE/QqhqypX4U3bdh01hObfpBFz1RxThZRv1Hc0ZyTY35ZCdGYUNj6sHBhiGGTTN78VkRK2qjF12lTOTc80Zlp9/KEJuhQ6APWVwZ/HI4DTlU280/csNga7xrSVMj02vsqT/1Jr8w9+WG/Q9qGEsN7HC33PMTGMpW8p8kfQROCcJWm0NUsQALD35BhDc8bdx3ja57jCHVsI0Cj7pBQA7qromFgoLHUVV8pg9BBF+/1CUQlcbcf2Swb0pcaS4NhD6yUP3Icq5qEP8A1Fm5Enir+M9zGkFRhLmOti6t37DYE4YjvS/XpTT/MCZiY3q6I2fbCw1f4mHH8pIpdLA0dQqppz2pQCwGUV/AfefO80HgIaL5ObFMg21QjlUczDNvW3Tc9QTFsiYXVjoQgN9jFBwtAX0AofsS6CcXWscVZVon8XEx5GW31TZ9n0LLdyBG6L71TFDtdMZpvqk/oZka407i01Da5x1Zpy94LzSI0ykrsE1nCF/lvO0mP7Tayntesr8qSsJSnn6lsgLAW2sK2CcmmUv9+kbDuOVIn9EEMfUeRNnIRYr4QxZc32DS5VYzsw9r85iEkCfwXfU5Q1to7W3xEoaIztJI3jozMkbmSNqRArUKdxECAio6Z/3Dyy2M9W5Pt3EUnNz5HVSvbZGQ0XTXgG1XhuxCxPE3sGfts9Eql7KviGfHeLzLfozzTKGamtANjqv5uIaFYZmgGKb9FwRk9Cs0rtKgMKLbkGIjpsVxlC7mHJQDukJA0PpnBVnLKuc0r7vgq+YiuYbdkY+roiX1aBSyJ8oGj0f9pjBG1mMQlqXQ9jORRDCEIaixWLyKgx5U76DUEc2o085HfsFl5IhdAwPVxRtiH1WPcuEa6aLfs9EpTlOBHJ4YlMs1LTumoNaWuiwa1rg777DEqnD8nE3zFHQBP4hd28GCJwjeYc+RExmU70G7yRYsLW14dCnzNxWxCKfJrzeHYQYhdPn1fggeLp7EijHUnQB2tiiwgNU00nD2XoTe/hMvhMK5V7pYJ51uWFRMoKOOX50nUV5T5yBYMU/yKZa9r7CikK5WluRABXr79R8NXrN6a+/qEm7gB98JLrk57Vk51F5AhF+6yOV+zC4ljNirRugmP1OPZWYPLHyuIMPbRZEVvsq40d+v+7DJHAnOtxBr69Q8u+7j1Mk8Cki9A+tuxU7TIw0aYanB6kaGP8KuSgbyvK6AJAjhbaNg+CyLT5d+hv3PjG0OMV+eKRLvVxVkydrL9hEWWpL8WK+4rGhbyyoh3htVgf/dRjKK+238eSYlZ0QwUgnzRCAk9zX1GUo91Asb+xDcYksm9rCS+DqXwOoKCEa1RWV5ZEzIZYXHAUlYNepShjrDOZHPWaax6alRS8eK5IYDTR/4hZMHfiyPJXir7UNU48NBFoGjfg6GSxIBtKKJRrTCFRRp8VaeywtSFZ2fYmSA+KZl2Ml+ve5wZKuJcQkV8nLPNnRARBw4o+qygril45KHZrF5NQp/wIaJy6EJcillD6jB0XxrC+ia1nzHfs9FmPpdi/p9o1eaqiLeGB68WAVMUv+IQi3wMi8yz2s3MqwIDZYj2xXTjhdnroAIF2LDsgMcQWKHb9oXkNfQ+7U4tgJZxZaSTea8aAE/ENg0yMgk7sWWBEEf2TGoGLKvn+BZFIotTmuiLbg4cS7JuVbdI1PiFcpwxrfnFlmYljE0OaAHixzqtiypnlGyYIjV1mzEr1LiLCBNfFdDnu4RcfzXMtocFvbR64Wn8kzlghi/rhxW81zSH/o3WdixAKcfQRWj40nGenlJMLbEU+mEOFtlHXe3jxjCH6W1d6IffQOo/ZMo4pZ85vUPD9sQKXddihCxXj7W9o3b+mKDvfxtBtFHkSWXZ2pDmLGbINc5rKl/NrFeCvY9aQ+6yC0eK3dh3LoKTRhg4pO45yYmNSaxQAcV+cm4j4Rb59uKCMmVM4yY1DyflpAqsgMMc6ktEoLM/tqIhV/4uUOyLr+hiuflHSy0Eofq8rR999LKiYU4YSC42+tDc9x7fCrEjjIvH+gUggTWqkvU0NsukZ2uV4LDxdYDljXoOhNGeTm8rfPEODmbCaQ4l4CU0aQ68HDc3M6H0CtWBj3rXdy+D0LMUkYlTExSaj3bbFvDaWnqDg5bl4jOSoDEU0VuhD+3PI++yUEFU1F11eWQ/iCwwllKw1x6KprLWG1sPsfY1nphBfADj1CVnVhTBoyDto0+NzOoY5YkHFq1nMGXZIfZp3OKoZopR3SiWjjx0yFXMmdjCeWSki7Ssid0wsyMW2/ZK+ww98w48xVxxqxZImcNkcvLhdp9JZ+qIS/01txoqaWCs5ieNNonpuKtemZ7HeaDWL0VgX1jlxHZSXJqTnl3tyQlplQt7UiFbPOAt7lMLFaE9Veh9zxnhghrqyAg4xFeR4RoNtDi+FvaD6C8UggAnVzxQ8xeoSp0+xpNnNmrL5Fuf8WAZp+nLft+y24St/DPq4om5viywwO1F9mKx7nisGTmTVhn92bQUYTO4MDF30JEW668Dvuk+UK0ITp/Sm11W/dfdYqWqC73TVcfUe9tB9Sk1oya5+F/o/7dqX/rr6+/15IoBVSij/dL13iBIWTQwAJtEpEX3v7pncobPyv9eI4GAK3sUvIfdiTUo1QfA00RBHhHl91mxfh4C97p1VxTpWpy9Uprkur/Z9C2I84wAAIABJREFU3FNiBlbKxN9GGJ0HSz/c7Xo3vzly2BRQhc7RvDv0im8EJ0egjcChCn6C/7QrzN8p8k8Z0rqNkfY3nuaIdphasbgZDxD0b6cttPJ7jatyyh9jCURMiAaDoVeOomZHmq09jhAaYjcghU1qu5EwIcRjXokTf4MDVxgTxSVr5xxtLFA+vFA70/q3xsET6RMkyskRaBC42BqlzDYvbvqN8qbWphxvnZvyWPeM7e1Yy4Om/qmuLJZQhCOwmsYaa13dN93n7H2IFVcqDNCq71L43VT29rMLRBRME9wNBeXZ0fsjOxcN0Wj2otChiRDWbtSu3zAJQUSm5vr1cpWUrTGd6sKifQ/hDe+EbXquoj1Je3Y+r9vg+O/BCOC8p81zQ38T/EVDbIkPzbN5H+GjFGKMRDjHvS5hbTW7Gk39Yq7oSzEulUKaBWiMMzdNBFJ2wmZHmiAbMDGrcW2Ep02MzPkfNuJTJQYwJuXYVcwmbHiGa2K8E0IMMhozIcIgp3L/WRfRLxNCAJtzrdfLmyjrS4yOvj6w7jnOpcYiQt/eXkTQx0GRL7XjsHUYtO/jGjzWr0gqHDlybJdxyO8YpTxNMCLC1M+OdlM0AI2l8Te/qbHRHEbpovTt/lCGQOHyOCXW6/BikMbkksF23Tsh90NMO0Pr6+9NH4EnK/mJ1R1CqYY0LssRaHMQRxycZ3Pshw8NvMaF9Lec73B+XeJYip+GWByeHtG4uyryi/VAGFHMfJ/gUSnlWXVM46LEZh2GMh+i63PCKRHmKzGY9H2DgwttZEUC8zg5AiAAr2otWvDhoCX0XPp4f91zbdCyrrI3W/k4QiPKIA7HUu3uravXkPu04e5dFSnknsYS4DURddDEszgqIr9JfKLZhhnCjCHvvrpyALPDJFCLLySaqOxwhOCR6x0cNmlXa/GI+JelIaD1+w9/s3rXEiHDY/uA1YqNxQhOqRgn0SuILU/u77BG4iiiZNK4ef5ARMVQHIxth2Mi8pvEJ9qtvlhA29/Rse4xCbRsCsnRS04viW2su37jX9zJEQABVv9aJbV3GUGJfksXv4bc63NW1ldEtNRT6jeF1CHmHfQNsJaKMZPrw8T6+bUU7XtYRGEQiGIw5RuOcGdJnB/HgmLx3Q8qiwLOZpZG5xIRQhNbYKhNIybewNLaayn1tXDkhftaCxpLAMB8kAlG269yf39w5ZU0JlKrRVvFpIFFQixGx0Zk6AJAB2hs/Wol/thGxKnNkqO74bcfE8dY/Cy+QwBz7f+OjrHAW+cwCNnN1rsVP40lAIwVvTS2P7M6xepgarSLYuxjB3UouQCwBjGNNmYs04a4tV1T3FndZrBEYSoWR+13j5kVml4ZDQIE09Lyk6XS2RgCAKZiGgc1WvyGfM/Cje3+qbrv1lh5YP00lFwAWIMYoSCHMJ723ecHBrZZU9xZ3t5rBOXAv/W4FZ4l0F6pTgSIoqmd+NC8tzx7HkMAeEvmsTBmLMWbH8HB8JMwZcLXREz9+Yaxayi5ALAGMc68NLGShzQi7i+duhHAFE8TJnNIO/DuXOKld6Ppd0MR4BhQE3Sn4Tvr4DK5BQBwwOV4U5/Srjj6wl23JrpiKE/keA8X8rEYI6wOPWpyAWBDq75R0RihjYiCkdNmBPARnisoyJS9LG5G0Z8OQQCvaqF9eN17nENbO5vJLQBoY2msw0Z7/4gqJPN9JrzVv4kXNX5o0KEaQi4AbEDr+gaDwCZGn104xQ1Yah9dSunWd1M7NM8+qS1kYd+zhY3b5Q+JCCFoDxQRjlUw53JajwBa43806PvaqH9dJcwtAGi9aTZ9y+KKE5+XFOa7v6uNNPcIiqQ5dhp63OQCwIbWAkzcZ1ow72oaMLLTMATwWnV8ovagfebi+e/CIoIws8pzzf/4hEcQcNoeAba8scRpsIq94hFv6GC8fWm2v5NbAECTPhYDi++I7YEFws1nutpfbWHcKMfi9o/VxAL+dwGgByQLG+CuBi0tCEUPDMU8xnNVChNNS1OtMcHiuIRBs4vnVu+hNOW0LQJW1ie32jZZs/9yCwA3DuSlVd6K/Z/tbwQw9KJwDpZCiDJrjAQJ4QslFjt2rYaSCwA9iDFR/13RKOsa8w49+frjbgTYvkbSXYdr7H2sPqZOKEIR3nQIBvhwdzoRAY5M/j0Qvy6sv5AQ0NwCQGqnaAjzH6nNfjlyJRbLkuliCv5DIXIouQAQgBhBLro6uubeKwPy9Ve2R4CtQA3uXd/ifXCo9uz2JRv/DtHAuuq36R7C1FXGL/roJcD86kcR+K1iSyCcKySsTW4BQBN7YBUbVveEkMXNNj7vcXozh35n2dwoIa/iFvo/x05DyQWAAMRgVIuVQbshZxtIIQBPzSsMHm0cLX5buWnV1Ev7LcpDsZYS6LnsrC3AhL/H9OpjRnxFmNmUlFsA0DimoW/iQ+ChtZA5Vec8KdtzNW2NzsUnVhML+N8FgACQeMXCI9jqZMV5ttMwBL5nNFA3bRETQWtYifO8fQklLoeKCBPhEomImw0/aK6/ymCPnlsA4AxeE6nz3EtkKEWd8WkQy4NvjsjXBYBA0C6YQBfgUYF5+2snInARRefo6lR4zqJd50DXM8AGvxdL25J9ggFuDW/liN6ZWwCgb+DPoKnj0OsN5tC5MtYBU92hGDfvHxBRThcABoC2v6JxmkZqX7XhOQcUfRavamOyt7HnN+nNhYheuFq/mP9jBpGpYngnpc11G1+OEHIIT2MIAJ9T8Bbb/07hCHxRgfUDw7M56U0XAE6Cov8HGqrfUjRQe8Bofl+oP1t/o0bgKEPsCRM6JxOjMxnqqSwhGNJNDXf0CMKSa6t7DAFAExjt5T56DUIAHx3N3DD0ihXFUHIBYCBiTNhDTa02NSRnPk79CFi6JMWxyBwVkj6uGDzaPIonMiKqzZWIzqdxt9rGit97ZgRqDAHgcQq++mxGbKae1fkUOMOHMUKoCwARXHMWEXmXiGDyszoYDP3/u5m2DiOqWdQnz1ZijXOct1Xa3myVz5WubrilDR8/c4a8eW/DnRIwOigzM40hAGhMb08QkaH+6TNDWkx2eyjGOALXxRxBuQCgaH6cNqDIp92aRoHLaT0CrNZDvdt1CWBEE1yKgxFrM8nXzOiohL6q8bO+ylvsBJ55PdsmeTKGAIC10mrdh/yPgyWnfgRepcA51vmUCwD97dL7BluKQzrE6rvv7c1h2S+gXb2K2ZD/MeFcChF9DsdGQ/Dpexd9CXQMpkqYN1oLRjhQGiNy5BgCAD4mCMTTxyfrnvsxZ1jPYTd4HYZ9918QlsV2b7kAsB0kw2/sICIoAvU10rrnOBmiIZy6EfiqAlswx5/5koizQM2OSRefstrFLezU6Owiwjl0V50092I0ri2wG0MAoNy4643F66MWFZ95Gric1+xO3TUSHxcAIoFb/UzrTAQ3rk7bI8C5duzAw3e/FBEivC2N0Ai29l6JQ5jHRp41joE/AXmsBSF4aswdpbEEgCcr+iFHcHNUurXkaSZwzTiHt9oYcgEgBrWOb66lbEAiORHMxWlbBN6vxPWF2ya3qP8eosRu3YCEtUHJ5qucy6eI3wEenxl5MhtLAMChzzp+CLmPIqHTegTeo8D35wqh3AWA9W0y6AnnZNpgIvsNynH+LxPaVrMtxsCUMjDLFFrgOYqBZdPAjhfFpxSmXIlfh/uKiMaWelOdOaMdW0gfSwDYSWk6iemtUzcCp67Mbv+q6KcxLoCbkrgA0CBhcH2SohEZeNAjOINBOeaSBH76Nw3Ifc8OmwsQinogmL5dieMmnFl9cB4+pqkX5k+E19Za42yqJ6FWS4jdMZYAAAt+SsFHBKpa4lFcSNe9jQJXePaeIZmseccFgDXAxNzGPwB2r5sGkr5nT43JeIbfWKz+7zJDXGKqxPkrkcL6eE/zHEFgbxGhD+QiTDvvV03+30lcN2LWXy5XpXryGVMA0MZNmEPUzZ7miXrMCl7T984bleuJH7kAoACv69NXKhsThw6E4Fw6ab3a/UxEMIlzOhEBthlTCwEMYpjHvU9EWNWQpzWxo3HtyusZ/gk0ljehAy6TP5NuKTSmAIBQHopb13soSjtti8COIoL+VxdeIfe+uW1yg/9zAWAwZJs/uLjBuTVR2ZZMt1Z0iKbTcBzjtC0CTMiHGGDbYNx3RU8AEzAc8FxTRDhHHkrY8O8qInjw4yiDreS+fK2elzb5g92YAgDC108V+LO4Oe1QBpj5+/C1hl+1emMuACRgMI3NLMyA4tuVE5RrCkmyXX2MslP8XUR2nkJlRygjQgCTsmbQif0W19lH10IISmHPqALy4Gf+EbUeASaG+1be9V5cbblj/XGkYcCeoWX+lYiw4i2NxhQAwIK2GYpl+32UNJ22EPiKEk/t7pQLAFttYfbruspGpcPgzQ2Je2mE17D2gBHz+yVLA21gfVlVMwHHYLuEb74nIhcciGmu18cWAHZT8g0TntOJCGiPVI5TmP81beACQIOE8fWTyo7CQIsd95II23KNOQyYoYR5jiWBpqgrxyRaM8u5CQSfK9zt8dgCAKaWONfStLt21apg+aI+1fj+B3+CdWnJBQAtgmu+x22qppPwLWdmJZgerami6W12Oz5tgNkBpqWaf2KPMcBcy+elfI81Qeke68YWAOgRONfStNlb5t+temuItQzjuwbHS/Tm0v+CCwD9GEW/QRAVTQPzLTsJMWEeows90ocWXuvoUPjUdgpHQBPqVcvbpX2PnXvpVIIAcFnluIaL6pI9Sebggf2VGFodpbgAkLC16SgWW6xjBR5JCM02SXPeqpWGmUz+Z5tU/Z8QBFwA2BLSXQAI4ZgT30FBUyPAvSw8q9m9eXoDE1ar42EXABKz11uVHYVOhjnVZRKXc6zk8SB3uAFGaG27F8XhregCwNZE5gJAOP9od+wY084Wnt2s3sRhlkZ4Qk/KyiW1CwCJWetcIkI0LE2D8+33I+2oE1dPnbz2PLHBdS91SZaZgAsAW33TBYDwPsAqVjuuPTc8u9m8ifdKbYRKS4dKLgBkYK1HGwgATHQ4QpkT3c4Ily8v1GTSghdcAHABIJaPMLdtBPCYK14jSzW3jMWk7ztNWOUGY0srChcA+lrM4Dl2199Sdpam8R9pUJ4SksBjosYFZoMHzmVKdNhSAsYhZXABYGsS8x2AEI7ZeueiBjpOmkh2WyWZxi/Mk7W6Tp83rqoLAMaArksOV6gWCoFMeLdcl8lE7uOl71gjgejlE6lzqcV0AcAFAA1vfljZjxkTLVe0mrqk/tbC+Zb12O8CQOpWb6VvwQCsfJEisTCYImFn/QXloNGs/vFLbqUMM0UsLcrsAoALABo+YmHT9MfY6xJMnRmvWbzFYsR37CJbm4S7AKDh/oHfnk5EfqRkgoaBjp+gkyC8iFnFpmflcKOB+Pvr2yOgEQAQ5AgRe4QRTze8HXMlSBDKURoNaz8C2J4/Qu58xqD97xaS0UTfYdK28Ax71wT1dwEgAaibkryWgSTYDJA/rMKinntTZgU9w9Pf6w0GiqbuLy2oblMuikYAIGBPQ3isRNmVSRR3zE07pbx+tzIl4wjo+iJy8rog9K/YPF0AaFpz2PWGCsybtsKM90zDsp3M21goNfWMvf6gxeOWFXcBwBLNwLSeZcAQDSNhHnj2wHzHeg0J+JXGdcacxkmPgJUA0C4JSq9EsyTK37tE5Nu1L4uGZ4de2e1hx4sJGtMxwkWvi/boAsD6yQZrmVT0RYP+bWnelqqeQ9NF8e/3BtjcZWjGge+7ABAIlOVrOL/5ugFTNAMpPsxL3Qlg5Y/Xr6as2uu/Fhwq2ZIHm7RSCABN2u0rQiA+MTgzvruI3K8SCgj/+1QReXa1+ntRKzzwQ6u488RJp2z4Ox/in98FgPV9LaUAoMG9GRMQ9Ig2OCd6r8HYx1yRKjKsCwAjcdvFqhXSnwyYo+k8PxYRTOtKIgSddxrWkbo+qqQKzqAsuQSAXFBpJiI/AtC10gcN+johbnEyNAe6gwEejHn00VTkAkAqZAPSvZWRaWAjBPxWRK4akG+OV1B4tFB8aerGFQVCay3YHFiUnIcLAFsrZhcAdJx6aSP9JtynT52YWBmP2+NXzO/UPOkCwMictp8Bk7QZ6+8icp+R67SLoeOjpm5HVee/px25XnPM3gWArUE69WBrwT8lRAPcVI9XGI1nU7YKQCH1cwY4EDVx101gGzxzAcAARE0SnO1YhA1uJsrmitIdW/C5iW0vrY/wpg7NFSWaC+euyELycwHABQBLVkeT32Lli5fQi1gWLGNaVkreL85QZhcAMoDclwVnXmhKNxOe1RX77Ev1ZW70fEcR0foG76o3Sn83NiqjJ7M9Ai4AbPU73wHYnj9i7qDg2dWXh95DuXlqu343NTrWJWBQDidnLgDEcHiCb9DiR5FvaCfpe5+AG/uICKZZqeh6lWY3Pgn6yjL0OVrBaIw7pUPABYAtvnUBwIbPcPhlEeKb8QJfE6k04G1qu5UKStgWJn/Ue4+tZJP+cgEgKbzDEoeB8Gg2dKIMef+bIoJ0akk4f3mTkcTbVQccyzilRcAFgK3+5gKAHa+x88jio6tfD72HnlTpZBnf5CMZK+sCQEawQ7K6SuVR7a9GHaero+G2U2try24F2/3/TFjOA0LA8nfUCLgAsDVJuQCgZqdtErAIfcsYxk7gvbZJuax/dhARC0dI1BX9qfNlrJ4LABnBDs0KH/d/Szi5wmicrz2smsjPElgojhCYLD5Q+VtHO7VLuLC69xo39wtsFf1rLgBs8bILAHp+aqfwX4YOzxhzbttOvJDfHHfg7dJq7HtA5nq5AJAZ8NDsrmsQOzqEKYlQdWTtYnXP6uzuJiJy+XqX4M4i8sTKt8DHMpWF8rKz4Lb+oVyif88FgK3B2wUAPT+tpnBJw9gQmDgzLpZCTP5vMZz8WVzlHvtcACiFmzrKcbVqlf4HQwYLEQjGfOc5I3SADtgXdcsFABcAUjP8Aw3HMLbIUToem5j832xYr58P2I21rLsLAJZoJkgLxx+pFAPHnOxX88YnvFN+BFwAcAEgNdexqj3IcLJkJ4CAUGMRjn4sJ392YYmoOAa5ADAG6gPzZHJcnTDn9D8+EJzGQcAFgK2+5UcA6XgQm/ZjDccx/IOMYSKMi/OPGtaDcfwp6WDvTdkFgF6Ixn8BBpnThL9al2+MD/FiS+ACwFbfcgEgbTcgVoC1hROuh1P6OGkjcv4EDtvQr+I4YSxyAWAs5Afk6wLAALD81UEIuADgAsAghlG+fNcEi5mPi8iZleXq+/zaIvJL47Ifk8nb36a6uQCwCZ1CnrkAUEhDzLAYt1AManhpK4004YA/XVplOspTejCgjiJvd+sZCp5b3T1s/ieM8A22y0l/Axv/5xlFOWzKyhWPgYSEH5tcABi7BQLydwEgACR/ZRACRGxkYNO4Lp2bAIDDmUMrHxkEtMq1rTyo0So/HHMQAFAKfFsCIYCJ9UARISCRBV259pfSnrgtfuMh8ToWBTRIwwUAAxBTJ+ECQGqEl5E+2ss4UznEyH3z3ASA9uD+s+psFhe0eL0sieYgAIDnqYxC5rbbrPn9q0rXADfiBCiLoUtUQdTebdRHmjI119Lim7gAEMMhmb9xASAz4DPL7pxVfeChnxqvuvBWyWq5FMIf+xeM64gHuvfW28u5nbR04ToXAYC6naF2QtZMjtZXzKdxR3zBLiBX7rHjgwdWHPtglmddlia9R6zkO/a/LgCM3QIB+bsAEACSv7INAkxWeE3DTSkmU80AZH1lRYO3yLEjthF8BqUq6/q10zu68tX+SMMt5m0aLPCfOQkAVBlX5Lglb+Oc4jfB0NA9uGctzIEj2/D3EZHXishvM5SBcbw0cgGgtBbpKI8LAB2g+K1OBFhVEePhuxkGtPZAzbECOw25CUHnIRliZ7Trys7H60XkSrkrOxMdgFXYziEiv87Mr+32zPGbnYUSyQWAEltlpUwaASB14J6m82i2zdwPwEqDR/xL/AaCKFnbWTftG3L9XT0Z51Kgu6yIoLkfUrZU7xxRR6o7TUSbxXwytx2ABgPGgFRtVEK6Ja7+wd4FgIYDC75qBIB9ReTGtdZtigiDX65cFT+oDh4U29FcAIhjPkyU7lEFcDq8sMGTLd07iQhKhykI86nXJT6rHcrLWFO8oOpnF01R4VaaLgBMU1BwAaDFxP5zGAIaAQAlmIbYHt69PvM6PnLSOEFEPiIiD18Z7DiDHTpoNu+7ANC0UNj1InX0RlbcDYYlXn8kIo83im+O1jj+37E80Ow2pcapMSW8fSJTQhcAyub5dfzlAkDY2OZvdSBgJQCsJo1rSzzBPa4+03yfiHxSRL4iIp8XkQ+JyFtr5Rk8eF1ORE65mkj9vwsAa4Axus1q+jYigtczJpl1A02J9ynvYSLyP7WmdYjXNmLJw1NEknv7RKNiYkpIHI9zGfEAybgAMC3eb/qjCwCGnWBpSaUSACxxdAHAEs2ttFCQ2qc6Z47dsWkGoNKu7F4gaCLQvFNE3iEiH6wFUILG5NJdyYELVhjvqYTq6xuEu3YBwAWArdFB/8t1APQYJk/BBYDkEBeXAQP9G0TknxNb7eeYUKecB6aEj1X4rncBwAUAy8HKBQBLNBOl5QJAImALS/a0tV0yNstTnuS87P3tR0x7dj2uN5AHXQDox7ZE/vMjgIGM7q9vIeACwBYWc/yFbgVhTf/iE/8iBR9MCXFIE2JK6AKACwCWY6DvAFiimSgtFwASATtispjw7Vkrx5W4YsnhGW2senOs8ucChS1MCZ+/Yl2zyqIuALgAsMoTmv9dANCgl+lbFwAyAZ0hmwvVVhUlej7DTwR6BzjYweyO32NN0qnyxT88LmB3qlfdXyu0jihI7tFhSugCwDR50o8AMgyuc83CBYBpt+zJRORWIvLRQk34vl07czrdCsy42cWOv2S7+yGCwlcrB0LnXakj/16zNnclTOuQ9HK8SwAnnHk1bpZdANi+jb6UgUfZndHo5rgA0NHx/FYYAi4AhOFU2ltnrwamJ4nITwqcWNgGx75+twDQUFQ7rsA6hE7ACDAvFBGOXTbRWWuBBwdGoWnneg9TQkLUEk0uNk+8dpZKGlfAmCBfoNKheHaCoD5fb+ln4FQtFnsXAErlvAmUywWACTRSq4is0ko14WNFSVS0oXHusVBAUXFqToh+WG/5t5qn9yeRDRF60NKfkz+COQsATaOy23b12i3zjyMnbHbEGHPpx21yAWBbAYhFgVMGBFwAyACyMgu2z4lKlyO06dBVCCtg3DffUkQYIDVEiOFSz83buOCyGs+DIZr1m/BgZflMEflV5GTSLtPYv5cgAKy2JYLuLWpnWgfWrqQ/Wzuh+kQdLvtldd+9RuViG0F3HbkA4ALAOt5Ich9FLDTFj1IMPu1YAEkKWSeq8QSI+RtCTnPOmbKc1mljwvfKwk34bmhcaVbIKKiVeCzAip2oiJbud4EP98WcA489iWvyL1EAoJ3QcdCYwDL25CCNAMAYzljedwyVox7tPNwKoI1GIb/RFH+O0XnWFASAZlBrzjnZfkUBrVQi3O2dReSLE5kQUJJKEZmPuBB7VUF6OCdt2nCsK2Z9LxERAiWlIFaPY9XNKt9SBAD6Nm6RcY9Mn9fWbwoCQFNHzGsZ2y+cgkkj0nQBIAK0FJ+0NcUtta5xMoI/+ZRE2QmF2jC5xfV7dcRBIhiWQkx4Dy1Uqa8P8/0Sg3jtWqnwr8Z80FcvhI9HVfbzp09YP4S9vnJM4fnYAsAZayXG7xvjOSUBoOETdGmwCsI6SHssp2F9FwA06Bl8e7ZK0WhvEYlVWGkYatMVxS/rbeCm6jAQZ2mb8tc84yz3tSJyhSbDka7Ety9xyzsUW7bGOeNMTacWEULhYmGQwpkQK8bDqxgJT0i42m9jRMTMPyTk79D2s3hvLAGAvksfpi9b1GM1jSkKAO06YCWEtRBWQ7nJBYDciNf5XaseJHMFe0HiZBvT6myU1TAmSX9M1KnbHaT5zQB2TxFhkslF7J4Qg74pw5SvmLfhACcXsdV7idqM6vVVKGCOIoY4QMJfPkqV4I+OCNvGO+YqfBXKF12Hz82k7eFbTO1yHa3RR+mr9NnUfWbqAkCDD3MBlifspuVqJxcAMg4oaJg+qFohYWbSNHruK1L4Syvh42KR9War9ZEjr4YJJfu8ynnLLpF1CP3sHjNQ/Frlr5eHVj7he1hMXLoKBXy1elJnx4C/m9Ume5hfMTAxAY9JGpv7VdxL+f8Dla7EWRKCSp+kb+ZUmJyLANDmEQTfB1dYrjrnsm46FwCsEe1Ib1cRYeAtzf/4kbUGLisrtJy7CK1VBmRM3A6uHKWU5C2NXY1DKg9dtzVWckNQe++IQlp7IKCOH6t1DyywJz1M+Zw2I4AyodWWNd4UnzVw96PNA9a/fx7oAGozQltPUTClD9IX4S/r8valhzCZgzTm2H11WPcc6wisjHDPnYJcAEiBqoiwRX7XaoXz+RE6xDpm6rvPWecxld0sLlNR1EF3oO+bUp5TVgtTQiwwSrDl5/z8gBVtYYQwC7xxjpPzKCBRF0uWLDsPVv32da1SYtZ7NxH5glE7aniB7WYiEGoIs1363NjjRC4BAHNFDebab7E6wvwWPrIiFwCskKzTQWkIT2tzcByiZdgxvkdJ7F31KnfoORpS9i9G7uSH9dgLv9OofC825vs5JYelhwXvYqGwTl/lMoWEgGZnYkg/4V12kOhjFiZ8Fjizw5qDnmrEF9o6E9AKt8cXNKi0CwAGILJi4PySLXJLEz4toyz9+yGmhEz+Y2l7Yzr36g7Xo12syZng0QYDEXw6tmVFV/3GvoeS7J8M8EU5NsQnAe05tl4QcRL6hAB0fx4mIt81wMZ6XEKYykGlCAANfhYePl0AUHDOziLyOBFhS7VpFL+WhwVnuXiHu/yatkaSHmMnsGYEAAAX5klEQVTlz2DKanOoDfsVKzM4C+sRfESMaYO8pjlGvY1zGos+zFbtUCIwE+aTFm07tA748egi+gx9J7d/hyHlT3U+vooHvjSGlCvnu5iRP7HSNcOsfAi5ADAErfpdlOIIjGKlJJSTUZaeF3HWOftsfMSjEc1OQS5csMdHE1vr7XAfozIjgDidiMCNjTBle1xDRCV87AgLCxwqQegvYZXxcSM8UvetXALA/hPAY+j44gJAzfR9F5Sm7leI29PUHWoJ6WNK+Nxa4TFHfY+vA5JYeWVk5W6hqMZW9RgOSPr6W+7nnNVbOHpiJWblvZI2JoATgZxyHC2Sx5sSOXBK2ceIx5GDpiAAtHHG3JzjpU2mhC4A9HDOJWsf4zkd3rQb0X/nW51bY41JFKuo2xibKTYsS6Q6C9PStqZ6k/bSrppALw3f0N7XSQQc1ikofqEA1uTn1xOxWA3bm6gJ/i+65BQxZ4xgx7pLV8IFgA5u+a9K2eWOlUemTxfa2XCFipMatpFZWU6BKdEYfrSI4AHxbYX5E7DGr9ldCFEC62C/QbdwFqItPyu/XIPooMplepmQsRZn3DjYSk2YgN299qqobfe5fH+l1KDX6SOATR0zTFAxRW1MCV0AaDEPYLDNM4ZCWB9jMUB1KbKhiIgDjr7vx3yOkLLqhx5lFZRWLLZdx6xbO2+UQe+bOeQnFijEN2+XI+Y3afRpgre6yqx+vtkAv9xulmkAtr7RNxjD+U4Mj6X65uqZuPH5BnySCoOh6eKS+5n1gmzot837jN2zIOxI31KQXWsDMFc0xTG/2XSuyCRw/xHN2Nrlbf9mYHpVT9lzn3O2y2f1m3Pfe1fCI2GCxyDcr/7NYHC6wxiFHznPKxtMoPA53jTHIhzhWFkvWPWJ0HTYffpw5eDmWAX/pjp2WW1PdnhC67X6Hou0Ek0oNcLj5AWA81b+5N9qMACsNrb2/1hnNnjmQpChU2nLoP0eN8Ns9w8hzPFwTDKlc843VMqEuA4em4iOp20zvD+OJcSMhd9nDHArRYcCd7xT6TusQOnrjTMbzS5mqkinqzzJYia2jz2g3mErzYlSbH34brICAL6rsd+3WDVpAFz9lq1ylJG0muLsaBBBTSPdrZYt9P+jKle6rCQ128mcT2FHjevL0Hxzv4dSaEkrZvRWwF6LA0cYS6GbGuCFy+aUwXWGtgVjx6EG9dLy0brv6dPtM+imfjhRW/dN3/2bN4kkvhJNta8s657vtVK2UtworytvyP1JCgBo06JEF1LBHO8wSSP9Wge0gd+I+PeiDCF72XHAth07ao4jLAkbX4JhEBQjR3uE5MGgX6IXPVYXIeXf9A5+3QkANXeCT3HVuwmLkGclCkwIg+gGhJQ/xzshAW00RxhY2eQgdldj8SIuTBeNHUgptj58NzkBAEkxZ5jKTeDmCmkL0+H05na1ja9V/TmmQHDBzhT3qakJW1Y03scO1IOCaK7wozGYYmGxie9Cnj0mJuOJfcOAHILFpneI22At8FrByMTC8dSm8qd+NiSkrYZvsdjKQZo4HIy/fdSEUmZuSN02FulPSgBAka6Es/Evi8g9NwQJ6WMS7XMGBlbVDxQRtrQwC+mzesA3OqslpPS9a1vnHbUFUXw/lstUjozWuRNWVMf0U7YWtSZtnM+O2b6mgHQkhuIp+g6aQZCdO1wyl0zU86PKeg7FCDfGuDOmjw45BtRsr3OkkIMOUmA55JgCp1TMEcwV/3975xqyTVHG8fnUgU6SVkRFVmhWRlEfwuSVirAsO0iRSWoqiJ1LU9BKKzqYvYlpBYYVpRhEB99As6JIrMhC7KSVphVEimWURXnADz2/fAbmWfa+7539z8zO7F7Xl91779ndmev6z8y1M9chlv8lyzejAJw9MSMJGfyFSpeNfcdh2ZcQpASXQUHYb/vLfl0UKX/vVEdcCVFIsMIvAXws/VugFGlLidkwV0rx9X9JI8zZeyu7JC6KufsHfZC+ODaqJNt8Y+uopjUeKkpFmTp06Es65dhqZO6oMex8EwrAlBmcYrLRdeRuPyM4UMKVsJUBH7bx9X6rMKAyELMqNEdbAJbs1W0kVlhKbHtFdIG1RZlEcqTuZRWESfHVCZJKYas0VgEopaxeI9TxkLUS2vwnbuAnF85bskke1SsAKaKkbWJC93862tcTJHvZDAkr0ceBHCFTsfhndaQlYgmxi83Y33NMFHRkAr6wwtIaKT7sXdxgBPuJ7VXCVHxQ4uyTpa8EKV42qRIWsa1CBFjmmBxKXVfW635XrQDgG1qSQVhPMzCwB2s0PQe8K6GitXvwt2gUx6rI9eJkh1sqFuVzIQZP1fL/r43aR+Cq+E8RD6SPPi7TyhDZD31/iz1eUAigyqoaW6upibmGOYe5J5ZnKcpXqwCwPIeWmqKRQ59xVYJlsNQAsefdb6WtJHJiEiQ9aouEa+lQ/K4qV8rAqgR/2Ydd1c6h11mGbZXYox/azr5yZEPNRTy7751Drn0xV6U6z1WMa7HFyEUE78LL4PuFY79UqQCwx6dElRoCuFVlSi1F5QLSHJ9LNsdV8hpynaXJVokv3uvE9hPRcS6kGHGBFZRBn0SlRZ5goKesihI1NRcdJeD0slyVCp7LStiQ8WJVGbyvStABzjlyFqRy917VHq5XqQBgqb2u0jn/w81wypjgJQDW2jsUPGDk5EOVttZuX9/DE/SHUrHWfZ1zHImXjzyV/p/zCzhHm/ueuUfgAZb+uUiJykjkw9zEFspY7BAIqTThSkj0wWuFem9qb3UKAEIqvfTfZRLW02NdYUqDZAnvw4WmK6Ohv380Ewap/sSXz4APLBMPlXtfOSa/OdhDEDWvr31Dr61LSqbAhIx+Q+vQLYdtQm7CuLj73qG/sR2YkohXQZwFYjQMrfOQcv92zlXlJn5+4gYOYUJfGTRSjLCMpufAjwVMtLz8H3JetQVgZavllZB9EuT9eEfI0IbP4YWyEhKb4Gsoq5StOjIJ5iYCgPWN9UOu4T1QA2GIyAdRyoB4Z9XQMOpAEoyagiV8oBbGLLwe7NsO6aR9ZV42E95hF3ODwAd4Q+a2Vgkvjj75Dr1GZETCac+FlLS0x2digrLEfndk1MExTThCwFCJLYqYNh20lZDpFqE9Yb/BsyTXqlBMm9y5iRr0x0TPQcuaw95plBAqK4zhzX2CPB9ZWXuU6jBwhx039pxJsEVvCJSfm8W2n6EwvsJ7SV8cK39fHk+CHITB6j1CvYgKmpNYAfI8iD2SRKg22iuhsfzkcTHQzlNYPWJNipXvlYKwQ3Dc1mAAmdqAqtRnf0GOUxjuKG3ddC/716q/8KqMZpvePeX/LxUwQF9mn5PBck6kREf9dEZGYFQWjp8x57nzMuwW6kbQpBqJuY608TF87it7x9T2MW9M0Iirg0awHKUsHYdMwiWRrxCjshwgjC25x0NZxJxXZ+GagH2qHzh9pDVS0syCl5wT3lS8JMJjTF8Iy+b0uVeCdg3JtqfwW8lWeIry4sz3EkMAY+dQxmPO8TaajNQvdr7UmfRDInazsnwcMvHM8MF2np0DKFxK6k5kNyf/d89wME5GwxCbMeetuUVi8KYsK9NeUrTOjZRkSGT6y0WKspZ7kiVrakxfCcuWSlc8Vi7YzzEHhnWOPb907MvV+1ieU90bXrmiEuoXk2ciigTpMY3KcOAcEczI7Ydlqlr8LYpbJHxpybhV2belrd8qLp0yLyR5jx+bYo85g+6w2hJbH1/+vMysU1aEc3lOpGyyYuSIDNgyncRQVgEzFSc62CriS/K7Aig9ODmy//roVS+y68k4QGrQkO9jz+eqADxH5A8uVxhstUBqFMS5eIF0ZaWMmTkVgPcK2CQ5Ti5imVxZDSa1egv0A4H/jLOTbAOQCGLsIM99z9sgGbLAKUkgwrqhbJg9wAaGC3+nTAA1VwUA9hI4JcRl7Lma2lQQ8eBbifwX266wPDYgc43lUasCwFJ5KIOYcyLe5aInCfUi9HIrAaRwD4zhebfsJN4AiqEXEdKGEEs4igYYMuo9Q15oZaI58PREniBeVnNWAN4sdnRSy9ZOHxPbWE2AkwyMrlUBIGWu73+xR7w1cq1MsRIUWx9f/sYM8sv5yF8Ibb0iZ8X6ns3XNIL3zI49xkT3er/wnrBeaIS7+hpj10ZzgNDLigtRKB9/PmcFgPCdSmaz2xv4OlYCnaDsk1F0rlSrAkD8eiVKHV/qOUhJVfzNHBXK+EyMKf0YGHtkXChKdNLYSoblYyx8UTZItxjeP/Ycg5Ku10FRxs3oZRie5Eh4MWcFAPETG3wsfrmv5iBXSthW2jaH3AfrunitCgB1VgKxvWJdo4X/LhH6CgbJLZG6dYZHQTFS9iwIXhBLRJsi2Y8ycPp7sTA2e4BYCewszx4tGrbnacrj3BUAslYq/Lpwpyiq+kXYYqVttbttqcyuWQFQXLpzba/+UsDTCaqwCt/PmHqn0N5NNnVJm6Nkthob1OTF4jJVODCxtGQ0ngPkvQ75mfJ87goAHV3x/a15GwBPhbFY+NdW3gOWoudMNSsAuPONlV0ODwVWGNm2HVun5zcIJCXmwatKtvcYQTBEdhpLSijNEEgAizSYRvEcSOXuF8ojPJ+7AgDHVQWqxsFNXcLMGekuHuV57qhZAXiTMKbn2IN+oVAfxpMW84koq6pvyAPZ/qeeKAjnov5HDrrK15PqM+knG/KM7z3orVbIc4C9vlReGV4O3eMSFADip3fbHfP7o14gFR1ZBo5pQ7fsoRW1JVdValYAVEymNgQ8XcAT9gwtkhIsjDm5GCnuTKorE8YOaJzdAWTMb4yOcrmwFBNGoRcRyEbx/BgqnyUoAGBO8Z74VSGZx7xGWb78u3OOoC9zp5oVAPiveKik/gJVkuVMFh5XBDBz49BxsluOObkYTakA0EgsoVN9iZ5ajGvtvgil688COLtgXfd7CQoASDhf5Oe+FcGJSJuKGxlpcpdANSsA8P8qAZN8vaYi0omT737dOLHuv7ekqkjh55gCEMHwjwgACcFDPgO8Goz6OfBw55xijRvyesj5UhQAdY/zpH5xTXJVsQkCE0UNmCbh0P0vrV0BOFsYU3GxTrWaSsTLIWPFqjIENmqRTAGIkBpaIh4Fq0AQc/1PjRqNRLBrVFF4rLgHxcjAl12KAgBv/ybgl6yLtRAGfF5+sUeSmZBCeglUuwKAjU+s/MLyByYS4oeFeuBNgq1Yi2QKQKTUHicOoiF4scBMpcFGNqPa4vichzwqcb4UBQChK4FOUB5qiWehbA/tqRb96StWuwJAGmdSMY/t56clYpmSM+N7ieowxWNMARjB9cPE/ccQ7CePeP9cb6Ezh7wpdb4kBUDJD488aljqPEDECe5nS6HaFQDk8DtBnj9LIMgnC++nT7SUNrvLLlMAuhwZ+FtNQOInt3u2cpHjDrN0ek1CpcrzduhxSQoAYakV47lUX1wK3t8qDtip3ceUtuS+twUFQJmEWD1gAlfoDBFPJJBrlRTeL8oLoCtg9lOZOIZOMuvK4Z7VYhCJLk/G/iaeO/uy63iU878lKQDIiMyYY/lZQ8KTrwj1/+1YkDZ6XwsKgGoHwASukJIVD8+Blt1JTQEQkPME5xx5BsYOpuF931ioPQBfY6lyLoT8jDlfmgJAUJ8Y/oRlsQOY2m5F2f+/QOjvLd7aggJAOOa7BEzeIAgGI8IQ37HnKKMtkykAovQOF41YQsDFpCwWq13F7Xs5534jdsCQf2PPl6YAvETk+f4ToueJYt3JKbIkakEBQB4kTBvbf7lv7DL8Z8T34o7aMpkCkEB6u0UQeeBjD8By+BLoAQlTLsM/JYnH0hSAh4n8Om5CgB4l9DX2i5eWmrsVBQBM+XFwzHFMvhf6AS58Y97HPXc75x4xYV9I8WpTABJwkT2gnwhACgF4ywxANYSlRGIL262c/3erI58iPG9pCgDyUewAPjtEwJnKfEqQ868z1anmx7aiALAayIQ6dhzg44kU7jFE9L6x7+O+GuxhYtrbV9YUgD6ujLjG0iTxxRVA+XtrCrgyghUbb3lfIj7BLyzaWdYl06LnX+xxiQrAuQK/rt0o4XwFlPj/LPcujVpRAJCLEoufPn9OhHAx4r5Z6AO8L3UugojqJytqCkAyVjr38oT2ALg6zZFel5BHdMJ3bzPJFIA4tCCHWEXJl+driy2c0kS0NSV5TOv7tWP43ZIC8FoBk2ATTyJyRAwhdcsB6/+HDHlR5WVMAUgsoPNEEPtBluUwsuHNiZiklWU+zxt/DNM8mwIQhxS8LzwfxxyfFfe6JKWfIdb5qUlq0dZDWlIAUCrVrKvkFthEKJI3ilhi4pwDmQKQWIqA+KciuPyA/HvnHIlx5kD7JXSZhD9YDbOM58kUAM+J4UclL8AUhoAsufq+EXvki62WMMbDJaSXbEkBoLWqQTXpwzfZAhwv4Mjj7rm6aKp4gikAGcTA19U/EoAMsI2xbs3QJOmRezvnbkrED3hC4A4seEMyBSDkxrBzxfXqk8NekbSUMjm0HK9dYWJrCgAfCkqkSsaHL61hGFb7atyRFOGH11Sx6F+mAGRiN4ZpSpILr2lybDl2+QMTRkyEF39xzj2+R2amAPQwZcMlJQPadzY8O8fflwtK5MdzVKiBZ7amAMDSywQ5M0Yw7h68QjYptmhfv+LZLV42BSCj1Ig6Fk7kY8+JkvXsjPXM9Wgixn05EQ/gHct7q5LRmAIQL0XFp57w1aUJF9mxfejY0pWt5H0tKgC7BDl7fPy8s0WIOJ4pxr/g2aRxD7ceKxHz6GqYAjCadZtv5OtX8bf2YOaI0Up32XtzDaYt8aEEHdnz4D7nHFEXV5EpAKs4s/o6A6Lnb+yRr6yHrn508n8eLC4Nr1Ick1e0sge2qADAwhRxVc4KZIFtlpLy1/ePdwXPnMOpKQCZpfgU5xwGSB5AyrGluNOqm02XT2/fICdTADYwqOdvAljh0tfl9dDfJb1UWAEbWq9uOZRHFIglUqsKgBquGgwQHfSgbaHjHdDFRezvW51z5C2YE5kCUECaqn9rCNQTC9RXfcWLnHP3Juhwvt3s220iUwA2caj//+sFOZXcC1XiFpBvfqnUqgKAvK4WsOnHDoL9EJ9FNSzkeW+bIYhMASgkVDXphAc0YW9Zuq2VnpbQA4I27xnovmUKwDhEwF+Prdjj6eNeOequ04R6Yjy4VGpZASDBTywm+8qnmPzZ+2dLd27UjAJwkgCGz1cgtQc5564T2hACm5zmJfdfh7LvMc65PyRqI+3FfmJotC1TAIZKaWc5JSTwhTsflfWXokCfn7VmdT+8ZQUAzpImPRz7pjovudpVElHMjWN5ypxcjI4WKsoSYA2Wm/i43im0IxTUxcU4P+xF7LFek6httBON+7HDXv3/UqYARDArKKokRLkyeE7u0ysEbC0tzXYoi9YVAGKqsOoZjn2lz9mKwKNpbsScyNw4lp9FcyEcJlSUBl7qnNu3AgkeKbYjFNYJFbSHKhBh7WsJ24XR5IGRbTMFIJJh28UVYytWokqRYqvAHvBSqXUFALl9MOHYEo6fQ84xIG3RBXsT3lGsVBdtxo5ihDX9EIFZGeOTYcAwYBgwDBgG8mKg6Ac1X5lK7HIDQ14wGH+Nv4YBw4BhYBkYuGOgcXbSFYKv2iqArYIYBgwDhgHDgGFgUgxMkqMmpT+9aarL0FRNziZnw4BhwDCQFgNHJP20H/gw/DBvM81vUs3POlLajmT8NH4aBgwDLWGAhGyEVp6ETjUFwBQAw4BhwDBgGDAMTIKBSfMhsAqg+C62pGlZXe3LwDBgGDAMGAZqwcBNNUREfIFzDv/MWphi9TBZGAYMA4YBw8CcMcCce8gk6/49Lz3TFABTgAwDhgHDgGHAMFAEAyVzf/RM+TsvEZrxIhN8EcHPWau1ttlXm2HAMGAYWI+Bknk/ds70a36hBOw2JcCUAMOAYcAwYBgwDGTBAMm0CMRXLR3rnPuPCT+L8E0zXq8ZG3+MP4YBw8AcMXDXVmr3d1Y763cqRqa9b5sSYEqAYcAwYBgwDBgGJAyQfZP8O83Rrq3sTXucc/caACQAzFGjtTbZl5phwDBgGOjHAHPmZc65g5ub9Xsq/Cjn3DHOuc9t56m/3TnHkoYJ33hgGDAMGAYMA0vGAHMhc+I128b0Rzvn9umZR5Nf+h/dYNYfg3c/oQAAAABJRU5ErkJggg==">
							</image>
						</defs>
					</svg> </span>
				<div class="advantage-content">
					<h3>Tiếp cận đối tượng rộng lớn</h3>
					<p><span style="color:blue">TikTok</span> có hàng tỷ người dùng toàn cầu, giúp các thương hiệu dễ
						dàng tiếp cận nhiều đối tượng khác nhau.</p>
				</div>
			</div>

			<div class="advantage-item">
				<span class="elementor-icon">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="60"
						 height="72" viewBox="0 0 72 72" fill="none">
						<mask id="mask0_3507_35021" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0"
							  width="72" height="72">
							<rect width="72" height="72" fill="url(#pattern0_3507_35021)"></rect>
						</mask>
						<g mask="url(#mask0_3507_35021)">
							<rect x="-48" y="-61" width="164" height="173" fill="url(#paint0_linear_3507_35021)"></rect>
						</g>
						<defs>
							<pattern id="pattern0_3507_35021" patternContentUnits="objectBoundingBox" width="1"
									 height="1">
								<use xlink:href="#image0_3507_35021" transform="scale(0.00195312)"></use>
							</pattern>
							<linearGradient id="paint0_linear_3507_35021" x1="-48" y1="-20.6333" x2="116.112"
											y2="-20.4204" gradientUnits="userSpaceOnUse">
								<stop stop-color="#020C6A"></stop>
								<stop offset="0.3" stop-color="#1A85F8"></stop>
								<stop offset="1" stop-color="#66E5FB"></stop>
							</linearGradient>
							<image id="image0_3507_35021" width="512" height="512"
								   xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAAAXNSR0IArs4c6QAAIABJREFUeAHsvQX8P0W1/3/uVa+iYIvdgY167cTuDkxEsbsTUUSuid2N3YqKidgBitioCIpid2H+7v+/z8sun/2+v/t+7+ycM7Ozu+c8Hp/Hvj8bE685M3Nm5oSIkyMwTwQuICJ3FpH9ROTtInKkiBwjIr8Vkb+LyP9X4N8vReRTVRkfLCI7ZG6W64nIm0XkOBH5R4HY5GivE0Tk1zWfHCYibxKRJ4rI7UTk7Jnbw7NzBBwBR8ARCETglCJyGxF5nYj8aAYT2E9E5GqBdde8dnoR+cAM8MohIHxbRF4sIghL/6kB3b91BBwBR8AR0CNwGRF5Sb2yzzEJ5MyDlfi19RCtTWEnEfm6T/5Ru0EIaE8XEXaanBwBR8ARcAQyIsDq+GAR+d+ZT2BsSZ8xEa5vnDl2OYS1f1VCwBuqY6aLJWojT9YRcAQcAUegRuBCIvLhhU1crDSt6VIi8v8WhmNKgQAsOX46i3VDeXqOgCPgCCwdgVOJyL4i8rcFTlo/TND4T1sgjikFgCbt34nI/Spe/Y8EbeZJOgKOgCOwOAQuXGvxN4PsEq/WK8uPuAAQdfYfynuHiMjZFtdTvcKOgCPgCBgicEcR+ZNPVnJRQ0xJ6nDHNKkAgKBwvIhcw7jdPDlHwBFwBBaBwEMXoOQXuqI8k3GLL02PIhRn6/ew5ECIdXIEHAFHwBEIQIDz02f7CvWkFWoKHQAcJFlPdp5eN6ZYqjwygO/9FUfAEXAEFo8AzlZ8MtnCYP8EHHFJtwLIzmMPSdCOnqQj4Ag4ArNBYB+f/LeZmH4lImdI1LoHOtbbYJ1a6MRU8E6J2tKTdQQcAUdg0gjs5RPSNhMSMQt2S9iieAL8mmO+DeaphYDU3h0Tsosn7Qg4Ao5AGgRw6btEG/91Ew5Bea6aBuptUj2diLzPhYCsQsDP3URwGx70fxwBR2DBCLAS/Z5PQvILETm0ikj3QBHB8VFOuk7t0pZASkuNBrhOGEtxHz8BHlAoJ4d7Xo6AI1AkAi9POPl/U0SeLyK7i8hla7/6RA50cgRWESAEMw6XrigidxeRV4rIsQl58+GrBfD/HQFHwBFYEgJXSqCN/mcRea6IXGJJQHpdkyHAUQx+/v9pLAzg4OqcyUrtCTsCjoAjUDACJxORIwwHVSKzHZAwel7BUHrRMiBwHhF5kyG/crTwtgzl9iwcAUfAESgOgTsbDqbfEZFdi6uhF2iOCFxfRFDks9IN+O85guR1cgQcAUdgHQJ4++N83mIQfWflOfA06zLy+45AAgTOKiJfMOLf9yQonyfpCDgCjkCxCNzKaPB8hWtTF9vGcy/YqUXEIqYCDoJcX2Xu3OL1cwQcgZMQwAxKu/p/i0/+J+HpP8ZBAMuBzxjwMu6vnRwBR8ARmD0CaD7/WzlofllE3Jxv9qwyiQqeUURw3KQRaH/r/DyJtvZCOgKOgBKBxysHS8z8LqAsg3/uCFgicC2D0NW3tiyQp+UIOAKOQIkIsHrXrJYeXWKlvEyLR+A1Sr7GxNDJEXAEHIHZIkBkO832P65qTzFbdLxiU0bgbCJygkII+NmUK+9ldwQcAUegD4FbKgZIdg0e1JeBP3cERkTghUr+vtiIZfesHQFHwBFIisBzFAMkq6vTJi2dJ+4I6BC4pIK/EXDvo8vev3YEHAFHoFwEDlYMkG8vt1peMkfgJAS+ruBxAlc5OQKOgCMwSwSOUQyOe80SEa/U3BB4loLHPzQ3MLw+joAj4AiAAHb7GgXAiziMjsAEELiZQgBAQHZyBBwBR2B2CJxDMTD+Q0ROPjtEvEJzROCCCj7Hx4WTI+AIOAKzQ4AVfKz9/9GzQ8MrNFcECHONf/8YXv9fd289V7bwejkCy0aAsKcxgyLffGXZ0HntJ4bAnxS8vtPE6urFdQQcAUegF4GrKwbFz/am7i84AuUg8HMFr+NQyMkRcAQcgVkhcA3FoEjENSdHYCoI4NUvdrfr7FOppJfTEXAEHIFQBFwACEPqP0Xk/CJyYxHB9PHh1WTyZBF5RvX5U0TksbXDmBuJyMVF5L/CkjV/i3zxXEc5cGBDuSgf5dy//p+y30VELi8iS9radgHAnN08QUfAEZgyAi4AdLfeqUXkBiKC/fjhIvLXgatHLCQIsPRSEbltQm+JpxeR3UXk5bVOxj8HlpMV8Y+rSI5vEJG7iwhhoedKLgDMtWW9Xo6AIxCFgAsAW7ChKX6TagWNd8O/RUykm7aXmZg/LiJ3E5EdtrKM+rWjiOwpIoeKyL+My0kd0O24h4iQz5zIBYA5tabXxRFwBNQIuABw4jY4W+U/TTCZdgkFfxCR50Wsts9X7yhotNm7yrPuHvk8V0TOquayMhJwAaCMdvBSOAKOQCEILFkAOI2I7CMiv8008a9OtH+vJteXVZP6zj28cJ5K/+DARKv91TJ1/c/xx7NF5Iw95Sz9sQsApbeQl88RcASyIrBUAeAW1Tb6j0aa+FcnWXYEHtbhVZGjAgSUofoHq+lb/f9LEblzVu60zcwFAFs8PTVHwBGYOAJLEwDOLCLvLWTiX52YDxORJrYCDpqOKrScBMfBhfTUyAWAqbWYl9cRcASSIrAkAeBqtcb76sRb0v9/EZHXiEiMNn/OeuBU55pJOdM+cRcA7DH1FB0BR2DCCCxFAHjQiGfoOSfmnHlhgfDQCfG+CwATaiwvqiPgCKRHYAkCABr+OSfGpeWFk6H/SM+q6hxcAFBD6Ak4Ao7AnBCYswDApISDnKVNyGPUF2sGvCWWTC4AlNw6XjZHwBHIjsCcBYDn+OSfVfhB2CqZXAAouXW8bI6AI5AdgbkKAI/3yT/r5N/sOjwmOweHZ+gCQDhW/qYj4AgsAIE5CgC3quzn/9cFgFEEAHC/Q6H9xgWAQhvGi+UIOALjIDA3AeC8I3r2a1bBS7/+ueXPYByu7s7VBYBuXPyuI+AILBSBOQkAp6gj4qWcgPGG97HKLe4LK6W3p7bC7T6/Cq/7wSqIznGF7DwQ4Q+HPe1yPrH27f++KqTxTxKXk0iIY4VEXteVXQBYh4zfdwQcgUUiMCcB4HGJJrVjRGRvEbl0oLkbvvsfKCKfS1SedQLOZ0TkASLCLkgIXVBEOLP/dqJyIiCVRC4AlNQaXhZHwBEYHYG5CADnT+Az/0gRQZ9AY+OOS993J5pgEQT+n4i8scrjUgpOon43FpEvGZeTYEcXUpTL+lMXAKwR9fQcAUdg0gjMRQA4yHDyIjgPK2lLu/bdqkA63zcsI5P/EdWxw+UNuQ9BYA8R+Y1hOQ82LJ82KRcAtAj6946AIzArBOYgAFzBcML6iohcIFEL71iH9V23hR96H037Z4oIOg8piEA/hxpiet0UhYxI0wWACND8E0fAEZgvAnMQAN5vNFmxi0AI3tSEjwK27kMn/PZ7bKuzSk9NCBevjCxju7z8/kTqwgam7wJAIFD+miPgCCwDgakLACjmWdj8v0NETp6xyTlzH7rVjjIiOgU5CeuG1Qk95v8r5yz0mrxcAFgDjN92BByBZSIwdQEAM7eYCan9DSvUU47Q/GcTESbYE3rq8NvaCmGnEcqIXsCBPeVrY7nu91tHKPtqli4ArCLi/zsCjsCiEZiyAHAqA6c/2MOfeWQOOL2I3E5EXiQi2OgfIiLvFJFnV5r5N8p0LLEJAnA+XCkE/LXyQXDaTZlkeOYCQAaQPQtHwBGYDgJTFgBur5yUODq49nSaatSS7hKwU7Fu9d/c33PUGoi4ADByA3j2joAjUBYCUxYAXq8UAPjeKRwBnCE1k3nMFU+JY5ILAGOi73k7Ao5AcQhMVQDgbPqnignpnwM85hXXaCMV6DQi8nMF5n8UkZONVHaydQFgRPA9a0fAESgPgakKAHi+i1mFNt9g4uY0HAHiCTQYxlwtHRcNLb0LAEMR8/cdAUdg1ghMVQC4p3Iiym1ONxcmOruI/EuB/UNHBMIFgBHB96wdAUegPASmKgA8VzEJEfzGKR6Bzyqwf0l8tuovXQBQQ+gJOAKOwJwQmKoA8FHFJHTAnBpwhLrso8D+wyOUt8nSBYAGCb86Ao6AI1C5aZ2qAHCsYhK6pbe8CoFbKLD/nipn3ccuAOjw868dAUdgZghMVQAgYl+MEhrfpAr2MzPWWFudiyqwZxIei1wAGAt5z9cRcASKRGCKAgA++2P9/xOEZ0xTtCKZYGChdlYIAMQ/GItcABgLec/XEXAEikRgigIArntjV/+/K7IVplUoYhLE4v+nEavqAsCI4HvWjoAjUB4CUxQAzqKYgMZcgZbX+nElOqcC/zEFMBcA4trbv3IEHIGZIjBFAeAMigkID4BOOgRw5hO7A/BDXdaqr10AUMHnHzsCjsDcEJiiAIBL2tgJiO9OPbdGzFyfmynw/3rmsrazcwGgjYb/dgQcgcUjMEUBgEb7i2ISutDiW10HwBMU2B+sy1r1tQsAKvj8Y0fAEZgbAlMVAI5WTEJ3nFsjZq7PRxTYvyhzWdvZuQDQRsN/OwKOwOIRmKoA8EnFJIQbYac4BDChJKpf7BGMxwKIw92/cgQcAUfAHIGpCgCsJGMnocPMUVxOgtdV4E57XX1EqHwHYETwPWtHwBEoD4GpCgD3VU5ErgcQx4tvVuD+bxFBgXMscgFgLOQ9X0fAESgSgakKAITzjd0B4DsU2ZyGIXA6ETlBgfvhw7Izf9sFAHNIPUFHwBGYMgJTFQA4i/69YjIiJPB/TLnhRij7IxR4I3Q9dYQyt7N0AaCNhv92BByBxSMwVQGAhjtIOSER1c4pDAF8J/xCifdVw7JK9pYLAMmg9YQdAUdgighMWQC4t3JCcmXAcI59lBLr46sdgP8Mzy7Jmy4AJIHVE3UEHIGpIjBlAYCYACiWaXQBbjTVhstY7jOJyK+UOD8zY3nXZeUCwDpk/L4j4AgsEoEpCwA02MeVE9N3ROS/Ftny4ZV+jRJjQjdfIjy7ZG+6AJAMWk/YEXAEpojA1AWA3ZWTE7sHj5tiw2Uq8zVFhAlcs8vyiUxl7cvGBYA+hPy5IzAAAc70zi8ibKNil/1YEXmaiDzD/yaDwZsUg/tnBvBKqldZvf9SUQcmtr+KyPlSFXDC6e4oIt9XYgu+ty4EA40A8GIf0yYzpmFt8hgRuaeIXFtEzlEI/82iGBcUkUeKyAdF5E8Gg4NmZeHf6lZmWvxKEADoVPsa8OFnK+H15LPooXaVeIMBrhyxjK381yCiEQC0fcW/H3eswoLlrSKC4vCZG4bwaxgCrLL2FBEGSe12oHeEcTuCJf6lCABnrITSPxtMVmPbqYf1xjxv0d8teKWkwEsuANi0qQVfjJnGP0TkffXOdZ7eNNFcTiEiD6q2Un5sNBiM2eiet33nL0UAoHsdYMCjWBSwZbh02lUZbrnpa98oaPVPm7oAYD8GNG091esRInLLpXf4rvqjHPZNg0F1qozh5e4fLEoSAM4gIr814NffiMiS4wScXUSOM8CR/nODroFlxHsuAPT36aWOeyiqXnRE3iwma7b7CZfqW/3eWfoGg5IEADoQ2vx9ZQ55zrn16YvpkfkKgre/LxthiI5QaeQCgE3/COlDU3yHOBf3Ko1pc5bnnCKCd7QpNp6XOX+7lSYAnEpEvmvEv/gX4AhsKURdta6Vmz6IcvB5CwTOBYD8Y0TDE1O6YhnFWLIoQrv/B0aD55Qa28saPyiUJgDQYa9s4B2w4Yl3L8QyAC19TZjfBq/mep9CR04XAOL7etO2S7l+SkSIfrkIuriBq8+lMIbXc2sQKVEAoMO+0FCQxRSuFDO2FIMRERFfbogXZ6mlRll0AWCr7/o41o/FV5cgBJzLUOnHmaqfqeaEUakCAA5sfmg4qb1ypkIAgs3LDHH6Y6Fb/43g5ALAssYni7H2CyKCbsws6TQi8i3DAcACcE9jOp20VAGAznp9Y0XWN87sOACnR9TJsr/do/BR0gUA2/a25J2S0+J4bJb0euMBoORG9LLZd/6SBQA67P7G/P0BEdlhBiMBlj7oN1j2CXYSSicXAGzb3JJ/Sk+rVL2W6D53e+MBoPQG9PLZd/7SBYCTVUqBHzHm80+KCD4Hpkp4TUTBybI/sE2KUFE6uQBg2+6WPFR6WpgIXrh0Bg8t306VvePxxoNA6Q3o5bPv/KULAPQHJmtr65ajK7/iu4R2toLeI3DXUcb9/ucigvnwFMgFAPsxYEnj6semwOQhZXyW8SCwJCbwum4NIlMQAOgPl6kj/lm23a9FBG+ZU6GrJLD0waf6VacCgLsCNt31sexLU0qrlMiW0d2OSEh/MRYA/lVvK7620pYmoAphgf1vGhhotMCnIgDQWTjy+n/GfP/3Ogx2dGfM9OFelZdEymo50ILl7pnKb5WNZgeAMOc+pk0DA8LRY757pDHP039Is1Qz16B+sp8hKMfUMZc5V3SaJgKsYmMnhikJALTOfRV13YQR2vQlmgqh6c9guKnssc8eOkF21wgAxEhwmh4C5xORJ4rI7w37wU2nB8OJJWZA4MwuttM33/2z2lJ99EQUf6baVrnKvSQBAEz3NuD/ph+0r18rLIjQuatgPCjntcto9RsMp0guAEyx1WzKfCYReY1Rf8AaaJKE5KIdBIi45iFTJ9n8nYVemgAACM8x6Add/Qgf+CWYC92iCuNNVMOuMmrvvbiTi6Zx0wWAabRTylI+sNoR4Mha0w9YAO+cspCp0j5QWXHOEVEmcpoPAksUADjDs1oNdA0kOA4Zw4/4Kasohs83doDUrt9LJn7+6QLAfMYtTU0eoJwH6RP30xRgrG+1pn/3HKvgnm8yBJYoAAAmQsCLDAaC9gTZ/o0r4usla7XtE76siHAM0S6D5W92TSat/KS0AnAdgO15bsp3XqXsK++cWuUvoqww54lTHwCm1mY5yrtUAaDB9inKftE3yb5DRLC8SUWE8UU7HZO8vrLEPkeRcA7kOwBzaEWbOqC4/jtFn8EMeFLz4R0UlWXguJYN7p5KYQgsXQCgOZhAYyfHkO9+KSJ7JGj3XUWEiGUhZYh9Z58E5R4rSRcAxkK+zHwfp+w75y2zWt2loiPHDgI/mpq00w2B3+1AwAWAE0G5v4FyUF//QnsY7XwtcdZPnAOtMtOm8qLoNLcjPxcAtJw3r+/xYPm/inmRgGOTIY0CIPHVneaJgAsAW+16IxEhpO2miVH7DEuBBynCC18pQwRPbKavuwXLbH65ADCbpjSryJcV/R1lwsnQ+xUVxZOY0zwRcAFg23a9hIigwKed6Pu+/7aI3GzbrDf+hx7BCyo/Bv9OXLZjReTiG0sy3YcuAEy37VKV/NWK/vSEVIVKkS5RzPoGpXXPb5yiQJ5mEQi4ALB9M2Djm8qJzmof+3AVmvdS2xfhpDtE2XtMhp0JykWdz3pSzvP74QLA/NpUW6N9FfPi07WZ5/z+S4qKXjlnQT2vrAi4ANANN+fsrLhXJ+wU/+NXH2uBVaUizAjZKUiR52qar1iAZ08XALp5fcl3cWm92hdC/5/U0bhGAODc0WmeCLgAsLld75ogeNa6AYYgXQTTuryIfEQxMK1Lv+v+30Rkz80QzOapCwCzaUqzijxE0c9cADBrBk9oLARcAOhH/pIi8l3FQNE18ZZwD12Hy/VXfzZvuAAwm6Y0q4gLAAEDm+8AmPFbcQm5ABDWJDvVIUZLmLgtyoAnszOEVX02b7kAMJumNKuICwAuAJgx0xQTcgFgWKvdTkQIiGUxCY+RxglVaNQphvId1krdb7sA0I3Lku+6ABAwmPkOwHy7iAsAw9v2bCKC9v4YE7gmz2/1WBwMR2JaX7gAMK32ylFaFwACBjIXAHKw4jh5uAAQh/t/VqZ5DxeRvwb0H82kbfEtvgP+R0SwbFgyuQCw5NbvrrsLAAEDmAsA3cwzh7suAOha8fwi8vGAPmQxkcek8QMRoY2dRFwAcC5YRcAFgIDBa0oCwKlE5Doigpcm4rJj/niMiBC96Vci8n0ROazewn2miNxaRM6xyhWB/xMN6qKV57i7Vw5UXiYiH6u8u32lCvyCNzUiTf2mzvsIEXlL5cVtbxHZrTB7axcAAht7w2vwwb1F5A8BfSlmEo/5hlX/ASKyw4ZyL+3RHASAk4nIFaudp0eLyOtXxjfGHMY63NtiRoqZ2p1FBCE1lvBNcUcReX6dJmPn0bUeTJPfN0QEpdL9qrEVp3Gnic1shO9cAAgYtEoXANjaRDmLYCsoOcUMmEdVIVUfLyLnCmDC/65jySNUxOSFvTeOX/A9z1bymHS1yDpQ78+NWfAC80Y3AIc6OPaJ4QurbxA4mSSctkXgF4p2GdNDIgLm1UWEGPbEaYjhk59UR0B4rttlW0g6/+MdjoyOi8zr7/UC6/aFLXa6KusCQEAjlyoAYJpFSEfCrcZ0iq5vGLw/VDtjaTMMEzVOYb5pmBf5s1tA1LWTtzPL+Bs78C4cQu4dmbGcU8oKRz65XAm324nJAQ1/VolO2yOg0dfYcfvkkt9hzLltgpDPnxeRG3aUntU7z9o8pf3N2PxIETl1R34l3HIBIKDBSxMA6BhsubLFrmXQdd8TJvJNtXtWjhRYVa171+L+9+qji9ydAmk/tvyEiXbqRoBV2x4ioll1DmkXdpSIYeDUjQBHg7GhX1kU5N6pQ4jURKoL4R2OCYhDcdlqh+EQxTgQkhfHLxwllEYuAAQ0fEkCwAUSSKmbGDhlzPXVfBmg2ObLeYZ29oD2Xy1n8z8DIwOr03oETl9h9IzqeOkfCpwbvLuu6LQQM8BpMwJ4c+zCL+QeIZxzEcGfnpMh6mNTb3RF6MfN/6mvRKUtSVB1ASCg8UsRAFDYiz0DS83YlumjVHOhTCMOKxv8wceWH30Ip34ECDOsCcm92j7sfj1MRE7Rn7W/ISJ3UvA4x345CIW7wxXlXOWRUv9HH6EUHRUXAAIYrgQBgLPNnJLq2J0HDdtcuKMAGVvfR+QYGWeUB22q2W5lJ4EohewsOIUj8EoFj783PJvoN3etjjV/qihjbP8d6zsUBW8VjZbdhy4ABDBdroloXbM+OaCMYzFyynzZerzWOlAM7x+kwPcThuVYUlJodX9mAO4cD3HOzxGY0zAE2OX68QCsV/v0s4dlN/htVsMlmZCu1j/V/xyvsjMzJrkAENAxxhQAHhhQvlQMWkK6CAGXSdxD8E8QW1d2Zc6duHxzTR5FwZuIyNs3mK/+sbLjPjADD8wVY+qFEm8sf/Pd7gnBQTchpTKzpt45vkUH4RYJ8e1L2gWAgM4xlgAAYyxp239dhzte4ayorwPw/LoBPLCubNzHvthJhwBmZletJ5v7186lWBku3X2vDtUTv2YLfxP/9j2LdRTWV3aU4TgP78t/7s9Z5HAEMga5ABDAgGMIAOdZuGS82uk/ndC+m8mHM7nVPEP/Z5V6pjF6r+fpCPQgwMQSa/4H/+NKOQVxLPFRRZ8L7ZtTeQ/vgvh1yU0uAAQwYW4BgK1RJrypMG+ucuKpMBUdrMQbD3hOjkBJCDCOHKrka1zgpqDHKsuVa8zJmc+rUwDdk6YLAAGMmFsAwDNeTsabSl64Odb49d7UF3CspMGBoxrOWp0cgVIQuK+Sp+kPuMq2Jvow7sA1/W2O37JTc01rsHvScwEggBFzCgA4wbF07Tu3jvKeHoaOfcwWvsYfADj/vPKFj2MhJ0dgbARQnNXyM+fzKTwAaqxu5jaerdbnq4kwX8ePLgAUJgA8KqA8q0yztP/x35+C0DbXYokTozOkKJyn6QgEIkBAL43ZX9MHnhSY35DXcJyl0Uloyjbn622GAKp81wWAgEE/1w4AXs1YRVoxN/719623lfCydZYqbCUe2fBJjZ//2MiBXeVDU5/zQiL8ESL4jFUI4IuIyC1F5OUigqJc13cx996mZPp1n9POMeVZ/eaLrhS4DmK/nxiBC9aKe6s8OfR/xgbGC2t6n1Efoz7sUBDyGVfQeA5lF+9i9ZiDTg7OxIbWe937v60skXCmhDfWi9fYcJRBUCHKYDluEwMhF7kAEMAkuQQAPEOtY8Ah9wk8sWfAVhLmPRoPYZQJBx4PCjDXOl0tjPzToI440EjlT/vjBuUDl+/Ug1Gujuz5OAI4zbIKvvSyBHCyM4Hd+5CxrOtdFhPslBI3YBPhLXJ/EdHEM8HzJI7YTrspozomCOMgJn1dZR567wo9+Vk9dgEgoMFyCQAW0jG+tIeeQ7Mj8OcAHFaZ+OsicuGBnMj2fWyc7Xb+Dx6Yb+jrV4nAoV2u9m8UnVDESnGOGloff2/+COArgZ0+zUTX5lvCBp8zAWwah1tN+Y6JEKx3ixSMOEYZOvazK8A5flPe2Gsq64vVZnUBIKCxhjLBKsgh/9OJtZqxX1FE0mNba4hP/NeKyA4hFet4B3eu2jPKT3Wka3ULRcPYjtv13ZfcQsCqaTydFgIIlncQESIidvFd7L39WnlY/tQG+mHhcLbIArHb+dkBOH1IRM4cmRfHn1ohgPExB7kAEMAUOQQArbtOLAe0UjtCCNtYOP/oGjxYYRBD+xoGnIl5kcbLIRrOqULx4to3ZkekC7P2vcPqHQF3GmTAQAtOAv58dKXL8901/bTNc0N/M/GkcEjDkZ22v2u95SEw3bnSEThyDW4oJ6K/gwdWfChoiJ0A7RiCPkdqcgFgDTO0O04OAeAJAeVol2n1N3bsloQCHz7AiUJ4n9pnu3UEtpcq60xAmVREqNlVjK3+ZyBkt+ZFIkKsBxQlEQDRkB77j50gvFAuNcwuAz+C9C4FtAW8gIIbimdEnUSxDd0SKz5cTYcJkPxSEDy+mt+Q/59hXCiEqNuKCEeJ9EH0r85qnAdtNqSOq+/e3bg8Xcm5ABDQSDkEgLcElGOVQZr/WbGfrKt1C7+HtUBTh5grDpNSEasFdjtiyjWHb1DWZLJ5axWmFeESK5I5ErsxbKO/SkSOqFbWnH/Pof1i6vDihA2MSWFMmfiGo9E+JbyERY9OmjJr+AkFxtTkAkA1NpaZAAAgAElEQVQAY+YQABh8YjtIDkZJxYicj5dab8yglhSjvK8dPldbl8TqfqTioaHpItwRhRBdDwurlD7cpvCc8/mU7apZ4CCETpXerBjfUpk7t7F0ASCggXIIABrN+NzuI9sMpP2tOQbg29T0ggD+mMIAb1lGzEzZOp1apD6299lOx3rFEo+pp4UNOyZ6KUljXotJ81TpkQpeI1hSanIBIKCBcggAGvvRKcej15y1vyZ176idG019gE9VfhxNpfAVn6JZsTw5JKCvp8Kq5HTvlQLwlTQ1WvH4N5gq3VzBc5/MUGkXAAIaKIcAoAlHS/yAqRIKOLGDI06MUhP2uLHlW8J3KDQ+s3AdlD0MTGzn3JZoxqembyn60SVTFy5h+nhGjeWdTyQsV5O0CwABDZRDANCYjAx1/NM0fglX9BdiO0gqe+U2Li4AhLXPh6vdEmsrkXY7xPxGMfZ5Cv6K5cupfZdDAFhneheC1VR2mbp4VBPZFb2J1OQCQMAAkUMAwJd+SGfoegfvdVMljaY9PgtSkwsA4XzJII8TlBKIyf8Nij7V1c/mei+HAIDjrlj87lICQ0WWQaPjhPCamlwACGDMHAIAduGxHQRFkykSjnw0ZjK3z1BpFwCG8SXa5GObbKHsZxHZMbY/Tu27HAIAGu2xuLwkQz9PlQV6MrH1flyqQrXSdQEgoIFyCABvDCjHOkbKoSzS4hmzn3dV1BkscpwNugAwfACDH8e0ECA627q+4ve3xyaHAEBAnVjsfzjReBrauCI4T0pNLgAEMGYOAUDTEHjwQst5avSFAOzXDRqE58SeOzW5ABA3cHN+qXWnGtO2GqXSdbw29/s5BICbKvo6+F83hhlG/kazqGNMj41FMKTamnnnhUMyGvtdjcOZHAKAVlrMYRNv2YY3Uw4IB1kWZkNaLgDECQAM2k/bgGuKR0S11Pibn/tEv65+OQQAnGqtyz/kfg6beEuexMupJjojVhM5yAWAAMbMIQDghYvY0yGdoesdPJrlCB5hwZTE8daYBVH/XHoPLgDE8yTtxIo8BxHyVWNK29WnlnIvhwAAD7CVr8GUNp4KEU1QU9dcCzoXAAIaKocAAGN/IKAsm5gKu9Extl2HdkrM9zbVo+8Zq7xcvuk1AgAe8/6trGsfFqU/ZxXE9m9KuoyI/HHhOGv4IJcAoDXJJPphqgiglvyJ50JNe/BtLudHLgAENFYuAYAtTC3j5PDqpeksVzXwv55zO1AjABBJka1PbIHfISIaU08tX4z5PT4uLq9hmg3fnq+KVomgNWb9xsob9+Gvq8ICM258UIFBLgHgCooyNhg/fQMvlPAIXazfK+t5dMaFnAsAAY2VSwA4tUEM6b+JyOVK6AkdZSDcpsUkSJjiXKQVAFbLidtm9B8QDogzgGBwsIgcWocIxhx0rD8CUtE+mrPLZqBevf6iMs0jRrolEcmPVeFqXhb/U15iBozVFk2+uC+GP1CqfI6IMGDfsBYs21hqgs7kEgAor7a9UI4jdG+JxO6EJqhbw7eEhs9FLgAEDCC5BAAanbCkDSPEXgkPbB3bWsuQO4nIYQZ1IzpfThMzawFAi2OO75lY2Uk6yqC92jzM4E/aFoSwrLEiaZer+f1rEXlsAkHFor59aUxFAMC2vcE79ooF0MX6AMn8/OQi8l6Dup0gIjk9u7oAENBoOQUAFPksVmDfKMgrG0p/Go9/7YHi/pk79hIFgAbiU1Q6DHuLCKuudhtofn/W4ByXwfb9hmWiPqywz9BUfILXqQgAO1aKoQhaGh7iW3aqSjF9Ru/q1QZ1ol7s8uQkFwACGi6nAEDjc66n7SB8z4qblfeYhEvWdxnV50cigjCRk5YsADQ4E0zH0rzunUofDgSBsugfTRocxUxBebZpj67rVAQAyo5Q2WCvuaIDcZ4uMDLfe65RfdCV2Tlz2V0ACGi83AKA1S4AnYuzZUwMxyBWkG8NwDd0EGAiyk0uAJyI+H0N25H2jjVz2te4HEycU5/8aaEpCQC4iv6NUTt+u0MfItcYAd8QCTN0/Op7D97OTS4ABDRgbgEAJrBkLJwg5ZYs2erT2sK2OwyCzBgDtQsAW0MS25PtNtH+fthW0kG/7m2cP2azuXeUgioa8dKUBACqZ9mW6DztEoGZ5hOOoSx3oogZMMZCzQWAgEFlDAEAZsAcRDvINt8fKyJ4p8pBKLF81bDsBAway8mRCwBbHIMApnFv2vBic+VY4XZbyW/8heWEhW5Mkzda9gipc6GpCQDwEhYOTXtorygGXjNTY1ovbugH18hU9tVsXAAIYMIxBAAaCv/XlgpYOTrJpSq79x8HYDqkw8OkY5ELANsiz4rZcuDGbPXq22ax3X9XFJG/GPLUMQVayWxX6YE3piYAUL2LVFYXtP+QsWDTu6R1h4G4DX39XLV56KZyDH2GDspY5AJAAAOOJQDAFDDHUIba9D7uhrFBT7GdTnQ/y4GaeuAdMUfQn3Ud0AWA7ZE5nYhgZbKJz4Y8QzBdtzt1IRH5lWFeaKAz8cyNpigA0AaaCaiLx1gwPaOKQ8EWvTVdT0R+aciLlJ+d0jG2/htsNPh7MKAGxYRXFOkwnepids09gulY2WRjl28tqFA3jkBOnxDbkKRdAOhGiZXQTwz5kiOqs61kdQ4D//HtPsJREkG35khTFQBoizcY8lHT3ocbmgmyWMI/hLVb798ZljGWp10ACGC+MXcAaNhzJpA86SiY0VwtlnPq71ihWZ73Nx2YwfrSyrJZfO4CwHoUOe75Q0D/adq079o+l0dT/EjDtAmWdeP1VZn8kykLAJypo83fxx9DnzPB3lrZsihPfyxB2Tj3L4EfXQAIaNyxBQB4GCURy/OypjOhWIXFwdBtKKTiBxi4Lm7K0b4iad9S2XGtPncBYDOS11FGsWy3O79xe4uXP8tBl23he2yuxuSfTlkAAHyOZSyPehq+ou3xq3LGiBa+baKFF2Vj4i2BXACYiAAAs9zcWBO66SRcUYxC6TCEiMRnqQjWLgcddq+QQmR6xwWAfqAJdtRuQ+1vy6MFypLTt3o/WmnemLoAACoEjMIZjpZ/ur4ntkOoHxGOHV+RqByU7WlpWCAqVRcAAhq6hB2ApnXx0c4k2cXk2nuk+/IN0jLKeKz6/5Qof8pf2mDtAkDDeZuvT0nIExq+ftnmYs/m6RwEABrjBsY7Squ8g79+AnKtI8xSf56Ql3EZnEIBe119+u67ABDQ2CUJADQoDlRSCQF0GLx0PXBFkxZTrC8HYLXa4Yb8/+Q+bh3huQsAYaAzqL02MX8M4SXeRdEVV9RLoLkIALQV5/ZYKw1t79D30S9CYOWoqSGOIKzilawrB0cRpfGjCwABjFaaAADT3s/YP3sX036rDr3JdhhKK13vWN17fNMTC7u6ABDeIFispB5EQ/nt0wZBh8JrPv6bcxIAQPMmiXSe2vyDvxJMl9mS/3vi8Q2vgWOaM6/jUBcAAhq+RAGABt0zgWlKu4Pk+M1OxsPXcWcB910AGNYIBJ9KYRUyhBfRKJ9yZL9hiJ/49twEAGqF3b21X5EhfGT1bsnBplwAmLAAQCfhzOyPAXWwYmbLdJC67xwz2mX8xgWA4WDjCprIjZa8EpoWYWJLiBA3HDXdF3MUAEBk1wSeRUN5SfseixuOGkomFwACBqpSdwAaxsIeG5t+LcPm/D6HW+IGH83VBYA49C5emTphh52Tp/BJwISxRJqrAEBb4hBq7F2loXzM4uaOE2BEFwACBqnSBYCmk3wxoC5DGTnF+7iRHSu4z9A+6QLAUMS23ic4S+qz1YY/URoLNWPdKuF8fs1ZAKCVcAyFUmfT3iVfMWNFaXoK5AJAAFNNQQCA2fB/jR/skjvH20TkNFPoGXUZXQDQNRbBWVIrkJJ+aFRBXW3K/XruAgDIY2lCHBPLqJDWY+VnOlxal8s1ulgMHgug0JZFszWlrX5Mp2EliPliSTawIc3nAkAISpvfeXRioZRJYem0BAGgaWOUA1Pa6seMbwihz1oxnW7KW/LVdwACBqep7AC0GQ1vfYcG1C2G2Yd+g1b2ZdqFm9BvFwBsGuuARLy4r03xJp/KkgQAGgtvfW9MxFNDxzeEkRtNlINcAAhgoikKAPAjq+37jGhKgxYsPgTaDjem1k9cALBpMXiRmBNDB9d178Nbe9sUbRapLE0AaBrt9rXjsnV8kvr+uwyjqjZ1ynl1ASBgUJqqANAwEgp3nwuop2Vnwff2TZsCTPjqAoBt42H2+XslLxI05la2xZp8aksVAGi4s46gIMgRK4urqZMLAAGD0dQFAJgUBcEnisgJAfXVCAKszIjvfeap94y6/C4A2DckZl2vilDmQtP/RTPiLUtklywAgCM7TMRJwbxYM36FfIu3y/NbNt6IabkAEMAwcxAAGh47Vz1BhzD60He+LyLXbzKayRUvXkNxaN6nczmtRwBeZBv/8A2WAoSG/kIluD6mOk7CwZBTNwJLFwAaVPAASZ+Fb5p+aHX92YCIgk15Sr8uRgD4lIIhblh6K0aU79oi8k0FJu1Oxa4CHq9OGVGO0j85UIHRHLYIc7XPjnU42JuJCOe6XC83cf2RXNiRz2sUfEqEz7nRZQ2PPdHwR5cJXwRzo30UfIPVw2Tog4qK3mMytRxWUIK34Ief6H/tCX3I73dXOwoXGJbtpN7+hAKbKXgCm1RjeGHXIqDZqdpvbarTfsCxwN2UXlIJKoUgOlciSNGQ8b797qSUcN+kqOikJJ0ITmX19djKTh9Xqu0G3vSbbVs8vc2ZGEB+OgCTVbxuPGdwvG5FIYA55Cr/hf6PED9n+q9aYY8t/FBMvlfvRM0ZF+r22QGYrGL34CmBg5S7WoHQ/znbXgKhuPc/IoIryy5s2ApjRYzXNSbHuRPuPLtwCL1HjHEnRyAHAkQGDeXL1ff+vJDQyXggZaHz3Q1YsbC59wQd+sTw2JmUuhKEbJ4M3WVDo692iK7/OVNaChG3+mpVFK57VhXmbP8R9aS/tChrGuc1/xQRjlicHIEcCFxZOb4tzZUy4/ketRIqQgHHdRfN0VAF5YHuR9dcF3pvKvFc/g9yIuaFVqzrvQ8V1HBelPQIoKGuMZn8Wvoieg6OwEkIoKCm8ZGPt86TnZSa/5g7Ajhn0xxvEoJ+UvzCljUORLom99B7aCY7LQMBghaF8kXXe89bBkxey4IQOEzJsx5ToaDGTFwUjnq7xq3Qex9IXL4kyb9DWWk8mC1tmyhJQxSe6KOUfEIncmGx8EaeYfGeruRbjq12myEuXqVtEbiNiOCwLXSy73qPwG6TI+yLuyoz5N4PReQSk6u5FzgUgfsrFWPgJQTFU4Vm6O85AkYIYK42ZCzrehdPei4EGDVIgcncwiA2DMrgk9QHY1DW+iGn0+AHmjjnTvNBYKcqjvfLDQZQ+APb2lLpwiJCuGhcHB9cKXd+q3af+pe67lyZBLjPNt9zReROM3J9Wmq7WJWLduua2IfcYycAD3GTOuO1AnCm6WAKidMfJu8hvND1LlFmJ0sahxmrYBBg57reUSbLCxQc16HYs2r1Q9q8gflgSXT5esL/gbLzYz6FT4xdS6qcl2UbBDjHb/Oi5jfCBNvFc/TwuQ1oM/5nBxHBAu4YQ75gQTBZYuuCoCKajrH67a+rFRIuY5Gw8BrIUUPKPzrl9UTk4jPpnDDppes6YY6UEjt2bpjwUYL5uIiw2lltT83/HyukZ2CCiG24lbvnVUxQOCOyX8wqEZ/+2BATnOqdIvJFETlKRIir/re6PX5XOW/BcctXROR9FZ9zvu07Ef3MhXa3pTBLu7PjSTthEox765T9k7QZAxjfLjMTV9D0xV3qxSJRLFPjd9/KTwuOoeg3fzUe346O7PP9nJvxDY37w9WBcOz/CXqB8woGSCbRqRCr0ueIyJFG21Jjt0OT/zVGbgCsXZD4jzPu+E39Vq9M3Aikm4gyYaf+7Mr2+liDclE3+jAxOtjadNoWAezaV9tpqv+jrIYQy84tvkmm4oCMCR+B6fMJFhljtiWLisnTztUZFyuMMYFMlTerKRQ9SiQ6LyvwI2aK/VtHBh0LFSLnpeKtTel+uENPgH62/wbPkpvSC332y0rh8hkdeY/cFKNmz5Y93ktDMZzSe9+pd7Zidp5yNAo7F5yRTwnT0LKy64eTuFnQ/WbaSE1jHiIiKHyVQjhiQhpuyje3K44xiHM/Fj1I6bjIoj2IJcE2/XlF5EWZy4MTnDfUW61jtUFJ+d7AwNTLgidSpcHOYUlh2s9dBQ16/4zHN3aaZxUUidUoWs6pGLSEdPHxzTnt2MSZVHO2WwIuKcowVuQ/9Cc0ga5SYJEiFntoOdHpYLv4jGMzfQH5Wyo8h+Kf8z2EvscUcCzAjiuWMznrnjsv9HVmRwRD+PHMG44ztLHCNiJkoTWem1lz5/eykXrG6ZTRvHLjlDO/X4jI0qMxchTw5QX0v1eNqJj2wJnpMHX10Y/Oaet/dazGqc/cpTcaFYW7nMTk/+IFDD5ERxzDTIrJf666FF2DUMw9bJ5RPByjfXL2tU15cSxloXgZg3/Ob7BSOPkmIBI8e/QCxjdMQTGVnjWhuW1tLpGT+UPzemamVkRR5NUL6BxYX+yYCdN2Nmz7f3oB+Ibydd97XxURzmiXSoSlRlmyD6epPyd+Ry4hgC3xqePVV/4ficg5l9JpUCjBnr8PlKk/J8RtSkI793ULwPGTIsIqfAx6/QLwte5nmA6WpBSbm28uUJmHYsNtjWtp6eXYCZiTmeW69iM65OKEZo4DLD0mrQN37Pucy6cgJv/SFNJSYE0dx9pW5swxRZ2WkCaOhqbkK8O6j3IcsASdgLcn3AnYbwH9j2PN2W/7r+tcxNXWhoKdwmBqvRPA5P/GmXcOLBnGDJmKc5ETZo5x6r6D/w88zC2V8EqH3wRtNLjU7aRNn50A6mpJc5/84Ql4o1QfC5Zt2ZsW3tRYMWgZseTvUZCyIDoaHa7kumrLhlQ8ZiholCqJPaGth39/opdEnBQtmfATMFdnQQ2PE/7dSieAsbJJd47Xr4nIVZbcIbrqzhkvinPY08+x0amTVgjAFet7ZowPnsd272KOzPfw5zBXHhyjXjilWrobYY6xOM+2jh0wRnuuy1MrBCB4P2/Gfe8nle4bx4pWglLmYTFPdvgLeHLlghKtyHWMNuX7sSaCDCAHzRATtsI+VQftKMH1JTss1qZcmL6+pdJ5uVt9Ln622tYXofditUe/187YZTb9lfDPTiKnqY+2UPya8ji2ruyxQgCTPx4t16U75fuYEBPYaSxdpkn2OyaDa9WexghQMadztKFCwKnqePJT7gTtsnO2TnRAVkS4si2J7mo4CHGs9bBqZwtTwhAiuhxuhue6SuwLZBSC0Zze+e9qUiCwGCauY3p0bPdNi99DdQKY/HHwZZF3CWngIZMjRKIEouzuZIDAmSt77GtXugK4uiW8LAyDhjgSZ8o//Pzje96asUIVA5k8PpIgfxS08DqVEjvSZmWLm1R2dXDhi4/rkiVh/J5btDXKrTtF8v3pq50BtKstytGkgW06iqPsQly18uWPqRqrUbYj2XVDWY/YAqzCUlnn4DFwndtgNKFx88oxINhxbHB8JUAR8wBe5Q+BCmcp+IF/bu16+3yRGJf2GbtBtMs9K8UwFOBeUoc9T90/CSyVQuAMFQJY6OFdsOFTq+tfqgUk5sOp8cNMGCdsTxWRu9cxE8bwV1IaP8+qPAgfxHu2Ys4mnT4hgBUhK+Xmfavrm0e0qy+ZMZgEtRizU/Vwo0riVlpTHspysIjgfItV1hBCSYmJ1nrn7YWtQpy/EkCeZhCmGpt7BAfCXjsNR4BxJsUK/F091gFM/iwQNDze9S1KxGMGCxveAv5F8QikMr1D6aWL6JTsPnQxuOYesd1LOGvvqvOY9ziKsPCr8DjjSuwTyQMMgpc1KAs7NuwUaXiu/S3bo/evd7VwH9x+ZvGb7fQ9XNEqquURxizaoJ3Gu9cIAYynKZxssaPBkamTI2COQC4hgK3ZFHGuX+GT/0k8gQ8KzvvfKiJo57YHrdjfeGW0JlbuQ1ZJRG1DCLEU8ijDo0SEyTsWm9zffa8+chq682HdflNLL4cQwDhKOGlrnmC3yyf/qXHcxMqbUghgsGLy5+zKunOwxbf0wZC2u1W9tf13Y4w5R+UsPQVR7pBzUs7ur5yiAHWauPCemp97BOkLJcRkjkmnFALgZYudttXx8YOF6xbNkU8WWycUp1g5rjKh9n+USb6YIN0+XYO5NyTKeEQT+2ECbJs2Z1s7Nd2sVo5r8myuCB8ojsUqHQ4pN3oSv0+IY1MnyytWJ3sNqaS/+39e6izbgLQ4DkAvwDrdUIVDb1ZHwAyBVDsB1p1D63zIDLAREsL5zIMzrFpxXpVj8m0gRCl1t8rU6HqVlvPFjbf7mzw2Xa820YieHKUs3SHRpnZdfTYFd7xo+Vu7IV7Fwf93BDoRKF0IyBWSuBOckW9evzrj/0GC1UaXgMbEsjR6SCZsu/DW3PvYSGGlp8ofJQsBOUMST7X9vNyJEShVCCDQxBIJe3ImZGvztU2TDrbbSyOUDLHV34RLqc84ZnNb7XCOLVEIwLOmu9QNb0N/MyECCAEptFpjB1Cc7iyRsAMfw4U0Ht2WSBw/YHUQy6djfsdOgB8HhHMtjm7GbK923q8Z4dgrHCl/c5EIlCIEPGmR6J+o5EUI4fZAkeM3pnFLNj1iJZYD5xR5vHqhfSW22iUIAVjDWJq4xmLh3zkC2yEwthDwhO1KtIwbKcyWQiecrywD4rW1xH1tKFYlvrfE45u1jRnwYEwhwJ2YBTSQvzIuAmMIAZx3E3RmacRKIIUL0yET1SOWBvpKffEtkSp2wJB2iH33r3VchJVq+b8bEBhDCCCa5NL9mGxoEn9UEgI5hQAmfzSyl0isCGIHfovv8CuAy+al09hCmLYtcZvsk8swLs4pBBD4ydtnWPv42yMjgBBwYOIJismf8LFLJEJtagd+zfdEG7vCEoHvqLNlCGVNm2i+vUNHvfzWZgRy9MGhodM3l9ifOgIZEUgpBDD5PyBjXUrK6l4jT/74F1iq5n8XHxB0SDP5tr/9rYgQs4LQ0bu0zPUIkUw+BPpBsEYAa3+n/f1dNyvratreeymFgGf15u4vOAKFI5BCCCCK2j0Kr3eq4jHxjqHtTzx6YjTg8veUqSo30XR3MDAHPF5E7jcAWzwvovdi6ZaYnQyn4QikEAKW6sdkOPr+RfEIWOoE/LteBRVf6QQFxMnPscYrv9WV4zdE5Pm1gHXFyqnQeeoATQmqM6skP61oF1b0p4tEY+fax/xqO8b8/6XIMvhnIpY6AUv1Y+J8NGMEUGJ5rIiweo8ZnPjmjyJyixlj1Fe1VDoV36/b5lx9BfDnaxG4fQRfc4xFkCYt0besTEE5ZnCKQ+DeIvKPCD5oxkMidHK85+QIzBaBW0fGn//cwsOa4tu/GSisrt8Ukdu5YxGTvsYk/KGBbYRAbEn7D8y/i4+eblmgBaZFoKjvRLTDt0WEcNNOjsDsEcBzHPbjR/d0FLb7PyMiN5k9IpsrCF6WgX2I3sf5MUczTnYIsI0fGs76KXbZnpQSQsh7evpU16Tfvve9k1LzH7EI0K/2FJGvBbTFV6u+je6Fe/eLRdu/mzQCaDqjzc8W5utE5CVVIJt9ai3oM026ZnaFZ7JuD9Ka3wxKF7Irmqe0ggAKkqzEcbDT1U4Icrdc+cby37NWwt0f1uTdVZ6ue+h9ONkgcO5qx3Ovyo4fRUHc+OK7g98oMZ/TJgtPxRFwBOaKAFHbfqkc0JtB/l0igsa6U3oEMNu7c6XVz5Y6Qu3e1W7WdTKt9B6u5Jfd08PjOTgCjoAj4Aj0IfA45WDeTP6v9y3/Pqhn8/y0G3YgGn7YdD1gNkh4RRwBR8ARmCgCnCUeZyAAvNcn/4lyQHyxNeG5D4rP1r90BBwBR8ARsECAs+JNK7WQZ0f4tr9FU0wuDZTQQvij651vTa62XmBHwBFwBGaGwMGKQZyBHW3/i8wME69OGAIa98Q/DcvC33IEHAFHwBFIgQBKZBqnIggAD01RME9zEgigB9C1ug+59+tJ1NAL6Qg4Ao7ATBG4i2IAZ5DHpe/JZ4qNV6sfAaw9Qib7rncwI3RyBBwBR8ARGAmBdygGcAZ1PC46LRcBnBJ1Te4h9/Bh4OQIOAKOgCMwEgI/VwzghHZ1z2IjNVwh2e6q4J8fF1IHL4Yj4Ag4AotD4PyKwZsVnkWAmcWBPrMK4142ZLXf9c4XZoaFV8cRcAQcgckgcCfF4E20RY/qN5mmTlbQNyt4iOMnJ0fAEXAEHIERENDEFj9yhPJ6lmUhsJMyHgDmpwSgcnIEHAFHwBHIjMCbFKu352Uuq2dXHgJE2uza2h9y7ycich/3IFle43qJHAFHYN4IcAY7ZLBuv3u3eUPjtetBgJDAlqGjCVd7yZ48/bEj4Ag4Ao6AEQLHKgSAKxmVwZOZJgJEHGwLhBa/TxCRe08TDi+1I+AIOALTQkAT/vds06qql9YYgUclEAAaIeItVXjjUxqX15NzBBwBR8ARaCHwF8UgvmMrHf+5PATQAWkm7BTXD3twqeUxldfYEXAE8iHwb8UgTghhp+Ui8EQF74QKDB8XkVMvF2KvuSPgCDgC6RDAFWvoYLz6nu8ApGuXKaRsEUJ6lae6/v+ge5ucAjt4GR0BR2BqCPxKIQCcfWqV9fKaIvBfIvIbBf90Tfbr7u1jWnJPzBFwBBwBR0B+qBjAr+L4LR4BwkCvm7Qt7+N18gaLR9sBcAQcAUfAEIHPKgbwPQzL4UlNEwECQbFFbznZr0uL3aozThMmL7Uj4Ag4AuUh8EbF4P3i8qozuRKdRUQeLCJvF5FPiQia73uLyGUnVJNTiMirFHy0bsLvuv+SCeHiRXUEHAFHoGgE9lMM3F8vumZlF46V8/1F5Pcb8EcomJKexeYO/JkAACAASURBVBVF5G0iogkv3TXpt+9htUL4YSdHwBFwBBwBJQK33TABtQfedb8vqMx/qZ+/NBD3n4nILhME6XwicmsR2V9Evh9Y13U8tnr/XRPEw4vsCDgCjkBxCJxbOTg/obgalV+ghw/E/CgRIereVImYAbcyFATYBXDBc6rc4OV2BByBohBglbm6ygr9/zgROXlRtSm7MKcVkd9F4P1OEWEinTLtICIvi6h7Fy++YMpAeNkdAUfAESgFgdcrB+W7lFKRCZRD4z8ffY05kAaDRhhAz8A9Uc6BG7wOjoAjMCoCt1MKAEQU9MAtYU34HSXWT53BTgBI7avEAUHgWmGQ+1uOgCPgCDgC6xBgW/rvygEZ0zWnzQhcVYlxs/rlOGDqbpg5ztD6DzhgM9z+1BFwBOaKAGZU5xARvNHtLiKPqFahT6+UpRgUXiEib64UhbBx5/ezKl/irJywt76ZiFxCRE4zV2Ai64X5VjPBxFz/ISKXicx7KZ+9W4lxu11+JCK3mDhw5xWRvykw+eLE6+/FdwQcgQAEcDRyhcq++L71hP5lgxUrg+kxIvImEXlgPXlNXckqAMq1r1xfMRA3E9N3ReQMa3NY9oOLiwjubBusrK6fq83thipinrU2L2QSHpNersAE4YF4BE6OgCMwMwQuVmlLP0REPiAif1YMEkMG2h+LyHNFhK3apQkD7Kj8wADnQ9wqoLMnare7+/j4tyKCMue9q631y4vI2UTkVHUo3fOICE56cDzEzhh83k4PF7vPq7z5nbOz5GlvXm2lLO1yhfxeqlMg+ittfCkRQXi/k4jcp/57TLWz8tiVPxZP8MZtat0JdkH5fmnjXFpu9tRVCMDMbONrAtSEDBoh7xwtIg9YWCxyBogQbPreoQ2dthC4sRGufbhrn+OVEOc9OYmdiz8o8LlpzsKOkNf566MeLCdeWU3en6wm8p8a7iah+8POHS6oMdF8UC0g+E7eCI29xCyRQh8vIt9UDALagW/T978WEUKRnnoBjcN2Knb9m/AIecZW90UWgFdIFU/XseIOwXCsd/5V68mE1M3qHXb5YuvLqncuhDLuTarKPKU68jy4Oppk7InFxeI7dopQOH1YvYPEUayTI2CCAFuSnL+jPGbBrKnTQOkq9+rIBOiBidzLqD3cUcuJwGuCLaXm6XXp/1JEzjSQbzSvs7JdV5a++ywepkr4MUCJmQUGuhwIX331HfP5X2rLDXSm3BPjVLluxHJz3oTN+ZcKZ/RNnYyz3DOPiGHqrDlbPNygfb6RuqATSB8dlk28VPKzJ2bEF8udWCymJgBw5HEDEXlNZZWE3kZsvUv4jqMDnFNxdOvkCGxE4OaVP/CvTZzhm07HNjmKVnMldme0GuucJy+ZMDctfUXX8HPXlQA+uegZinFhKgLA1WsLprG39bva2uIeDq6eNJIiaS4+9XwiELieiBym6OAWzJkiDUyQ5uwC99nKNsNyY6m0m4icoMQvBc8OTTOXhv2BCqw4ny6VTl/7HilVv2koP4S8T6Cm94sICz531VwqZ2YoFwplr1J07BBmG/sdVsl3zYDlGFnQfl9VtB++2pdIrPz/qsBtbJ5u54/zrByk2Rm8fY4CDsyD8M2vnhEftHliyG/8rOB8zZ2uDWSgqb/OObKl17MhTJf7XSRePBHOkVBQisUTnwJLI5Sjprztv9rWaIEPdTA0tM3Rp6EPreYd+j88WgrhCfMdBsdnoXWfynvoOuyfWbG0FJ5YZDlwOjEV5rQo5z9F5MozbGm818Xig4LQUmgnEdFsY8dinOO7OyZuxD0VPPa/hSjkXrQ226M8Odpkqnn8sQ4ChWms00wR4Nzn+AV2BJwXzc15Btq9sYPNt2bK36vVQqMbE9FYnLq+w9U1Dl+6nuW+hzVHyl2A9yrqibOusQkBRhtIK3ebjp3f76rjkUe7G+exWTdN/tdUdOixGVOb/3vSQDpaqpdVtOWRo5U6T8ac8x6kwGcdr2FrfaHaRSvuXUvwiol3uBS0g4hQ33VY9N3Hx8KYhF8QrbVMXx3n/BwB7pZjNqDnbY8ASh9zZtq+uqEENhe6nKItj5gLCCv1uFJ9zqs5t97EQ7hjbhPKmPjwt95l2FSG1Wd/qgMHtctl8RtN8dW8hvyP06qxCA3/uZr0DWkDi3c/KiIXGKshPV9bBAhCYcEUIWmgcIUUiXMegplgE7yXiKAZ3PzdQUTuVyln4djktbVJombV0Vcutr7nYv5ySUVbftuWrUZNDV0I+Jq27Wt/zXM0x9cRPMWK8+MjrTo5CrA+u8UZTixenLeffR1YGe4/XFH22DrP+TssZ4h3kPK4KQNbeBb3TNgxsC1n25XzIxxrsIUYQ6yq+P5pibZYMZ9iJffM2hri63XoYbRhUYShI6M4iMtVlOW+UNvO/k9tUYBSUQlCxIUVbcnW9ViEFQo+GhAMMUdEUPxZFTXt87Vp6iNrf/fscDCJgPWOtUIZeg+sTOGxt2f040/ZThkIGGXGy+ChlWCCP4pcEwPuasHJgoitoQkChJ7EmETUy1y4Lykf2hWB22miCBDG15JhGcBfWIe8DB0gh0DHZIEiFwOwZbm1aeFIhghdWFSMtdIhVnxsPRBuxiB8lGv8F8TWV/MduyWx7qUJ+YvjIVZP7CAgTGJ/jaIVq2QETX4T8ldTxubbr1RR6c5h0LAIaE2aMVf8549JCJQx5bb8hp1MdkAZu1CmJKYCEf3wrLj6x310Jj5U74L+ZKSdpJD6M/ZhUuuhisfkcEXerBRCGnrdOwQIemsdGSvnlhBxCko810PRiPgJeD3j7DEXIXisa6O++2N4AmTyt5ro+upn9fzYTO5T2S2zss4hHO11lUz4MQVvgT0KqmNSznGCXUN2e9hRZIf1GiKys0Hl2QlF4ZQFELtimLKivFuKLwt28M5iUE9PIjMC2MTHMBGDN9vnhAgei8ibbSirAd46Hc7KXlrpM5wnA0B48IotP0pyOYlt/Kmt/L8nIuyy5CJL/xwIpU+vHLzEhIg9t3L1CW5jk0XArHV9C+HibbU+E9vh7FLmJPr9dao2wrc/5qjsIq0ra+r7OKO6Qs7Ke142CKC5HOoYg21+rAfYziyBiMtdesRCdkleVB2PnDExYJoz5lgdjZgq3XnEQSpmEGSlddaYiiq+YbImyE9Medd9Q5wPdEWGEBPLuvRC7u87JLNE77IaDylr6DsE03myiPz3CBN+H0SMhyigvk5ECPIVWier9/CzMKbFRx8+/nwNAreplbDWMcJvqqApjxERFIJKo3PVSnrryl7KfTDE8iHVeZlm2/h8GRv1AyMMTLE88D4RwXvgGMTWfahgHlo/zqJXzRfX1Q0hH4E/NO2u99AzGpvYOteujOlbuMi99NiVGZA/eli3qBVkWYR0tU+qeyx4SlCOHgCXv4rWMBMUPrLZWkeJCO1q7pU48bdbjDKmYmbrdDkvS3F0ggVDbFmv2gYz4W8mU81ORWz9hn7Htjmr11TCWijEKAsOLXvI+5wh9+36sJILSWvdOwQOKoU4rlxXznX34QGUe281A5M3zudRPkURcV19re8j6HtwoVJ6wMzLgQIiCk/WTJwqPVZW1pMuykex5b1tJv7I6XsiFgtWe1rFOSs4USRNNWjjAIrdsy7iLPsoBT+BPfb3pRD1eUNgfVgtEx2VnYO5EThwRKBV/g7tWywiUyx25tYuXh8DBHAwFMqYJbzHedndDerdJPEWRf053klNV5vA6h+LljOlBmJg+mw7p3KIhRlil3Ijbl81fYRdntJwZDcHfad11id4UXz+BqFoYLMV/zoWCp9StnMIj6AImkMRunjAvYBpEUCPIYQhS3qHM96HGsESs83ZYIHnxZR014STWFMHzZVVNiZWpRJmr6lcGuMIqq0Dwtkt3gQ1eLLaLpXQbWCseFblt+MV1Tb1s2tnVFaOk0qt97pyXa8+7tW0d9+3uMee447KOkz9/ggIXEQ5aPUxccrn2PZqiUk2tow4pUlB56/CL39EUa7Y+oR+h2Im2Jdi1bKpDVDes1YKbHBCf6TRCSCf5n7sld0ep+kgwNEAfgu0Sp+b+AWHTIzRTo5AEgQ4L93EgCU/Y2C/hxIVfDrE1hFnQDgbsSI80OEVstTwq0z8KPlZ+8y3wm9dOnhdQzkttp03fYe/f5Q0tZMAuwdO00QAM8IXJ+QxfAW0d5umiZKXukgEWMFsGuBKf8YWL77tYwk/A5o6Xis249Z3TPwvKPisH1e+nAOXbtXSgnS7n4QeTmXWxU6Qhof49m7bldhvTA0BdnDwd6Dlha7vf2DkonpqmHp5EyMw5R2ApqPgSlRjO83Ktklr6JWAS7GENjm2vyWa+KH0hX91wgPPhRigtSv1ofwR8j7uknO6BJ9Le5ZYDxZU9OkUx05E68zpKr1EfL1MxggQmS9kkCr9HbRmYzsHIWhj64d73qFEObG+KGmrn9UxK1kiNmJqyfnmHOmctfvX2PZO8R27K07zQuAmGywnNDz0CeNjx3mh7rUZjMCNFJMfEfFYAbO9ykoRl6mYMZ2hDnKBBitb5CjKoDWMo6RUWtl0Kkz6Ymg/BQbki2lQCDGp3ifRwLA6qKCghhZxE56ZiHn8ESUNO+ODayEE//ma0NMh9S7tHTT2n2Dg6W4V85j/2ZGYgjJlaW04hfIQEwJX0jF8semb1xfgbGsK+HsZAxB4nIJB3xWQ/uorrH5R3EvRMeg0CCND6YYKDMjzoIAMd6miP6YMsNIeMHDI4tSPwBVFhLPVNna5fxMjxGkcBPD0d+PanJEVe4rIfLgWJoyxNV8xbjs5AmoEiLMdy5ya828KThSsTyvy7yo3q9yhXrRYgWmcxqBhfpkNLYGCF1EOu8prfQ+FPXcluqExVh6hwY+LX+t2CEmPtvKz/5UGyfDvrrWZ7epuJP8fksi3BS6FLS1RKOv1M2DlWcwYAaKn/UEx+FloLuNp7C6VljnHCSGDZsg7b4xoMwLYhKS97h221VcHc+rGmfq6b6zvs73f5aEuAo7FfUK0RY0QGNOW7DxpCKET6xHcE+PSGw10YpLcwYPKrIWV3ccQ3Rv6M66+LXVhSM9S4Zewyt7f1zb11gMGYjw3Iel/szK5wZUnQTcIGnLNrdcW94uY2DEDV/ONZRxrGJm2adLWXNHAHdqudzTIG5/9bcrpZhmHIcRWd4pHAD0WXNtqeC/0W4K+xBLmmISu3aRpzvh2idgMZvodUf42YdbVdghXlg6aGHPxH9KVV8w9jhVZyDmtQQB/ymhObgIXhaih28ZrspvUbVbKm3DZ9OyEBMpLONT4mKJM7fJ+aWBLYL6j2Q0hb8KnNttyTzSqR7tO636zlewrgYENvub1HK6x6Tux3t04rgoNSgM/X35NPZd2e+fKffjvI/skQsObqmBHWJBYEFY2sWXpGgPYZXTqQIBBEU3oLtBW72FGdvaONOZ6C219zXYUrmpTEKsbJu/V9on5/2YDC8h2akw+7W8YdInoZnne105/9ffbRATByckOgc8Y8MFqO7X/f5CiqEMVyhj/0HNYOj3ZoE3ZHdJ6Hm3awXK3ibFmtyZhv56IAKY+nx/Y6B9dkHkFSintQWno70ckZDS0cS20szE7HEL44F9VDBqKS6730ZmwjIo4BKe5v/sAZd/YxAMfVowxhFseuoVNWR4/9wYLqB9HIpvaZcgzrJ8sojZiIs1u0JC8172Lu+CpuegOaLb4V4gEtg6sTfe1ijnxJc73JVrinBlvwqHv2SUTFxezOQulLGzchxA2tn11H/P5v2rFr1inR0OwWOq7rM5StDFKW7G7jPRZdJdiynXUUhuyrjfb/zGC0yasUbq00A24qYjQpzflFfoMz51ONQIfigQ11pnMlIDXnk8jbaJYmZruF9mG7Q7zzoGFxC+/pZJOuyza3+iqXGpgffz14Qic1YDvVtuabVpNzIoDlGXCOddSaXcldqtt2fyPNcEeBqBajHOUCR4LdUpmUOxyk8D5QqzdNX6550xnbnmHaxh56FVr/x+KL0IGk97Q8rXfRzGPFcAQ2luZZzt/i98fFBGc1jjlQQA9FIt2a6ehcdzCjoT2aAovnUulVyRoz3bbooSnNRd8llEZ2e1h/ls0XVsBJkpccybCl7aZd+hvttJw8ZuLUOQMsdvdVI+h3tawCAhVHt2Ur/YZMQp84s/FaVv5EOJZ23bt75mAYgnfEoQKbqcX8xvBf4nEIuKHBvj1YY5ZpkYIQGcNHbS+fEKer5ojL67d91cAiTOVuRJbkCEMtOmdT44AznOV5R5qEkgVsdfVrro24bjpGeUlf6dxEMAkeFP7DHnGkaJmYri3QVkY03Ic2Y3TWptzRYAe0l6ad/Ezw0QeSygWWggrWCss0az9JNw1ZmRst86RWAFYhEK95Qjg0DE0NvrsWsQoXz0l4+DBwEP7oLy61MF6BNbqzBIHOpqJoPmWVeGqd8jODNfc5CgCZbMmvdgrgbiWSs8xwG8I7vhW0QgBOFfj2HJInl3vvnapDY5XJM2W8RxNZliBaHz+NwyGw5mxJietjf5eER2CjnyoQWds8Nt0ZWfFwrQoopr+yQoCmGdtaqu+ZwicnAtr+woRC/vy6ntONMihOjArcEz2X/A/zgDDPoxXnzNWaUgToK0pCwqBl9YUYqrfEuihASHmepWpVnxDua380VtovG4o5sZHF1Oa8rx9Y+rrH7KVdrSSp/r48Ksigt6BUxkIaLwBYkGCz3ctsWOn2fVqeO6B2oJM+Hvcvzc45L5qnD2xYGNBoC0zi77F0Z4K4LA7n5tfZQ0ebQYsIXKZJnLg8YqegIMgvm/jYflbYx6mqJZ/ugaB+yjamqBSFvR8RRka3vysUv/Aoh5jpmGx69lgOfSK/hA2/rF0AYUlW1NWdqIW5wpa03HwQz8nwhriHwYDCQxFvOyx6aHKumj85RNo5zfK/JuOuXo999jAev7bIKDZerdwxoIfAo2bbviL73GmtVSir4+lxNv0b3ZwmMhj6ZEG4w1m1IsiTKeaBhh6xf57LoRHw1hfCKu4YZ5SAmHLvFq2If/fWlkJhIAU5oEXVJbLP7dF4KUKPtvHoCj7KvJv+sMcdZmGQPtMAwwbLDVXFNJjd5XRQSIaoSZ/dgEWpQugOa/VThBDGDTlu5xBWq38WUlcNGVhB6b9fUWHsBic8RR4pKIMXZ2Zs0qnchDQRKTEbE9D6IL8Sslf31VMOpqyl/It+hO5wjp39efVe89QAIO7YSbx1TSH/I954iIIiUkz8c0hfjbRqiy3vjQezFIw3RsUnYHIeRZEdDXSGtIJN71L8BmnchCI9blPG2vOfUFAo3/Q8BhKjEsmJtwGi5grfhMIJBbzbdc3aORjWRJL+JLoSjf0HnOiVSjj2Dpk+Y6z1FBQVt9j0iTW9lQJ948vUtR/FQ/+/4rSjjkFlg9T1BGlKEu6l9Exy/MsC+VpqRBgu1YTnEUTqwGzNVy5dvXF0HtfMDA/VAE48sdEEtXG8iBWCj4YiCMSinvfe9+pTEPxMBlD51GatlM2LMFmT0R+62uIdc+nHAMARRNLibXB6D0FcozGRpvjIWu6iIGvgMUp6lg3gmF6uLlu+H/ola1aJo5YQtF2aJ6r7y89GIxGfwMsWS2jhAlhjmcZRwDl0lh6oZI3cDIWq4sQW+bs3+GlbrVDhP4/VQsAPMf9XlHvPnxulb0VN2eo2eVhZZCCWLlpvAai1+BUBgI3UvQlvPZp6B2KvOnHH9BkPoNv/9vg+PPNKzjQt1+sbJdmjD1BYRWAJ1OtUvdcdNxWmmjrX43N+9TCADMR5rBzxf79tFsQj/4L16oaHYcdE9XgMopBgi3n2UvniXC3TpbAUc2APfSKn4pYOp2B6R87oEslVusaF/BNWxN5cZVI+60KvmjS5hrrkIwyaUzcyXv2O40PVzTSS1ZbvdD/mcBYbeK0qM1YKX+/vDAsNP7RU0UyRH9EI5hwlOA0PgL474/tS0TajCWUd2Pz5TsmvyUTHg81+PHtpl1gzu8/ZZAHCoF4q42h8yn1UxifmuONmPyL/2Y/RQPlinEfCyKa5ziGsAjoE9NRtOZNsfXu+g6Fmpg68E1Km1iNieItuirq97Ij8E0Fbz1aUdpDFPnC13dQ5D31T3F4pN0eB8M+/QkmTwuPoO9XAK61Ppq1a2hN5Ccm1xIJN7RocP5OOUDETpjNd0SoKiVELb7zm3INvaYUAHADO7Q8zfuEsHYaFwEU+DS7ODeILD6+JVgZNrww9EoIWU3UwchiF/EZR2cWCtAE/QqhqypX4U3bdh01hObfpBFz1RxThZRv1Hc0ZyTY35ZCdGYUNj6sHBhiGGTTN78VkRK2qjF12lTOTc80Zlp9/KEJuhQ6APWVwZ/HI4DTlU280/csNga7xrSVMj02vsqT/1Jr8w9+WG/Q9qGEsN7HC33PMTGMpW8p8kfQROCcJWm0NUsQALD35BhDc8bdx3ja57jCHVsI0Cj7pBQA7qromFgoLHUVV8pg9BBF+/1CUQlcbcf2Swb0pcaS4NhD6yUP3Icq5qEP8A1Fm5Enir+M9zGkFRhLmOti6t37DYE4YjvS/XpTT/MCZiY3q6I2fbCw1f4mHH8pIpdLA0dQqppz2pQCwGUV/AfefO80HgIaL5ObFMg21QjlUczDNvW3Tc9QTFsiYXVjoQgN9jFBwtAX0AofsS6CcXWscVZVon8XEx5GW31TZ9n0LLdyBG6L71TFDtdMZpvqk/oZka407i01Da5x1Zpy94LzSI0ykrsE1nCF/lvO0mP7Tayntesr8qSsJSnn6lsgLAW2sK2CcmmUv9+kbDuOVIn9EEMfUeRNnIRYr4QxZc32DS5VYzsw9r85iEkCfwXfU5Q1to7W3xEoaIztJI3jozMkbmSNqRArUKdxECAio6Z/3Dyy2M9W5Pt3EUnNz5HVSvbZGQ0XTXgG1XhuxCxPE3sGfts9Eql7KviGfHeLzLfozzTKGamtANjqv5uIaFYZmgGKb9FwRk9Cs0rtKgMKLbkGIjpsVxlC7mHJQDukJA0PpnBVnLKuc0r7vgq+YiuYbdkY+roiX1aBSyJ8oGj0f9pjBG1mMQlqXQ9jORRDCEIaixWLyKgx5U76DUEc2o085HfsFl5IhdAwPVxRtiH1WPcuEa6aLfs9EpTlOBHJ4YlMs1LTumoNaWuiwa1rg777DEqnD8nE3zFHQBP4hd28GCJwjeYc+RExmU70G7yRYsLW14dCnzNxWxCKfJrzeHYQYhdPn1fggeLp7EijHUnQB2tiiwgNU00nD2XoTe/hMvhMK5V7pYJ51uWFRMoKOOX50nUV5T5yBYMU/yKZa9r7CikK5WluRABXr79R8NXrN6a+/qEm7gB98JLrk57Vk51F5AhF+6yOV+zC4ljNirRugmP1OPZWYPLHyuIMPbRZEVvsq40d+v+7DJHAnOtxBr69Q8u+7j1Mk8Cki9A+tuxU7TIw0aYanB6kaGP8KuSgbyvK6AJAjhbaNg+CyLT5d+hv3PjG0OMV+eKRLvVxVkydrL9hEWWpL8WK+4rGhbyyoh3htVgf/dRjKK+238eSYlZ0QwUgnzRCAk9zX1GUo91Asb+xDcYksm9rCS+DqXwOoKCEa1RWV5ZEzIZYXHAUlYNepShjrDOZHPWaax6alRS8eK5IYDTR/4hZMHfiyPJXir7UNU48NBFoGjfg6GSxIBtKKJRrTCFRRp8VaeywtSFZ2fYmSA+KZl2Ml+ve5wZKuJcQkV8nLPNnRARBw4o+qygril45KHZrF5NQp/wIaJy6EJcillD6jB0XxrC+ia1nzHfs9FmPpdi/p9o1eaqiLeGB68WAVMUv+IQi3wMi8yz2s3MqwIDZYj2xXTjhdnroAIF2LDsgMcQWKHb9oXkNfQ+7U4tgJZxZaSTea8aAE/ENg0yMgk7sWWBEEf2TGoGLKvn+BZFIotTmuiLbg4cS7JuVbdI1PiFcpwxrfnFlmYljE0OaAHixzqtiypnlGyYIjV1mzEr1LiLCBNfFdDnu4RcfzXMtocFvbR64Wn8kzlghi/rhxW81zSH/o3WdixAKcfQRWj40nGenlJMLbEU+mEOFtlHXe3jxjCH6W1d6IffQOo/ZMo4pZ85vUPD9sQKXddihCxXj7W9o3b+mKDvfxtBtFHkSWXZ2pDmLGbINc5rKl/NrFeCvY9aQ+6yC0eK3dh3LoKTRhg4pO45yYmNSaxQAcV+cm4j4Rb59uKCMmVM4yY1DyflpAqsgMMc6ktEoLM/tqIhV/4uUOyLr+hiuflHSy0Eofq8rR999LKiYU4YSC42+tDc9x7fCrEjjIvH+gUggTWqkvU0NsukZ2uV4LDxdYDljXoOhNGeTm8rfPEODmbCaQ4l4CU0aQ68HDc3M6H0CtWBj3rXdy+D0LMUkYlTExSaj3bbFvDaWnqDg5bl4jOSoDEU0VuhD+3PI++yUEFU1F11eWQ/iCwwllKw1x6KprLWG1sPsfY1nphBfADj1CVnVhTBoyDto0+NzOoY5YkHFq1nMGXZIfZp3OKoZopR3SiWjjx0yFXMmdjCeWSki7Ssid0wsyMW2/ZK+ww98w48xVxxqxZImcNkcvLhdp9JZ+qIS/01txoqaWCs5ieNNonpuKtemZ7HeaDWL0VgX1jlxHZSXJqTnl3tyQlplQt7UiFbPOAt7lMLFaE9Veh9zxnhghrqyAg4xFeR4RoNtDi+FvaD6C8UggAnVzxQ8xeoSp0+xpNnNmrL5Fuf8WAZp+nLft+y24St/DPq4om5viywwO1F9mKx7nisGTmTVhn92bQUYTO4MDF30JEW668Dvuk+UK0ITp/Sm11W/dfdYqWqC73TVcfUe9tB9Sk1oya5+F/o/7dqX/rr6+/15IoBVSij/dL13iBIWTQwAJtEpEX3v7pncobPyv9eI4GAK3sUvIfdiTUo1QfA00RBHhHl91mxfh4C97p1VxTpWpy9Uprkur/Z9C2I84wAAIABJREFU3FNiBlbKxN9GGJ0HSz/c7Xo3vzly2BRQhc7RvDv0im8EJ0egjcChCn6C/7QrzN8p8k8Z0rqNkfY3nuaIdphasbgZDxD0b6cttPJ7jatyyh9jCURMiAaDoVeOomZHmq09jhAaYjcghU1qu5EwIcRjXokTf4MDVxgTxSVr5xxtLFA+vFA70/q3xsET6RMkyskRaBC42BqlzDYvbvqN8qbWphxvnZvyWPeM7e1Yy4Om/qmuLJZQhCOwmsYaa13dN93n7H2IFVcqDNCq71L43VT29rMLRBRME9wNBeXZ0fsjOxcN0Wj2otChiRDWbtSu3zAJQUSm5vr1cpWUrTGd6sKifQ/hDe+EbXquoj1Je3Y+r9vg+O/BCOC8p81zQ38T/EVDbIkPzbN5H+GjFGKMRDjHvS5hbTW7Gk39Yq7oSzEulUKaBWiMMzdNBFJ2wmZHmiAbMDGrcW2Ep02MzPkfNuJTJQYwJuXYVcwmbHiGa2K8E0IMMhozIcIgp3L/WRfRLxNCAJtzrdfLmyjrS4yOvj6w7jnOpcYiQt/eXkTQx0GRL7XjsHUYtO/jGjzWr0gqHDlybJdxyO8YpTxNMCLC1M+OdlM0AI2l8Te/qbHRHEbpovTt/lCGQOHyOCXW6/BikMbkksF23Tsh90NMO0Pr6+9NH4EnK/mJ1R1CqYY0LssRaHMQRxycZ3Pshw8NvMaF9Lec73B+XeJYip+GWByeHtG4uyryi/VAGFHMfJ/gUSnlWXVM46LEZh2GMh+i63PCKRHmKzGY9H2DgwttZEUC8zg5AiAAr2otWvDhoCX0XPp4f91zbdCyrrI3W/k4QiPKIA7HUu3uravXkPu04e5dFSnknsYS4DURddDEszgqIr9JfKLZhhnCjCHvvrpyALPDJFCLLySaqOxwhOCR6x0cNmlXa/GI+JelIaD1+w9/s3rXEiHDY/uA1YqNxQhOqRgn0SuILU/u77BG4iiiZNK4ef5ARMVQHIxth2Mi8pvEJ9qtvlhA29/Rse4xCbRsCsnRS04viW2su37jX9zJEQABVv9aJbV3GUGJfksXv4bc63NW1ldEtNRT6jeF1CHmHfQNsJaKMZPrw8T6+bUU7XtYRGEQiGIw5RuOcGdJnB/HgmLx3Q8qiwLOZpZG5xIRQhNbYKhNIybewNLaayn1tXDkhftaCxpLAMB8kAlG269yf39w5ZU0JlKrRVvFpIFFQixGx0Zk6AJAB2hs/Wol/thGxKnNkqO74bcfE8dY/Cy+QwBz7f+OjrHAW+cwCNnN1rsVP40lAIwVvTS2P7M6xepgarSLYuxjB3UouQCwBjGNNmYs04a4tV1T3FndZrBEYSoWR+13j5kVml4ZDQIE09Lyk6XS2RgCAKZiGgc1WvyGfM/Cje3+qbrv1lh5YP00lFwAWIMYoSCHMJ723ecHBrZZU9xZ3t5rBOXAv/W4FZ4l0F6pTgSIoqmd+NC8tzx7HkMAeEvmsTBmLMWbH8HB8JMwZcLXREz9+Yaxayi5ALAGMc68NLGShzQi7i+duhHAFE8TJnNIO/DuXOKld6Ppd0MR4BhQE3Sn4Tvr4DK5BQBwwOV4U5/Srjj6wl23JrpiKE/keA8X8rEYI6wOPWpyAWBDq75R0RihjYiCkdNmBPARnisoyJS9LG5G0Z8OQQCvaqF9eN17nENbO5vJLQBoY2msw0Z7/4gqJPN9JrzVv4kXNX5o0KEaQi4AbEDr+gaDwCZGn104xQ1Yah9dSunWd1M7NM8+qS1kYd+zhY3b5Q+JCCFoDxQRjlUw53JajwBa43806PvaqH9dJcwtAGi9aTZ9y+KKE5+XFOa7v6uNNPcIiqQ5dhp63OQCwIbWAkzcZ1ow72oaMLLTMATwWnV8ovagfebi+e/CIoIws8pzzf/4hEcQcNoeAba8scRpsIq94hFv6GC8fWm2v5NbAECTPhYDi++I7YEFws1nutpfbWHcKMfi9o/VxAL+dwGgByQLG+CuBi0tCEUPDMU8xnNVChNNS1OtMcHiuIRBs4vnVu+hNOW0LQJW1ie32jZZs/9yCwA3DuSlVd6K/Z/tbwQw9KJwDpZCiDJrjAQJ4QslFjt2rYaSCwA9iDFR/13RKOsa8w49+frjbgTYvkbSXYdr7H2sPqZOKEIR3nQIBvhwdzoRAY5M/j0Qvy6sv5AQ0NwCQGqnaAjzH6nNfjlyJRbLkuliCv5DIXIouQAQgBhBLro6uubeKwPy9Ve2R4CtQA3uXd/ifXCo9uz2JRv/DtHAuuq36R7C1FXGL/roJcD86kcR+K1iSyCcKySsTW4BQBN7YBUbVveEkMXNNj7vcXozh35n2dwoIa/iFvo/x05DyQWAAMRgVIuVQbshZxtIIQBPzSsMHm0cLX5buWnV1Ev7LcpDsZYS6LnsrC3AhL/H9OpjRnxFmNmUlFsA0DimoW/iQ+ChtZA5Vec8KdtzNW2NzsUnVhML+N8FgACQeMXCI9jqZMV5ttMwBL5nNFA3bRETQWtYifO8fQklLoeKCBPhEomImw0/aK6/ymCPnlsA4AxeE6nz3EtkKEWd8WkQy4NvjsjXBYBA0C6YQBfgUYF5+2snInARRefo6lR4zqJd50DXM8AGvxdL25J9ggFuDW/liN6ZWwCgb+DPoKnj0OsN5tC5MtYBU92hGDfvHxBRThcABoC2v6JxmkZqX7XhOQcUfRavamOyt7HnN+nNhYheuFq/mP9jBpGpYngnpc11G1+OEHIIT2MIAJ9T8Bbb/07hCHxRgfUDw7M56U0XAE6Cov8HGqrfUjRQe8Bofl+oP1t/o0bgKEPsCRM6JxOjMxnqqSwhGNJNDXf0CMKSa6t7DAFAExjt5T56DUIAHx3N3DD0ihXFUHIBYCBiTNhDTa02NSRnPk79CFi6JMWxyBwVkj6uGDzaPIonMiKqzZWIzqdxt9rGit97ZgRqDAHgcQq++mxGbKae1fkUOMOHMUKoCwARXHMWEXmXiGDyszoYDP3/u5m2DiOqWdQnz1ZijXOct1Xa3myVz5WubrilDR8/c4a8eW/DnRIwOigzM40hAGhMb08QkaH+6TNDWkx2eyjGOALXxRxBuQCgaH6cNqDIp92aRoHLaT0CrNZDvdt1CWBEE1yKgxFrM8nXzOiohL6q8bO+ylvsBJ55PdsmeTKGAIC10mrdh/yPgyWnfgRepcA51vmUCwD97dL7BluKQzrE6rvv7c1h2S+gXb2K2ZD/MeFcChF9DsdGQ/Dpexd9CXQMpkqYN1oLRjhQGiNy5BgCAD4mCMTTxyfrnvsxZ1jPYTd4HYZ9918QlsV2b7kAsB0kw2/sICIoAvU10rrnOBmiIZy6EfiqAlswx5/5koizQM2OSRefstrFLezU6Owiwjl0V50092I0ri2wG0MAoNy4643F66MWFZ95Gric1+xO3TUSHxcAIoFb/UzrTAQ3rk7bI8C5duzAw3e/FBEivC2N0Ai29l6JQ5jHRp41joE/AXmsBSF4aswdpbEEgCcr+iFHcHNUurXkaSZwzTiHt9oYcgEgBrWOb66lbEAiORHMxWlbBN6vxPWF2ya3qP8eosRu3YCEtUHJ5qucy6eI3wEenxl5MhtLAMChzzp+CLmPIqHTegTeo8D35wqh3AWA9W0y6AnnZNpgIvsNynH+LxPaVrMtxsCUMjDLFFrgOYqBZdPAjhfFpxSmXIlfh/uKiMaWelOdOaMdW0gfSwDYSWk6iemtUzcCp67Mbv+q6KcxLoCbkrgA0CBhcH2SohEZeNAjOINBOeaSBH76Nw3Ifc8OmwsQinogmL5dieMmnFl9cB4+pqkX5k+E19Za42yqJ6FWS4jdMZYAAAt+SsFHBKpa4lFcSNe9jQJXePaeIZmseccFgDXAxNzGPwB2r5sGkr5nT43JeIbfWKz+7zJDXGKqxPkrkcL6eE/zHEFgbxGhD+QiTDvvV03+30lcN2LWXy5XpXryGVMA0MZNmEPUzZ7miXrMCl7T984bleuJH7kAoACv69NXKhsThw6E4Fw6ab3a/UxEMIlzOhEBthlTCwEMYpjHvU9EWNWQpzWxo3HtyusZ/gk0ljehAy6TP5NuKTSmAIBQHopb13soSjtti8COIoL+VxdeIfe+uW1yg/9zAWAwZJs/uLjBuTVR2ZZMt1Z0iKbTcBzjtC0CTMiHGGDbYNx3RU8AEzAc8FxTRDhHHkrY8O8qInjw4yiDreS+fK2elzb5g92YAgDC108V+LO4Oe1QBpj5+/C1hl+1emMuACRgMI3NLMyA4tuVE5RrCkmyXX2MslP8XUR2nkJlRygjQgCTsmbQif0W19lH10IISmHPqALy4Gf+EbUeASaG+1be9V5cbblj/XGkYcCeoWX+lYiw4i2NxhQAwIK2GYpl+32UNJ22EPiKEk/t7pQLAFttYfbruspGpcPgzQ2Je2mE17D2gBHz+yVLA21gfVlVMwHHYLuEb74nIhcciGmu18cWAHZT8g0TntOJCGiPVI5TmP81beACQIOE8fWTyo7CQIsd95II23KNOQyYoYR5jiWBpqgrxyRaM8u5CQSfK9zt8dgCAKaWONfStLt21apg+aI+1fj+B3+CdWnJBQAtgmu+x22qppPwLWdmJZgerami6W12Oz5tgNkBpqWaf2KPMcBcy+elfI81Qeke68YWAOgRONfStNlb5t+temuItQzjuwbHS/Tm0v+CCwD9GEW/QRAVTQPzLTsJMWEeows90ocWXuvoUPjUdgpHQBPqVcvbpX2PnXvpVIIAcFnluIaL6pI9Sebggf2VGFodpbgAkLC16SgWW6xjBR5JCM02SXPeqpWGmUz+Z5tU/Z8QBFwA2BLSXQAI4ZgT30FBUyPAvSw8q9m9eXoDE1ar42EXABKz11uVHYVOhjnVZRKXc6zk8SB3uAFGaG27F8XhregCwNZE5gJAOP9od+wY084Wnt2s3sRhlkZ4Qk/KyiW1CwCJWetcIkI0LE2D8+33I+2oE1dPnbz2PLHBdS91SZaZgAsAW33TBYDwPsAqVjuuPTc8u9m8ifdKbYRKS4dKLgBkYK1HGwgATHQ4QpkT3c4Ily8v1GTSghdcAHABIJaPMLdtBPCYK14jSzW3jMWk7ztNWOUGY0srChcA+lrM4Dl2199Sdpam8R9pUJ4SksBjosYFZoMHzmVKdNhSAsYhZXABYGsS8x2AEI7ZeueiBjpOmkh2WyWZxi/Mk7W6Tp83rqoLAMaArksOV6gWCoFMeLdcl8lE7uOl71gjgejlE6lzqcV0AcAFAA1vfljZjxkTLVe0mrqk/tbC+Zb12O8CQOpWb6VvwQCsfJEisTCYImFn/QXloNGs/vFLbqUMM0UsLcrsAoALABo+YmHT9MfY6xJMnRmvWbzFYsR37CJbm4S7AKDh/oHfnk5EfqRkgoaBjp+gkyC8iFnFpmflcKOB+Pvr2yOgEQAQ5AgRe4QRTze8HXMlSBDKURoNaz8C2J4/Qu58xqD97xaS0UTfYdK28Ax71wT1dwEgAaibkryWgSTYDJA/rMKinntTZgU9w9Pf6w0GiqbuLy2oblMuikYAIGBPQ3isRNmVSRR3zE07pbx+tzIl4wjo+iJy8rog9K/YPF0AaFpz2PWGCsybtsKM90zDsp3M21goNfWMvf6gxeOWFXcBwBLNwLSeZcAQDSNhHnj2wHzHeg0J+JXGdcacxkmPgJUA0C4JSq9EsyTK37tE5Nu1L4uGZ4de2e1hx4sJGtMxwkWvi/boAsD6yQZrmVT0RYP+bWnelqqeQ9NF8e/3BtjcZWjGge+7ABAIlOVrOL/5ugFTNAMpPsxL3Qlg5Y/Xr6as2uu/Fhwq2ZIHm7RSCABN2u0rQiA+MTgzvruI3K8SCgj/+1QReXa1+ntRKzzwQ6u488RJp2z4Ox/in98FgPV9LaUAoMG9GRMQ9Ig2OCd6r8HYx1yRKjKsCwAjcdvFqhXSnwyYo+k8PxYRTOtKIgSddxrWkbo+qqQKzqAsuQSAXFBpJiI/AtC10gcN+johbnEyNAe6gwEejHn00VTkAkAqZAPSvZWRaWAjBPxWRK4akG+OV1B4tFB8aerGFQVCay3YHFiUnIcLAFsrZhcAdJx6aSP9JtynT52YWBmP2+NXzO/UPOkCwMictp8Bk7QZ6+8icp+R67SLoeOjpm5HVee/px25XnPM3gWArUE69WBrwT8lRAPcVI9XGI1nU7YKQCH1cwY4EDVx101gGzxzAcAARE0SnO1YhA1uJsrmitIdW/C5iW0vrY/wpg7NFSWaC+euyELycwHABQBLVkeT32Lli5fQi1gWLGNaVkreL85QZhcAMoDclwVnXmhKNxOe1RX77Ev1ZW70fEcR0foG76o3Sn83NiqjJ7M9Ai4AbPU73wHYnj9i7qDg2dWXh95DuXlqu343NTrWJWBQDidnLgDEcHiCb9DiR5FvaCfpe5+AG/uICKZZqeh6lWY3Pgn6yjL0OVrBaIw7pUPABYAtvnUBwIbPcPhlEeKb8QJfE6k04G1qu5UKStgWJn/Ue4+tZJP+cgEgKbzDEoeB8Gg2dKIMef+bIoJ0akk4f3mTkcTbVQccyzilRcAFgK3+5gKAHa+x88jio6tfD72HnlTpZBnf5CMZK+sCQEawQ7K6SuVR7a9GHaero+G2U2try24F2/3/TFjOA0LA8nfUCLgAsDVJuQCgZqdtErAIfcsYxk7gvbZJuax/dhARC0dI1BX9qfNlrJ4LABnBDs0KH/d/Szi5wmicrz2smsjPElgojhCYLD5Q+VtHO7VLuLC69xo39wtsFf1rLgBs8bILAHp+aqfwX4YOzxhzbttOvJDfHHfg7dJq7HtA5nq5AJAZ8NDsrmsQOzqEKYlQdWTtYnXP6uzuJiJy+XqX4M4i8sTKt8DHMpWF8rKz4Lb+oVyif88FgK3B2wUAPT+tpnBJw9gQmDgzLpZCTP5vMZz8WVzlHvtcACiFmzrKcbVqlf4HQwYLEQjGfOc5I3SADtgXdcsFABcAUjP8Aw3HMLbIUToem5j832xYr58P2I21rLsLAJZoJkgLxx+pFAPHnOxX88YnvFN+BFwAcAEgNdexqj3IcLJkJ4CAUGMRjn4sJ392YYmoOAa5ADAG6gPzZHJcnTDn9D8+EJzGQcAFgK2+5UcA6XgQm/ZjDccx/IOMYSKMi/OPGtaDcfwp6WDvTdkFgF6Ixn8BBpnThL9al2+MD/FiS+ACwFbfcgEgbTcgVoC1hROuh1P6OGkjcv4EDtvQr+I4YSxyAWAs5Afk6wLAALD81UEIuADgAsAghlG+fNcEi5mPi8iZleXq+/zaIvJL47Ifk8nb36a6uQCwCZ1CnrkAUEhDzLAYt1AManhpK4004YA/XVplOspTejCgjiJvd+sZCp5b3T1s/ieM8A22y0l/Axv/5xlFOWzKyhWPgYSEH5tcABi7BQLydwEgACR/ZRACRGxkYNO4Lp2bAIDDmUMrHxkEtMq1rTyo0So/HHMQAFAKfFsCIYCJ9UARISCRBV259pfSnrgtfuMh8ToWBTRIwwUAAxBTJ+ECQGqEl5E+2ss4UznEyH3z3ASA9uD+s+psFhe0eL0sieYgAIDnqYxC5rbbrPn9q0rXADfiBCiLoUtUQdTebdRHmjI119Lim7gAEMMhmb9xASAz4DPL7pxVfeChnxqvuvBWyWq5FMIf+xeM64gHuvfW28u5nbR04ToXAYC6naF2QtZMjtZXzKdxR3zBLiBX7rHjgwdWHPtglmddlia9R6zkO/a/LgCM3QIB+bsAEACSv7INAkxWeE3DTSkmU80AZH1lRYO3yLEjthF8BqUq6/q10zu68tX+SMMt5m0aLPCfOQkAVBlX5Lglb+Oc4jfB0NA9uGctzIEj2/D3EZHXishvM5SBcbw0cgGgtBbpKI8LAB2g+K1OBFhVEePhuxkGtPZAzbECOw25CUHnIRliZ7Trys7H60XkSrkrOxMdgFXYziEiv87Mr+32zPGbnYUSyQWAEltlpUwaASB14J6m82i2zdwPwEqDR/xL/AaCKFnbWTftG3L9XT0Z51Kgu6yIoLkfUrZU7xxRR6o7TUSbxXwytx2ABgPGgFRtVEK6Ja7+wd4FgIYDC75qBIB9ReTGtdZtigiDX65cFT+oDh4U29FcAIhjPkyU7lEFcDq8sMGTLd07iQhKhykI86nXJT6rHcrLWFO8oOpnF01R4VaaLgBMU1BwAaDFxP5zGAIaAQAlmIbYHt69PvM6PnLSOEFEPiIiD18Z7DiDHTpoNu+7ANC0UNj1InX0RlbcDYYlXn8kIo83im+O1jj+37E80Ow2pcapMSW8fSJTQhcAyub5dfzlAkDY2OZvdSBgJQCsJo1rSzzBPa4+03yfiHxSRL4iIp8XkQ+JyFtr5Rk8eF1ORE65mkj9vwsAa4Axus1q+jYigtczJpl1A02J9ynvYSLyP7WmdYjXNmLJw1NEknv7RKNiYkpIHI9zGfEAybgAMC3eb/qjCwCGnWBpSaUSACxxdAHAEs2ttFCQ2qc6Z47dsWkGoNKu7F4gaCLQvFNE3iEiH6wFUILG5NJdyYELVhjvqYTq6xuEu3YBwAWArdFB/8t1APQYJk/BBYDkEBeXAQP9G0TknxNb7eeYUKecB6aEj1X4rncBwAUAy8HKBQBLNBOl5QJAImALS/a0tV0yNstTnuS87P3tR0x7dj2uN5AHXQDox7ZE/vMjgIGM7q9vIeACwBYWc/yFbgVhTf/iE/8iBR9MCXFIE2JK6AKACwCWY6DvAFiimSgtFwASATtispjw7Vkrx5W4YsnhGW2senOs8ucChS1MCZ+/Yl2zyqIuALgAsMoTmv9dANCgl+lbFwAyAZ0hmwvVVhUlej7DTwR6BzjYweyO32NN0qnyxT88LmB3qlfdXyu0jihI7tFhSugCwDR50o8AMgyuc83CBYBpt+zJRORWIvLRQk34vl07czrdCsy42cWOv2S7+yGCwlcrB0LnXakj/16zNnclTOuQ9HK8SwAnnHk1bpZdANi+jb6UgUfZndHo5rgA0NHx/FYYAi4AhOFU2ltnrwamJ4nITwqcWNgGx75+twDQUFQ7rsA6hE7ACDAvFBGOXTbRWWuBBwdGoWnneg9TQkLUEk0uNk+8dpZKGlfAmCBfoNKheHaCoD5fb+ln4FQtFnsXAErlvAmUywWACTRSq4is0ko14WNFSVS0oXHusVBAUXFqToh+WG/5t5qn9yeRDRF60NKfkz+COQsATaOy23b12i3zjyMnbHbEGHPpx21yAWBbAYhFgVMGBFwAyACyMgu2z4lKlyO06dBVCCtg3DffUkQYIDVEiOFSz83buOCyGs+DIZr1m/BgZflMEflV5GTSLtPYv5cgAKy2JYLuLWpnWgfWrqQ/Wzuh+kQdLvtldd+9RuViG0F3HbkA4ALAOt5Ich9FLDTFj1IMPu1YAEkKWSeq8QSI+RtCTnPOmbKc1mljwvfKwk34bmhcaVbIKKiVeCzAip2oiJbud4EP98WcA489iWvyL1EAoJ3QcdCYwDL25CCNAMAYzljedwyVox7tPNwKoI1GIb/RFH+O0XnWFASAZlBrzjnZfkUBrVQi3O2dReSLE5kQUJJKEZmPuBB7VUF6OCdt2nCsK2Z9LxERAiWlIFaPY9XNKt9SBAD6Nm6RcY9Mn9fWbwoCQFNHzGsZ2y+cgkkj0nQBIAK0FJ+0NcUtta5xMoI/+ZRE2QmF2jC5xfV7dcRBIhiWQkx4Dy1Uqa8P8/0Sg3jtWqnwr8Z80FcvhI9HVfbzp09YP4S9vnJM4fnYAsAZayXG7xvjOSUBoOETdGmwCsI6SHssp2F9FwA06Bl8e7ZK0WhvEYlVWGkYatMVxS/rbeCm6jAQZ2mb8tc84yz3tSJyhSbDka7Ety9xyzsUW7bGOeNMTacWEULhYmGQwpkQK8bDqxgJT0i42m9jRMTMPyTk79D2s3hvLAGAvksfpi9b1GM1jSkKAO06YCWEtRBWQ7nJBYDciNf5XaseJHMFe0HiZBvT6myU1TAmSX9M1KnbHaT5zQB2TxFhkslF7J4Qg74pw5SvmLfhACcXsdV7idqM6vVVKGCOIoY4QMJfPkqV4I+OCNvGO+YqfBXKF12Hz82k7eFbTO1yHa3RR+mr9NnUfWbqAkCDD3MBlifspuVqJxcAMg4oaJg+qFohYWbSNHruK1L4Syvh42KR9War9ZEjr4YJJfu8ynnLLpF1CP3sHjNQ/Frlr5eHVj7he1hMXLoKBXy1elJnx4C/m9Ume5hfMTAxAY9JGpv7VdxL+f8Dla7EWRKCSp+kb+ZUmJyLANDmEQTfB1dYrjrnsm46FwCsEe1Ib1cRYeAtzf/4kbUGLisrtJy7CK1VBmRM3A6uHKWU5C2NXY1DKg9dtzVWckNQe++IQlp7IKCOH6t1DyywJz1M+Zw2I4AyodWWNd4UnzVw96PNA9a/fx7oAGozQltPUTClD9IX4S/r8valhzCZgzTm2H11WPcc6wisjHDPnYJcAEiBqoiwRX7XaoXz+RE6xDpm6rvPWecxld0sLlNR1EF3oO+bUp5TVgtTQiwwSrDl5/z8gBVtYYQwC7xxjpPzKCBRF0uWLDsPVv32da1SYtZ7NxH5glE7aniB7WYiEGoIs1363NjjRC4BAHNFDebab7E6wvwWPrIiFwCskKzTQWkIT2tzcByiZdgxvkdJ7F31KnfoORpS9i9G7uSH9dgLv9OofC825vs5JYelhwXvYqGwTl/lMoWEgGZnYkg/4V12kOhjFiZ8Fjizw5qDnmrEF9o6E9AKt8cXNKi0CwAGILJi4PySLXJLEz4toyz9+yGmhEz+Y2l7Yzr36g7Xo12syZng0QYDEXw6tmVFV/3GvoeS7J8M8EU5NsQnAe05tl4QcRL6hAB0fx4mIt81wMZ6XEKYykGlCAANfhYePl0AUHDOziLyOBFhS7VpFL+WhwVnuXiHu/yatkaSHmMnsGYEAAAX5klEQVTlz2DKanOoDfsVKzM4C+sRfESMaYO8pjlGvY1zGos+zFbtUCIwE+aTFm07tA748egi+gx9J7d/hyHlT3U+vooHvjSGlCvnu5iRP7HSNcOsfAi5ADAErfpdlOIIjGKlJJSTUZaeF3HWOftsfMSjEc1OQS5csMdHE1vr7XAfozIjgDidiMCNjTBle1xDRCV87AgLCxwqQegvYZXxcSM8UvetXALA/hPAY+j44gJAzfR9F5Sm7leI29PUHWoJ6WNK+Nxa4TFHfY+vA5JYeWVk5W6hqMZW9RgOSPr6W+7nnNVbOHpiJWblvZI2JoATgZxyHC2Sx5sSOXBK2ceIx5GDpiAAtHHG3JzjpU2mhC4A9HDOJWsf4zkd3rQb0X/nW51bY41JFKuo2xibKTYsS6Q6C9PStqZ6k/bSrppALw3f0N7XSQQc1ikofqEA1uTn1xOxWA3bm6gJ/i+65BQxZ4xgx7pLV8IFgA5u+a9K2eWOlUemTxfa2XCFipMatpFZWU6BKdEYfrSI4AHxbYX5E7DGr9ldCFEC62C/QbdwFqItPyu/XIPooMplepmQsRZn3DjYSk2YgN299qqobfe5fH+l1KDX6SOATR0zTFAxRW1MCV0AaDEPYLDNM4ZCWB9jMUB1KbKhiIgDjr7vx3yOkLLqhx5lFZRWLLZdx6xbO2+UQe+bOeQnFijEN2+XI+Y3afRpgre6yqx+vtkAv9xulmkAtr7RNxjD+U4Mj6X65uqZuPH5BnySCoOh6eKS+5n1gmzot837jN2zIOxI31KQXWsDMFc0xTG/2XSuyCRw/xHN2Nrlbf9mYHpVT9lzn3O2y2f1m3Pfe1fCI2GCxyDcr/7NYHC6wxiFHznPKxtMoPA53jTHIhzhWFkvWPWJ0HTYffpw5eDmWAX/pjp2WW1PdnhC67X6Hou0Ek0oNcLj5AWA81b+5N9qMACsNrb2/1hnNnjmQpChU2nLoP0eN8Ns9w8hzPFwTDKlc843VMqEuA4em4iOp20zvD+OJcSMhd9nDHArRYcCd7xT6TusQOnrjTMbzS5mqkinqzzJYia2jz2g3mErzYlSbH34brICAL6rsd+3WDVpAFz9lq1ylJG0muLsaBBBTSPdrZYt9P+jKle6rCQ128mcT2FHjevL0Hxzv4dSaEkrZvRWwF6LA0cYS6GbGuCFy+aUwXWGtgVjx6EG9dLy0brv6dPtM+imfjhRW/dN3/2bN4kkvhJNta8s657vtVK2UtworytvyP1JCgBo06JEF1LBHO8wSSP9Wge0gd+I+PeiDCF72XHAth07ao4jLAkbX4JhEBQjR3uE5MGgX6IXPVYXIeXf9A5+3QkANXeCT3HVuwmLkGclCkwIg+gGhJQ/xzshAW00RxhY2eQgdldj8SIuTBeNHUgptj58NzkBAEkxZ5jKTeDmCmkL0+H05na1ja9V/TmmQHDBzhT3qakJW1Y03scO1IOCaK7wozGYYmGxie9Cnj0mJuOJfcOAHILFpneI22At8FrByMTC8dSm8qd+NiSkrYZvsdjKQZo4HIy/fdSEUmZuSN02FulPSgBAka6Es/Evi8g9NwQJ6WMS7XMGBlbVDxQRtrQwC+mzesA3OqslpPS9a1vnHbUFUXw/lstUjozWuRNWVMf0U7YWtSZtnM+O2b6mgHQkhuIp+g6aQZCdO1wyl0zU86PKeg7FCDfGuDOmjw45BtRsr3OkkIMOUmA55JgCp1TMEcwV/3975xqyTVHG8fnUgU6SVkRFVmhWRlEfwuSVirAsO0iRSWoqiJ1LU9BKKzqYvYlpBYYVpRhEB99As6JIrMhC7KSVphVEimWURXnADz2/fAbmWfa+7539z8zO7F7Xl91779ndmev6z8y1M9chlv8lyzejAJw9MSMJGfyFSpeNfcdh2ZcQpASXQUHYb/vLfl0UKX/vVEdcCVFIsMIvAXws/VugFGlLidkwV0rx9X9JI8zZeyu7JC6KufsHfZC+ODaqJNt8Y+uopjUeKkpFmTp06Es65dhqZO6oMex8EwrAlBmcYrLRdeRuPyM4UMKVsJUBH7bx9X6rMKAyELMqNEdbAJbs1W0kVlhKbHtFdIG1RZlEcqTuZRWESfHVCZJKYas0VgEopaxeI9TxkLUS2vwnbuAnF85bskke1SsAKaKkbWJC93862tcTJHvZDAkr0ceBHCFTsfhndaQlYgmxi83Y33NMFHRkAr6wwtIaKT7sXdxgBPuJ7VXCVHxQ4uyTpa8EKV42qRIWsa1CBFjmmBxKXVfW635XrQDgG1qSQVhPMzCwB2s0PQe8K6GitXvwt2gUx6rI9eJkh1sqFuVzIQZP1fL/r43aR+Cq+E8RD6SPPi7TyhDZD31/iz1eUAigyqoaW6upibmGOYe5J5ZnKcpXqwCwPIeWmqKRQ59xVYJlsNQAsefdb6WtJHJiEiQ9aouEa+lQ/K4qV8rAqgR/2Ydd1c6h11mGbZXYox/azr5yZEPNRTy7751Drn0xV6U6z1WMa7HFyEUE78LL4PuFY79UqQCwx6dElRoCuFVlSi1F5QLSHJ9LNsdV8hpynaXJVokv3uvE9hPRcS6kGHGBFZRBn0SlRZ5goKesihI1NRcdJeD0slyVCp7LStiQ8WJVGbyvStABzjlyFqRy917VHq5XqQBgqb2u0jn/w81wypjgJQDW2jsUPGDk5EOVttZuX9/DE/SHUrHWfZ1zHImXjzyV/p/zCzhHm/ueuUfgAZb+uUiJykjkw9zEFspY7BAIqTThSkj0wWuFem9qb3UKAEIqvfTfZRLW02NdYUqDZAnvw4WmK6Ohv380Ewap/sSXz4APLBMPlXtfOSa/OdhDEDWvr31Dr61LSqbAhIx+Q+vQLYdtQm7CuLj73qG/sR2YkohXQZwFYjQMrfOQcv92zlXlJn5+4gYOYUJfGTRSjLCMpufAjwVMtLz8H3JetQVgZavllZB9EuT9eEfI0IbP4YWyEhKb4Gsoq5StOjIJ5iYCgPWN9UOu4T1QA2GIyAdRyoB4Z9XQMOpAEoyagiV8oBbGLLwe7NsO6aR9ZV42E95hF3ODwAd4Q+a2Vgkvjj75Dr1GZETCac+FlLS0x2digrLEfndk1MExTThCwFCJLYqYNh20lZDpFqE9Yb/BsyTXqlBMm9y5iRr0x0TPQcuaw95plBAqK4zhzX2CPB9ZWXuU6jBwhx039pxJsEVvCJSfm8W2n6EwvsJ7SV8cK39fHk+CHITB6j1CvYgKmpNYAfI8iD2SRKg22iuhsfzkcTHQzlNYPWJNipXvlYKwQ3Dc1mAAmdqAqtRnf0GOUxjuKG3ddC/716q/8KqMZpvePeX/LxUwQF9mn5PBck6kREf9dEZGYFQWjp8x57nzMuwW6kbQpBqJuY608TF87it7x9T2MW9M0Iirg0awHKUsHYdMwiWRrxCjshwgjC25x0NZxJxXZ+GagH2qHzh9pDVS0syCl5wT3lS8JMJjTF8Iy+b0uVeCdg3JtqfwW8lWeIry4sz3EkMAY+dQxmPO8TaajNQvdr7UmfRDInazsnwcMvHM8MF2np0DKFxK6k5kNyf/d89wME5GwxCbMeetuUVi8KYsK9NeUrTOjZRkSGT6y0WKspZ7kiVrakxfCcuWSlc8Vi7YzzEHhnWOPb907MvV+1ieU90bXrmiEuoXk2ciigTpMY3KcOAcEczI7Ydlqlr8LYpbJHxpybhV2belrd8qLp0yLyR5jx+bYo85g+6w2hJbH1/+vMysU1aEc3lOpGyyYuSIDNgyncRQVgEzFSc62CriS/K7Aig9ODmy//roVS+y68k4QGrQkO9jz+eqADxH5A8uVxhstUBqFMS5eIF0ZaWMmTkVgPcK2CQ5Ti5imVxZDSa1egv0A4H/jLOTbAOQCGLsIM99z9sgGbLAKUkgwrqhbJg9wAaGC3+nTAA1VwUA9hI4JcRl7Lma2lQQ8eBbifwX266wPDYgc43lUasCwFJ5KIOYcyLe5aInCfUi9HIrAaRwD4zhebfsJN4AiqEXEdKGEEs4igYYMuo9Q15oZaI58PREniBeVnNWAN4sdnRSy9ZOHxPbWE2AkwyMrlUBIGWu73+xR7w1cq1MsRIUWx9f/sYM8sv5yF8Ibb0iZ8X6ns3XNIL3zI49xkT3er/wnrBeaIS7+hpj10ZzgNDLigtRKB9/PmcFgPCdSmaz2xv4OlYCnaDsk1F0rlSrAkD8eiVKHV/qOUhJVfzNHBXK+EyMKf0YGHtkXChKdNLYSoblYyx8UTZItxjeP/Ycg5Ku10FRxs3oZRie5Eh4MWcFAPETG3wsfrmv5iBXSthW2jaH3AfrunitCgB1VgKxvWJdo4X/LhH6CgbJLZG6dYZHQTFS9iwIXhBLRJsi2Y8ycPp7sTA2e4BYCewszx4tGrbnacrj3BUAslYq/Lpwpyiq+kXYYqVttbttqcyuWQFQXLpzba/+UsDTCaqwCt/PmHqn0N5NNnVJm6Nkthob1OTF4jJVODCxtGQ0ngPkvQ75mfJ87goAHV3x/a15GwBPhbFY+NdW3gOWoudMNSsAuPONlV0ODwVWGNm2HVun5zcIJCXmwatKtvcYQTBEdhpLSijNEEgAizSYRvEcSOXuF8ojPJ+7AgDHVQWqxsFNXcLMGekuHuV57qhZAXiTMKbn2IN+oVAfxpMW84koq6pvyAPZ/qeeKAjnov5HDrrK15PqM+knG/KM7z3orVbIc4C9vlReGV4O3eMSFADip3fbHfP7o14gFR1ZBo5pQ7fsoRW1JVdValYAVEymNgQ8XcAT9gwtkhIsjDm5GCnuTKorE8YOaJzdAWTMb4yOcrmwFBNGoRcRyEbx/BgqnyUoAGBO8Z74VSGZx7xGWb78u3OOoC9zp5oVAPiveKik/gJVkuVMFh5XBDBz49BxsluOObkYTakA0EgsoVN9iZ5ajGvtvgil688COLtgXfd7CQoASDhf5Oe+FcGJSJuKGxlpcpdANSsA8P8qAZN8vaYi0omT737dOLHuv7ekqkjh55gCEMHwjwgACcFDPgO8Goz6OfBw55xijRvyesj5UhQAdY/zpH5xTXJVsQkCE0UNmCbh0P0vrV0BOFsYU3GxTrWaSsTLIWPFqjIENmqRTAGIkBpaIh4Fq0AQc/1PjRqNRLBrVFF4rLgHxcjAl12KAgBv/ybgl6yLtRAGfF5+sUeSmZBCeglUuwKAjU+s/MLyByYS4oeFeuBNgq1Yi2QKQKTUHicOoiF4scBMpcFGNqPa4vichzwqcb4UBQChK4FOUB5qiWehbA/tqRb96StWuwJAGmdSMY/t56clYpmSM+N7ieowxWNMARjB9cPE/ccQ7CePeP9cb6Ezh7wpdb4kBUDJD488aljqPEDECe5nS6HaFQDk8DtBnj9LIMgnC++nT7SUNrvLLlMAuhwZ+FtNQOInt3u2cpHjDrN0ek1CpcrzduhxSQoAYakV47lUX1wK3t8qDtip3ceUtuS+twUFQJmEWD1gAlfoDBFPJJBrlRTeL8oLoCtg9lOZOIZOMuvK4Z7VYhCJLk/G/iaeO/uy63iU878lKQDIiMyYY/lZQ8KTrwj1/+1YkDZ6XwsKgGoHwASukJIVD8+Blt1JTQEQkPME5xx5BsYOpuF931ioPQBfY6lyLoT8jDlfmgJAUJ8Y/oRlsQOY2m5F2f+/QOjvLd7aggJAOOa7BEzeIAgGI8IQ37HnKKMtkykAovQOF41YQsDFpCwWq13F7Xs5534jdsCQf2PPl6YAvETk+f4ToueJYt3JKbIkakEBQB4kTBvbf7lv7DL8Z8T34o7aMpkCkEB6u0UQeeBjD8By+BLoAQlTLsM/JYnH0hSAh4n8Om5CgB4l9DX2i5eWmrsVBQBM+XFwzHFMvhf6AS58Y97HPXc75x4xYV9I8WpTABJwkT2gnwhACgF4ywxANYSlRGIL262c/3erI58iPG9pCgDyUewAPjtEwJnKfEqQ868z1anmx7aiALAayIQ6dhzg44kU7jFE9L6x7+O+GuxhYtrbV9YUgD6ujLjG0iTxxRVA+XtrCrgyghUbb3lfIj7BLyzaWdYl06LnX+xxiQrAuQK/rt0o4XwFlPj/LPcujVpRAJCLEoufPn9OhHAx4r5Z6AO8L3UugojqJytqCkAyVjr38oT2ALg6zZFel5BHdMJ3bzPJFIA4tCCHWEXJl+driy2c0kS0NSV5TOv7tWP43ZIC8FoBk2ATTyJyRAwhdcsB6/+HDHlR5WVMAUgsoPNEEPtBluUwsuHNiZiklWU+zxt/DNM8mwIQhxS8LzwfxxyfFfe6JKWfIdb5qUlq0dZDWlIAUCrVrKvkFthEKJI3ilhi4pwDmQKQWIqA+KciuPyA/HvnHIlx5kD7JXSZhD9YDbOM58kUAM+J4UclL8AUhoAsufq+EXvki62WMMbDJaSXbEkBoLWqQTXpwzfZAhwv4Mjj7rm6aKp4gikAGcTA19U/EoAMsI2xbs3QJOmRezvnbkrED3hC4A4seEMyBSDkxrBzxfXqk8NekbSUMjm0HK9dYWJrCgAfCkqkSsaHL61hGFb7atyRFOGH11Sx6F+mAGRiN4ZpSpILr2lybDl2+QMTRkyEF39xzj2+R2amAPQwZcMlJQPadzY8O8fflwtK5MdzVKiBZ7amAMDSywQ5M0Yw7h68QjYptmhfv+LZLV42BSCj1Ig6Fk7kY8+JkvXsjPXM9Wgixn05EQ/gHct7q5LRmAIQL0XFp57w1aUJF9mxfejY0pWt5H0tKgC7BDl7fPy8s0WIOJ4pxr/g2aRxD7ceKxHz6GqYAjCadZtv5OtX8bf2YOaI0Up32XtzDaYt8aEEHdnz4D7nHFEXV5EpAKs4s/o6A6Lnb+yRr6yHrn508n8eLC4Nr1Ick1e0sge2qADAwhRxVc4KZIFtlpLy1/ePdwXPnMOpKQCZpfgU5xwGSB5AyrGluNOqm02XT2/fICdTADYwqOdvAljh0tfl9dDfJb1UWAEbWq9uOZRHFIglUqsKgBquGgwQHfSgbaHjHdDFRezvW51z5C2YE5kCUECaqn9rCNQTC9RXfcWLnHP3Juhwvt3s220iUwA2caj//+sFOZXcC1XiFpBvfqnUqgKAvK4WsOnHDoL9EJ9FNSzkeW+bIYhMASgkVDXphAc0YW9Zuq2VnpbQA4I27xnovmUKwDhEwF+Prdjj6eNeOequ04R6Yjy4VGpZASDBTywm+8qnmPzZ+2dLd27UjAJwkgCGz1cgtQc5564T2hACm5zmJfdfh7LvMc65PyRqI+3FfmJotC1TAIZKaWc5JSTwhTsflfWXokCfn7VmdT+8ZQUAzpImPRz7pjovudpVElHMjWN5ypxcjI4WKsoSYA2Wm/i43im0IxTUxcU4P+xF7LFek6httBON+7HDXv3/UqYARDArKKokRLkyeE7u0ysEbC0tzXYoi9YVAGKqsOoZjn2lz9mKwKNpbsScyNw4lp9FcyEcJlSUBl7qnNu3AgkeKbYjFNYJFbSHKhBh7WsJ24XR5IGRbTMFIJJh28UVYytWokqRYqvAHvBSqXUFALl9MOHYEo6fQ84xIG3RBXsT3lGsVBdtxo5ihDX9EIFZGeOTYcAwYBgwDBgG8mKg6Ac1X5lK7HIDQ14wGH+Nv4YBw4BhYBkYuGOgcXbSFYKv2iqArYIYBgwDhgHDgGFgUgxMkqMmpT+9aarL0FRNziZnw4BhwDCQFgNHJP20H/gw/DBvM81vUs3POlLajmT8NH4aBgwDLWGAhGyEVp6ETjUFwBQAw4BhwDBgGDAMTIKBSfMhsAqg+C62pGlZXe3LwDBgGDAMGAZqwcBNNUREfIFzDv/MWphi9TBZGAYMA4YBw8CcMcCce8gk6/49Lz3TFABTgAwDhgHDgGHAMFAEAyVzf/RM+TsvEZrxIhN8EcHPWau1ttlXm2HAMGAYWI+Bknk/ds70a36hBOw2JcCUAMOAYcAwYBgwDGTBAMm0CMRXLR3rnPuPCT+L8E0zXq8ZG3+MP4YBw8AcMXDXVmr3d1Y763cqRqa9b5sSYEqAYcAwYBgwDBgGJAyQfZP8O83Rrq3sTXucc/caACQAzFGjtTbZl5phwDBgGOjHAHPmZc65g5ub9Xsq/Cjn3DHOuc9t56m/3TnHkoYJ33hgGDAMGAYMA0vGAHMhc+I128b0Rzvn9umZR5Nf+h/dYNYfg3c/oQAAAABJRU5ErkJggg==">
							</image>
						</defs>
					</svg> </span>
				<div class="advantage-content">
					<h3>Tính lan tỏa mạnh mẽ</h3>
					<p>Nội dung trên TikTok có khả năng viral cao, giúp thông điệp của thương hiệu nhanh chóng được chia
						sẻ rộng rãi.</p>
				</div>
			</div>

			<div class="advantage-item">
				<span class="elementor-icon">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="60"
						 height="72" viewBox="0 0 72 72" fill="none">
						<mask id="mask0_3507_35021" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0"
							  width="72" height="72">
							<rect width="72" height="72" fill="url(#pattern0_3507_35021)"></rect>
						</mask>
						<g mask="url(#mask0_3507_35021)">
							<rect x="-48" y="-61" width="164" height="173" fill="url(#paint0_linear_3507_35021)"></rect>
						</g>
						<defs>
							<pattern id="pattern0_3507_35021" patternContentUnits="objectBoundingBox" width="1"
									 height="1">
								<use xlink:href="#image0_3507_35021" transform="scale(0.00195312)"></use>
							</pattern>
							<linearGradient id="paint0_linear_3507_35021" x1="-48" y1="-20.6333" x2="116.112"
											y2="-20.4204" gradientUnits="userSpaceOnUse">
								<stop stop-color="#020C6A"></stop>
								<stop offset="0.3" stop-color="#1A85F8"></stop>
								<stop offset="1" stop-color="#66E5FB"></stop>
							</linearGradient>
							<image id="image0_3507_35021" width="512" height="512"
								   xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAAAXNSR0IArs4c6QAAIABJREFUeAHsvQX8P0W1/3/uVa+iYIvdgY167cTuDkxEsbsTUUSuid2N3YqKidgBitioCIpid2H+7v+/z8sun/2+v/t+7+ycM7Ozu+c8Hp/Hvj8bE685M3Nm5oSIkyMwTwQuICJ3FpH9ROTtInKkiBwjIr8Vkb+LyP9X4N8vReRTVRkfLCI7ZG6W64nIm0XkOBH5R4HY5GivE0Tk1zWfHCYibxKRJ4rI7UTk7Jnbw7NzBBwBR8ARCETglCJyGxF5nYj8aAYT2E9E5GqBdde8dnoR+cAM8MohIHxbRF4sIghL/6kB3b91BBwBR8AR0CNwGRF5Sb2yzzEJ5MyDlfi19RCtTWEnEfm6T/5Ru0EIaE8XEXaanBwBR8ARcAQyIsDq+GAR+d+ZT2BsSZ8xEa5vnDl2OYS1f1VCwBuqY6aLJWojT9YRcAQcAUegRuBCIvLhhU1crDSt6VIi8v8WhmNKgQAsOX46i3VDeXqOgCPgCCwdgVOJyL4i8rcFTlo/TND4T1sgjikFgCbt34nI/Spe/Y8EbeZJOgKOgCOwOAQuXGvxN4PsEq/WK8uPuAAQdfYfynuHiMjZFtdTvcKOgCPgCBgicEcR+ZNPVnJRQ0xJ6nDHNKkAgKBwvIhcw7jdPDlHwBFwBBaBwEMXoOQXuqI8k3GLL02PIhRn6/ew5ECIdXIEHAFHwBEIQIDz02f7CvWkFWoKHQAcJFlPdp5eN6ZYqjwygO/9FUfAEXAEFo8AzlZ8MtnCYP8EHHFJtwLIzmMPSdCOnqQj4Ag4ArNBYB+f/LeZmH4lImdI1LoHOtbbYJ1a6MRU8E6J2tKTdQQcAUdg0gjs5RPSNhMSMQt2S9iieAL8mmO+DeaphYDU3h0Tsosn7Qg4Ao5AGgRw6btEG/91Ew5Bea6aBuptUj2diLzPhYCsQsDP3URwGx70fxwBR2DBCLAS/Z5PQvILETm0ikj3QBHB8VFOuk7t0pZASkuNBrhOGEtxHz8BHlAoJ4d7Xo6AI1AkAi9POPl/U0SeLyK7i8hla7/6RA50cgRWESAEMw6XrigidxeRV4rIsQl58+GrBfD/HQFHwBFYEgJXSqCN/mcRea6IXGJJQHpdkyHAUQx+/v9pLAzg4OqcyUrtCTsCjoAjUDACJxORIwwHVSKzHZAwel7BUHrRMiBwHhF5kyG/crTwtgzl9iwcAUfAESgOgTsbDqbfEZFdi6uhF2iOCFxfRFDks9IN+O85guR1cgQcAUdgHQJ4++N83mIQfWflOfA06zLy+45AAgTOKiJfMOLf9yQonyfpCDgCjkCxCNzKaPB8hWtTF9vGcy/YqUXEIqYCDoJcX2Xu3OL1cwQcgZMQwAxKu/p/i0/+J+HpP8ZBAMuBzxjwMu6vnRwBR8ARmD0CaD7/WzlofllE3Jxv9qwyiQqeUURw3KQRaH/r/DyJtvZCOgKOgBKBxysHS8z8LqAsg3/uCFgicC2D0NW3tiyQp+UIOAKOQIkIsHrXrJYeXWKlvEyLR+A1Sr7GxNDJEXAEHIHZIkBkO832P65qTzFbdLxiU0bgbCJygkII+NmUK+9ldwQcAUegD4FbKgZIdg0e1JeBP3cERkTghUr+vtiIZfesHQFHwBFIisBzFAMkq6vTJi2dJ+4I6BC4pIK/EXDvo8vev3YEHAFHoFwEDlYMkG8vt1peMkfgJAS+ruBxAlc5OQKOgCMwSwSOUQyOe80SEa/U3BB4loLHPzQ3MLw+joAj4AiAAHb7GgXAiziMjsAEELiZQgBAQHZyBBwBR2B2CJxDMTD+Q0ROPjtEvEJzROCCCj7Hx4WTI+AIOAKzQ4AVfKz9/9GzQ8MrNFcECHONf/8YXv9fd289V7bwejkCy0aAsKcxgyLffGXZ0HntJ4bAnxS8vtPE6urFdQQcAUegF4GrKwbFz/am7i84AuUg8HMFr+NQyMkRcAQcgVkhcA3FoEjENSdHYCoI4NUvdrfr7FOppJfTEXAEHIFQBFwACEPqP0Xk/CJyYxHB9PHh1WTyZBF5RvX5U0TksbXDmBuJyMVF5L/CkjV/i3zxXEc5cGBDuSgf5dy//p+y30VELi8iS9radgHAnN08QUfAEZgyAi4AdLfeqUXkBiKC/fjhIvLXgatHLCQIsPRSEbltQm+JpxeR3UXk5bVOxj8HlpMV8Y+rSI5vEJG7iwhhoedKLgDMtWW9Xo6AIxCFgAsAW7ChKX6TagWNd8O/RUykm7aXmZg/LiJ3E5EdtrKM+rWjiOwpIoeKyL+My0kd0O24h4iQz5zIBYA5tabXxRFwBNQIuABw4jY4W+U/TTCZdgkFfxCR50Wsts9X7yhotNm7yrPuHvk8V0TOquayMhJwAaCMdvBSOAKOQCEILFkAOI2I7CMiv8008a9OtH+vJteXVZP6zj28cJ5K/+DARKv91TJ1/c/xx7NF5Iw95Sz9sQsApbeQl88RcASyIrBUAeAW1Tb6j0aa+FcnWXYEHtbhVZGjAgSUofoHq+lb/f9LEblzVu60zcwFAFs8PTVHwBGYOAJLEwDOLCLvLWTiX52YDxORJrYCDpqOKrScBMfBhfTUyAWAqbWYl9cRcASSIrAkAeBqtcb76sRb0v9/EZHXiEiMNn/OeuBU55pJOdM+cRcA7DH1FB0BR2DCCCxFAHjQiGfoOSfmnHlhgfDQCfG+CwATaiwvqiPgCKRHYAkCABr+OSfGpeWFk6H/SM+q6hxcAFBD6Ak4Ao7AnBCYswDApISDnKVNyGPUF2sGvCWWTC4AlNw6XjZHwBHIjsCcBYDn+OSfVfhB2CqZXAAouXW8bI6AI5AdgbkKAI/3yT/r5N/sOjwmOweHZ+gCQDhW/qYj4AgsAIE5CgC3quzn/9cFgFEEAHC/Q6H9xgWAQhvGi+UIOALjIDA3AeC8I3r2a1bBS7/+ueXPYByu7s7VBYBuXPyuI+AILBSBOQkAp6gj4qWcgPGG97HKLe4LK6W3p7bC7T6/Cq/7wSqIznGF7DwQ4Q+HPe1yPrH27f++KqTxTxKXk0iIY4VEXteVXQBYh4zfdwQcgUUiMCcB4HGJJrVjRGRvEbl0oLkbvvsfKCKfS1SedQLOZ0TkASLCLkgIXVBEOLP/dqJyIiCVRC4AlNQaXhZHwBEYHYG5CADnT+Az/0gRQZ9AY+OOS993J5pgEQT+n4i8scrjUgpOon43FpEvGZeTYEcXUpTL+lMXAKwR9fQcAUdg0gjMRQA4yHDyIjgPK2lLu/bdqkA63zcsI5P/EdWxw+UNuQ9BYA8R+Y1hOQ82LJ82KRcAtAj6946AIzArBOYgAFzBcML6iohcIFEL71iH9V23hR96H037Z4oIOg8piEA/hxpiet0UhYxI0wWACND8E0fAEZgvAnMQAN5vNFmxi0AI3tSEjwK27kMn/PZ7bKuzSk9NCBevjCxju7z8/kTqwgam7wJAIFD+miPgCCwDgakLACjmWdj8v0NETp6xyTlzH7rVjjIiOgU5CeuG1Qk95v8r5yz0mrxcAFgDjN92BByBZSIwdQEAM7eYCan9DSvUU47Q/GcTESbYE3rq8NvaCmGnEcqIXsCBPeVrY7nu91tHKPtqli4ArCLi/zsCjsCiEZiyAHAqA6c/2MOfeWQOOL2I3E5EXiQi2OgfIiLvFJFnV5r5N8p0LLEJAnA+XCkE/LXyQXDaTZlkeOYCQAaQPQtHwBGYDgJTFgBur5yUODq49nSaatSS7hKwU7Fu9d/c33PUGoi4ADByA3j2joAjUBYCUxYAXq8UAPjeKRwBnCE1k3nMFU+JY5ILAGOi73k7Ao5AcQhMVQDgbPqnignpnwM85hXXaCMV6DQi8nMF5n8UkZONVHaydQFgRPA9a0fAESgPgakKAHi+i1mFNt9g4uY0HAHiCTQYxlwtHRcNLb0LAEMR8/cdAUdg1ghMVQC4p3Iiym1ONxcmOruI/EuB/UNHBMIFgBHB96wdAUegPASmKgA8VzEJEfzGKR6Bzyqwf0l8tuovXQBQQ+gJOAKOwJwQmKoA8FHFJHTAnBpwhLrso8D+wyOUt8nSBYAGCb86Ao6AI1C5aZ2qAHCsYhK6pbe8CoFbKLD/nipn3ccuAOjw868dAUdgZghMVQAgYl+MEhrfpAr2MzPWWFudiyqwZxIei1wAGAt5z9cRcASKRGCKAgA++2P9/xOEZ0xTtCKZYGChdlYIAMQ/GItcABgLec/XEXAEikRgigIArntjV/+/K7IVplUoYhLE4v+nEavqAsCI4HvWjoAjUB4CUxQAzqKYgMZcgZbX+nElOqcC/zEFMBcA4trbv3IEHIGZIjBFAeAMigkID4BOOgRw5hO7A/BDXdaqr10AUMHnHzsCjsDcEJiiAIBL2tgJiO9OPbdGzFyfmynw/3rmsrazcwGgjYb/dgQcgcUjMEUBgEb7i2ISutDiW10HwBMU2B+sy1r1tQsAKvj8Y0fAEZgbAlMVAI5WTEJ3nFsjZq7PRxTYvyhzWdvZuQDQRsN/OwKOwOIRmKoA8EnFJIQbYac4BDChJKpf7BGMxwKIw92/cgQcAUfAHIGpCgCsJGMnocPMUVxOgtdV4E57XX1EqHwHYETwPWtHwBEoD4GpCgD3VU5ErgcQx4tvVuD+bxFBgXMscgFgLOQ9X0fAESgSgakKAITzjd0B4DsU2ZyGIXA6ETlBgfvhw7Izf9sFAHNIPUFHwBGYMgJTFQA4i/69YjIiJPB/TLnhRij7IxR4I3Q9dYQyt7N0AaCNhv92BByBxSMwVQGAhjtIOSER1c4pDAF8J/xCifdVw7JK9pYLAMmg9YQdAUdgighMWQC4t3JCcmXAcI59lBLr46sdgP8Mzy7Jmy4AJIHVE3UEHIGpIjBlAYCYACiWaXQBbjTVhstY7jOJyK+UOD8zY3nXZeUCwDpk/L4j4AgsEoEpCwA02MeVE9N3ROS/Ftny4ZV+jRJjQjdfIjy7ZG+6AJAMWk/YEXAEpojA1AWA3ZWTE7sHj5tiw2Uq8zVFhAlcs8vyiUxl7cvGBYA+hPy5IzAAAc70zi8ibKNil/1YEXmaiDzD/yaDwZsUg/tnBvBKqldZvf9SUQcmtr+KyPlSFXDC6e4oIt9XYgu+ty4EA40A8GIf0yYzpmFt8hgRuaeIXFtEzlEI/82iGBcUkUeKyAdF5E8Gg4NmZeHf6lZmWvxKEADoVPsa8OFnK+H15LPooXaVeIMBrhyxjK381yCiEQC0fcW/H3eswoLlrSKC4vCZG4bwaxgCrLL2FBEGSe12oHeEcTuCJf6lCABnrITSPxtMVmPbqYf1xjxv0d8teKWkwEsuANi0qQVfjJnGP0TkffXOdZ7eNNFcTiEiD6q2Un5sNBiM2eiet33nL0UAoHsdYMCjWBSwZbh02lUZbrnpa98oaPVPm7oAYD8GNG091esRInLLpXf4rvqjHPZNg0F1qozh5e4fLEoSAM4gIr814NffiMiS4wScXUSOM8CR/nODroFlxHsuAPT36aWOeyiqXnRE3iwma7b7CZfqW/3eWfoGg5IEADoQ2vx9ZQ55zrn16YvpkfkKgre/LxthiI5QaeQCgE3/COlDU3yHOBf3Ko1pc5bnnCKCd7QpNp6XOX+7lSYAnEpEvmvEv/gX4AhsKURdta6Vmz6IcvB5CwTOBYD8Y0TDE1O6YhnFWLIoQrv/B0aD55Qa28saPyiUJgDQYa9s4B2w4Yl3L8QyAC19TZjfBq/mep9CR04XAOL7etO2S7l+SkSIfrkIuriBq8+lMIbXc2sQKVEAoMO+0FCQxRSuFDO2FIMRERFfbogXZ6mlRll0AWCr7/o41o/FV5cgBJzLUOnHmaqfqeaEUakCAA5sfmg4qb1ypkIAgs3LDHH6Y6Fb/43g5ALAssYni7H2CyKCbsws6TQi8i3DAcACcE9jOp20VAGAznp9Y0XWN87sOACnR9TJsr/do/BR0gUA2/a25J2S0+J4bJb0euMBoORG9LLZd/6SBQA67P7G/P0BEdlhBiMBlj7oN1j2CXYSSicXAGzb3JJ/Sk+rVL2W6D53e+MBoPQG9PLZd/7SBYCTVUqBHzHm80+KCD4Hpkp4TUTBybI/sE2KUFE6uQBg2+6WPFR6WpgIXrh0Bg8t306VvePxxoNA6Q3o5bPv/KULAPQHJmtr65ajK7/iu4R2toLeI3DXUcb9/ucigvnwFMgFAPsxYEnj6semwOQhZXyW8SCwJCbwum4NIlMQAOgPl6kj/lm23a9FBG+ZU6GrJLD0waf6VacCgLsCNt31sexLU0qrlMiW0d2OSEh/MRYA/lVvK7620pYmoAphgf1vGhhotMCnIgDQWTjy+n/GfP/3Ogx2dGfM9OFelZdEymo50ILl7pnKb5WNZgeAMOc+pk0DA8LRY757pDHP039Is1Qz16B+sp8hKMfUMZc5V3SaJgKsYmMnhikJALTOfRV13YQR2vQlmgqh6c9guKnssc8eOkF21wgAxEhwmh4C5xORJ4rI7w37wU2nB8OJJWZA4MwuttM33/2z2lJ99EQUf6baVrnKvSQBAEz3NuD/ph+0r18rLIjQuatgPCjntcto9RsMp0guAEyx1WzKfCYReY1Rf8AaaJKE5KIdBIi45iFTJ9n8nYVemgAACM8x6Add/Qgf+CWYC92iCuNNVMOuMmrvvbiTi6Zx0wWAabRTylI+sNoR4Mha0w9YAO+cspCp0j5QWXHOEVEmcpoPAksUADjDs1oNdA0kOA4Zw4/4Kasohs83doDUrt9LJn7+6QLAfMYtTU0eoJwH6RP30xRgrG+1pn/3HKvgnm8yBJYoAAAmQsCLDAaC9gTZ/o0r4usla7XtE76siHAM0S6D5W92TSat/KS0AnAdgO15bsp3XqXsK++cWuUvoqww54lTHwCm1mY5yrtUAaDB9inKftE3yb5DRLC8SUWE8UU7HZO8vrLEPkeRcA7kOwBzaEWbOqC4/jtFn8EMeFLz4R0UlWXguJYN7p5KYQgsXQCgOZhAYyfHkO9+KSJ7JGj3XUWEiGUhZYh9Z58E5R4rSRcAxkK+zHwfp+w75y2zWt2loiPHDgI/mpq00w2B3+1AwAWAE0G5v4FyUF//QnsY7XwtcdZPnAOtMtOm8qLoNLcjPxcAtJw3r+/xYPm/inmRgGOTIY0CIPHVneaJgAsAW+16IxEhpO2miVH7DEuBBynCC18pQwRPbKavuwXLbH65ADCbpjSryJcV/R1lwsnQ+xUVxZOY0zwRcAFg23a9hIigwKed6Pu+/7aI3GzbrDf+hx7BCyo/Bv9OXLZjReTiG0sy3YcuAEy37VKV/NWK/vSEVIVKkS5RzPoGpXXPb5yiQJ5mEQi4ALB9M2Djm8qJzmof+3AVmvdS2xfhpDtE2XtMhp0JykWdz3pSzvP74QLA/NpUW6N9FfPi07WZ5/z+S4qKXjlnQT2vrAi4ANANN+fsrLhXJ+wU/+NXH2uBVaUizAjZKUiR52qar1iAZ08XALp5fcl3cWm92hdC/5/U0bhGAODc0WmeCLgAsLld75ogeNa6AYYgXQTTuryIfEQxMK1Lv+v+30Rkz80QzOapCwCzaUqzijxE0c9cADBrBk9oLARcAOhH/pIi8l3FQNE18ZZwD12Hy/VXfzZvuAAwm6Y0q4gLAAEDm+8AmPFbcQm5ABDWJDvVIUZLmLgtyoAnszOEVX02b7kAMJumNKuICwAuAJgx0xQTcgFgWKvdTkQIiGUxCY+RxglVaNQphvId1krdb7sA0I3Lku+6ABAwmPkOwHy7iAsAw9v2bCKC9v4YE7gmz2/1WBwMR2JaX7gAMK32ylFaFwACBjIXAHKw4jh5uAAQh/t/VqZ5DxeRvwb0H82kbfEtvgP+R0SwbFgyuQCw5NbvrrsLAAEDmAsA3cwzh7suAOha8fwi8vGAPmQxkcek8QMRoY2dRFwAcC5YRcAFgIDBa0oCwKlE5Doigpcm4rJj/niMiBC96Vci8n0ROazewn2miNxaRM6xyhWB/xMN6qKV57i7Vw5UXiYiH6u8u32lCvyCNzUiTf2mzvsIEXlL5cVtbxHZrTB7axcAAht7w2vwwb1F5A8BfSlmEo/5hlX/ASKyw4ZyL+3RHASAk4nIFaudp0eLyOtXxjfGHMY63NtiRoqZ2p1FBCE1lvBNcUcReX6dJmPn0bUeTJPfN0QEpdL9qrEVp3Gnic1shO9cAAgYtEoXANjaRDmLYCsoOcUMmEdVIVUfLyLnCmDC/65jySNUxOSFvTeOX/A9z1bymHS1yDpQ78+NWfAC80Y3AIc6OPaJ4QurbxA4mSSctkXgF4p2GdNDIgLm1UWEGPbEaYjhk59UR0B4rttlW0g6/+MdjoyOi8zr7/UC6/aFLXa6KusCQEAjlyoAYJpFSEfCrcZ0iq5vGLw/VDtjaTMMEzVOYb5pmBf5s1tA1LWTtzPL+Bs78C4cQu4dmbGcU8oKRz65XAm324nJAQ1/VolO2yOg0dfYcfvkkt9hzLltgpDPnxeRG3aUntU7z9o8pf3N2PxIETl1R34l3HIBIKDBSxMA6BhsubLFrmXQdd8TJvJNtXtWjhRYVa171+L+9+qji9ydAmk/tvyEiXbqRoBV2x4ioll1DmkXdpSIYeDUjQBHg7GhX1kU5N6pQ4jURKoL4R2OCYhDcdlqh+EQxTgQkhfHLxwllEYuAAQ0fEkCwAUSSKmbGDhlzPXVfBmg2ObLeYZ29oD2Xy1n8z8DIwOr03oETl9h9IzqeOkfCpwbvLuu6LQQM8BpMwJ4c+zCL+QeIZxzEcGfnpMh6mNTb3RF6MfN/6mvRKUtSVB1ASCg8UsRAFDYiz0DS83YlumjVHOhTCMOKxv8wceWH30Ip34ECDOsCcm92j7sfj1MRE7Rn7W/ISJ3UvA4x345CIW7wxXlXOWRUv9HH6EUHRUXAAIYrgQBgLPNnJLq2J0HDdtcuKMAGVvfR+QYGWeUB22q2W5lJ4EohewsOIUj8EoFj783PJvoN3etjjV/qihjbP8d6zsUBW8VjZbdhy4ABDBdroloXbM+OaCMYzFyynzZerzWOlAM7x+kwPcThuVYUlJodX9mAO4cD3HOzxGY0zAE2OX68QCsV/v0s4dlN/htVsMlmZCu1j/V/xyvsjMzJrkAENAxxhQAHhhQvlQMWkK6CAGXSdxD8E8QW1d2Zc6duHxzTR5FwZuIyNs3mK/+sbLjPjADD8wVY+qFEm8sf/Pd7gnBQTchpTKzpt45vkUH4RYJ8e1L2gWAgM4xlgAAYyxp239dhzte4ayorwPw/LoBPLCubNzHvthJhwBmZletJ5v7186lWBku3X2vDtUTv2YLfxP/9j2LdRTWV3aU4TgP78t/7s9Z5HAEMga5ABDAgGMIAOdZuGS82uk/ndC+m8mHM7nVPEP/Z5V6pjF6r+fpCPQgwMQSa/4H/+NKOQVxLPFRRZ8L7ZtTeQ/vgvh1yU0uAAQwYW4BgK1RJrypMG+ucuKpMBUdrMQbD3hOjkBJCDCOHKrka1zgpqDHKsuVa8zJmc+rUwDdk6YLAAGMmFsAwDNeTsabSl64Odb49d7UF3CspMGBoxrOWp0cgVIQuK+Sp+kPuMq2Jvow7sA1/W2O37JTc01rsHvScwEggBFzCgA4wbF07Tu3jvKeHoaOfcwWvsYfADj/vPKFj2MhJ0dgbARQnNXyM+fzKTwAaqxu5jaerdbnq4kwX8ePLgAUJgA8KqA8q0yztP/x35+C0DbXYokTozOkKJyn6QgEIkBAL43ZX9MHnhSY35DXcJyl0Uloyjbn622GAKp81wWAgEE/1w4AXs1YRVoxN/719623lfCydZYqbCUe2fBJjZ//2MiBXeVDU5/zQiL8ESL4jFUI4IuIyC1F5OUigqJc13cx996mZPp1n9POMeVZ/eaLrhS4DmK/nxiBC9aKe6s8OfR/xgbGC2t6n1Efoz7sUBDyGVfQeA5lF+9i9ZiDTg7OxIbWe937v60skXCmhDfWi9fYcJRBUCHKYDluEwMhF7kAEMAkuQQAPEOtY8Ah9wk8sWfAVhLmPRoPYZQJBx4PCjDXOl0tjPzToI440EjlT/vjBuUDl+/Ug1Gujuz5OAI4zbIKvvSyBHCyM4Hd+5CxrOtdFhPslBI3YBPhLXJ/EdHEM8HzJI7YTrspozomCOMgJn1dZR567wo9+Vk9dgEgoMFyCQAW0jG+tIeeQ7Mj8OcAHFaZ+OsicuGBnMj2fWyc7Xb+Dx6Yb+jrV4nAoV2u9m8UnVDESnGOGloff2/+COArgZ0+zUTX5lvCBp8zAWwah1tN+Y6JEKx3ixSMOEYZOvazK8A5flPe2Gsq64vVZnUBIKCxhjLBKsgh/9OJtZqxX1FE0mNba4hP/NeKyA4hFet4B3eu2jPKT3Wka3ULRcPYjtv13ZfcQsCqaTydFgIIlncQESIidvFd7L39WnlY/tQG+mHhcLbIArHb+dkBOH1IRM4cmRfHn1ohgPExB7kAEMAUOQQArbtOLAe0UjtCCNtYOP/oGjxYYRBD+xoGnIl5kcbLIRrOqULx4to3ZkekC7P2vcPqHQF3GmTAQAtOAv58dKXL8901/bTNc0N/M/GkcEjDkZ22v2u95SEw3bnSEThyDW4oJ6K/gwdWfChoiJ0A7RiCPkdqcgFgDTO0O04OAeAJAeVol2n1N3bsloQCHz7AiUJ4n9pnu3UEtpcq60xAmVREqNlVjK3+ZyBkt+ZFIkKsBxQlEQDRkB77j50gvFAuNcwuAz+C9C4FtAW8gIIbimdEnUSxDd0SKz5cTYcJkPxSEDy+mt+Q/59hXCiEqNuKCEeJ9EH0r85qnAdtNqSOq+/e3bg8Xcm5ABDQSDkEgLcElGOVQZr/WbGfrKt1C7+HtUBTh5grDpNSEasFdjtiyjWHb1DWZLJ5axWmFeESK5I5ErsxbKO/SkSOqFbWnH/Pof1i6vDihA2MSWFMmfiGo9E+JbyERY9OmjJr+AkFxtTkAkA1NpaZAAAgAElEQVQAY+YQABh8YjtIDkZJxYicj5dab8yglhSjvK8dPldbl8TqfqTioaHpItwRhRBdDwurlD7cpvCc8/mU7apZ4CCETpXerBjfUpk7t7F0ASCggXIIABrN+NzuI9sMpP2tOQbg29T0ggD+mMIAb1lGzEzZOp1apD6299lOx3rFEo+pp4UNOyZ6KUljXotJ81TpkQpeI1hSanIBIKCBcggAGvvRKcej15y1vyZ176idG019gE9VfhxNpfAVn6JZsTw5JKCvp8Kq5HTvlQLwlTQ1WvH4N5gq3VzBc5/MUGkXAAIaKIcAoAlHS/yAqRIKOLGDI06MUhP2uLHlW8J3KDQ+s3AdlD0MTGzn3JZoxqembyn60SVTFy5h+nhGjeWdTyQsV5O0CwABDZRDANCYjAx1/NM0fglX9BdiO0gqe+U2Li4AhLXPh6vdEmsrkXY7xPxGMfZ5Cv6K5cupfZdDAFhneheC1VR2mbp4VBPZFb2J1OQCQMAAkUMAwJd+SGfoegfvdVMljaY9PgtSkwsA4XzJII8TlBKIyf8Nij7V1c/mei+HAIDjrlj87lICQ0WWQaPjhPCamlwACGDMHAIAduGxHQRFkykSjnw0ZjK3z1BpFwCG8SXa5GObbKHsZxHZMbY/Tu27HAIAGu2xuLwkQz9PlQV6MrH1flyqQrXSdQEgoIFyCABvDCjHOkbKoSzS4hmzn3dV1BkscpwNugAwfACDH8e0ECA627q+4ve3xyaHAEBAnVjsfzjReBrauCI4T0pNLgAEMGYOAUDTEHjwQst5avSFAOzXDRqE58SeOzW5ABA3cHN+qXWnGtO2GqXSdbw29/s5BICbKvo6+F83hhlG/kazqGNMj41FMKTamnnnhUMyGvtdjcOZHAKAVlrMYRNv2YY3Uw4IB1kWZkNaLgDECQAM2k/bgGuKR0S11Pibn/tEv65+OQQAnGqtyz/kfg6beEuexMupJjojVhM5yAWAAMbMIQDghYvY0yGdoesdPJrlCB5hwZTE8daYBVH/XHoPLgDE8yTtxIo8BxHyVWNK29WnlnIvhwAAD7CVr8GUNp4KEU1QU9dcCzoXAAIaKocAAGN/IKAsm5gKu9Extl2HdkrM9zbVo+8Zq7xcvuk1AgAe8/6trGsfFqU/ZxXE9m9KuoyI/HHhOGv4IJcAoDXJJPphqgiglvyJ50JNe/BtLudHLgAENFYuAYAtTC3j5PDqpeksVzXwv55zO1AjABBJka1PbIHfISIaU08tX4z5PT4uLq9hmg3fnq+KVomgNWb9xsob9+Gvq8ICM258UIFBLgHgCooyNhg/fQMvlPAIXazfK+t5dMaFnAsAAY2VSwA4tUEM6b+JyOVK6AkdZSDcpsUkSJjiXKQVAFbLidtm9B8QDogzgGBwsIgcWocIxhx0rD8CUtE+mrPLZqBevf6iMs0jRrolEcmPVeFqXhb/U15iBozVFk2+uC+GP1CqfI6IMGDfsBYs21hqgs7kEgAor7a9UI4jdG+JxO6EJqhbw7eEhs9FLgAEDCC5BAAanbCkDSPEXgkPbB3bWsuQO4nIYQZ1IzpfThMzawFAi2OO75lY2Uk6yqC92jzM4E/aFoSwrLEiaZer+f1rEXlsAkHFor59aUxFAMC2vcE79ooF0MX6AMn8/OQi8l6Dup0gIjk9u7oAENBoOQUAFPksVmDfKMgrG0p/Go9/7YHi/pk79hIFgAbiU1Q6DHuLCKuudhtofn/W4ByXwfb9hmWiPqywz9BUfILXqQgAO1aKoQhaGh7iW3aqSjF9Ru/q1QZ1ol7s8uQkFwACGi6nAEDjc66n7SB8z4qblfeYhEvWdxnV50cigjCRk5YsADQ4E0zH0rzunUofDgSBsugfTRocxUxBebZpj67rVAQAyo5Q2WCvuaIDcZ4uMDLfe65RfdCV2Tlz2V0ACGi83AKA1S4AnYuzZUwMxyBWkG8NwDd0EGAiyk0uAJyI+H0N25H2jjVz2te4HEycU5/8aaEpCQC4iv6NUTt+u0MfItcYAd8QCTN0/Op7D97OTS4ABDRgbgEAJrBkLJwg5ZYs2erT2sK2OwyCzBgDtQsAW0MS25PtNtH+fthW0kG/7m2cP2azuXeUgioa8dKUBACqZ9mW6DztEoGZ5hOOoSx3oogZMMZCzQWAgEFlDAEAZsAcRDvINt8fKyJ4p8pBKLF81bDsBAway8mRCwBbHIMApnFv2vBic+VY4XZbyW/8heWEhW5Mkzda9gipc6GpCQDwEhYOTXtorygGXjNTY1ovbugH18hU9tVsXAAIYMIxBAAaCv/XlgpYOTrJpSq79x8HYDqkw8OkY5ELANsiz4rZcuDGbPXq22ax3X9XFJG/GPLUMQVayWxX6YE3piYAUL2LVFYXtP+QsWDTu6R1h4G4DX39XLV56KZyDH2GDspY5AJAAAOOJQDAFDDHUIba9D7uhrFBT7GdTnQ/y4GaeuAdMUfQn3Ud0AWA7ZE5nYhgZbKJz4Y8QzBdtzt1IRH5lWFeaKAz8cyNpigA0AaaCaiLx1gwPaOKQ8EWvTVdT0R+aciLlJ+d0jG2/htsNPh7MKAGxYRXFOkwnepids09gulY2WRjl28tqFA3jkBOnxDbkKRdAOhGiZXQTwz5kiOqs61kdQ4D//HtPsJREkG35khTFQBoizcY8lHT3ocbmgmyWMI/hLVb798ZljGWp10ACGC+MXcAaNhzJpA86SiY0VwtlnPq71ihWZ73Nx2YwfrSyrJZfO4CwHoUOe75Q0D/adq079o+l0dT/EjDtAmWdeP1VZn8kykLAJypo83fxx9DnzPB3lrZsihPfyxB2Tj3L4EfXQAIaNyxBQB4GCURy/OypjOhWIXFwdBtKKTiBxi4Lm7K0b4iad9S2XGtPncBYDOS11FGsWy3O79xe4uXP8tBl23he2yuxuSfTlkAAHyOZSyPehq+ou3xq3LGiBa+baKFF2Vj4i2BXACYiAAAs9zcWBO66SRcUYxC6TCEiMRnqQjWLgcddq+QQmR6xwWAfqAJdtRuQ+1vy6MFypLTt3o/WmnemLoAACoEjMIZjpZ/ur4ntkOoHxGOHV+RqByU7WlpWCAqVRcAAhq6hB2ApnXx0c4k2cXk2nuk+/IN0jLKeKz6/5Qof8pf2mDtAkDDeZuvT0nIExq+ftnmYs/m6RwEABrjBsY7Squ8g79+AnKtI8xSf56Ql3EZnEIBe119+u67ABDQ2CUJADQoDlRSCQF0GLx0PXBFkxZTrC8HYLXa4Yb8/+Q+bh3huQsAYaAzqL02MX8M4SXeRdEVV9RLoLkIALQV5/ZYKw1t79D30S9CYOWoqSGOIKzilawrB0cRpfGjCwABjFaaAADT3s/YP3sX036rDr3JdhhKK13vWN17fNMTC7u6ABDeIFispB5EQ/nt0wZBh8JrPv6bcxIAQPMmiXSe2vyDvxJMl9mS/3vi8Q2vgWOaM6/jUBcAAhq+RAGABt0zgWlKu4Pk+M1OxsPXcWcB910AGNYIBJ9KYRUyhBfRKJ9yZL9hiJ/49twEAGqF3b21X5EhfGT1bsnBplwAmLAAQCfhzOyPAXWwYmbLdJC67xwz2mX8xgWA4WDjCprIjZa8EpoWYWJLiBA3HDXdF3MUAEBk1wSeRUN5SfseixuOGkomFwACBqpSdwAaxsIeG5t+LcPm/D6HW+IGH83VBYA49C5emTphh52Tp/BJwISxRJqrAEBb4hBq7F2loXzM4uaOE2BEFwACBqnSBYCmk3wxoC5DGTnF+7iRHSu4z9A+6QLAUMS23ic4S+qz1YY/URoLNWPdKuF8fs1ZAKCVcAyFUmfT3iVfMWNFaXoK5AJAAFNNQQCA2fB/jR/skjvH20TkNFPoGXUZXQDQNRbBWVIrkJJ+aFRBXW3K/XruAgDIY2lCHBPLqJDWY+VnOlxal8s1ulgMHgug0JZFszWlrX5Mp2EliPliSTawIc3nAkAISpvfeXRioZRJYem0BAGgaWOUA1Pa6seMbwihz1oxnW7KW/LVdwACBqep7AC0GQ1vfYcG1C2G2Yd+g1b2ZdqFm9BvFwBsGuuARLy4r03xJp/KkgQAGgtvfW9MxFNDxzeEkRtNlINcAAhgoikKAPAjq+37jGhKgxYsPgTaDjem1k9cALBpMXiRmBNDB9d178Nbe9sUbRapLE0AaBrt9rXjsnV8kvr+uwyjqjZ1ynl1ASBgUJqqANAwEgp3nwuop2Vnwff2TZsCTPjqAoBt42H2+XslLxI05la2xZp8aksVAGi4s46gIMgRK4urqZMLAAGD0dQFAJgUBcEnisgJAfXVCAKszIjvfeap94y6/C4A2DckZl2vilDmQtP/RTPiLUtklywAgCM7TMRJwbxYM36FfIu3y/NbNt6IabkAEMAwcxAAGh47Vz1BhzD60He+LyLXbzKayRUvXkNxaN6nczmtRwBeZBv/8A2WAoSG/kIluD6mOk7CwZBTNwJLFwAaVPAASZ+Fb5p+aHX92YCIgk15Sr8uRgD4lIIhblh6K0aU79oi8k0FJu1Oxa4CHq9OGVGO0j85UIHRHLYIc7XPjnU42JuJCOe6XC83cf2RXNiRz2sUfEqEz7nRZQ2PPdHwR5cJXwRzo30UfIPVw2Tog4qK3mMytRxWUIK34Ief6H/tCX3I73dXOwoXGJbtpN7+hAKbKXgCm1RjeGHXIqDZqdpvbarTfsCxwN2UXlIJKoUgOlciSNGQ8b797qSUcN+kqOikJJ0ITmX19djKTh9Xqu0G3vSbbVs8vc2ZGEB+OgCTVbxuPGdwvG5FIYA55Cr/hf6PED9n+q9aYY8t/FBMvlfvRM0ZF+r22QGYrGL34CmBg5S7WoHQ/znbXgKhuPc/IoIryy5s2ApjRYzXNSbHuRPuPLtwCL1HjHEnRyAHAkQGDeXL1ff+vJDQyXggZaHz3Q1YsbC59wQd+sTw2JmUuhKEbJ4M3WVDo692iK7/OVNaChG3+mpVFK57VhXmbP8R9aS/tChrGuc1/xQRjlicHIEcCFxZOb4tzZUy4/ketRIqQgHHdRfN0VAF5YHuR9dcF3pvKvFc/g9yIuaFVqzrvQ8V1HBelPQIoKGuMZn8Wvoieg6OwEkIoKCm8ZGPt86TnZSa/5g7Ajhn0xxvEoJ+UvzCljUORLom99B7aCY7LQMBghaF8kXXe89bBkxey4IQOEzJsx5ToaDGTFwUjnq7xq3Qex9IXL4kyb9DWWk8mC1tmyhJQxSe6KOUfEIncmGx8EaeYfGeruRbjq12myEuXqVtEbiNiOCwLXSy73qPwG6TI+yLuyoz5N4PReQSk6u5FzgUgfsrFWPgJQTFU4Vm6O85AkYIYK42ZCzrehdPei4EGDVIgcncwiA2DMrgk9QHY1DW+iGn0+AHmjjnTvNBYKcqjvfLDQZQ+APb2lLpwiJCuGhcHB9cKXd+q3af+pe67lyZBLjPNt9zReROM3J9Wmq7WJWLduua2IfcYycAD3GTOuO1AnCm6WAKidMfJu8hvND1LlFmJ0sahxmrYBBg57reUSbLCxQc16HYs2r1Q9q8gflgSXT5esL/gbLzYz6FT4xdS6qcl2UbBDjHb/Oi5jfCBNvFc/TwuQ1oM/5nBxHBAu4YQ75gQTBZYuuCoCKajrH67a+rFRIuY5Gw8BrIUUPKPzrl9UTk4jPpnDDppes6YY6UEjt2bpjwUYL5uIiw2lltT83/HyukZ2CCiG24lbvnVUxQOCOyX8wqEZ/+2BATnOqdIvJFETlKRIir/re6PX5XOW/BcctXROR9FZ9zvu07Ef3MhXa3pTBLu7PjSTthEox765T9k7QZAxjfLjMTV9D0xV3qxSJRLFPjd9/KTwuOoeg3fzUe346O7PP9nJvxDY37w9WBcOz/CXqB8woGSCbRqRCr0ueIyJFG21Jjt0OT/zVGbgCsXZD4jzPu+E39Vq9M3Aikm4gyYaf+7Mr2+liDclE3+jAxOtjadNoWAezaV9tpqv+jrIYQy84tvkmm4oCMCR+B6fMJFhljtiWLisnTztUZFyuMMYFMlTerKRQ9SiQ6LyvwI2aK/VtHBh0LFSLnpeKtTel+uENPgH62/wbPkpvSC332y0rh8hkdeY/cFKNmz5Y93ktDMZzSe9+pd7Zidp5yNAo7F5yRTwnT0LKy64eTuFnQ/WbaSE1jHiIiKHyVQjhiQhpuyje3K44xiHM/Fj1I6bjIoj2IJcE2/XlF5EWZy4MTnDfUW61jtUFJ+d7AwNTLgidSpcHOYUlh2s9dBQ16/4zHN3aaZxUUidUoWs6pGLSEdPHxzTnt2MSZVHO2WwIuKcowVuQ/9Cc0ga5SYJEiFntoOdHpYLv4jGMzfQH5Wyo8h+Kf8z2EvscUcCzAjiuWMznrnjsv9HVmRwRD+PHMG44ztLHCNiJkoTWem1lz5/eykXrG6ZTRvHLjlDO/X4jI0qMxchTw5QX0v1eNqJj2wJnpMHX10Y/Oaet/dazGqc/cpTcaFYW7nMTk/+IFDD5ERxzDTIrJf666FF2DUMw9bJ5RPByjfXL2tU15cSxloXgZg3/Ob7BSOPkmIBI8e/QCxjdMQTGVnjWhuW1tLpGT+UPzemamVkRR5NUL6BxYX+yYCdN2Nmz7f3oB+Ibydd97XxURzmiXSoSlRlmyD6epPyd+Ry4hgC3xqePVV/4ficg5l9JpUCjBnr8PlKk/J8RtSkI793ULwPGTIsIqfAx6/QLwte5nmA6WpBSbm28uUJmHYsNtjWtp6eXYCZiTmeW69iM65OKEZo4DLD0mrQN37Pucy6cgJv/SFNJSYE0dx9pW5swxRZ2WkCaOhqbkK8O6j3IcsASdgLcn3AnYbwH9j2PN2W/7r+tcxNXWhoKdwmBqvRPA5P/GmXcOLBnGDJmKc5ETZo5x6r6D/w88zC2V8EqH3wRtNLjU7aRNn50A6mpJc5/84Ql4o1QfC5Zt2ZsW3tRYMWgZseTvUZCyIDoaHa7kumrLhlQ8ZiholCqJPaGth39/opdEnBQtmfATMFdnQQ2PE/7dSieAsbJJd47Xr4nIVZbcIbrqzhkvinPY08+x0amTVgjAFet7ZowPnsd272KOzPfw5zBXHhyjXjilWrobYY6xOM+2jh0wRnuuy1MrBCB4P2/Gfe8nle4bx4pWglLmYTFPdvgLeHLlghKtyHWMNuX7sSaCDCAHzRATtsI+VQftKMH1JTss1qZcmL6+pdJ5uVt9Ln622tYXofditUe/187YZTb9lfDPTiKnqY+2UPya8ji2ruyxQgCTPx4t16U75fuYEBPYaSxdpkn2OyaDa9WexghQMadztKFCwKnqePJT7gTtsnO2TnRAVkS4si2J7mo4CHGs9bBqZwtTwhAiuhxuhue6SuwLZBSC0Zze+e9qUiCwGCauY3p0bPdNi99DdQKY/HHwZZF3CWngIZMjRKIEouzuZIDAmSt77GtXugK4uiW8LAyDhjgSZ8o//Pzje96asUIVA5k8PpIgfxS08DqVEjvSZmWLm1R2dXDhi4/rkiVh/J5btDXKrTtF8v3pq50BtKstytGkgW06iqPsQly18uWPqRqrUbYj2XVDWY/YAqzCUlnn4DFwndtgNKFx88oxINhxbHB8JUAR8wBe5Q+BCmcp+IF/bu16+3yRGJf2GbtBtMs9K8UwFOBeUoc9T90/CSyVQuAMFQJY6OFdsOFTq+tfqgUk5sOp8cNMGCdsTxWRu9cxE8bwV1IaP8+qPAgfxHu2Ys4mnT4hgBUhK+Xmfavrm0e0qy+ZMZgEtRizU/Vwo0riVlpTHspysIjgfItV1hBCSYmJ1nrn7YWtQpy/EkCeZhCmGpt7BAfCXjsNR4BxJsUK/F091gFM/iwQNDze9S1KxGMGCxveAv5F8QikMr1D6aWL6JTsPnQxuOYesd1LOGvvqvOY9ziKsPCr8DjjSuwTyQMMgpc1KAs7NuwUaXiu/S3bo/evd7VwH9x+ZvGb7fQ9XNEqquURxizaoJ3Gu9cIAYynKZxssaPBkamTI2COQC4hgK3ZFHGuX+GT/0k8gQ8KzvvfKiJo57YHrdjfeGW0JlbuQ1ZJRG1DCLEU8ijDo0SEyTsWm9zffa8+chq682HdflNLL4cQwDhKOGlrnmC3yyf/qXHcxMqbUghgsGLy5+zKunOwxbf0wZC2u1W9tf13Y4w5R+UsPQVR7pBzUs7ur5yiAHWauPCemp97BOkLJcRkjkmnFALgZYudttXx8YOF6xbNkU8WWycUp1g5rjKh9n+USb6YIN0+XYO5NyTKeEQT+2ECbJs2Z1s7Nd2sVo5r8myuCB8ojsUqHQ4pN3oSv0+IY1MnyytWJ3sNqaS/+39e6izbgLQ4DkAvwDrdUIVDb1ZHwAyBVDsB1p1D63zIDLAREsL5zIMzrFpxXpVj8m0gRCl1t8rU6HqVlvPFjbf7mzw2Xa820YieHKUs3SHRpnZdfTYFd7xo+Vu7IV7Fwf93BDoRKF0IyBWSuBOckW9evzrj/0GC1UaXgMbEsjR6SCZsu/DW3PvYSGGlp8ofJQsBOUMST7X9vNyJEShVCCDQxBIJe3ImZGvztU2TDrbbSyOUDLHV34RLqc84ZnNb7XCOLVEIwLOmu9QNb0N/MyECCAEptFpjB1Cc7iyRsAMfw4U0Ht2WSBw/YHUQy6djfsdOgB8HhHMtjm7GbK923q8Z4dgrHCl/c5EIlCIEPGmR6J+o5EUI4fZAkeM3pnFLNj1iJZYD5xR5vHqhfSW22iUIAVjDWJq4xmLh3zkC2yEwthDwhO1KtIwbKcyWQiecrywD4rW1xH1tKFYlvrfE45u1jRnwYEwhwJ2YBTSQvzIuAmMIAZx3E3RmacRKIIUL0yET1SOWBvpKffEtkSp2wJB2iH33r3VchJVq+b8bEBhDCCCa5NL9mGxoEn9UEgI5hQAmfzSyl0isCGIHfovv8CuAy+al09hCmLYtcZvsk8swLs4pBBD4ydtnWPv42yMjgBBwYOIJismf8LFLJEJtagd+zfdEG7vCEoHvqLNlCGVNm2i+vUNHvfzWZgRy9MGhodM3l9ifOgIZEUgpBDD5PyBjXUrK6l4jT/74F1iq5n8XHxB0SDP5tr/9rYgQs4LQ0bu0zPUIkUw+BPpBsEYAa3+n/f1dNyvratreeymFgGf15u4vOAKFI5BCCCCK2j0Kr3eq4jHxjqHtTzx6YjTg8veUqSo30XR3MDAHPF5E7jcAWzwvovdi6ZaYnQyn4QikEAKW6sdkOPr+RfEIWOoE/LteBRVf6QQFxMnPscYrv9WV4zdE5Pm1gHXFyqnQeeoATQmqM6skP61oF1b0p4tEY+fax/xqO8b8/6XIMvhnIpY6AUv1Y+J8NGMEUGJ5rIiweo8ZnPjmjyJyixlj1Fe1VDoV36/b5lx9BfDnaxG4fQRfc4xFkCYt0besTEE5ZnCKQ+DeIvKPCD5oxkMidHK85+QIzBaBW0fGn//cwsOa4tu/GSisrt8Ukdu5YxGTvsYk/KGBbYRAbEn7D8y/i4+eblmgBaZFoKjvRLTDt0WEcNNOjsDsEcBzHPbjR/d0FLb7PyMiN5k9IpsrCF6WgX2I3sf5MUczTnYIsI0fGs76KXbZnpQSQsh7evpU16Tfvve9k1LzH7EI0K/2FJGvBbTFV6u+je6Fe/eLRdu/mzQCaDqjzc8W5utE5CVVIJt9ai3oM026ZnaFZ7JuD9Ka3wxKF7Irmqe0ggAKkqzEcbDT1U4Icrdc+cby37NWwt0f1uTdVZ6ue+h9ONkgcO5qx3Ovyo4fRUHc+OK7g98oMZ/TJgtPxRFwBOaKAFHbfqkc0JtB/l0igsa6U3oEMNu7c6XVz5Y6Qu3e1W7WdTKt9B6u5Jfd08PjOTgCjoAj4Aj0IfA45WDeTP6v9y3/Pqhn8/y0G3YgGn7YdD1gNkh4RRwBR8ARmCgCnCUeZyAAvNcn/4lyQHyxNeG5D4rP1r90BBwBR8ARsECAs+JNK7WQZ0f4tr9FU0wuDZTQQvij651vTa62XmBHwBFwBGaGwMGKQZyBHW3/i8wME69OGAIa98Q/DcvC33IEHAFHwBFIgQBKZBqnIggAD01RME9zEgigB9C1ug+59+tJ1NAL6Qg4Ao7ATBG4i2IAZ5DHpe/JZ4qNV6sfAaw9Qib7rncwI3RyBBwBR8ARGAmBdygGcAZ1PC46LRcBnBJ1Te4h9/Bh4OQIOAKOgCMwEgI/VwzghHZ1z2IjNVwh2e6q4J8fF1IHL4Yj4Ag4AotD4PyKwZsVnkWAmcWBPrMK4142ZLXf9c4XZoaFV8cRcAQcgckgcCfF4E20RY/qN5mmTlbQNyt4iOMnJ0fAEXAEHIERENDEFj9yhPJ6lmUhsJMyHgDmpwSgcnIEHAFHwBHIjMCbFKu352Uuq2dXHgJE2uza2h9y7ycich/3IFle43qJHAFHYN4IcAY7ZLBuv3u3eUPjtetBgJDAlqGjCVd7yZ48/bEj4Ag4Ao6AEQLHKgSAKxmVwZOZJgJEHGwLhBa/TxCRe08TDi+1I+AIOALTQkAT/vds06qql9YYgUclEAAaIeItVXjjUxqX15NzBBwBR8ARaCHwF8UgvmMrHf+5PATQAWkm7BTXD3twqeUxldfYEXAE8iHwb8UgTghhp+Ui8EQF74QKDB8XkVMvF2KvuSPgCDgC6RDAFWvoYLz6nu8ApGuXKaRsEUJ6lae6/v+ge5ucAjt4GR0BR2BqCPxKIQCcfWqV9fKaIvBfIvIbBf90Tfbr7u1jWnJPzBFwBBwBR0B+qBjAr+L4LR4BwkCvm7Qt7+N18gaLR9sBcAQcAUfAEIHPKgbwPQzL4UlNEwECQbFFbznZr0uL3aozThMmL7Uj4Ag4AuUh8EbF4P3i8qozuRKdRUQeLCJvF5FPiQia73uLyGUnVJNTiMirFHy0bsLvuv+SCeHiRXUEHAFHoGgE9lMM3F8vumZlF46V8/1F5Pcb8EcomJKexeYO/JkAACAASURBVBVF5G0iogkv3TXpt+9htUL4YSdHwBFwBBwBJQK33TABtQfedb8vqMx/qZ+/NBD3n4nILhME6XwicmsR2V9Evh9Y13U8tnr/XRPEw4vsCDgCjkBxCJxbOTg/obgalV+ghw/E/CgRIereVImYAbcyFATYBXDBc6rc4OV2BByBohBglbm6ygr9/zgROXlRtSm7MKcVkd9F4P1OEWEinTLtICIvi6h7Fy++YMpAeNkdAUfAESgFgdcrB+W7lFKRCZRD4z8ffY05kAaDRhhAz8A9Uc6BG7wOjoAjMCoCt1MKAEQU9MAtYU34HSXWT53BTgBI7avEAUHgWmGQ+1uOgCPgCDgC6xBgW/rvygEZ0zWnzQhcVYlxs/rlOGDqbpg5ztD6DzhgM9z+1BFwBOaKAGZU5xARvNHtLiKPqFahT6+UpRgUXiEib64UhbBx5/ezKl/irJywt76ZiFxCRE4zV2Ai64X5VjPBxFz/ISKXicx7KZ+9W4lxu11+JCK3mDhw5xWRvykw+eLE6+/FdwQcgQAEcDRyhcq++L71hP5lgxUrg+kxIvImEXlgPXlNXckqAMq1r1xfMRA3E9N3ReQMa3NY9oOLiwjubBusrK6fq83thipinrU2L2QSHpNersAE4YF4BE6OgCMwMwQuVmlLP0REPiAif1YMEkMG2h+LyHNFhK3apQkD7Kj8wADnQ9wqoLMnare7+/j4tyKCMue9q631y4vI2UTkVHUo3fOICE56cDzEzhh83k4PF7vPq7z5nbOz5GlvXm2lLO1yhfxeqlMg+ittfCkRQXi/k4jcp/57TLWz8tiVPxZP8MZtat0JdkH5fmnjXFpu9tRVCMDMbONrAtSEDBoh7xwtIg9YWCxyBogQbPreoQ2dthC4sRGufbhrn+OVEOc9OYmdiz8o8LlpzsKOkNf566MeLCdeWU3en6wm8p8a7iah+8POHS6oMdF8UC0g+E7eCI29xCyRQh8vIt9UDALagW/T978WEUKRnnoBjcN2Knb9m/AIecZW90UWgFdIFU/XseIOwXCsd/5V68mE1M3qHXb5YuvLqncuhDLuTarKPKU68jy4Oppk7InFxeI7dopQOH1YvYPEUayTI2CCAFuSnL+jPGbBrKnTQOkq9+rIBOiBidzLqD3cUcuJwGuCLaXm6XXp/1JEzjSQbzSvs7JdV5a++ywepkr4MUCJmQUGuhwIX331HfP5X2rLDXSm3BPjVLluxHJz3oTN+ZcKZ/RNnYyz3DOPiGHqrDlbPNygfb6RuqATSB8dlk28VPKzJ2bEF8udWCymJgBw5HEDEXlNZZWE3kZsvUv4jqMDnFNxdOvkCGxE4OaVP/CvTZzhm07HNjmKVnMldme0GuucJy+ZMDctfUXX8HPXlQA+uegZinFhKgLA1WsLprG39bva2uIeDq6eNJIiaS4+9XwiELieiBym6OAWzJkiDUyQ5uwC99nKNsNyY6m0m4icoMQvBc8OTTOXhv2BCqw4ny6VTl/7HilVv2koP4S8T6Cm94sICz531VwqZ2YoFwplr1J07BBmG/sdVsl3zYDlGFnQfl9VtB++2pdIrPz/qsBtbJ5u54/zrByk2Rm8fY4CDsyD8M2vnhEftHliyG/8rOB8zZ2uDWSgqb/OObKl17MhTJf7XSRePBHOkVBQisUTnwJLI5Sjprztv9rWaIEPdTA0tM3Rp6EPreYd+j88WgrhCfMdBsdnoXWfynvoOuyfWbG0FJ5YZDlwOjEV5rQo5z9F5MozbGm818Xig4LQUmgnEdFsY8dinOO7OyZuxD0VPPa/hSjkXrQ226M8Odpkqnn8sQ4ChWms00wR4Nzn+AV2BJwXzc15Btq9sYPNt2bK36vVQqMbE9FYnLq+w9U1Dl+6nuW+hzVHyl2A9yrqibOusQkBRhtIK3ebjp3f76rjkUe7G+exWTdN/tdUdOixGVOb/3vSQDpaqpdVtOWRo5U6T8ac8x6kwGcdr2FrfaHaRSvuXUvwiol3uBS0g4hQ33VY9N3Hx8KYhF8QrbVMXx3n/BwB7pZjNqDnbY8ASh9zZtq+uqEENhe6nKItj5gLCCv1uFJ9zqs5t97EQ7hjbhPKmPjwt95l2FSG1Wd/qgMHtctl8RtN8dW8hvyP06qxCA3/uZr0DWkDi3c/KiIXGKshPV9bBAhCYcEUIWmgcIUUiXMegplgE7yXiKAZ3PzdQUTuVyln4djktbVJombV0Vcutr7nYv5ySUVbftuWrUZNDV0I+Jq27Wt/zXM0x9cRPMWK8+MjrTo5CrA+u8UZTixenLeffR1YGe4/XFH22DrP+TssZ4h3kPK4KQNbeBb3TNgxsC1n25XzIxxrsIUYQ6yq+P5pibZYMZ9iJffM2hri63XoYbRhUYShI6M4iMtVlOW+UNvO/k9tUYBSUQlCxIUVbcnW9ViEFQo+GhAMMUdEUPxZFTXt87Vp6iNrf/fscDCJgPWOtUIZeg+sTOGxt2f040/ZThkIGGXGy+ChlWCCP4pcEwPuasHJgoitoQkChJ7EmETUy1y4Lykf2hWB22miCBDG15JhGcBfWIe8DB0gh0DHZIEiFwOwZbm1aeFIhghdWFSMtdIhVnxsPRBuxiB8lGv8F8TWV/MduyWx7qUJ+YvjIVZP7CAgTGJ/jaIVq2QETX4T8ldTxubbr1RR6c5h0LAIaE2aMVf8549JCJQx5bb8hp1MdkAZu1CmJKYCEf3wrLj6x310Jj5U74L+ZKSdpJD6M/ZhUuuhisfkcEXerBRCGnrdOwQIemsdGSvnlhBxCko810PRiPgJeD3j7DEXIXisa6O++2N4AmTyt5ro+upn9fzYTO5T2S2zss4hHO11lUz4MQVvgT0KqmNSznGCXUN2e9hRZIf1GiKys0Hl2QlF4ZQFELtimLKivFuKLwt28M5iUE9PIjMC2MTHMBGDN9vnhAgei8ibbSirAd46Hc7KXlrpM5wnA0B48IotP0pyOYlt/Kmt/L8nIuyy5CJL/xwIpU+vHLzEhIg9t3L1CW5jk0XArHV9C+HibbU+E9vh7FLmJPr9dao2wrc/5qjsIq0ra+r7OKO6Qs7Ke142CKC5HOoYg21+rAfYziyBiMtdesRCdkleVB2PnDExYJoz5lgdjZgq3XnEQSpmEGSlddaYiiq+YbImyE9Medd9Q5wPdEWGEBPLuvRC7u87JLNE77IaDylr6DsE03myiPz3CBN+H0SMhyigvk5ECPIVWier9/CzMKbFRx8+/nwNAreplbDWMcJvqqApjxERFIJKo3PVSnrryl7KfTDE8iHVeZlm2/h8GRv1AyMMTLE88D4RwXvgGMTWfahgHlo/zqJXzRfX1Q0hH4E/NO2u99AzGpvYOteujOlbuMi99NiVGZA/eli3qBVkWYR0tU+qeyx4SlCOHgCXv4rWMBMUPrLZWkeJCO1q7pU48bdbjDKmYmbrdDkvS3F0ggVDbFmv2gYz4W8mU81ORWz9hn7Htjmr11TCWijEKAsOLXvI+5wh9+36sJILSWvdOwQOKoU4rlxXznX34QGUe281A5M3zudRPkURcV19re8j6HtwoVJ6wMzLgQIiCk/WTJwqPVZW1pMuykex5b1tJv7I6XsiFgtWe1rFOSs4USRNNWjjAIrdsy7iLPsoBT+BPfb3pRD1eUNgfVgtEx2VnYO5EThwRKBV/g7tWywiUyx25tYuXh8DBHAwFMqYJbzHedndDerdJPEWRf053klNV5vA6h+LljOlBmJg+mw7p3KIhRlil3Ijbl81fYRdntJwZDcHfad11id4UXz+BqFoYLMV/zoWCp9StnMIj6AImkMRunjAvYBpEUCPIYQhS3qHM96HGsESs83ZYIHnxZR014STWFMHzZVVNiZWpRJmr6lcGuMIqq0Dwtkt3gQ1eLLaLpXQbWCseFblt+MV1Tb1s2tnVFaOk0qt97pyXa8+7tW0d9+3uMee447KOkz9/ggIXEQ5aPUxccrn2PZqiUk2tow4pUlB56/CL39EUa7Y+oR+h2Im2Jdi1bKpDVDes1YKbHBCf6TRCSCf5n7sld0ep+kgwNEAfgu0Sp+b+AWHTIzRTo5AEgQ4L93EgCU/Y2C/hxIVfDrE1hFnQDgbsSI80OEVstTwq0z8KPlZ+8y3wm9dOnhdQzkttp03fYe/f5Q0tZMAuwdO00QAM8IXJ+QxfAW0d5umiZKXukgEWMFsGuBKf8YWL77tYwk/A5o6Xis249Z3TPwvKPisH1e+nAOXbtXSgnS7n4QeTmXWxU6Qhof49m7bldhvTA0BdnDwd6Dlha7vf2DkonpqmHp5EyMw5R2ApqPgSlRjO83Ktklr6JWAS7GENjm2vyWa+KH0hX91wgPPhRigtSv1ofwR8j7uknO6BJ9Le5ZYDxZU9OkUx05E68zpKr1EfL1MxggQmS9kkCr9HbRmYzsHIWhj64d73qFEObG+KGmrn9UxK1kiNmJqyfnmHOmctfvX2PZO8R27K07zQuAmGywnNDz0CeNjx3mh7rUZjMCNFJMfEfFYAbO9ykoRl6mYMZ2hDnKBBitb5CjKoDWMo6RUWtl0Kkz6Ymg/BQbki2lQCDGp3ifRwLA6qKCghhZxE56ZiHn8ESUNO+ODayEE//ma0NMh9S7tHTT2n2Dg6W4V85j/2ZGYgjJlaW04hfIQEwJX0jF8semb1xfgbGsK+HsZAxB4nIJB3xWQ/uorrH5R3EvRMeg0CCND6YYKDMjzoIAMd6miP6YMsNIeMHDI4tSPwBVFhLPVNna5fxMjxGkcBPD0d+PanJEVe4rIfLgWJoyxNV8xbjs5AmoEiLMdy5ya828KThSsTyvy7yo3q9yhXrRYgWmcxqBhfpkNLYGCF1EOu8prfQ+FPXcluqExVh6hwY+LX+t2CEmPtvKz/5UGyfDvrrWZ7epuJP8fksi3BS6FLS1RKOv1M2DlWcwYAaKn/UEx+FloLuNp7C6VljnHCSGDZsg7b4xoMwLYhKS97h221VcHc+rGmfq6b6zvs73f5aEuAo7FfUK0RY0QGNOW7DxpCKET6xHcE+PSGw10YpLcwYPKrIWV3ccQ3Rv6M66+LXVhSM9S4Zewyt7f1zb11gMGYjw3Iel/szK5wZUnQTcIGnLNrdcW94uY2DEDV/ONZRxrGJm2adLWXNHAHdqudzTIG5/9bcrpZhmHIcRWd4pHAD0WXNtqeC/0W4K+xBLmmISu3aRpzvh2idgMZvodUf42YdbVdghXlg6aGHPxH9KVV8w9jhVZyDmtQQB/ymhObgIXhaih28ZrspvUbVbKm3DZ9OyEBMpLONT4mKJM7fJ+aWBLYL6j2Q0hb8KnNttyTzSqR7tO636zlewrgYENvub1HK6x6Tux3t04rgoNSgM/X35NPZd2e+fKffjvI/skQsObqmBHWJBYEFY2sWXpGgPYZXTqQIBBEU3oLtBW72FGdvaONOZ6C219zXYUrmpTEKsbJu/V9on5/2YDC8h2akw+7W8YdInoZnne105/9ffbRATByckOgc8Y8MFqO7X/f5CiqEMVyhj/0HNYOj3ZoE3ZHdJ6Hm3awXK3ibFmtyZhv56IAKY+nx/Y6B9dkHkFSintQWno70ckZDS0cS20szE7HEL44F9VDBqKS6730ZmwjIo4BKe5v/sAZd/YxAMfVowxhFseuoVNWR4/9wYLqB9HIpvaZcgzrJ8sojZiIs1u0JC8172Lu+CpuegOaLb4V4gEtg6sTfe1ijnxJc73JVrinBlvwqHv2SUTFxezOQulLGzchxA2tn11H/P5v2rFr1inR0OwWOq7rM5StDFKW7G7jPRZdJdiynXUUhuyrjfb/zGC0yasUbq00A24qYjQpzflFfoMz51ONQIfigQ11pnMlIDXnk8jbaJYmZruF9mG7Q7zzoGFxC+/pZJOuyza3+iqXGpgffz14Qic1YDvVtuabVpNzIoDlGXCOddSaXcldqtt2fyPNcEeBqBajHOUCR4LdUpmUOxyk8D5QqzdNX6550xnbnmHaxh56FVr/x+KL0IGk97Q8rXfRzGPFcAQ2luZZzt/i98fFBGc1jjlQQA9FIt2a6ehcdzCjoT2aAovnUulVyRoz3bbooSnNRd8llEZ2e1h/ls0XVsBJkpccybCl7aZd+hvttJw8ZuLUOQMsdvdVI+h3tawCAhVHt2Ur/YZMQp84s/FaVv5EOJZ23bt75mAYgnfEoQKbqcX8xvBf4nEIuKHBvj1YY5ZpkYIQGcNHbS+fEKer5ojL67d91cAiTOVuRJbkCEMtOmdT44AznOV5R5qEkgVsdfVrro24bjpGeUlf6dxEMAkeFP7DHnGkaJmYri3QVkY03Ic2Y3TWptzRYAe0l6ad/Ezw0QeSygWWggrWCss0az9JNw1ZmRst86RWAFYhEK95Qjg0DE0NvrsWsQoXz0l4+DBwEP7oLy61MF6BNbqzBIHOpqJoPmWVeGqd8jODNfc5CgCZbMmvdgrgbiWSs8xwG8I7vhW0QgBOFfj2HJInl3vvnapDY5XJM2W8RxNZliBaHz+NwyGw5mxJietjf5eER2CjnyoQWds8Nt0ZWfFwrQoopr+yQoCmGdtaqu+ZwicnAtr+woRC/vy6ntONMihOjArcEz2X/A/zgDDPoxXnzNWaUgToK0pCwqBl9YUYqrfEuihASHmepWpVnxDua380VtovG4o5sZHF1Oa8rx9Y+rrH7KVdrSSp/r48Ksigt6BUxkIaLwBYkGCz3ctsWOn2fVqeO6B2oJM+Hvcvzc45L5qnD2xYGNBoC0zi77F0Z4K4LA7n5tfZQ0ebQYsIXKZJnLg8YqegIMgvm/jYflbYx6mqJZ/ugaB+yjamqBSFvR8RRka3vysUv/Aoh5jpmGx69lgOfSK/hA2/rF0AYUlW1NWdqIW5wpa03HwQz8nwhriHwYDCQxFvOyx6aHKumj85RNo5zfK/JuOuXo999jAev7bIKDZerdwxoIfAo2bbviL73GmtVSir4+lxNv0b3ZwmMhj6ZEG4w1m1IsiTKeaBhh6xf57LoRHw1hfCKu4YZ5SAmHLvFq2If/fWlkJhIAU5oEXVJbLP7dF4KUKPtvHoCj7KvJv+sMcdZmGQPtMAwwbLDVXFNJjd5XRQSIaoSZ/dgEWpQugOa/VThBDGDTlu5xBWq38WUlcNGVhB6b9fUWHsBic8RR4pKIMXZ2Zs0qnchDQRKTEbE9D6IL8Sslf31VMOpqyl/It+hO5wjp39efVe89QAIO7YSbx1TSH/I954iIIiUkz8c0hfjbRqiy3vjQezFIw3RsUnYHIeRZEdDXSGtIJN71L8BmnchCI9blPG2vOfUFAo3/Q8BhKjEsmJtwGi5grfhMIJBbzbdc3aORjWRJL+JLoSjf0HnOiVSjj2Dpk+Y6z1FBQVt9j0iTW9lQJ948vUtR/FQ/+/4rSjjkFlg9T1BGlKEu6l9Exy/MsC+VpqRBgu1YTnEUTqwGzNVy5dvXF0HtfMDA/VAE48sdEEtXG8iBWCj4YiCMSinvfe9+pTEPxMBlD51GatlM2LMFmT0R+62uIdc+nHAMARRNLibXB6D0FcozGRpvjIWu6iIGvgMUp6lg3gmF6uLlu+H/ola1aJo5YQtF2aJ6r7y89GIxGfwMsWS2jhAlhjmcZRwDl0lh6oZI3cDIWq4sQW+bs3+GlbrVDhP4/VQsAPMf9XlHvPnxulb0VN2eo2eVhZZCCWLlpvAai1+BUBgI3UvQlvPZp6B2KvOnHH9BkPoNv/9vg+PPNKzjQt1+sbJdmjD1BYRWAJ1OtUvdcdNxWmmjrX43N+9TCADMR5rBzxf79tFsQj/4L16oaHYcdE9XgMopBgi3n2UvniXC3TpbAUc2APfSKn4pYOp2B6R87oEslVusaF/BNWxN5cZVI+60KvmjS5hrrkIwyaUzcyXv2O40PVzTSS1ZbvdD/mcBYbeK0qM1YKX+/vDAsNP7RU0UyRH9EI5hwlOA0PgL474/tS0TajCWUd2Pz5TsmvyUTHg81+PHtpl1gzu8/ZZAHCoF4q42h8yn1UxifmuONmPyL/2Y/RQPlinEfCyKa5ziGsAjoE9NRtOZNsfXu+g6Fmpg68E1Km1iNieItuirq97Ij8E0Fbz1aUdpDFPnC13dQ5D31T3F4pN0eB8M+/QkmTwuPoO9XAK61Ppq1a2hN5Ccm1xIJN7RocP5OOUDETpjNd0SoKiVELb7zm3INvaYUAHADO7Q8zfuEsHYaFwEU+DS7ODeILD6+JVgZNrww9EoIWU3UwchiF/EZR2cWCtAE/QqhqypX4U3bdh01hObfpBFz1RxThZRv1Hc0ZyTY35ZCdGYUNj6sHBhiGGTTN78VkRK2qjF12lTOTc80Zlp9/KEJuhQ6APWVwZ/HI4DTlU280/csNga7xrSVMj02vsqT/1Jr8w9+WG/Q9qGEsN7HC33PMTGMpW8p8kfQROCcJWm0NUsQALD35BhDc8bdx3ja57jCHVsI0Cj7pBQA7qromFgoLHUVV8pg9BBF+/1CUQlcbcf2Swb0pcaS4NhD6yUP3Icq5qEP8A1Fm5Enir+M9zGkFRhLmOti6t37DYE4YjvS/XpTT/MCZiY3q6I2fbCw1f4mHH8pIpdLA0dQqppz2pQCwGUV/AfefO80HgIaL5ObFMg21QjlUczDNvW3Tc9QTFsiYXVjoQgN9jFBwtAX0AofsS6CcXWscVZVon8XEx5GW31TZ9n0LLdyBG6L71TFDtdMZpvqk/oZka407i01Da5x1Zpy94LzSI0ykrsE1nCF/lvO0mP7Tayntesr8qSsJSnn6lsgLAW2sK2CcmmUv9+kbDuOVIn9EEMfUeRNnIRYr4QxZc32DS5VYzsw9r85iEkCfwXfU5Q1to7W3xEoaIztJI3jozMkbmSNqRArUKdxECAio6Z/3Dyy2M9W5Pt3EUnNz5HVSvbZGQ0XTXgG1XhuxCxPE3sGfts9Eql7KviGfHeLzLfozzTKGamtANjqv5uIaFYZmgGKb9FwRk9Cs0rtKgMKLbkGIjpsVxlC7mHJQDukJA0PpnBVnLKuc0r7vgq+YiuYbdkY+roiX1aBSyJ8oGj0f9pjBG1mMQlqXQ9jORRDCEIaixWLyKgx5U76DUEc2o085HfsFl5IhdAwPVxRtiH1WPcuEa6aLfs9EpTlOBHJ4YlMs1LTumoNaWuiwa1rg777DEqnD8nE3zFHQBP4hd28GCJwjeYc+RExmU70G7yRYsLW14dCnzNxWxCKfJrzeHYQYhdPn1fggeLp7EijHUnQB2tiiwgNU00nD2XoTe/hMvhMK5V7pYJ51uWFRMoKOOX50nUV5T5yBYMU/yKZa9r7CikK5WluRABXr79R8NXrN6a+/qEm7gB98JLrk57Vk51F5AhF+6yOV+zC4ljNirRugmP1OPZWYPLHyuIMPbRZEVvsq40d+v+7DJHAnOtxBr69Q8u+7j1Mk8Cki9A+tuxU7TIw0aYanB6kaGP8KuSgbyvK6AJAjhbaNg+CyLT5d+hv3PjG0OMV+eKRLvVxVkydrL9hEWWpL8WK+4rGhbyyoh3htVgf/dRjKK+238eSYlZ0QwUgnzRCAk9zX1GUo91Asb+xDcYksm9rCS+DqXwOoKCEa1RWV5ZEzIZYXHAUlYNepShjrDOZHPWaax6alRS8eK5IYDTR/4hZMHfiyPJXir7UNU48NBFoGjfg6GSxIBtKKJRrTCFRRp8VaeywtSFZ2fYmSA+KZl2Ml+ve5wZKuJcQkV8nLPNnRARBw4o+qygril45KHZrF5NQp/wIaJy6EJcillD6jB0XxrC+ia1nzHfs9FmPpdi/p9o1eaqiLeGB68WAVMUv+IQi3wMi8yz2s3MqwIDZYj2xXTjhdnroAIF2LDsgMcQWKHb9oXkNfQ+7U4tgJZxZaSTea8aAE/ENg0yMgk7sWWBEEf2TGoGLKvn+BZFIotTmuiLbg4cS7JuVbdI1PiFcpwxrfnFlmYljE0OaAHixzqtiypnlGyYIjV1mzEr1LiLCBNfFdDnu4RcfzXMtocFvbR64Wn8kzlghi/rhxW81zSH/o3WdixAKcfQRWj40nGenlJMLbEU+mEOFtlHXe3jxjCH6W1d6IffQOo/ZMo4pZ85vUPD9sQKXddihCxXj7W9o3b+mKDvfxtBtFHkSWXZ2pDmLGbINc5rKl/NrFeCvY9aQ+6yC0eK3dh3LoKTRhg4pO45yYmNSaxQAcV+cm4j4Rb59uKCMmVM4yY1DyflpAqsgMMc6ktEoLM/tqIhV/4uUOyLr+hiuflHSy0Eofq8rR999LKiYU4YSC42+tDc9x7fCrEjjIvH+gUggTWqkvU0NsukZ2uV4LDxdYDljXoOhNGeTm8rfPEODmbCaQ4l4CU0aQ68HDc3M6H0CtWBj3rXdy+D0LMUkYlTExSaj3bbFvDaWnqDg5bl4jOSoDEU0VuhD+3PI++yUEFU1F11eWQ/iCwwllKw1x6KprLWG1sPsfY1nphBfADj1CVnVhTBoyDto0+NzOoY5YkHFq1nMGXZIfZp3OKoZopR3SiWjjx0yFXMmdjCeWSki7Ssid0wsyMW2/ZK+ww98w48xVxxqxZImcNkcvLhdp9JZ+qIS/01txoqaWCs5ieNNonpuKtemZ7HeaDWL0VgX1jlxHZSXJqTnl3tyQlplQt7UiFbPOAt7lMLFaE9Veh9zxnhghrqyAg4xFeR4RoNtDi+FvaD6C8UggAnVzxQ8xeoSp0+xpNnNmrL5Fuf8WAZp+nLft+y24St/DPq4om5viywwO1F9mKx7nisGTmTVhn92bQUYTO4MDF30JEW668Dvuk+UK0ITp/Sm11W/dfdYqWqC73TVcfUe9tB9Sk1oya5+F/o/7dqX/rr6+/15IoBVSij/dL13iBIWTQwAJtEpEX3v7pncobPyv9eI4GAK3sUvIfdiTUo1QfA00RBHhHl91mxfh4C97p1VxTpWpy9Uprkur/Z9C2I84wAAIABJREFU3FNiBlbKxN9GGJ0HSz/c7Xo3vzly2BRQhc7RvDv0im8EJ0egjcChCn6C/7QrzN8p8k8Z0rqNkfY3nuaIdphasbgZDxD0b6cttPJ7jatyyh9jCURMiAaDoVeOomZHmq09jhAaYjcghU1qu5EwIcRjXokTf4MDVxgTxSVr5xxtLFA+vFA70/q3xsET6RMkyskRaBC42BqlzDYvbvqN8qbWphxvnZvyWPeM7e1Yy4Om/qmuLJZQhCOwmsYaa13dN93n7H2IFVcqDNCq71L43VT29rMLRBRME9wNBeXZ0fsjOxcN0Wj2otChiRDWbtSu3zAJQUSm5vr1cpWUrTGd6sKifQ/hDe+EbXquoj1Je3Y+r9vg+O/BCOC8p81zQ38T/EVDbIkPzbN5H+GjFGKMRDjHvS5hbTW7Gk39Yq7oSzEulUKaBWiMMzdNBFJ2wmZHmiAbMDGrcW2Ep02MzPkfNuJTJQYwJuXYVcwmbHiGa2K8E0IMMhozIcIgp3L/WRfRLxNCAJtzrdfLmyjrS4yOvj6w7jnOpcYiQt/eXkTQx0GRL7XjsHUYtO/jGjzWr0gqHDlybJdxyO8YpTxNMCLC1M+OdlM0AI2l8Te/qbHRHEbpovTt/lCGQOHyOCXW6/BikMbkksF23Tsh90NMO0Pr6+9NH4EnK/mJ1R1CqYY0LssRaHMQRxycZ3Pshw8NvMaF9Lec73B+XeJYip+GWByeHtG4uyryi/VAGFHMfJ/gUSnlWXVM46LEZh2GMh+i63PCKRHmKzGY9H2DgwttZEUC8zg5AiAAr2otWvDhoCX0XPp4f91zbdCyrrI3W/k4QiPKIA7HUu3uravXkPu04e5dFSnknsYS4DURddDEszgqIr9JfKLZhhnCjCHvvrpyALPDJFCLLySaqOxwhOCR6x0cNmlXa/GI+JelIaD1+w9/s3rXEiHDY/uA1YqNxQhOqRgn0SuILU/u77BG4iiiZNK4ef5ARMVQHIxth2Mi8pvEJ9qtvlhA29/Rse4xCbRsCsnRS04viW2su37jX9zJEQABVv9aJbV3GUGJfksXv4bc63NW1ldEtNRT6jeF1CHmHfQNsJaKMZPrw8T6+bUU7XtYRGEQiGIw5RuOcGdJnB/HgmLx3Q8qiwLOZpZG5xIRQhNbYKhNIybewNLaayn1tXDkhftaCxpLAMB8kAlG269yf39w5ZU0JlKrRVvFpIFFQixGx0Zk6AJAB2hs/Wol/thGxKnNkqO74bcfE8dY/Cy+QwBz7f+OjrHAW+cwCNnN1rsVP40lAIwVvTS2P7M6xepgarSLYuxjB3UouQCwBjGNNmYs04a4tV1T3FndZrBEYSoWR+13j5kVml4ZDQIE09Lyk6XS2RgCAKZiGgc1WvyGfM/Cje3+qbrv1lh5YP00lFwAWIMYoSCHMJ723ecHBrZZU9xZ3t5rBOXAv/W4FZ4l0F6pTgSIoqmd+NC8tzx7HkMAeEvmsTBmLMWbH8HB8JMwZcLXREz9+Yaxayi5ALAGMc68NLGShzQi7i+duhHAFE8TJnNIO/DuXOKld6Ppd0MR4BhQE3Sn4Tvr4DK5BQBwwOV4U5/Srjj6wl23JrpiKE/keA8X8rEYI6wOPWpyAWBDq75R0RihjYiCkdNmBPARnisoyJS9LG5G0Z8OQQCvaqF9eN17nENbO5vJLQBoY2msw0Z7/4gqJPN9JrzVv4kXNX5o0KEaQi4AbEDr+gaDwCZGn104xQ1Yah9dSunWd1M7NM8+qS1kYd+zhY3b5Q+JCCFoDxQRjlUw53JajwBa43806PvaqH9dJcwtAGi9aTZ9y+KKE5+XFOa7v6uNNPcIiqQ5dhp63OQCwIbWAkzcZ1ow72oaMLLTMATwWnV8ovagfebi+e/CIoIws8pzzf/4hEcQcNoeAba8scRpsIq94hFv6GC8fWm2v5NbAECTPhYDi++I7YEFws1nutpfbWHcKMfi9o/VxAL+dwGgByQLG+CuBi0tCEUPDMU8xnNVChNNS1OtMcHiuIRBs4vnVu+hNOW0LQJW1ie32jZZs/9yCwA3DuSlVd6K/Z/tbwQw9KJwDpZCiDJrjAQJ4QslFjt2rYaSCwA9iDFR/13RKOsa8w49+frjbgTYvkbSXYdr7H2sPqZOKEIR3nQIBvhwdzoRAY5M/j0Qvy6sv5AQ0NwCQGqnaAjzH6nNfjlyJRbLkuliCv5DIXIouQAQgBhBLro6uubeKwPy9Ve2R4CtQA3uXd/ifXCo9uz2JRv/DtHAuuq36R7C1FXGL/roJcD86kcR+K1iSyCcKySsTW4BQBN7YBUbVveEkMXNNj7vcXozh35n2dwoIa/iFvo/x05DyQWAAMRgVIuVQbshZxtIIQBPzSsMHm0cLX5buWnV1Ev7LcpDsZYS6LnsrC3AhL/H9OpjRnxFmNmUlFsA0DimoW/iQ+ChtZA5Vec8KdtzNW2NzsUnVhML+N8FgACQeMXCI9jqZMV5ttMwBL5nNFA3bRETQWtYifO8fQklLoeKCBPhEomImw0/aK6/ymCPnlsA4AxeE6nz3EtkKEWd8WkQy4NvjsjXBYBA0C6YQBfgUYF5+2snInARRefo6lR4zqJd50DXM8AGvxdL25J9ggFuDW/liN6ZWwCgb+DPoKnj0OsN5tC5MtYBU92hGDfvHxBRThcABoC2v6JxmkZqX7XhOQcUfRavamOyt7HnN+nNhYheuFq/mP9jBpGpYngnpc11G1+OEHIIT2MIAJ9T8Bbb/07hCHxRgfUDw7M56U0XAE6Cov8HGqrfUjRQe8Bofl+oP1t/o0bgKEPsCRM6JxOjMxnqqSwhGNJNDXf0CMKSa6t7DAFAExjt5T56DUIAHx3N3DD0ihXFUHIBYCBiTNhDTa02NSRnPk79CFi6JMWxyBwVkj6uGDzaPIonMiKqzZWIzqdxt9rGit97ZgRqDAHgcQq++mxGbKae1fkUOMOHMUKoCwARXHMWEXmXiGDyszoYDP3/u5m2DiOqWdQnz1ZijXOct1Xa3myVz5WubrilDR8/c4a8eW/DnRIwOigzM40hAGhMb08QkaH+6TNDWkx2eyjGOALXxRxBuQCgaH6cNqDIp92aRoHLaT0CrNZDvdt1CWBEE1yKgxFrM8nXzOiohL6q8bO+ylvsBJ55PdsmeTKGAIC10mrdh/yPgyWnfgRepcA51vmUCwD97dL7BluKQzrE6rvv7c1h2S+gXb2K2ZD/MeFcChF9DsdGQ/Dpexd9CXQMpkqYN1oLRjhQGiNy5BgCAD4mCMTTxyfrnvsxZ1jPYTd4HYZ9918QlsV2b7kAsB0kw2/sICIoAvU10rrnOBmiIZy6EfiqAlswx5/5koizQM2OSRefstrFLezU6Owiwjl0V50092I0ri2wG0MAoNy4643F66MWFZ95Gric1+xO3TUSHxcAIoFb/UzrTAQ3rk7bI8C5duzAw3e/FBEivC2N0Ai29l6JQ5jHRp41joE/AXmsBSF4aswdpbEEgCcr+iFHcHNUurXkaSZwzTiHt9oYcgEgBrWOb66lbEAiORHMxWlbBN6vxPWF2ya3qP8eosRu3YCEtUHJ5qucy6eI3wEenxl5MhtLAMChzzp+CLmPIqHTegTeo8D35wqh3AWA9W0y6AnnZNpgIvsNynH+LxPaVrMtxsCUMjDLFFrgOYqBZdPAjhfFpxSmXIlfh/uKiMaWelOdOaMdW0gfSwDYSWk6iemtUzcCp67Mbv+q6KcxLoCbkrgA0CBhcH2SohEZeNAjOINBOeaSBH76Nw3Ifc8OmwsQinogmL5dieMmnFl9cB4+pqkX5k+E19Za42yqJ6FWS4jdMZYAAAt+SsFHBKpa4lFcSNe9jQJXePaeIZmseccFgDXAxNzGPwB2r5sGkr5nT43JeIbfWKz+7zJDXGKqxPkrkcL6eE/zHEFgbxGhD+QiTDvvV03+30lcN2LWXy5XpXryGVMA0MZNmEPUzZ7miXrMCl7T984bleuJH7kAoACv69NXKhsThw6E4Fw6ab3a/UxEMIlzOhEBthlTCwEMYpjHvU9EWNWQpzWxo3HtyusZ/gk0ljehAy6TP5NuKTSmAIBQHopb13soSjtti8COIoL+VxdeIfe+uW1yg/9zAWAwZJs/uLjBuTVR2ZZMt1Z0iKbTcBzjtC0CTMiHGGDbYNx3RU8AEzAc8FxTRDhHHkrY8O8qInjw4yiDreS+fK2elzb5g92YAgDC108V+LO4Oe1QBpj5+/C1hl+1emMuACRgMI3NLMyA4tuVE5RrCkmyXX2MslP8XUR2nkJlRygjQgCTsmbQif0W19lH10IISmHPqALy4Gf+EbUeASaG+1be9V5cbblj/XGkYcCeoWX+lYiw4i2NxhQAwIK2GYpl+32UNJ22EPiKEk/t7pQLAFttYfbruspGpcPgzQ2Je2mE17D2gBHz+yVLA21gfVlVMwHHYLuEb74nIhcciGmu18cWAHZT8g0TntOJCGiPVI5TmP81beACQIOE8fWTyo7CQIsd95II23KNOQyYoYR5jiWBpqgrxyRaM8u5CQSfK9zt8dgCAKaWONfStLt21apg+aI+1fj+B3+CdWnJBQAtgmu+x22qppPwLWdmJZgerami6W12Oz5tgNkBpqWaf2KPMcBcy+elfI81Qeke68YWAOgRONfStNlb5t+temuItQzjuwbHS/Tm0v+CCwD9GEW/QRAVTQPzLTsJMWEeows90ocWXuvoUPjUdgpHQBPqVcvbpX2PnXvpVIIAcFnluIaL6pI9Sebggf2VGFodpbgAkLC16SgWW6xjBR5JCM02SXPeqpWGmUz+Z5tU/Z8QBFwA2BLSXQAI4ZgT30FBUyPAvSw8q9m9eXoDE1ar42EXABKz11uVHYVOhjnVZRKXc6zk8SB3uAFGaG27F8XhregCwNZE5gJAOP9od+wY084Wnt2s3sRhlkZ4Qk/KyiW1CwCJWetcIkI0LE2D8+33I+2oE1dPnbz2PLHBdS91SZaZgAsAW33TBYDwPsAqVjuuPTc8u9m8ifdKbYRKS4dKLgBkYK1HGwgATHQ4QpkT3c4Ily8v1GTSghdcAHABIJaPMLdtBPCYK14jSzW3jMWk7ztNWOUGY0srChcA+lrM4Dl2199Sdpam8R9pUJ4SksBjosYFZoMHzmVKdNhSAsYhZXABYGsS8x2AEI7ZeueiBjpOmkh2WyWZxi/Mk7W6Tp83rqoLAMaArksOV6gWCoFMeLdcl8lE7uOl71gjgejlE6lzqcV0AcAFAA1vfljZjxkTLVe0mrqk/tbC+Zb12O8CQOpWb6VvwQCsfJEisTCYImFn/QXloNGs/vFLbqUMM0UsLcrsAoALABo+YmHT9MfY6xJMnRmvWbzFYsR37CJbm4S7AKDh/oHfnk5EfqRkgoaBjp+gkyC8iFnFpmflcKOB+Pvr2yOgEQAQ5AgRe4QRTze8HXMlSBDKURoNaz8C2J4/Qu58xqD97xaS0UTfYdK28Ax71wT1dwEgAaibkryWgSTYDJA/rMKinntTZgU9w9Pf6w0GiqbuLy2oblMuikYAIGBPQ3isRNmVSRR3zE07pbx+tzIl4wjo+iJy8rog9K/YPF0AaFpz2PWGCsybtsKM90zDsp3M21goNfWMvf6gxeOWFXcBwBLNwLSeZcAQDSNhHnj2wHzHeg0J+JXGdcacxkmPgJUA0C4JSq9EsyTK37tE5Nu1L4uGZ4de2e1hx4sJGtMxwkWvi/boAsD6yQZrmVT0RYP+bWnelqqeQ9NF8e/3BtjcZWjGge+7ABAIlOVrOL/5ugFTNAMpPsxL3Qlg5Y/Xr6as2uu/Fhwq2ZIHm7RSCABN2u0rQiA+MTgzvruI3K8SCgj/+1QReXa1+ntRKzzwQ6u488RJp2z4Ox/in98FgPV9LaUAoMG9GRMQ9Ig2OCd6r8HYx1yRKjKsCwAjcdvFqhXSnwyYo+k8PxYRTOtKIgSddxrWkbo+qqQKzqAsuQSAXFBpJiI/AtC10gcN+johbnEyNAe6gwEejHn00VTkAkAqZAPSvZWRaWAjBPxWRK4akG+OV1B4tFB8aerGFQVCay3YHFiUnIcLAFsrZhcAdJx6aSP9JtynT52YWBmP2+NXzO/UPOkCwMictp8Bk7QZ6+8icp+R67SLoeOjpm5HVee/px25XnPM3gWArUE69WBrwT8lRAPcVI9XGI1nU7YKQCH1cwY4EDVx101gGzxzAcAARE0SnO1YhA1uJsrmitIdW/C5iW0vrY/wpg7NFSWaC+euyELycwHABQBLVkeT32Lli5fQi1gWLGNaVkreL85QZhcAMoDclwVnXmhKNxOe1RX77Ev1ZW70fEcR0foG76o3Sn83NiqjJ7M9Ai4AbPU73wHYnj9i7qDg2dWXh95DuXlqu343NTrWJWBQDidnLgDEcHiCb9DiR5FvaCfpe5+AG/uICKZZqeh6lWY3Pgn6yjL0OVrBaIw7pUPABYAtvnUBwIbPcPhlEeKb8QJfE6k04G1qu5UKStgWJn/Ue4+tZJP+cgEgKbzDEoeB8Gg2dKIMef+bIoJ0akk4f3mTkcTbVQccyzilRcAFgK3+5gKAHa+x88jio6tfD72HnlTpZBnf5CMZK+sCQEawQ7K6SuVR7a9GHaero+G2U2try24F2/3/TFjOA0LA8nfUCLgAsDVJuQCgZqdtErAIfcsYxk7gvbZJuax/dhARC0dI1BX9qfNlrJ4LABnBDs0KH/d/Szi5wmicrz2smsjPElgojhCYLD5Q+VtHO7VLuLC69xo39wtsFf1rLgBs8bILAHp+aqfwX4YOzxhzbttOvJDfHHfg7dJq7HtA5nq5AJAZ8NDsrmsQOzqEKYlQdWTtYnXP6uzuJiJy+XqX4M4i8sTKt8DHMpWF8rKz4Lb+oVyif88FgK3B2wUAPT+tpnBJw9gQmDgzLpZCTP5vMZz8WVzlHvtcACiFmzrKcbVqlf4HQwYLEQjGfOc5I3SADtgXdcsFABcAUjP8Aw3HMLbIUToem5j832xYr58P2I21rLsLAJZoJkgLxx+pFAPHnOxX88YnvFN+BFwAcAEgNdexqj3IcLJkJ4CAUGMRjn4sJ392YYmoOAa5ADAG6gPzZHJcnTDn9D8+EJzGQcAFgK2+5UcA6XgQm/ZjDccx/IOMYSKMi/OPGtaDcfwp6WDvTdkFgF6Ixn8BBpnThL9al2+MD/FiS+ACwFbfcgEgbTcgVoC1hROuh1P6OGkjcv4EDtvQr+I4YSxyAWAs5Afk6wLAALD81UEIuADgAsAghlG+fNcEi5mPi8iZleXq+/zaIvJL47Ifk8nb36a6uQCwCZ1CnrkAUEhDzLAYt1AManhpK4004YA/XVplOspTejCgjiJvd+sZCp5b3T1s/ieM8A22y0l/Axv/5xlFOWzKyhWPgYSEH5tcABi7BQLydwEgACR/ZRACRGxkYNO4Lp2bAIDDmUMrHxkEtMq1rTyo0So/HHMQAFAKfFsCIYCJ9UARISCRBV259pfSnrgtfuMh8ToWBTRIwwUAAxBTJ+ECQGqEl5E+2ss4UznEyH3z3ASA9uD+s+psFhe0eL0sieYgAIDnqYxC5rbbrPn9q0rXADfiBCiLoUtUQdTebdRHmjI119Lim7gAEMMhmb9xASAz4DPL7pxVfeChnxqvuvBWyWq5FMIf+xeM64gHuvfW28u5nbR04ToXAYC6naF2QtZMjtZXzKdxR3zBLiBX7rHjgwdWHPtglmddlia9R6zkO/a/LgCM3QIB+bsAEACSv7INAkxWeE3DTSkmU80AZH1lRYO3yLEjthF8BqUq6/q10zu68tX+SMMt5m0aLPCfOQkAVBlX5Lglb+Oc4jfB0NA9uGctzIEj2/D3EZHXishvM5SBcbw0cgGgtBbpKI8LAB2g+K1OBFhVEePhuxkGtPZAzbECOw25CUHnIRliZ7Trys7H60XkSrkrOxMdgFXYziEiv87Mr+32zPGbnYUSyQWAEltlpUwaASB14J6m82i2zdwPwEqDR/xL/AaCKFnbWTftG3L9XT0Z51Kgu6yIoLkfUrZU7xxRR6o7TUSbxXwytx2ABgPGgFRtVEK6Ja7+wd4FgIYDC75qBIB9ReTGtdZtigiDX65cFT+oDh4U29FcAIhjPkyU7lEFcDq8sMGTLd07iQhKhykI86nXJT6rHcrLWFO8oOpnF01R4VaaLgBMU1BwAaDFxP5zGAIaAQAlmIbYHt69PvM6PnLSOEFEPiIiD18Z7DiDHTpoNu+7ANC0UNj1InX0RlbcDYYlXn8kIo83im+O1jj+37E80Ow2pcapMSW8fSJTQhcAyub5dfzlAkDY2OZvdSBgJQCsJo1rSzzBPa4+03yfiHxSRL4iIp8XkQ+JyFtr5Rk8eF1ORE65mkj9vwsAa4Axus1q+jYigtczJpl1A02J9ynvYSLyP7WmdYjXNmLJw1NEknv7RKNiYkpIHI9zGfEAybgAMC3eb/qjCwCGnWBpSaUSACxxdAHAEs2ttFCQ2qc6Z47dsWkGoNKu7F4gaCLQvFNE3iEiH6wFUILG5NJdyYELVhjvqYTq6xuEu3YBwAWArdFB/8t1APQYJk/BBYDkEBeXAQP9G0TknxNb7eeYUKecB6aEj1X4rncBwAUAy8HKBQBLNBOl5QJAImALS/a0tV0yNstTnuS87P3tR0x7dj2uN5AHXQDox7ZE/vMjgIGM7q9vIeACwBYWc/yFbgVhTf/iE/8iBR9MCXFIE2JK6AKACwCWY6DvAFiimSgtFwASATtispjw7Vkrx5W4YsnhGW2senOs8ucChS1MCZ+/Yl2zyqIuALgAsMoTmv9dANCgl+lbFwAyAZ0hmwvVVhUlej7DTwR6BzjYweyO32NN0qnyxT88LmB3qlfdXyu0jihI7tFhSugCwDR50o8AMgyuc83CBYBpt+zJRORWIvLRQk34vl07czrdCsy42cWOv2S7+yGCwlcrB0LnXakj/16zNnclTOuQ9HK8SwAnnHk1bpZdANi+jb6UgUfZndHo5rgA0NHx/FYYAi4AhOFU2ltnrwamJ4nITwqcWNgGx75+twDQUFQ7rsA6hE7ACDAvFBGOXTbRWWuBBwdGoWnneg9TQkLUEk0uNk+8dpZKGlfAmCBfoNKheHaCoD5fb+ln4FQtFnsXAErlvAmUywWACTRSq4is0ko14WNFSVS0oXHusVBAUXFqToh+WG/5t5qn9yeRDRF60NKfkz+COQsATaOy23b12i3zjyMnbHbEGHPpx21yAWBbAYhFgVMGBFwAyACyMgu2z4lKlyO06dBVCCtg3DffUkQYIDVEiOFSz83buOCyGs+DIZr1m/BgZflMEflV5GTSLtPYv5cgAKy2JYLuLWpnWgfWrqQ/Wzuh+kQdLvtldd+9RuViG0F3HbkA4ALAOt5Ich9FLDTFj1IMPu1YAEkKWSeq8QSI+RtCTnPOmbKc1mljwvfKwk34bmhcaVbIKKiVeCzAip2oiJbud4EP98WcA489iWvyL1EAoJ3QcdCYwDL25CCNAMAYzljedwyVox7tPNwKoI1GIb/RFH+O0XnWFASAZlBrzjnZfkUBrVQi3O2dReSLE5kQUJJKEZmPuBB7VUF6OCdt2nCsK2Z9LxERAiWlIFaPY9XNKt9SBAD6Nm6RcY9Mn9fWbwoCQFNHzGsZ2y+cgkkj0nQBIAK0FJ+0NcUtta5xMoI/+ZRE2QmF2jC5xfV7dcRBIhiWQkx4Dy1Uqa8P8/0Sg3jtWqnwr8Z80FcvhI9HVfbzp09YP4S9vnJM4fnYAsAZayXG7xvjOSUBoOETdGmwCsI6SHssp2F9FwA06Bl8e7ZK0WhvEYlVWGkYatMVxS/rbeCm6jAQZ2mb8tc84yz3tSJyhSbDka7Ety9xyzsUW7bGOeNMTacWEULhYmGQwpkQK8bDqxgJT0i42m9jRMTMPyTk79D2s3hvLAGAvksfpi9b1GM1jSkKAO06YCWEtRBWQ7nJBYDciNf5XaseJHMFe0HiZBvT6myU1TAmSX9M1KnbHaT5zQB2TxFhkslF7J4Qg74pw5SvmLfhACcXsdV7idqM6vVVKGCOIoY4QMJfPkqV4I+OCNvGO+YqfBXKF12Hz82k7eFbTO1yHa3RR+mr9NnUfWbqAkCDD3MBlifspuVqJxcAMg4oaJg+qFohYWbSNHruK1L4Syvh42KR9War9ZEjr4YJJfu8ynnLLpF1CP3sHjNQ/Frlr5eHVj7he1hMXLoKBXy1elJnx4C/m9Ume5hfMTAxAY9JGpv7VdxL+f8Dla7EWRKCSp+kb+ZUmJyLANDmEQTfB1dYrjrnsm46FwCsEe1Ib1cRYeAtzf/4kbUGLisrtJy7CK1VBmRM3A6uHKWU5C2NXY1DKg9dtzVWckNQe++IQlp7IKCOH6t1DyywJz1M+Zw2I4AyodWWNd4UnzVw96PNA9a/fx7oAGozQltPUTClD9IX4S/r8valhzCZgzTm2H11WPcc6wisjHDPnYJcAEiBqoiwRX7XaoXz+RE6xDpm6rvPWecxld0sLlNR1EF3oO+bUp5TVgtTQiwwSrDl5/z8gBVtYYQwC7xxjpPzKCBRF0uWLDsPVv32da1SYtZ7NxH5glE7aniB7WYiEGoIs1363NjjRC4BAHNFDebab7E6wvwWPrIiFwCskKzTQWkIT2tzcByiZdgxvkdJ7F31KnfoORpS9i9G7uSH9dgLv9OofC825vs5JYelhwXvYqGwTl/lMoWEgGZnYkg/4V12kOhjFiZ8Fjizw5qDnmrEF9o6E9AKt8cXNKi0CwAGILJi4PySLXJLEz4toyz9+yGmhEz+Y2l7Yzr36g7Xo12syZng0QYDEXw6tmVFV/3GvoeS7J8M8EU5NsQnAe05tl4QcRL6hAB0fx4mIt81wMZ6XEKYykGlCAANfhYePl0AUHDOziLyOBFhS7VpFL+WhwVnuXiHu/yatkaSHmMnsGYEAAAX5klEQVTlz2DKanOoDfsVKzM4C+sRfESMaYO8pjlGvY1zGos+zFbtUCIwE+aTFm07tA748egi+gx9J7d/hyHlT3U+vooHvjSGlCvnu5iRP7HSNcOsfAi5ADAErfpdlOIIjGKlJJSTUZaeF3HWOftsfMSjEc1OQS5csMdHE1vr7XAfozIjgDidiMCNjTBle1xDRCV87AgLCxwqQegvYZXxcSM8UvetXALA/hPAY+j44gJAzfR9F5Sm7leI29PUHWoJ6WNK+Nxa4TFHfY+vA5JYeWVk5W6hqMZW9RgOSPr6W+7nnNVbOHpiJWblvZI2JoATgZxyHC2Sx5sSOXBK2ceIx5GDpiAAtHHG3JzjpU2mhC4A9HDOJWsf4zkd3rQb0X/nW51bY41JFKuo2xibKTYsS6Q6C9PStqZ6k/bSrppALw3f0N7XSQQc1ikofqEA1uTn1xOxWA3bm6gJ/i+65BQxZ4xgx7pLV8IFgA5u+a9K2eWOlUemTxfa2XCFipMatpFZWU6BKdEYfrSI4AHxbYX5E7DGr9ldCFEC62C/QbdwFqItPyu/XIPooMplepmQsRZn3DjYSk2YgN299qqobfe5fH+l1KDX6SOATR0zTFAxRW1MCV0AaDEPYLDNM4ZCWB9jMUB1KbKhiIgDjr7vx3yOkLLqhx5lFZRWLLZdx6xbO2+UQe+bOeQnFijEN2+XI+Y3afRpgre6yqx+vtkAv9xulmkAtr7RNxjD+U4Mj6X65uqZuPH5BnySCoOh6eKS+5n1gmzot837jN2zIOxI31KQXWsDMFc0xTG/2XSuyCRw/xHN2Nrlbf9mYHpVT9lzn3O2y2f1m3Pfe1fCI2GCxyDcr/7NYHC6wxiFHznPKxtMoPA53jTHIhzhWFkvWPWJ0HTYffpw5eDmWAX/pjp2WW1PdnhC67X6Hou0Ek0oNcLj5AWA81b+5N9qMACsNrb2/1hnNnjmQpChU2nLoP0eN8Ns9w8hzPFwTDKlc843VMqEuA4em4iOp20zvD+OJcSMhd9nDHArRYcCd7xT6TusQOnrjTMbzS5mqkinqzzJYia2jz2g3mErzYlSbH34brICAL6rsd+3WDVpAFz9lq1ylJG0muLsaBBBTSPdrZYt9P+jKle6rCQ128mcT2FHjevL0Hxzv4dSaEkrZvRWwF6LA0cYS6GbGuCFy+aUwXWGtgVjx6EG9dLy0brv6dPtM+imfjhRW/dN3/2bN4kkvhJNta8s657vtVK2UtworytvyP1JCgBo06JEF1LBHO8wSSP9Wge0gd+I+PeiDCF72XHAth07ao4jLAkbX4JhEBQjR3uE5MGgX6IXPVYXIeXf9A5+3QkANXeCT3HVuwmLkGclCkwIg+gGhJQ/xzshAW00RxhY2eQgdldj8SIuTBeNHUgptj58NzkBAEkxZ5jKTeDmCmkL0+H05na1ja9V/TmmQHDBzhT3qakJW1Y03scO1IOCaK7wozGYYmGxie9Cnj0mJuOJfcOAHILFpneI22At8FrByMTC8dSm8qd+NiSkrYZvsdjKQZo4HIy/fdSEUmZuSN02FulPSgBAka6Es/Evi8g9NwQJ6WMS7XMGBlbVDxQRtrQwC+mzesA3OqslpPS9a1vnHbUFUXw/lstUjozWuRNWVMf0U7YWtSZtnM+O2b6mgHQkhuIp+g6aQZCdO1wyl0zU86PKeg7FCDfGuDOmjw45BtRsr3OkkIMOUmA55JgCp1TMEcwV/3975xqyTVHG8fnUgU6SVkRFVmhWRlEfwuSVirAsO0iRSWoqiJ1LU9BKKzqYvYlpBYYVpRhEB99As6JIrMhC7KSVphVEimWURXnADz2/fAbmWfa+7539z8zO7F7Xl91779ndmev6z8y1M9chlv8lyzejAJw9MSMJGfyFSpeNfcdh2ZcQpASXQUHYb/vLfl0UKX/vVEdcCVFIsMIvAXws/VugFGlLidkwV0rx9X9JI8zZeyu7JC6KufsHfZC+ODaqJNt8Y+uopjUeKkpFmTp06Es65dhqZO6oMex8EwrAlBmcYrLRdeRuPyM4UMKVsJUBH7bx9X6rMKAyELMqNEdbAJbs1W0kVlhKbHtFdIG1RZlEcqTuZRWESfHVCZJKYas0VgEopaxeI9TxkLUS2vwnbuAnF85bskke1SsAKaKkbWJC93862tcTJHvZDAkr0ceBHCFTsfhndaQlYgmxi83Y33NMFHRkAr6wwtIaKT7sXdxgBPuJ7VXCVHxQ4uyTpa8EKV42qRIWsa1CBFjmmBxKXVfW635XrQDgG1qSQVhPMzCwB2s0PQe8K6GitXvwt2gUx6rI9eJkh1sqFuVzIQZP1fL/r43aR+Cq+E8RD6SPPi7TyhDZD31/iz1eUAigyqoaW6upibmGOYe5J5ZnKcpXqwCwPIeWmqKRQ59xVYJlsNQAsefdb6WtJHJiEiQ9aouEa+lQ/K4qV8rAqgR/2Ydd1c6h11mGbZXYox/azr5yZEPNRTy7751Drn0xV6U6z1WMa7HFyEUE78LL4PuFY79UqQCwx6dElRoCuFVlSi1F5QLSHJ9LNsdV8hpynaXJVokv3uvE9hPRcS6kGHGBFZRBn0SlRZ5goKesihI1NRcdJeD0slyVCp7LStiQ8WJVGbyvStABzjlyFqRy917VHq5XqQBgqb2u0jn/w81wypjgJQDW2jsUPGDk5EOVttZuX9/DE/SHUrHWfZ1zHImXjzyV/p/zCzhHm/ueuUfgAZb+uUiJykjkw9zEFspY7BAIqTThSkj0wWuFem9qb3UKAEIqvfTfZRLW02NdYUqDZAnvw4WmK6Ohv380Ewap/sSXz4APLBMPlXtfOSa/OdhDEDWvr31Dr61LSqbAhIx+Q+vQLYdtQm7CuLj73qG/sR2YkohXQZwFYjQMrfOQcv92zlXlJn5+4gYOYUJfGTRSjLCMpufAjwVMtLz8H3JetQVgZavllZB9EuT9eEfI0IbP4YWyEhKb4Gsoq5StOjIJ5iYCgPWN9UOu4T1QA2GIyAdRyoB4Z9XQMOpAEoyagiV8oBbGLLwe7NsO6aR9ZV42E95hF3ODwAd4Q+a2Vgkvjj75Dr1GZETCac+FlLS0x2digrLEfndk1MExTThCwFCJLYqYNh20lZDpFqE9Yb/BsyTXqlBMm9y5iRr0x0TPQcuaw95plBAqK4zhzX2CPB9ZWXuU6jBwhx039pxJsEVvCJSfm8W2n6EwvsJ7SV8cK39fHk+CHITB6j1CvYgKmpNYAfI8iD2SRKg22iuhsfzkcTHQzlNYPWJNipXvlYKwQ3Dc1mAAmdqAqtRnf0GOUxjuKG3ddC/716q/8KqMZpvePeX/LxUwQF9mn5PBck6kREf9dEZGYFQWjp8x57nzMuwW6kbQpBqJuY608TF87it7x9T2MW9M0Iirg0awHKUsHYdMwiWRrxCjshwgjC25x0NZxJxXZ+GagH2qHzh9pDVS0syCl5wT3lS8JMJjTF8Iy+b0uVeCdg3JtqfwW8lWeIry4sz3EkMAY+dQxmPO8TaajNQvdr7UmfRDInazsnwcMvHM8MF2np0DKFxK6k5kNyf/d89wME5GwxCbMeetuUVi8KYsK9NeUrTOjZRkSGT6y0WKspZ7kiVrakxfCcuWSlc8Vi7YzzEHhnWOPb907MvV+1ieU90bXrmiEuoXk2ciigTpMY3KcOAcEczI7Ydlqlr8LYpbJHxpybhV2belrd8qLp0yLyR5jx+bYo85g+6w2hJbH1/+vMysU1aEc3lOpGyyYuSIDNgyncRQVgEzFSc62CriS/K7Aig9ODmy//roVS+y68k4QGrQkO9jz+eqADxH5A8uVxhstUBqFMS5eIF0ZaWMmTkVgPcK2CQ5Ti5imVxZDSa1egv0A4H/jLOTbAOQCGLsIM99z9sgGbLAKUkgwrqhbJg9wAaGC3+nTAA1VwUA9hI4JcRl7Lma2lQQ8eBbifwX266wPDYgc43lUasCwFJ5KIOYcyLe5aInCfUi9HIrAaRwD4zhebfsJN4AiqEXEdKGEEs4igYYMuo9Q15oZaI58PREniBeVnNWAN4sdnRSy9ZOHxPbWE2AkwyMrlUBIGWu73+xR7w1cq1MsRIUWx9f/sYM8sv5yF8Ibb0iZ8X6ns3XNIL3zI49xkT3er/wnrBeaIS7+hpj10ZzgNDLigtRKB9/PmcFgPCdSmaz2xv4OlYCnaDsk1F0rlSrAkD8eiVKHV/qOUhJVfzNHBXK+EyMKf0YGHtkXChKdNLYSoblYyx8UTZItxjeP/Ycg5Ku10FRxs3oZRie5Eh4MWcFAPETG3wsfrmv5iBXSthW2jaH3AfrunitCgB1VgKxvWJdo4X/LhH6CgbJLZG6dYZHQTFS9iwIXhBLRJsi2Y8ycPp7sTA2e4BYCewszx4tGrbnacrj3BUAslYq/Lpwpyiq+kXYYqVttbttqcyuWQFQXLpzba/+UsDTCaqwCt/PmHqn0N5NNnVJm6Nkthob1OTF4jJVODCxtGQ0ngPkvQ75mfJ87goAHV3x/a15GwBPhbFY+NdW3gOWoudMNSsAuPONlV0ODwVWGNm2HVun5zcIJCXmwatKtvcYQTBEdhpLSijNEEgAizSYRvEcSOXuF8ojPJ+7AgDHVQWqxsFNXcLMGekuHuV57qhZAXiTMKbn2IN+oVAfxpMW84koq6pvyAPZ/qeeKAjnov5HDrrK15PqM+knG/KM7z3orVbIc4C9vlReGV4O3eMSFADip3fbHfP7o14gFR1ZBo5pQ7fsoRW1JVdValYAVEymNgQ8XcAT9gwtkhIsjDm5GCnuTKorE8YOaJzdAWTMb4yOcrmwFBNGoRcRyEbx/BgqnyUoAGBO8Z74VSGZx7xGWb78u3OOoC9zp5oVAPiveKik/gJVkuVMFh5XBDBz49BxsluOObkYTakA0EgsoVN9iZ5ajGvtvgil688COLtgXfd7CQoASDhf5Oe+FcGJSJuKGxlpcpdANSsA8P8qAZN8vaYi0omT737dOLHuv7ekqkjh55gCEMHwjwgACcFDPgO8Goz6OfBw55xijRvyesj5UhQAdY/zpH5xTXJVsQkCE0UNmCbh0P0vrV0BOFsYU3GxTrWaSsTLIWPFqjIENmqRTAGIkBpaIh4Fq0AQc/1PjRqNRLBrVFF4rLgHxcjAl12KAgBv/ybgl6yLtRAGfF5+sUeSmZBCeglUuwKAjU+s/MLyByYS4oeFeuBNgq1Yi2QKQKTUHicOoiF4scBMpcFGNqPa4vichzwqcb4UBQChK4FOUB5qiWehbA/tqRb96StWuwJAGmdSMY/t56clYpmSM+N7ieowxWNMARjB9cPE/ccQ7CePeP9cb6Ezh7wpdb4kBUDJD488aljqPEDECe5nS6HaFQDk8DtBnj9LIMgnC++nT7SUNrvLLlMAuhwZ+FtNQOInt3u2cpHjDrN0ek1CpcrzduhxSQoAYakV47lUX1wK3t8qDtip3ceUtuS+twUFQJmEWD1gAlfoDBFPJJBrlRTeL8oLoCtg9lOZOIZOMuvK4Z7VYhCJLk/G/iaeO/uy63iU878lKQDIiMyYY/lZQ8KTrwj1/+1YkDZ6XwsKgGoHwASukJIVD8+Blt1JTQEQkPME5xx5BsYOpuF931ioPQBfY6lyLoT8jDlfmgJAUJ8Y/oRlsQOY2m5F2f+/QOjvLd7aggJAOOa7BEzeIAgGI8IQ37HnKKMtkykAovQOF41YQsDFpCwWq13F7Xs5534jdsCQf2PPl6YAvETk+f4ToueJYt3JKbIkakEBQB4kTBvbf7lv7DL8Z8T34o7aMpkCkEB6u0UQeeBjD8By+BLoAQlTLsM/JYnH0hSAh4n8Om5CgB4l9DX2i5eWmrsVBQBM+XFwzHFMvhf6AS58Y97HPXc75x4xYV9I8WpTABJwkT2gnwhACgF4ywxANYSlRGIL262c/3erI58iPG9pCgDyUewAPjtEwJnKfEqQ868z1anmx7aiALAayIQ6dhzg44kU7jFE9L6x7+O+GuxhYtrbV9YUgD6ujLjG0iTxxRVA+XtrCrgyghUbb3lfIj7BLyzaWdYl06LnX+xxiQrAuQK/rt0o4XwFlPj/LPcujVpRAJCLEoufPn9OhHAx4r5Z6AO8L3UugojqJytqCkAyVjr38oT2ALg6zZFel5BHdMJ3bzPJFIA4tCCHWEXJl+driy2c0kS0NSV5TOv7tWP43ZIC8FoBk2ATTyJyRAwhdcsB6/+HDHlR5WVMAUgsoPNEEPtBluUwsuHNiZiklWU+zxt/DNM8mwIQhxS8LzwfxxyfFfe6JKWfIdb5qUlq0dZDWlIAUCrVrKvkFthEKJI3ilhi4pwDmQKQWIqA+KciuPyA/HvnHIlx5kD7JXSZhD9YDbOM58kUAM+J4UclL8AUhoAsufq+EXvki62WMMbDJaSXbEkBoLWqQTXpwzfZAhwv4Mjj7rm6aKp4gikAGcTA19U/EoAMsI2xbs3QJOmRezvnbkrED3hC4A4seEMyBSDkxrBzxfXqk8NekbSUMjm0HK9dYWJrCgAfCkqkSsaHL61hGFb7atyRFOGH11Sx6F+mAGRiN4ZpSpILr2lybDl2+QMTRkyEF39xzj2+R2amAPQwZcMlJQPadzY8O8fflwtK5MdzVKiBZ7amAMDSywQ5M0Yw7h68QjYptmhfv+LZLV42BSCj1Ig6Fk7kY8+JkvXsjPXM9Wgixn05EQ/gHct7q5LRmAIQL0XFp57w1aUJF9mxfejY0pWt5H0tKgC7BDl7fPy8s0WIOJ4pxr/g2aRxD7ceKxHz6GqYAjCadZtv5OtX8bf2YOaI0Up32XtzDaYt8aEEHdnz4D7nHFEXV5EpAKs4s/o6A6Lnb+yRr6yHrn508n8eLC4Nr1Ick1e0sge2qADAwhRxVc4KZIFtlpLy1/ePdwXPnMOpKQCZpfgU5xwGSB5AyrGluNOqm02XT2/fICdTADYwqOdvAljh0tfl9dDfJb1UWAEbWq9uOZRHFIglUqsKgBquGgwQHfSgbaHjHdDFRezvW51z5C2YE5kCUECaqn9rCNQTC9RXfcWLnHP3Juhwvt3s220iUwA2caj//+sFOZXcC1XiFpBvfqnUqgKAvK4WsOnHDoL9EJ9FNSzkeW+bIYhMASgkVDXphAc0YW9Zuq2VnpbQA4I27xnovmUKwDhEwF+Prdjj6eNeOequ04R6Yjy4VGpZASDBTywm+8qnmPzZ+2dLd27UjAJwkgCGz1cgtQc5564T2hACm5zmJfdfh7LvMc65PyRqI+3FfmJotC1TAIZKaWc5JSTwhTsflfWXokCfn7VmdT+8ZQUAzpImPRz7pjovudpVElHMjWN5ypxcjI4WKsoSYA2Wm/i43im0IxTUxcU4P+xF7LFek6httBON+7HDXv3/UqYARDArKKokRLkyeE7u0ysEbC0tzXYoi9YVAGKqsOoZjn2lz9mKwKNpbsScyNw4lp9FcyEcJlSUBl7qnNu3AgkeKbYjFNYJFbSHKhBh7WsJ24XR5IGRbTMFIJJh28UVYytWokqRYqvAHvBSqXUFALl9MOHYEo6fQ84xIG3RBXsT3lGsVBdtxo5ihDX9EIFZGeOTYcAwYBgwDBgG8mKg6Ac1X5lK7HIDQ14wGH+Nv4YBw4BhYBkYuGOgcXbSFYKv2iqArYIYBgwDhgHDgGFgUgxMkqMmpT+9aarL0FRNziZnw4BhwDCQFgNHJP20H/gw/DBvM81vUs3POlLajmT8NH4aBgwDLWGAhGyEVp6ETjUFwBQAw4BhwDBgGDAMTIKBSfMhsAqg+C62pGlZXe3LwDBgGDAMGAZqwcBNNUREfIFzDv/MWphi9TBZGAYMA4YBw8CcMcCce8gk6/49Lz3TFABTgAwDhgHDgGHAMFAEAyVzf/RM+TsvEZrxIhN8EcHPWau1ttlXm2HAMGAYWI+Bknk/ds70a36hBOw2JcCUAMOAYcAwYBgwDGTBAMm0CMRXLR3rnPuPCT+L8E0zXq8ZG3+MP4YBw8AcMXDXVmr3d1Y763cqRqa9b5sSYEqAYcAwYBgwDBgGJAyQfZP8O83Rrq3sTXucc/caACQAzFGjtTbZl5phwDBgGOjHAHPmZc65g5ub9Xsq/Cjn3DHOuc9t56m/3TnHkoYJ33hgGDAMGAYMA0vGAHMhc+I128b0Rzvn9umZR5Nf+h/dYNYfg3c/oQAAAABJRU5ErkJggg==">
							</image>
						</defs>
					</svg> </span>
				<div class="advantage-content">
					<h3>Tăng cường nhận diện thương hiệu</h3>
					<p>Các video ngắn gọn, sáng tạo giúp các thương hiệu dễ dàng tạo dấu ấn và thu hút sự chú ý của
						người dùng.</p>
				</div>
			</div>

			<div class="advantage-item">
				<span class="elementor-icon">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="60"
						 height="72" viewBox="0 0 72 72" fill="none">
						<mask id="mask0_3507_35021" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0"
							  width="72" height="72">
							<rect width="72" height="72" fill="url(#pattern0_3507_35021)"></rect>
						</mask>
						<g mask="url(#mask0_3507_35021)">
							<rect x="-48" y="-61" width="164" height="173" fill="url(#paint0_linear_3507_35021)"></rect>
						</g>
						<defs>
							<pattern id="pattern0_3507_35021" patternContentUnits="objectBoundingBox" width="1"
									 height="1">
								<use xlink:href="#image0_3507_35021" transform="scale(0.00195312)"></use>
							</pattern>
							<linearGradient id="paint0_linear_3507_35021" x1="-48" y1="-20.6333" x2="116.112"
											y2="-20.4204" gradientUnits="userSpaceOnUse">
								<stop stop-color="#020C6A"></stop>
								<stop offset="0.3" stop-color="#1A85F8"></stop>
								<stop offset="1" stop-color="#66E5FB"></stop>
							</linearGradient>
							<image id="image0_3507_35021" width="512" height="512"
								   xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAAAXNSR0IArs4c6QAAIABJREFUeAHsvQX8P0W1/3/uVa+iYIvdgY167cTuDkxEsbsTUUSuid2N3YqKidgBitioCIpid2H+7v+/z8sun/2+v/t+7+ycM7Ozu+c8Hp/Hvj8bE685M3Nm5oSIkyMwTwQuICJ3FpH9ROTtInKkiBwjIr8Vkb+LyP9X4N8vReRTVRkfLCI7ZG6W64nIm0XkOBH5R4HY5GivE0Tk1zWfHCYibxKRJ4rI7UTk7Jnbw7NzBBwBR8ARCETglCJyGxF5nYj8aAYT2E9E5GqBdde8dnoR+cAM8MohIHxbRF4sIghL/6kB3b91BBwBR8AR0CNwGRF5Sb2yzzEJ5MyDlfi19RCtTWEnEfm6T/5Ru0EIaE8XEXaanBwBR8ARcAQyIsDq+GAR+d+ZT2BsSZ8xEa5vnDl2OYS1f1VCwBuqY6aLJWojT9YRcAQcAUegRuBCIvLhhU1crDSt6VIi8v8WhmNKgQAsOX46i3VDeXqOgCPgCCwdgVOJyL4i8rcFTlo/TND4T1sgjikFgCbt34nI/Spe/Y8EbeZJOgKOgCOwOAQuXGvxN4PsEq/WK8uPuAAQdfYfynuHiMjZFtdTvcKOgCPgCBgicEcR+ZNPVnJRQ0xJ6nDHNKkAgKBwvIhcw7jdPDlHwBFwBBaBwEMXoOQXuqI8k3GLL02PIhRn6/ew5ECIdXIEHAFHwBEIQIDz02f7CvWkFWoKHQAcJFlPdp5eN6ZYqjwygO/9FUfAEXAEFo8AzlZ8MtnCYP8EHHFJtwLIzmMPSdCOnqQj4Ag4ArNBYB+f/LeZmH4lImdI1LoHOtbbYJ1a6MRU8E6J2tKTdQQcAUdg0gjs5RPSNhMSMQt2S9iieAL8mmO+DeaphYDU3h0Tsosn7Qg4Ao5AGgRw6btEG/91Ew5Bea6aBuptUj2diLzPhYCsQsDP3URwGx70fxwBR2DBCLAS/Z5PQvILETm0ikj3QBHB8VFOuk7t0pZASkuNBrhOGEtxHz8BHlAoJ4d7Xo6AI1AkAi9POPl/U0SeLyK7i8hla7/6RA50cgRWESAEMw6XrigidxeRV4rIsQl58+GrBfD/HQFHwBFYEgJXSqCN/mcRea6IXGJJQHpdkyHAUQx+/v9pLAzg4OqcyUrtCTsCjoAjUDACJxORIwwHVSKzHZAwel7BUHrRMiBwHhF5kyG/crTwtgzl9iwcAUfAESgOgTsbDqbfEZFdi6uhF2iOCFxfRFDks9IN+O85guR1cgQcAUdgHQJ4++N83mIQfWflOfA06zLy+45AAgTOKiJfMOLf9yQonyfpCDgCjkCxCNzKaPB8hWtTF9vGcy/YqUXEIqYCDoJcX2Xu3OL1cwQcgZMQwAxKu/p/i0/+J+HpP8ZBAMuBzxjwMu6vnRwBR8ARmD0CaD7/WzlofllE3Jxv9qwyiQqeUURw3KQRaH/r/DyJtvZCOgKOgBKBxysHS8z8LqAsg3/uCFgicC2D0NW3tiyQp+UIOAKOQIkIsHrXrJYeXWKlvEyLR+A1Sr7GxNDJEXAEHIHZIkBkO832P65qTzFbdLxiU0bgbCJygkII+NmUK+9ldwQcAUegD4FbKgZIdg0e1JeBP3cERkTghUr+vtiIZfesHQFHwBFIisBzFAMkq6vTJi2dJ+4I6BC4pIK/EXDvo8vev3YEHAFHoFwEDlYMkG8vt1peMkfgJAS+ruBxAlc5OQKOgCMwSwSOUQyOe80SEa/U3BB4loLHPzQ3MLw+joAj4AiAAHb7GgXAiziMjsAEELiZQgBAQHZyBBwBR2B2CJxDMTD+Q0ROPjtEvEJzROCCCj7Hx4WTI+AIOAKzQ4AVfKz9/9GzQ8MrNFcECHONf/8YXv9fd289V7bwejkCy0aAsKcxgyLffGXZ0HntJ4bAnxS8vtPE6urFdQQcAUegF4GrKwbFz/am7i84AuUg8HMFr+NQyMkRcAQcgVkhcA3FoEjENSdHYCoI4NUvdrfr7FOppJfTEXAEHIFQBFwACEPqP0Xk/CJyYxHB9PHh1WTyZBF5RvX5U0TksbXDmBuJyMVF5L/CkjV/i3zxXEc5cGBDuSgf5dy//p+y30VELi8iS9radgHAnN08QUfAEZgyAi4AdLfeqUXkBiKC/fjhIvLXgatHLCQIsPRSEbltQm+JpxeR3UXk5bVOxj8HlpMV8Y+rSI5vEJG7iwhhoedKLgDMtWW9Xo6AIxCFgAsAW7ChKX6TagWNd8O/RUykm7aXmZg/LiJ3E5EdtrKM+rWjiOwpIoeKyL+My0kd0O24h4iQz5zIBYA5tabXxRFwBNQIuABw4jY4W+U/TTCZdgkFfxCR50Wsts9X7yhotNm7yrPuHvk8V0TOquayMhJwAaCMdvBSOAKOQCEILFkAOI2I7CMiv8008a9OtH+vJteXVZP6zj28cJ5K/+DARKv91TJ1/c/xx7NF5Iw95Sz9sQsApbeQl88RcASyIrBUAeAW1Tb6j0aa+FcnWXYEHtbhVZGjAgSUofoHq+lb/f9LEblzVu60zcwFAFs8PTVHwBGYOAJLEwDOLCLvLWTiX52YDxORJrYCDpqOKrScBMfBhfTUyAWAqbWYl9cRcASSIrAkAeBqtcb76sRb0v9/EZHXiEiMNn/OeuBU55pJOdM+cRcA7DH1FB0BR2DCCCxFAHjQiGfoOSfmnHlhgfDQCfG+CwATaiwvqiPgCKRHYAkCABr+OSfGpeWFk6H/SM+q6hxcAFBD6Ak4Ao7AnBCYswDApISDnKVNyGPUF2sGvCWWTC4AlNw6XjZHwBHIjsCcBYDn+OSfVfhB2CqZXAAouXW8bI6AI5AdgbkKAI/3yT/r5N/sOjwmOweHZ+gCQDhW/qYj4AgsAIE5CgC3quzn/9cFgFEEAHC/Q6H9xgWAQhvGi+UIOALjIDA3AeC8I3r2a1bBS7/+ueXPYByu7s7VBYBuXPyuI+AILBSBOQkAp6gj4qWcgPGG97HKLe4LK6W3p7bC7T6/Cq/7wSqIznGF7DwQ4Q+HPe1yPrH27f++KqTxTxKXk0iIY4VEXteVXQBYh4zfdwQcgUUiMCcB4HGJJrVjRGRvEbl0oLkbvvsfKCKfS1SedQLOZ0TkASLCLkgIXVBEOLP/dqJyIiCVRC4AlNQaXhZHwBEYHYG5CADnT+Az/0gRQZ9AY+OOS993J5pgEQT+n4i8scrjUgpOon43FpEvGZeTYEcXUpTL+lMXAKwR9fQcAUdg0gjMRQA4yHDyIjgPK2lLu/bdqkA63zcsI5P/EdWxw+UNuQ9BYA8R+Y1hOQ82LJ82KRcAtAj6946AIzArBOYgAFzBcML6iohcIFEL71iH9V23hR96H037Z4oIOg8piEA/hxpiet0UhYxI0wWACND8E0fAEZgvAnMQAN5vNFmxi0AI3tSEjwK27kMn/PZ7bKuzSk9NCBevjCxju7z8/kTqwgam7wJAIFD+miPgCCwDgakLACjmWdj8v0NETp6xyTlzH7rVjjIiOgU5CeuG1Qk95v8r5yz0mrxcAFgDjN92BByBZSIwdQEAM7eYCan9DSvUU47Q/GcTESbYE3rq8NvaCmGnEcqIXsCBPeVrY7nu91tHKPtqli4ArCLi/zsCjsCiEZiyAHAqA6c/2MOfeWQOOL2I3E5EXiQi2OgfIiLvFJFnV5r5N8p0LLEJAnA+XCkE/LXyQXDaTZlkeOYCQAaQPQtHwBGYDgJTFgBur5yUODq49nSaatSS7hKwU7Fu9d/c33PUGoi4ADByA3j2joAjUBYCUxYAXq8UAPjeKRwBnCE1k3nMFU+JY5ILAGOi73k7Ao5AcQhMVQDgbPqnignpnwM85hXXaCMV6DQi8nMF5n8UkZONVHaydQFgRPA9a0fAESgPgakKAHi+i1mFNt9g4uY0HAHiCTQYxlwtHRcNLb0LAEMR8/cdAUdg1ghMVQC4p3Iiym1ONxcmOruI/EuB/UNHBMIFgBHB96wdAUegPASmKgA8VzEJEfzGKR6Bzyqwf0l8tuovXQBQQ+gJOAKOwJwQmKoA8FHFJHTAnBpwhLrso8D+wyOUt8nSBYAGCb86Ao6AI1C5aZ2qAHCsYhK6pbe8CoFbKLD/nipn3ccuAOjw868dAUdgZghMVQAgYl+MEhrfpAr2MzPWWFudiyqwZxIei1wAGAt5z9cRcASKRGCKAgA++2P9/xOEZ0xTtCKZYGChdlYIAMQ/GItcABgLec/XEXAEikRgigIArntjV/+/K7IVplUoYhLE4v+nEavqAsCI4HvWjoAjUB4CUxQAzqKYgMZcgZbX+nElOqcC/zEFMBcA4trbv3IEHIGZIjBFAeAMigkID4BOOgRw5hO7A/BDXdaqr10AUMHnHzsCjsDcEJiiAIBL2tgJiO9OPbdGzFyfmynw/3rmsrazcwGgjYb/dgQcgcUjMEUBgEb7i2ISutDiW10HwBMU2B+sy1r1tQsAKvj8Y0fAEZgbAlMVAI5WTEJ3nFsjZq7PRxTYvyhzWdvZuQDQRsN/OwKOwOIRmKoA8EnFJIQbYac4BDChJKpf7BGMxwKIw92/cgQcAUfAHIGpCgCsJGMnocPMUVxOgtdV4E57XX1EqHwHYETwPWtHwBEoD4GpCgD3VU5ErgcQx4tvVuD+bxFBgXMscgFgLOQ9X0fAESgSgakKAITzjd0B4DsU2ZyGIXA6ETlBgfvhw7Izf9sFAHNIPUFHwBGYMgJTFQA4i/69YjIiJPB/TLnhRij7IxR4I3Q9dYQyt7N0AaCNhv92BByBxSMwVQGAhjtIOSER1c4pDAF8J/xCifdVw7JK9pYLAMmg9YQdAUdgighMWQC4t3JCcmXAcI59lBLr46sdgP8Mzy7Jmy4AJIHVE3UEHIGpIjBlAYCYACiWaXQBbjTVhstY7jOJyK+UOD8zY3nXZeUCwDpk/L4j4AgsEoEpCwA02MeVE9N3ROS/Ftny4ZV+jRJjQjdfIjy7ZG+6AJAMWk/YEXAEpojA1AWA3ZWTE7sHj5tiw2Uq8zVFhAlcs8vyiUxl7cvGBYA+hPy5IzAAAc70zi8ibKNil/1YEXmaiDzD/yaDwZsUg/tnBvBKqldZvf9SUQcmtr+KyPlSFXDC6e4oIt9XYgu+ty4EA40A8GIf0yYzpmFt8hgRuaeIXFtEzlEI/82iGBcUkUeKyAdF5E8Gg4NmZeHf6lZmWvxKEADoVPsa8OFnK+H15LPooXaVeIMBrhyxjK381yCiEQC0fcW/H3eswoLlrSKC4vCZG4bwaxgCrLL2FBEGSe12oHeEcTuCJf6lCABnrITSPxtMVmPbqYf1xjxv0d8teKWkwEsuANi0qQVfjJnGP0TkffXOdZ7eNNFcTiEiD6q2Un5sNBiM2eiet33nL0UAoHsdYMCjWBSwZbh02lUZbrnpa98oaPVPm7oAYD8GNG091esRInLLpXf4rvqjHPZNg0F1qozh5e4fLEoSAM4gIr814NffiMiS4wScXUSOM8CR/nODroFlxHsuAPT36aWOeyiqXnRE3iwma7b7CZfqW/3eWfoGg5IEADoQ2vx9ZQ55zrn16YvpkfkKgre/LxthiI5QaeQCgE3/COlDU3yHOBf3Ko1pc5bnnCKCd7QpNp6XOX+7lSYAnEpEvmvEv/gX4AhsKURdta6Vmz6IcvB5CwTOBYD8Y0TDE1O6YhnFWLIoQrv/B0aD55Qa28saPyiUJgDQYa9s4B2w4Yl3L8QyAC19TZjfBq/mep9CR04XAOL7etO2S7l+SkSIfrkIuriBq8+lMIbXc2sQKVEAoMO+0FCQxRSuFDO2FIMRERFfbogXZ6mlRll0AWCr7/o41o/FV5cgBJzLUOnHmaqfqeaEUakCAA5sfmg4qb1ypkIAgs3LDHH6Y6Fb/43g5ALAssYni7H2CyKCbsws6TQi8i3DAcACcE9jOp20VAGAznp9Y0XWN87sOACnR9TJsr/do/BR0gUA2/a25J2S0+J4bJb0euMBoORG9LLZd/6SBQA67P7G/P0BEdlhBiMBlj7oN1j2CXYSSicXAGzb3JJ/Sk+rVL2W6D53e+MBoPQG9PLZd/7SBYCTVUqBHzHm80+KCD4Hpkp4TUTBybI/sE2KUFE6uQBg2+6WPFR6WpgIXrh0Bg8t306VvePxxoNA6Q3o5bPv/KULAPQHJmtr65ajK7/iu4R2toLeI3DXUcb9/ucigvnwFMgFAPsxYEnj6semwOQhZXyW8SCwJCbwum4NIlMQAOgPl6kj/lm23a9FBG+ZU6GrJLD0waf6VacCgLsCNt31sexLU0qrlMiW0d2OSEh/MRYA/lVvK7620pYmoAphgf1vGhhotMCnIgDQWTjy+n/GfP/3Ogx2dGfM9OFelZdEymo50ILl7pnKb5WNZgeAMOc+pk0DA8LRY757pDHP039Is1Qz16B+sp8hKMfUMZc5V3SaJgKsYmMnhikJALTOfRV13YQR2vQlmgqh6c9guKnssc8eOkF21wgAxEhwmh4C5xORJ4rI7w37wU2nB8OJJWZA4MwuttM33/2z2lJ99EQUf6baVrnKvSQBAEz3NuD/ph+0r18rLIjQuatgPCjntcto9RsMp0guAEyx1WzKfCYReY1Rf8AaaJKE5KIdBIi45iFTJ9n8nYVemgAACM8x6Add/Qgf+CWYC92iCuNNVMOuMmrvvbiTi6Zx0wWAabRTylI+sNoR4Mha0w9YAO+cspCp0j5QWXHOEVEmcpoPAksUADjDs1oNdA0kOA4Zw4/4Kasohs83doDUrt9LJn7+6QLAfMYtTU0eoJwH6RP30xRgrG+1pn/3HKvgnm8yBJYoAAAmQsCLDAaC9gTZ/o0r4usla7XtE76siHAM0S6D5W92TSat/KS0AnAdgO15bsp3XqXsK++cWuUvoqww54lTHwCm1mY5yrtUAaDB9inKftE3yb5DRLC8SUWE8UU7HZO8vrLEPkeRcA7kOwBzaEWbOqC4/jtFn8EMeFLz4R0UlWXguJYN7p5KYQgsXQCgOZhAYyfHkO9+KSJ7JGj3XUWEiGUhZYh9Z58E5R4rSRcAxkK+zHwfp+w75y2zWt2loiPHDgI/mpq00w2B3+1AwAWAE0G5v4FyUF//QnsY7XwtcdZPnAOtMtOm8qLoNLcjPxcAtJw3r+/xYPm/inmRgGOTIY0CIPHVneaJgAsAW+16IxEhpO2miVH7DEuBBynCC18pQwRPbKavuwXLbH65ADCbpjSryJcV/R1lwsnQ+xUVxZOY0zwRcAFg23a9hIigwKed6Pu+/7aI3GzbrDf+hx7BCyo/Bv9OXLZjReTiG0sy3YcuAEy37VKV/NWK/vSEVIVKkS5RzPoGpXXPb5yiQJ5mEQi4ALB9M2Djm8qJzmof+3AVmvdS2xfhpDtE2XtMhp0JykWdz3pSzvP74QLA/NpUW6N9FfPi07WZ5/z+S4qKXjlnQT2vrAi4ANANN+fsrLhXJ+wU/+NXH2uBVaUizAjZKUiR52qar1iAZ08XALp5fcl3cWm92hdC/5/U0bhGAODc0WmeCLgAsLld75ogeNa6AYYgXQTTuryIfEQxMK1Lv+v+30Rkz80QzOapCwCzaUqzijxE0c9cADBrBk9oLARcAOhH/pIi8l3FQNE18ZZwD12Hy/VXfzZvuAAwm6Y0q4gLAAEDm+8AmPFbcQm5ABDWJDvVIUZLmLgtyoAnszOEVX02b7kAMJumNKuICwAuAJgx0xQTcgFgWKvdTkQIiGUxCY+RxglVaNQphvId1krdb7sA0I3Lku+6ABAwmPkOwHy7iAsAw9v2bCKC9v4YE7gmz2/1WBwMR2JaX7gAMK32ylFaFwACBjIXAHKw4jh5uAAQh/t/VqZ5DxeRvwb0H82kbfEtvgP+R0SwbFgyuQCw5NbvrrsLAAEDmAsA3cwzh7suAOha8fwi8vGAPmQxkcek8QMRoY2dRFwAcC5YRcAFgIDBa0oCwKlE5Doigpcm4rJj/niMiBC96Vci8n0ROazewn2miNxaRM6xyhWB/xMN6qKV57i7Vw5UXiYiH6u8u32lCvyCNzUiTf2mzvsIEXlL5cVtbxHZrTB7axcAAht7w2vwwb1F5A8BfSlmEo/5hlX/ASKyw4ZyL+3RHASAk4nIFaudp0eLyOtXxjfGHMY63NtiRoqZ2p1FBCE1lvBNcUcReX6dJmPn0bUeTJPfN0QEpdL9qrEVp3Gnic1shO9cAAgYtEoXANjaRDmLYCsoOcUMmEdVIVUfLyLnCmDC/65jySNUxOSFvTeOX/A9z1bymHS1yDpQ78+NWfAC80Y3AIc6OPaJ4QurbxA4mSSctkXgF4p2GdNDIgLm1UWEGPbEaYjhk59UR0B4rttlW0g6/+MdjoyOi8zr7/UC6/aFLXa6KusCQEAjlyoAYJpFSEfCrcZ0iq5vGLw/VDtjaTMMEzVOYb5pmBf5s1tA1LWTtzPL+Bs78C4cQu4dmbGcU8oKRz65XAm324nJAQ1/VolO2yOg0dfYcfvkkt9hzLltgpDPnxeRG3aUntU7z9o8pf3N2PxIETl1R34l3HIBIKDBSxMA6BhsubLFrmXQdd8TJvJNtXtWjhRYVa171+L+9+qji9ydAmk/tvyEiXbqRoBV2x4ioll1DmkXdpSIYeDUjQBHg7GhX1kU5N6pQ4jURKoL4R2OCYhDcdlqh+EQxTgQkhfHLxwllEYuAAQ0fEkCwAUSSKmbGDhlzPXVfBmg2ObLeYZ29oD2Xy1n8z8DIwOr03oETl9h9IzqeOkfCpwbvLuu6LQQM8BpMwJ4c+zCL+QeIZxzEcGfnpMh6mNTb3RF6MfN/6mvRKUtSVB1ASCg8UsRAFDYiz0DS83YlumjVHOhTCMOKxv8wceWH30Ip34ECDOsCcm92j7sfj1MRE7Rn7W/ISJ3UvA4x345CIW7wxXlXOWRUv9HH6EUHRUXAAIYrgQBgLPNnJLq2J0HDdtcuKMAGVvfR+QYGWeUB22q2W5lJ4EohewsOIUj8EoFj783PJvoN3etjjV/qihjbP8d6zsUBW8VjZbdhy4ABDBdroloXbM+OaCMYzFyynzZerzWOlAM7x+kwPcThuVYUlJodX9mAO4cD3HOzxGY0zAE2OX68QCsV/v0s4dlN/htVsMlmZCu1j/V/xyvsjMzJrkAENAxxhQAHhhQvlQMWkK6CAGXSdxD8E8QW1d2Zc6duHxzTR5FwZuIyNs3mK/+sbLjPjADD8wVY+qFEm8sf/Pd7gnBQTchpTKzpt45vkUH4RYJ8e1L2gWAgM4xlgAAYyxp239dhzte4ayorwPw/LoBPLCubNzHvthJhwBmZletJ5v7186lWBku3X2vDtUTv2YLfxP/9j2LdRTWV3aU4TgP78t/7s9Z5HAEMga5ABDAgGMIAOdZuGS82uk/ndC+m8mHM7nVPEP/Z5V6pjF6r+fpCPQgwMQSa/4H/+NKOQVxLPFRRZ8L7ZtTeQ/vgvh1yU0uAAQwYW4BgK1RJrypMG+ucuKpMBUdrMQbD3hOjkBJCDCOHKrka1zgpqDHKsuVa8zJmc+rUwDdk6YLAAGMmFsAwDNeTsabSl64Odb49d7UF3CspMGBoxrOWp0cgVIQuK+Sp+kPuMq2Jvow7sA1/W2O37JTc01rsHvScwEggBFzCgA4wbF07Tu3jvKeHoaOfcwWvsYfADj/vPKFj2MhJ0dgbARQnNXyM+fzKTwAaqxu5jaerdbnq4kwX8ePLgAUJgA8KqA8q0yztP/x35+C0DbXYokTozOkKJyn6QgEIkBAL43ZX9MHnhSY35DXcJyl0Uloyjbn622GAKp81wWAgEE/1w4AXs1YRVoxN/719623lfCydZYqbCUe2fBJjZ//2MiBXeVDU5/zQiL8ESL4jFUI4IuIyC1F5OUigqJc13cx996mZPp1n9POMeVZ/eaLrhS4DmK/nxiBC9aKe6s8OfR/xgbGC2t6n1Efoz7sUBDyGVfQeA5lF+9i9ZiDTg7OxIbWe937v60skXCmhDfWi9fYcJRBUCHKYDluEwMhF7kAEMAkuQQAPEOtY8Ah9wk8sWfAVhLmPRoPYZQJBx4PCjDXOl0tjPzToI440EjlT/vjBuUDl+/Ug1Gujuz5OAI4zbIKvvSyBHCyM4Hd+5CxrOtdFhPslBI3YBPhLXJ/EdHEM8HzJI7YTrspozomCOMgJn1dZR567wo9+Vk9dgEgoMFyCQAW0jG+tIeeQ7Mj8OcAHFaZ+OsicuGBnMj2fWyc7Xb+Dx6Yb+jrV4nAoV2u9m8UnVDESnGOGloff2/+COArgZ0+zUTX5lvCBp8zAWwah1tN+Y6JEKx3ixSMOEYZOvazK8A5flPe2Gsq64vVZnUBIKCxhjLBKsgh/9OJtZqxX1FE0mNba4hP/NeKyA4hFet4B3eu2jPKT3Wka3ULRcPYjtv13ZfcQsCqaTydFgIIlncQESIidvFd7L39WnlY/tQG+mHhcLbIArHb+dkBOH1IRM4cmRfHn1ohgPExB7kAEMAUOQQArbtOLAe0UjtCCNtYOP/oGjxYYRBD+xoGnIl5kcbLIRrOqULx4to3ZkekC7P2vcPqHQF3GmTAQAtOAv58dKXL8901/bTNc0N/M/GkcEjDkZ22v2u95SEw3bnSEThyDW4oJ6K/gwdWfChoiJ0A7RiCPkdqcgFgDTO0O04OAeAJAeVol2n1N3bsloQCHz7AiUJ4n9pnu3UEtpcq60xAmVREqNlVjK3+ZyBkt+ZFIkKsBxQlEQDRkB77j50gvFAuNcwuAz+C9C4FtAW8gIIbimdEnUSxDd0SKz5cTYcJkPxSEDy+mt+Q/59hXCiEqNuKCEeJ9EH0r85qnAdtNqSOq+/e3bg8Xcm5ABDQSDkEgLcElGOVQZr/WbGfrKt1C7+HtUBTh5grDpNSEasFdjtiyjWHb1DWZLJ5axWmFeESK5I5ErsxbKO/SkSOqFbWnH/Pof1i6vDihA2MSWFMmfiGo9E+JbyERY9OmjJr+AkFxtTkAkA1NpaZAAAgAElEQVQAY+YQABh8YjtIDkZJxYicj5dab8yglhSjvK8dPldbl8TqfqTioaHpItwRhRBdDwurlD7cpvCc8/mU7apZ4CCETpXerBjfUpk7t7F0ASCggXIIABrN+NzuI9sMpP2tOQbg29T0ggD+mMIAb1lGzEzZOp1apD6299lOx3rFEo+pp4UNOyZ6KUljXotJ81TpkQpeI1hSanIBIKCBcggAGvvRKcej15y1vyZ176idG019gE9VfhxNpfAVn6JZsTw5JKCvp8Kq5HTvlQLwlTQ1WvH4N5gq3VzBc5/MUGkXAAIaKIcAoAlHS/yAqRIKOLGDI06MUhP2uLHlW8J3KDQ+s3AdlD0MTGzn3JZoxqembyn60SVTFy5h+nhGjeWdTyQsV5O0CwABDZRDANCYjAx1/NM0fglX9BdiO0gqe+U2Li4AhLXPh6vdEmsrkXY7xPxGMfZ5Cv6K5cupfZdDAFhneheC1VR2mbp4VBPZFb2J1OQCQMAAkUMAwJd+SGfoegfvdVMljaY9PgtSkwsA4XzJII8TlBKIyf8Nij7V1c/mei+HAIDjrlj87lICQ0WWQaPjhPCamlwACGDMHAIAduGxHQRFkykSjnw0ZjK3z1BpFwCG8SXa5GObbKHsZxHZMbY/Tu27HAIAGu2xuLwkQz9PlQV6MrH1flyqQrXSdQEgoIFyCABvDCjHOkbKoSzS4hmzn3dV1BkscpwNugAwfACDH8e0ECA627q+4ve3xyaHAEBAnVjsfzjReBrauCI4T0pNLgAEMGYOAUDTEHjwQst5avSFAOzXDRqE58SeOzW5ABA3cHN+qXWnGtO2GqXSdbw29/s5BICbKvo6+F83hhlG/kazqGNMj41FMKTamnnnhUMyGvtdjcOZHAKAVlrMYRNv2YY3Uw4IB1kWZkNaLgDECQAM2k/bgGuKR0S11Pibn/tEv65+OQQAnGqtyz/kfg6beEuexMupJjojVhM5yAWAAMbMIQDghYvY0yGdoesdPJrlCB5hwZTE8daYBVH/XHoPLgDE8yTtxIo8BxHyVWNK29WnlnIvhwAAD7CVr8GUNp4KEU1QU9dcCzoXAAIaKocAAGN/IKAsm5gKu9Extl2HdkrM9zbVo+8Zq7xcvuk1AgAe8/6trGsfFqU/ZxXE9m9KuoyI/HHhOGv4IJcAoDXJJPphqgiglvyJ50JNe/BtLudHLgAENFYuAYAtTC3j5PDqpeksVzXwv55zO1AjABBJka1PbIHfISIaU08tX4z5PT4uLq9hmg3fnq+KVomgNWb9xsob9+Gvq8ICM258UIFBLgHgCooyNhg/fQMvlPAIXazfK+t5dMaFnAsAAY2VSwA4tUEM6b+JyOVK6AkdZSDcpsUkSJjiXKQVAFbLidtm9B8QDogzgGBwsIgcWocIxhx0rD8CUtE+mrPLZqBevf6iMs0jRrolEcmPVeFqXhb/U15iBozVFk2+uC+GP1CqfI6IMGDfsBYs21hqgs7kEgAor7a9UI4jdG+JxO6EJqhbw7eEhs9FLgAEDCC5BAAanbCkDSPEXgkPbB3bWsuQO4nIYQZ1IzpfThMzawFAi2OO75lY2Uk6yqC92jzM4E/aFoSwrLEiaZer+f1rEXlsAkHFor59aUxFAMC2vcE79ooF0MX6AMn8/OQi8l6Dup0gIjk9u7oAENBoOQUAFPksVmDfKMgrG0p/Go9/7YHi/pk79hIFgAbiU1Q6DHuLCKuudhtofn/W4ByXwfb9hmWiPqywz9BUfILXqQgAO1aKoQhaGh7iW3aqSjF9Ru/q1QZ1ol7s8uQkFwACGi6nAEDjc66n7SB8z4qblfeYhEvWdxnV50cigjCRk5YsADQ4E0zH0rzunUofDgSBsugfTRocxUxBebZpj67rVAQAyo5Q2WCvuaIDcZ4uMDLfe65RfdCV2Tlz2V0ACGi83AKA1S4AnYuzZUwMxyBWkG8NwDd0EGAiyk0uAJyI+H0N25H2jjVz2te4HEycU5/8aaEpCQC4iv6NUTt+u0MfItcYAd8QCTN0/Op7D97OTS4ABDRgbgEAJrBkLJwg5ZYs2erT2sK2OwyCzBgDtQsAW0MS25PtNtH+fthW0kG/7m2cP2azuXeUgioa8dKUBACqZ9mW6DztEoGZ5hOOoSx3oogZMMZCzQWAgEFlDAEAZsAcRDvINt8fKyJ4p8pBKLF81bDsBAway8mRCwBbHIMApnFv2vBic+VY4XZbyW/8heWEhW5Mkzda9gipc6GpCQDwEhYOTXtorygGXjNTY1ovbugH18hU9tVsXAAIYMIxBAAaCv/XlgpYOTrJpSq79x8HYDqkw8OkY5ELANsiz4rZcuDGbPXq22ax3X9XFJG/GPLUMQVayWxX6YE3piYAUL2LVFYXtP+QsWDTu6R1h4G4DX39XLV56KZyDH2GDspY5AJAAAOOJQDAFDDHUIba9D7uhrFBT7GdTnQ/y4GaeuAdMUfQn3Ud0AWA7ZE5nYhgZbKJz4Y8QzBdtzt1IRH5lWFeaKAz8cyNpigA0AaaCaiLx1gwPaOKQ8EWvTVdT0R+aciLlJ+d0jG2/htsNPh7MKAGxYRXFOkwnepids09gulY2WRjl28tqFA3jkBOnxDbkKRdAOhGiZXQTwz5kiOqs61kdQ4D//HtPsJREkG35khTFQBoizcY8lHT3ocbmgmyWMI/hLVb798ZljGWp10ACGC+MXcAaNhzJpA86SiY0VwtlnPq71ihWZ73Nx2YwfrSyrJZfO4CwHoUOe75Q0D/adq079o+l0dT/EjDtAmWdeP1VZn8kykLAJypo83fxx9DnzPB3lrZsihPfyxB2Tj3L4EfXQAIaNyxBQB4GCURy/OypjOhWIXFwdBtKKTiBxi4Lm7K0b4iad9S2XGtPncBYDOS11FGsWy3O79xe4uXP8tBl23he2yuxuSfTlkAAHyOZSyPehq+ou3xq3LGiBa+baKFF2Vj4i2BXACYiAAAs9zcWBO66SRcUYxC6TCEiMRnqQjWLgcddq+QQmR6xwWAfqAJdtRuQ+1vy6MFypLTt3o/WmnemLoAACoEjMIZjpZ/ur4ntkOoHxGOHV+RqByU7WlpWCAqVRcAAhq6hB2ApnXx0c4k2cXk2nuk+/IN0jLKeKz6/5Qof8pf2mDtAkDDeZuvT0nIExq+ftnmYs/m6RwEABrjBsY7Squ8g79+AnKtI8xSf56Ql3EZnEIBe119+u67ABDQ2CUJADQoDlRSCQF0GLx0PXBFkxZTrC8HYLXa4Yb8/+Q+bh3huQsAYaAzqL02MX8M4SXeRdEVV9RLoLkIALQV5/ZYKw1t79D30S9CYOWoqSGOIKzilawrB0cRpfGjCwABjFaaAADT3s/YP3sX036rDr3JdhhKK13vWN17fNMTC7u6ABDeIFispB5EQ/nt0wZBh8JrPv6bcxIAQPMmiXSe2vyDvxJMl9mS/3vi8Q2vgWOaM6/jUBcAAhq+RAGABt0zgWlKu4Pk+M1OxsPXcWcB910AGNYIBJ9KYRUyhBfRKJ9yZL9hiJ/49twEAGqF3b21X5EhfGT1bsnBplwAmLAAQCfhzOyPAXWwYmbLdJC67xwz2mX8xgWA4WDjCprIjZa8EpoWYWJLiBA3HDXdF3MUAEBk1wSeRUN5SfseixuOGkomFwACBqpSdwAaxsIeG5t+LcPm/D6HW+IGH83VBYA49C5emTphh52Tp/BJwISxRJqrAEBb4hBq7F2loXzM4uaOE2BEFwACBqnSBYCmk3wxoC5DGTnF+7iRHSu4z9A+6QLAUMS23ic4S+qz1YY/URoLNWPdKuF8fs1ZAKCVcAyFUmfT3iVfMWNFaXoK5AJAAFNNQQCA2fB/jR/skjvH20TkNFPoGXUZXQDQNRbBWVIrkJJ+aFRBXW3K/XruAgDIY2lCHBPLqJDWY+VnOlxal8s1ulgMHgug0JZFszWlrX5Mp2EliPliSTawIc3nAkAISpvfeXRioZRJYem0BAGgaWOUA1Pa6seMbwihz1oxnW7KW/LVdwACBqep7AC0GQ1vfYcG1C2G2Yd+g1b2ZdqFm9BvFwBsGuuARLy4r03xJp/KkgQAGgtvfW9MxFNDxzeEkRtNlINcAAhgoikKAPAjq+37jGhKgxYsPgTaDjem1k9cALBpMXiRmBNDB9d178Nbe9sUbRapLE0AaBrt9rXjsnV8kvr+uwyjqjZ1ynl1ASBgUJqqANAwEgp3nwuop2Vnwff2TZsCTPjqAoBt42H2+XslLxI05la2xZp8aksVAGi4s46gIMgRK4urqZMLAAGD0dQFAJgUBcEnisgJAfXVCAKszIjvfeap94y6/C4A2DckZl2vilDmQtP/RTPiLUtklywAgCM7TMRJwbxYM36FfIu3y/NbNt6IabkAEMAwcxAAGh47Vz1BhzD60He+LyLXbzKayRUvXkNxaN6nczmtRwBeZBv/8A2WAoSG/kIluD6mOk7CwZBTNwJLFwAaVPAASZ+Fb5p+aHX92YCIgk15Sr8uRgD4lIIhblh6K0aU79oi8k0FJu1Oxa4CHq9OGVGO0j85UIHRHLYIc7XPjnU42JuJCOe6XC83cf2RXNiRz2sUfEqEz7nRZQ2PPdHwR5cJXwRzo30UfIPVw2Tog4qK3mMytRxWUIK34Ief6H/tCX3I73dXOwoXGJbtpN7+hAKbKXgCm1RjeGHXIqDZqdpvbarTfsCxwN2UXlIJKoUgOlciSNGQ8b797qSUcN+kqOikJJ0ITmX19djKTh9Xqu0G3vSbbVs8vc2ZGEB+OgCTVbxuPGdwvG5FIYA55Cr/hf6PED9n+q9aYY8t/FBMvlfvRM0ZF+r22QGYrGL34CmBg5S7WoHQ/znbXgKhuPc/IoIryy5s2ApjRYzXNSbHuRPuPLtwCL1HjHEnRyAHAkQGDeXL1ff+vJDQyXggZaHz3Q1YsbC59wQd+sTw2JmUuhKEbJ4M3WVDo692iK7/OVNaChG3+mpVFK57VhXmbP8R9aS/tChrGuc1/xQRjlicHIEcCFxZOb4tzZUy4/ketRIqQgHHdRfN0VAF5YHuR9dcF3pvKvFc/g9yIuaFVqzrvQ8V1HBelPQIoKGuMZn8Wvoieg6OwEkIoKCm8ZGPt86TnZSa/5g7Ajhn0xxvEoJ+UvzCljUORLom99B7aCY7LQMBghaF8kXXe89bBkxey4IQOEzJsx5ToaDGTFwUjnq7xq3Qex9IXL4kyb9DWWk8mC1tmyhJQxSe6KOUfEIncmGx8EaeYfGeruRbjq12myEuXqVtEbiNiOCwLXSy73qPwG6TI+yLuyoz5N4PReQSk6u5FzgUgfsrFWPgJQTFU4Vm6O85AkYIYK42ZCzrehdPei4EGDVIgcncwiA2DMrgk9QHY1DW+iGn0+AHmjjnTvNBYKcqjvfLDQZQ+APb2lLpwiJCuGhcHB9cKXd+q3af+pe67lyZBLjPNt9zReROM3J9Wmq7WJWLduua2IfcYycAD3GTOuO1AnCm6WAKidMfJu8hvND1LlFmJ0sahxmrYBBg57reUSbLCxQc16HYs2r1Q9q8gflgSXT5esL/gbLzYz6FT4xdS6qcl2UbBDjHb/Oi5jfCBNvFc/TwuQ1oM/5nBxHBAu4YQ75gQTBZYuuCoCKajrH67a+rFRIuY5Gw8BrIUUPKPzrl9UTk4jPpnDDppes6YY6UEjt2bpjwUYL5uIiw2lltT83/HyukZ2CCiG24lbvnVUxQOCOyX8wqEZ/+2BATnOqdIvJFETlKRIir/re6PX5XOW/BcctXROR9FZ9zvu07Ef3MhXa3pTBLu7PjSTthEox765T9k7QZAxjfLjMTV9D0xV3qxSJRLFPjd9/KTwuOoeg3fzUe346O7PP9nJvxDY37w9WBcOz/CXqB8woGSCbRqRCr0ueIyJFG21Jjt0OT/zVGbgCsXZD4jzPu+E39Vq9M3Aikm4gyYaf+7Mr2+liDclE3+jAxOtjadNoWAezaV9tpqv+jrIYQy84tvkmm4oCMCR+B6fMJFhljtiWLisnTztUZFyuMMYFMlTerKRQ9SiQ6LyvwI2aK/VtHBh0LFSLnpeKtTel+uENPgH62/wbPkpvSC332y0rh8hkdeY/cFKNmz5Y93ktDMZzSe9+pd7Zidp5yNAo7F5yRTwnT0LKy64eTuFnQ/WbaSE1jHiIiKHyVQjhiQhpuyje3K44xiHM/Fj1I6bjIoj2IJcE2/XlF5EWZy4MTnDfUW61jtUFJ+d7AwNTLgidSpcHOYUlh2s9dBQ16/4zHN3aaZxUUidUoWs6pGLSEdPHxzTnt2MSZVHO2WwIuKcowVuQ/9Cc0ga5SYJEiFntoOdHpYLv4jGMzfQH5Wyo8h+Kf8z2EvscUcCzAjiuWMznrnjsv9HVmRwRD+PHMG44ztLHCNiJkoTWem1lz5/eykXrG6ZTRvHLjlDO/X4jI0qMxchTw5QX0v1eNqJj2wJnpMHX10Y/Oaet/dazGqc/cpTcaFYW7nMTk/+IFDD5ERxzDTIrJf666FF2DUMw9bJ5RPByjfXL2tU15cSxloXgZg3/Ob7BSOPkmIBI8e/QCxjdMQTGVnjWhuW1tLpGT+UPzemamVkRR5NUL6BxYX+yYCdN2Nmz7f3oB+Ibydd97XxURzmiXSoSlRlmyD6epPyd+Ry4hgC3xqePVV/4ficg5l9JpUCjBnr8PlKk/J8RtSkI793ULwPGTIsIqfAx6/QLwte5nmA6WpBSbm28uUJmHYsNtjWtp6eXYCZiTmeW69iM65OKEZo4DLD0mrQN37Pucy6cgJv/SFNJSYE0dx9pW5swxRZ2WkCaOhqbkK8O6j3IcsASdgLcn3AnYbwH9j2PN2W/7r+tcxNXWhoKdwmBqvRPA5P/GmXcOLBnGDJmKc5ETZo5x6r6D/w88zC2V8EqH3wRtNLjU7aRNn50A6mpJc5/84Ql4o1QfC5Zt2ZsW3tRYMWgZseTvUZCyIDoaHa7kumrLhlQ8ZiholCqJPaGth39/opdEnBQtmfATMFdnQQ2PE/7dSieAsbJJd47Xr4nIVZbcIbrqzhkvinPY08+x0amTVgjAFet7ZowPnsd272KOzPfw5zBXHhyjXjilWrobYY6xOM+2jh0wRnuuy1MrBCB4P2/Gfe8nle4bx4pWglLmYTFPdvgLeHLlghKtyHWMNuX7sSaCDCAHzRATtsI+VQftKMH1JTss1qZcmL6+pdJ5uVt9Ln622tYXofditUe/187YZTb9lfDPTiKnqY+2UPya8ji2ruyxQgCTPx4t16U75fuYEBPYaSxdpkn2OyaDa9WexghQMadztKFCwKnqePJT7gTtsnO2TnRAVkS4si2J7mo4CHGs9bBqZwtTwhAiuhxuhue6SuwLZBSC0Zze+e9qUiCwGCauY3p0bPdNi99DdQKY/HHwZZF3CWngIZMjRKIEouzuZIDAmSt77GtXugK4uiW8LAyDhjgSZ8o//Pzje96asUIVA5k8PpIgfxS08DqVEjvSZmWLm1R2dXDhi4/rkiVh/J5btDXKrTtF8v3pq50BtKstytGkgW06iqPsQly18uWPqRqrUbYj2XVDWY/YAqzCUlnn4DFwndtgNKFx88oxINhxbHB8JUAR8wBe5Q+BCmcp+IF/bu16+3yRGJf2GbtBtMs9K8UwFOBeUoc9T90/CSyVQuAMFQJY6OFdsOFTq+tfqgUk5sOp8cNMGCdsTxWRu9cxE8bwV1IaP8+qPAgfxHu2Ys4mnT4hgBUhK+Xmfavrm0e0qy+ZMZgEtRizU/Vwo0riVlpTHspysIjgfItV1hBCSYmJ1nrn7YWtQpy/EkCeZhCmGpt7BAfCXjsNR4BxJsUK/F091gFM/iwQNDze9S1KxGMGCxveAv5F8QikMr1D6aWL6JTsPnQxuOYesd1LOGvvqvOY9ziKsPCr8DjjSuwTyQMMgpc1KAs7NuwUaXiu/S3bo/evd7VwH9x+ZvGb7fQ9XNEqquURxizaoJ3Gu9cIAYynKZxssaPBkamTI2COQC4hgK3ZFHGuX+GT/0k8gQ8KzvvfKiJo57YHrdjfeGW0JlbuQ1ZJRG1DCLEU8ijDo0SEyTsWm9zffa8+chq682HdflNLL4cQwDhKOGlrnmC3yyf/qXHcxMqbUghgsGLy5+zKunOwxbf0wZC2u1W9tf13Y4w5R+UsPQVR7pBzUs7ur5yiAHWauPCemp97BOkLJcRkjkmnFALgZYudttXx8YOF6xbNkU8WWycUp1g5rjKh9n+USb6YIN0+XYO5NyTKeEQT+2ECbJs2Z1s7Nd2sVo5r8myuCB8ojsUqHQ4pN3oSv0+IY1MnyytWJ3sNqaS/+39e6izbgLQ4DkAvwDrdUIVDb1ZHwAyBVDsB1p1D63zIDLAREsL5zIMzrFpxXpVj8m0gRCl1t8rU6HqVlvPFjbf7mzw2Xa820YieHKUs3SHRpnZdfTYFd7xo+Vu7IV7Fwf93BDoRKF0IyBWSuBOckW9evzrj/0GC1UaXgMbEsjR6SCZsu/DW3PvYSGGlp8ofJQsBOUMST7X9vNyJEShVCCDQxBIJe3ImZGvztU2TDrbbSyOUDLHV34RLqc84ZnNb7XCOLVEIwLOmu9QNb0N/MyECCAEptFpjB1Cc7iyRsAMfw4U0Ht2WSBw/YHUQy6djfsdOgB8HhHMtjm7GbK923q8Z4dgrHCl/c5EIlCIEPGmR6J+o5EUI4fZAkeM3pnFLNj1iJZYD5xR5vHqhfSW22iUIAVjDWJq4xmLh3zkC2yEwthDwhO1KtIwbKcyWQiecrywD4rW1xH1tKFYlvrfE45u1jRnwYEwhwJ2YBTSQvzIuAmMIAZx3E3RmacRKIIUL0yET1SOWBvpKffEtkSp2wJB2iH33r3VchJVq+b8bEBhDCCCa5NL9mGxoEn9UEgI5hQAmfzSyl0isCGIHfovv8CuAy+al09hCmLYtcZvsk8swLs4pBBD4ydtnWPv42yMjgBBwYOIJismf8LFLJEJtagd+zfdEG7vCEoHvqLNlCGVNm2i+vUNHvfzWZgRy9MGhodM3l9ifOgIZEUgpBDD5PyBjXUrK6l4jT/74F1iq5n8XHxB0SDP5tr/9rYgQs4LQ0bu0zPUIkUw+BPpBsEYAa3+n/f1dNyvratreeymFgGf15u4vOAKFI5BCCCCK2j0Kr3eq4jHxjqHtTzx6YjTg8veUqSo30XR3MDAHPF5E7jcAWzwvovdi6ZaYnQyn4QikEAKW6sdkOPr+RfEIWOoE/LteBRVf6QQFxMnPscYrv9WV4zdE5Pm1gHXFyqnQeeoATQmqM6skP61oF1b0p4tEY+fax/xqO8b8/6XIMvhnIpY6AUv1Y+J8NGMEUGJ5rIiweo8ZnPjmjyJyixlj1Fe1VDoV36/b5lx9BfDnaxG4fQRfc4xFkCYt0besTEE5ZnCKQ+DeIvKPCD5oxkMidHK85+QIzBaBW0fGn//cwsOa4tu/GSisrt8Ukdu5YxGTvsYk/KGBbYRAbEn7D8y/i4+eblmgBaZFoKjvRLTDt0WEcNNOjsDsEcBzHPbjR/d0FLb7PyMiN5k9IpsrCF6WgX2I3sf5MUczTnYIsI0fGs76KXbZnpQSQsh7evpU16Tfvve9k1LzH7EI0K/2FJGvBbTFV6u+je6Fe/eLRdu/mzQCaDqjzc8W5utE5CVVIJt9ai3oM026ZnaFZ7JuD9Ka3wxKF7Irmqe0ggAKkqzEcbDT1U4Icrdc+cby37NWwt0f1uTdVZ6ue+h9ONkgcO5qx3Ovyo4fRUHc+OK7g98oMZ/TJgtPxRFwBOaKAFHbfqkc0JtB/l0igsa6U3oEMNu7c6XVz5Y6Qu3e1W7WdTKt9B6u5Jfd08PjOTgCjoAj4Aj0IfA45WDeTP6v9y3/Pqhn8/y0G3YgGn7YdD1gNkh4RRwBR8ARmCgCnCUeZyAAvNcn/4lyQHyxNeG5D4rP1r90BBwBR8ARsECAs+JNK7WQZ0f4tr9FU0wuDZTQQvij651vTa62XmBHwBFwBGaGwMGKQZyBHW3/i8wME69OGAIa98Q/DcvC33IEHAFHwBFIgQBKZBqnIggAD01RME9zEgigB9C1ug+59+tJ1NAL6Qg4Ao7ATBG4i2IAZ5DHpe/JZ4qNV6sfAaw9Qib7rncwI3RyBBwBR8ARGAmBdygGcAZ1PC46LRcBnBJ1Te4h9/Bh4OQIOAKOgCMwEgI/VwzghHZ1z2IjNVwh2e6q4J8fF1IHL4Yj4Ag4AotD4PyKwZsVnkWAmcWBPrMK4142ZLXf9c4XZoaFV8cRcAQcgckgcCfF4E20RY/qN5mmTlbQNyt4iOMnJ0fAEXAEHIERENDEFj9yhPJ6lmUhsJMyHgDmpwSgcnIEHAFHwBHIjMCbFKu352Uuq2dXHgJE2uza2h9y7ycich/3IFle43qJHAFHYN4IcAY7ZLBuv3u3eUPjtetBgJDAlqGjCVd7yZ48/bEj4Ag4Ao6AEQLHKgSAKxmVwZOZJgJEHGwLhBa/TxCRe08TDi+1I+AIOALTQkAT/vds06qql9YYgUclEAAaIeItVXjjUxqX15NzBBwBR8ARaCHwF8UgvmMrHf+5PATQAWkm7BTXD3twqeUxldfYEXAE8iHwb8UgTghhp+Ui8EQF74QKDB8XkVMvF2KvuSPgCDgC6RDAFWvoYLz6nu8ApGuXKaRsEUJ6lae6/v+ge5ucAjt4GR0BR2BqCPxKIQCcfWqV9fKaIvBfIvIbBf90Tfbr7u1jWnJPzBFwBBwBR0B+qBjAr+L4LR4BwkCvm7Qt7+N18gaLR9sBcAQcAUfAEIHPKgbwPQzL4UlNEwECQbFFbznZr0uL3aozThMmL7Uj4Ag4AuUh8EbF4P3i8qozuRKdRUQeLCJvF5FPiQia73uLyGUnVJNTiMirFHy0bsLvuv+SCeHiRXUEHAFHoGgE9lMM3F8vumZlF46V8/1F5Pcb8EcomJKexeYO/JkAACAASURBVBVF5G0iogkv3TXpt+9htUL4YSdHwBFwBBwBJQK33TABtQfedb8vqMx/qZ+/NBD3n4nILhME6XwicmsR2V9Evh9Y13U8tnr/XRPEw4vsCDgCjkBxCJxbOTg/obgalV+ghw/E/CgRIereVImYAbcyFATYBXDBc6rc4OV2BByBohBglbm6ygr9/zgROXlRtSm7MKcVkd9F4P1OEWEinTLtICIvi6h7Fy++YMpAeNkdAUfAESgFgdcrB+W7lFKRCZRD4z8ffY05kAaDRhhAz8A9Uc6BG7wOjoAjMCoCt1MKAEQU9MAtYU34HSXWT53BTgBI7avEAUHgWmGQ+1uOgCPgCDgC6xBgW/rvygEZ0zWnzQhcVYlxs/rlOGDqbpg5ztD6DzhgM9z+1BFwBOaKAGZU5xARvNHtLiKPqFahT6+UpRgUXiEib64UhbBx5/ezKl/irJywt76ZiFxCRE4zV2Ai64X5VjPBxFz/ISKXicx7KZ+9W4lxu11+JCK3mDhw5xWRvykw+eLE6+/FdwQcgQAEcDRyhcq++L71hP5lgxUrg+kxIvImEXlgPXlNXckqAMq1r1xfMRA3E9N3ReQMa3NY9oOLiwjubBusrK6fq83thipinrU2L2QSHpNersAE4YF4BE6OgCMwMwQuVmlLP0REPiAif1YMEkMG2h+LyHNFhK3apQkD7Kj8wADnQ9wqoLMnare7+/j4tyKCMue9q631y4vI2UTkVHUo3fOICE56cDzEzhh83k4PF7vPq7z5nbOz5GlvXm2lLO1yhfxeqlMg+ittfCkRQXi/k4jcp/57TLWz8tiVPxZP8MZtat0JdkH5fmnjXFpu9tRVCMDMbONrAtSEDBoh7xwtIg9YWCxyBogQbPreoQ2dthC4sRGufbhrn+OVEOc9OYmdiz8o8LlpzsKOkNf566MeLCdeWU3en6wm8p8a7iah+8POHS6oMdF8UC0g+E7eCI29xCyRQh8vIt9UDALagW/T978WEUKRnnoBjcN2Knb9m/AIecZW90UWgFdIFU/XseIOwXCsd/5V68mE1M3qHXb5YuvLqncuhDLuTarKPKU68jy4Oppk7InFxeI7dopQOH1YvYPEUayTI2CCAFuSnL+jPGbBrKnTQOkq9+rIBOiBidzLqD3cUcuJwGuCLaXm6XXp/1JEzjSQbzSvs7JdV5a++ywepkr4MUCJmQUGuhwIX331HfP5X2rLDXSm3BPjVLluxHJz3oTN+ZcKZ/RNnYyz3DOPiGHqrDlbPNygfb6RuqATSB8dlk28VPKzJ2bEF8udWCymJgBw5HEDEXlNZZWE3kZsvUv4jqMDnFNxdOvkCGxE4OaVP/CvTZzhm07HNjmKVnMldme0GuucJy+ZMDctfUXX8HPXlQA+uegZinFhKgLA1WsLprG39bva2uIeDq6eNJIiaS4+9XwiELieiBym6OAWzJkiDUyQ5uwC99nKNsNyY6m0m4icoMQvBc8OTTOXhv2BCqw4ny6VTl/7HilVv2koP4S8T6Cm94sICz531VwqZ2YoFwplr1J07BBmG/sdVsl3zYDlGFnQfl9VtB++2pdIrPz/qsBtbJ5u54/zrByk2Rm8fY4CDsyD8M2vnhEftHliyG/8rOB8zZ2uDWSgqb/OObKl17MhTJf7XSRePBHOkVBQisUTnwJLI5Sjprztv9rWaIEPdTA0tM3Rp6EPreYd+j88WgrhCfMdBsdnoXWfynvoOuyfWbG0FJ5YZDlwOjEV5rQo5z9F5MozbGm818Xig4LQUmgnEdFsY8dinOO7OyZuxD0VPPa/hSjkXrQ226M8Odpkqnn8sQ4ChWms00wR4Nzn+AV2BJwXzc15Btq9sYPNt2bK36vVQqMbE9FYnLq+w9U1Dl+6nuW+hzVHyl2A9yrqibOusQkBRhtIK3ebjp3f76rjkUe7G+exWTdN/tdUdOixGVOb/3vSQDpaqpdVtOWRo5U6T8ac8x6kwGcdr2FrfaHaRSvuXUvwiol3uBS0g4hQ33VY9N3Hx8KYhF8QrbVMXx3n/BwB7pZjNqDnbY8ASh9zZtq+uqEENhe6nKItj5gLCCv1uFJ9zqs5t97EQ7hjbhPKmPjwt95l2FSG1Wd/qgMHtctl8RtN8dW8hvyP06qxCA3/uZr0DWkDi3c/KiIXGKshPV9bBAhCYcEUIWmgcIUUiXMegplgE7yXiKAZ3PzdQUTuVyln4djktbVJombV0Vcutr7nYv5ySUVbftuWrUZNDV0I+Jq27Wt/zXM0x9cRPMWK8+MjrTo5CrA+u8UZTixenLeffR1YGe4/XFH22DrP+TssZ4h3kPK4KQNbeBb3TNgxsC1n25XzIxxrsIUYQ6yq+P5pibZYMZ9iJffM2hri63XoYbRhUYShI6M4iMtVlOW+UNvO/k9tUYBSUQlCxIUVbcnW9ViEFQo+GhAMMUdEUPxZFTXt87Vp6iNrf/fscDCJgPWOtUIZeg+sTOGxt2f040/ZThkIGGXGy+ChlWCCP4pcEwPuasHJgoitoQkChJ7EmETUy1y4Lykf2hWB22miCBDG15JhGcBfWIe8DB0gh0DHZIEiFwOwZbm1aeFIhghdWFSMtdIhVnxsPRBuxiB8lGv8F8TWV/MduyWx7qUJ+YvjIVZP7CAgTGJ/jaIVq2QETX4T8ldTxubbr1RR6c5h0LAIaE2aMVf8549JCJQx5bb8hp1MdkAZu1CmJKYCEf3wrLj6x310Jj5U74L+ZKSdpJD6M/ZhUuuhisfkcEXerBRCGnrdOwQIemsdGSvnlhBxCko810PRiPgJeD3j7DEXIXisa6O++2N4AmTyt5ro+upn9fzYTO5T2S2zss4hHO11lUz4MQVvgT0KqmNSznGCXUN2e9hRZIf1GiKys0Hl2QlF4ZQFELtimLKivFuKLwt28M5iUE9PIjMC2MTHMBGDN9vnhAgei8ibbSirAd46Hc7KXlrpM5wnA0B48IotP0pyOYlt/Kmt/L8nIuyy5CJL/xwIpU+vHLzEhIg9t3L1CW5jk0XArHV9C+HibbU+E9vh7FLmJPr9dao2wrc/5qjsIq0ra+r7OKO6Qs7Ke142CKC5HOoYg21+rAfYziyBiMtdesRCdkleVB2PnDExYJoz5lgdjZgq3XnEQSpmEGSlddaYiiq+YbImyE9Medd9Q5wPdEWGEBPLuvRC7u87JLNE77IaDylr6DsE03myiPz3CBN+H0SMhyigvk5ECPIVWier9/CzMKbFRx8+/nwNAreplbDWMcJvqqApjxERFIJKo3PVSnrryl7KfTDE8iHVeZlm2/h8GRv1AyMMTLE88D4RwXvgGMTWfahgHlo/zqJXzRfX1Q0hH4E/NO2u99AzGpvYOteujOlbuMi99NiVGZA/eli3qBVkWYR0tU+qeyx4SlCOHgCXv4rWMBMUPrLZWkeJCO1q7pU48bdbjDKmYmbrdDkvS3F0ggVDbFmv2gYz4W8mU81ORWz9hn7Htjmr11TCWijEKAsOLXvI+5wh9+36sJILSWvdOwQOKoU4rlxXznX34QGUe281A5M3zudRPkURcV19re8j6HtwoVJ6wMzLgQIiCk/WTJwqPVZW1pMuykex5b1tJv7I6XsiFgtWe1rFOSs4USRNNWjjAIrdsy7iLPsoBT+BPfb3pRD1eUNgfVgtEx2VnYO5EThwRKBV/g7tWywiUyx25tYuXh8DBHAwFMqYJbzHedndDerdJPEWRf053klNV5vA6h+LljOlBmJg+mw7p3KIhRlil3Ijbl81fYRdntJwZDcHfad11id4UXz+BqFoYLMV/zoWCp9StnMIj6AImkMRunjAvYBpEUCPIYQhS3qHM96HGsESs83ZYIHnxZR014STWFMHzZVVNiZWpRJmr6lcGuMIqq0Dwtkt3gQ1eLLaLpXQbWCseFblt+MV1Tb1s2tnVFaOk0qt97pyXa8+7tW0d9+3uMee447KOkz9/ggIXEQ5aPUxccrn2PZqiUk2tow4pUlB56/CL39EUa7Y+oR+h2Im2Jdi1bKpDVDes1YKbHBCf6TRCSCf5n7sld0ep+kgwNEAfgu0Sp+b+AWHTIzRTo5AEgQ4L93EgCU/Y2C/hxIVfDrE1hFnQDgbsSI80OEVstTwq0z8KPlZ+8y3wm9dOnhdQzkttp03fYe/f5Q0tZMAuwdO00QAM8IXJ+QxfAW0d5umiZKXukgEWMFsGuBKf8YWL77tYwk/A5o6Xis249Z3TPwvKPisH1e+nAOXbtXSgnS7n4QeTmXWxU6Qhof49m7bldhvTA0BdnDwd6Dlha7vf2DkonpqmHp5EyMw5R2ApqPgSlRjO83Ktklr6JWAS7GENjm2vyWa+KH0hX91wgPPhRigtSv1ofwR8j7uknO6BJ9Le5ZYDxZU9OkUx05E68zpKr1EfL1MxggQmS9kkCr9HbRmYzsHIWhj64d73qFEObG+KGmrn9UxK1kiNmJqyfnmHOmctfvX2PZO8R27K07zQuAmGywnNDz0CeNjx3mh7rUZjMCNFJMfEfFYAbO9ykoRl6mYMZ2hDnKBBitb5CjKoDWMo6RUWtl0Kkz6Ymg/BQbki2lQCDGp3ifRwLA6qKCghhZxE56ZiHn8ESUNO+ODayEE//ma0NMh9S7tHTT2n2Dg6W4V85j/2ZGYgjJlaW04hfIQEwJX0jF8semb1xfgbGsK+HsZAxB4nIJB3xWQ/uorrH5R3EvRMeg0CCND6YYKDMjzoIAMd6miP6YMsNIeMHDI4tSPwBVFhLPVNna5fxMjxGkcBPD0d+PanJEVe4rIfLgWJoyxNV8xbjs5AmoEiLMdy5ya828KThSsTyvy7yo3q9yhXrRYgWmcxqBhfpkNLYGCF1EOu8prfQ+FPXcluqExVh6hwY+LX+t2CEmPtvKz/5UGyfDvrrWZ7epuJP8fksi3BS6FLS1RKOv1M2DlWcwYAaKn/UEx+FloLuNp7C6VljnHCSGDZsg7b4xoMwLYhKS97h221VcHc+rGmfq6b6zvs73f5aEuAo7FfUK0RY0QGNOW7DxpCKET6xHcE+PSGw10YpLcwYPKrIWV3ccQ3Rv6M66+LXVhSM9S4Zewyt7f1zb11gMGYjw3Iel/szK5wZUnQTcIGnLNrdcW94uY2DEDV/ONZRxrGJm2adLWXNHAHdqudzTIG5/9bcrpZhmHIcRWd4pHAD0WXNtqeC/0W4K+xBLmmISu3aRpzvh2idgMZvodUf42YdbVdghXlg6aGHPxH9KVV8w9jhVZyDmtQQB/ymhObgIXhaih28ZrspvUbVbKm3DZ9OyEBMpLONT4mKJM7fJ+aWBLYL6j2Q0hb8KnNttyTzSqR7tO636zlewrgYENvub1HK6x6Tux3t04rgoNSgM/X35NPZd2e+fKffjvI/skQsObqmBHWJBYEFY2sWXpGgPYZXTqQIBBEU3oLtBW72FGdvaONOZ6C219zXYUrmpTEKsbJu/V9on5/2YDC8h2akw+7W8YdInoZnne105/9ffbRATByckOgc8Y8MFqO7X/f5CiqEMVyhj/0HNYOj3ZoE3ZHdJ6Hm3awXK3ibFmtyZhv56IAKY+nx/Y6B9dkHkFSintQWno70ckZDS0cS20szE7HEL44F9VDBqKS6730ZmwjIo4BKe5v/sAZd/YxAMfVowxhFseuoVNWR4/9wYLqB9HIpvaZcgzrJ8sojZiIs1u0JC8172Lu+CpuegOaLb4V4gEtg6sTfe1ijnxJc73JVrinBlvwqHv2SUTFxezOQulLGzchxA2tn11H/P5v2rFr1inR0OwWOq7rM5StDFKW7G7jPRZdJdiynXUUhuyrjfb/zGC0yasUbq00A24qYjQpzflFfoMz51ONQIfigQ11pnMlIDXnk8jbaJYmZruF9mG7Q7zzoGFxC+/pZJOuyza3+iqXGpgffz14Qic1YDvVtuabVpNzIoDlGXCOddSaXcldqtt2fyPNcEeBqBajHOUCR4LdUpmUOxyk8D5QqzdNX6550xnbnmHaxh56FVr/x+KL0IGk97Q8rXfRzGPFcAQ2luZZzt/i98fFBGc1jjlQQA9FIt2a6ehcdzCjoT2aAovnUulVyRoz3bbooSnNRd8llEZ2e1h/ls0XVsBJkpccybCl7aZd+hvttJw8ZuLUOQMsdvdVI+h3tawCAhVHt2Ur/YZMQp84s/FaVv5EOJZ23bt75mAYgnfEoQKbqcX8xvBf4nEIuKHBvj1YY5ZpkYIQGcNHbS+fEKer5ojL67d91cAiTOVuRJbkCEMtOmdT44AznOV5R5qEkgVsdfVrro24bjpGeUlf6dxEMAkeFP7DHnGkaJmYri3QVkY03Ic2Y3TWptzRYAe0l6ad/Ezw0QeSygWWggrWCss0az9JNw1ZmRst86RWAFYhEK95Qjg0DE0NvrsWsQoXz0l4+DBwEP7oLy61MF6BNbqzBIHOpqJoPmWVeGqd8jODNfc5CgCZbMmvdgrgbiWSs8xwG8I7vhW0QgBOFfj2HJInl3vvnapDY5XJM2W8RxNZliBaHz+NwyGw5mxJietjf5eER2CjnyoQWds8Nt0ZWfFwrQoopr+yQoCmGdtaqu+ZwicnAtr+woRC/vy6ntONMihOjArcEz2X/A/zgDDPoxXnzNWaUgToK0pCwqBl9YUYqrfEuihASHmepWpVnxDua380VtovG4o5sZHF1Oa8rx9Y+rrH7KVdrSSp/r48Ksigt6BUxkIaLwBYkGCz3ctsWOn2fVqeO6B2oJM+Hvcvzc45L5qnD2xYGNBoC0zi77F0Z4K4LA7n5tfZQ0ebQYsIXKZJnLg8YqegIMgvm/jYflbYx6mqJZ/ugaB+yjamqBSFvR8RRka3vysUv/Aoh5jpmGx69lgOfSK/hA2/rF0AYUlW1NWdqIW5wpa03HwQz8nwhriHwYDCQxFvOyx6aHKumj85RNo5zfK/JuOuXo999jAev7bIKDZerdwxoIfAo2bbviL73GmtVSir4+lxNv0b3ZwmMhj6ZEG4w1m1IsiTKeaBhh6xf57LoRHw1hfCKu4YZ5SAmHLvFq2If/fWlkJhIAU5oEXVJbLP7dF4KUKPtvHoCj7KvJv+sMcdZmGQPtMAwwbLDVXFNJjd5XRQSIaoSZ/dgEWpQugOa/VThBDGDTlu5xBWq38WUlcNGVhB6b9fUWHsBic8RR4pKIMXZ2Zs0qnchDQRKTEbE9D6IL8Sslf31VMOpqyl/It+hO5wjp39efVe89QAIO7YSbx1TSH/I954iIIiUkz8c0hfjbRqiy3vjQezFIw3RsUnYHIeRZEdDXSGtIJN71L8BmnchCI9blPG2vOfUFAo3/Q8BhKjEsmJtwGi5grfhMIJBbzbdc3aORjWRJL+JLoSjf0HnOiVSjj2Dpk+Y6z1FBQVt9j0iTW9lQJ948vUtR/FQ/+/4rSjjkFlg9T1BGlKEu6l9Exy/MsC+VpqRBgu1YTnEUTqwGzNVy5dvXF0HtfMDA/VAE48sdEEtXG8iBWCj4YiCMSinvfe9+pTEPxMBlD51GatlM2LMFmT0R+62uIdc+nHAMARRNLibXB6D0FcozGRpvjIWu6iIGvgMUp6lg3gmF6uLlu+H/ola1aJo5YQtF2aJ6r7y89GIxGfwMsWS2jhAlhjmcZRwDl0lh6oZI3cDIWq4sQW+bs3+GlbrVDhP4/VQsAPMf9XlHvPnxulb0VN2eo2eVhZZCCWLlpvAai1+BUBgI3UvQlvPZp6B2KvOnHH9BkPoNv/9vg+PPNKzjQt1+sbJdmjD1BYRWAJ1OtUvdcdNxWmmjrX43N+9TCADMR5rBzxf79tFsQj/4L16oaHYcdE9XgMopBgi3n2UvniXC3TpbAUc2APfSKn4pYOp2B6R87oEslVusaF/BNWxN5cZVI+60KvmjS5hrrkIwyaUzcyXv2O40PVzTSS1ZbvdD/mcBYbeK0qM1YKX+/vDAsNP7RU0UyRH9EI5hwlOA0PgL474/tS0TajCWUd2Pz5TsmvyUTHg81+PHtpl1gzu8/ZZAHCoF4q42h8yn1UxifmuONmPyL/2Y/RQPlinEfCyKa5ziGsAjoE9NRtOZNsfXu+g6Fmpg68E1Km1iNieItuirq97Ij8E0Fbz1aUdpDFPnC13dQ5D31T3F4pN0eB8M+/QkmTwuPoO9XAK61Ppq1a2hN5Ccm1xIJN7RocP5OOUDETpjNd0SoKiVELb7zm3INvaYUAHADO7Q8zfuEsHYaFwEU+DS7ODeILD6+JVgZNrww9EoIWU3UwchiF/EZR2cWCtAE/QqhqypX4U3bdh01hObfpBFz1RxThZRv1Hc0ZyTY35ZCdGYUNj6sHBhiGGTTN78VkRK2qjF12lTOTc80Zlp9/KEJuhQ6APWVwZ/HI4DTlU280/csNga7xrSVMj02vsqT/1Jr8w9+WG/Q9qGEsN7HC33PMTGMpW8p8kfQROCcJWm0NUsQALD35BhDc8bdx3ja57jCHVsI0Cj7pBQA7qromFgoLHUVV8pg9BBF+/1CUQlcbcf2Swb0pcaS4NhD6yUP3Icq5qEP8A1Fm5Enir+M9zGkFRhLmOti6t37DYE4YjvS/XpTT/MCZiY3q6I2fbCw1f4mHH8pIpdLA0dQqppz2pQCwGUV/AfefO80HgIaL5ObFMg21QjlUczDNvW3Tc9QTFsiYXVjoQgN9jFBwtAX0AofsS6CcXWscVZVon8XEx5GW31TZ9n0LLdyBG6L71TFDtdMZpvqk/oZka407i01Da5x1Zpy94LzSI0ykrsE1nCF/lvO0mP7Tayntesr8qSsJSnn6lsgLAW2sK2CcmmUv9+kbDuOVIn9EEMfUeRNnIRYr4QxZc32DS5VYzsw9r85iEkCfwXfU5Q1to7W3xEoaIztJI3jozMkbmSNqRArUKdxECAio6Z/3Dyy2M9W5Pt3EUnNz5HVSvbZGQ0XTXgG1XhuxCxPE3sGfts9Eql7KviGfHeLzLfozzTKGamtANjqv5uIaFYZmgGKb9FwRk9Cs0rtKgMKLbkGIjpsVxlC7mHJQDukJA0PpnBVnLKuc0r7vgq+YiuYbdkY+roiX1aBSyJ8oGj0f9pjBG1mMQlqXQ9jORRDCEIaixWLyKgx5U76DUEc2o085HfsFl5IhdAwPVxRtiH1WPcuEa6aLfs9EpTlOBHJ4YlMs1LTumoNaWuiwa1rg777DEqnD8nE3zFHQBP4hd28GCJwjeYc+RExmU70G7yRYsLW14dCnzNxWxCKfJrzeHYQYhdPn1fggeLp7EijHUnQB2tiiwgNU00nD2XoTe/hMvhMK5V7pYJ51uWFRMoKOOX50nUV5T5yBYMU/yKZa9r7CikK5WluRABXr79R8NXrN6a+/qEm7gB98JLrk57Vk51F5AhF+6yOV+zC4ljNirRugmP1OPZWYPLHyuIMPbRZEVvsq40d+v+7DJHAnOtxBr69Q8u+7j1Mk8Cki9A+tuxU7TIw0aYanB6kaGP8KuSgbyvK6AJAjhbaNg+CyLT5d+hv3PjG0OMV+eKRLvVxVkydrL9hEWWpL8WK+4rGhbyyoh3htVgf/dRjKK+238eSYlZ0QwUgnzRCAk9zX1GUo91Asb+xDcYksm9rCS+DqXwOoKCEa1RWV5ZEzIZYXHAUlYNepShjrDOZHPWaax6alRS8eK5IYDTR/4hZMHfiyPJXir7UNU48NBFoGjfg6GSxIBtKKJRrTCFRRp8VaeywtSFZ2fYmSA+KZl2Ml+ve5wZKuJcQkV8nLPNnRARBw4o+qygril45KHZrF5NQp/wIaJy6EJcillD6jB0XxrC+ia1nzHfs9FmPpdi/p9o1eaqiLeGB68WAVMUv+IQi3wMi8yz2s3MqwIDZYj2xXTjhdnroAIF2LDsgMcQWKHb9oXkNfQ+7U4tgJZxZaSTea8aAE/ENg0yMgk7sWWBEEf2TGoGLKvn+BZFIotTmuiLbg4cS7JuVbdI1PiFcpwxrfnFlmYljE0OaAHixzqtiypnlGyYIjV1mzEr1LiLCBNfFdDnu4RcfzXMtocFvbR64Wn8kzlghi/rhxW81zSH/o3WdixAKcfQRWj40nGenlJMLbEU+mEOFtlHXe3jxjCH6W1d6IffQOo/ZMo4pZ85vUPD9sQKXddihCxXj7W9o3b+mKDvfxtBtFHkSWXZ2pDmLGbINc5rKl/NrFeCvY9aQ+6yC0eK3dh3LoKTRhg4pO45yYmNSaxQAcV+cm4j4Rb59uKCMmVM4yY1DyflpAqsgMMc6ktEoLM/tqIhV/4uUOyLr+hiuflHSy0Eofq8rR999LKiYU4YSC42+tDc9x7fCrEjjIvH+gUggTWqkvU0NsukZ2uV4LDxdYDljXoOhNGeTm8rfPEODmbCaQ4l4CU0aQ68HDc3M6H0CtWBj3rXdy+D0LMUkYlTExSaj3bbFvDaWnqDg5bl4jOSoDEU0VuhD+3PI++yUEFU1F11eWQ/iCwwllKw1x6KprLWG1sPsfY1nphBfADj1CVnVhTBoyDto0+NzOoY5YkHFq1nMGXZIfZp3OKoZopR3SiWjjx0yFXMmdjCeWSki7Ssid0wsyMW2/ZK+ww98w48xVxxqxZImcNkcvLhdp9JZ+qIS/01txoqaWCs5ieNNonpuKtemZ7HeaDWL0VgX1jlxHZSXJqTnl3tyQlplQt7UiFbPOAt7lMLFaE9Veh9zxnhghrqyAg4xFeR4RoNtDi+FvaD6C8UggAnVzxQ8xeoSp0+xpNnNmrL5Fuf8WAZp+nLft+y24St/DPq4om5viywwO1F9mKx7nisGTmTVhn92bQUYTO4MDF30JEW668Dvuk+UK0ITp/Sm11W/dfdYqWqC73TVcfUe9tB9Sk1oya5+F/o/7dqX/rr6+/15IoBVSij/dL13iBIWTQwAJtEpEX3v7pncobPyv9eI4GAK3sUvIfdiTUo1QfA00RBHhHl91mxfh4C97p1VxTpWpy9Uprkur/Z9C2I84wAAIABJREFU3FNiBlbKxN9GGJ0HSz/c7Xo3vzly2BRQhc7RvDv0im8EJ0egjcChCn6C/7QrzN8p8k8Z0rqNkfY3nuaIdphasbgZDxD0b6cttPJ7jatyyh9jCURMiAaDoVeOomZHmq09jhAaYjcghU1qu5EwIcRjXokTf4MDVxgTxSVr5xxtLFA+vFA70/q3xsET6RMkyskRaBC42BqlzDYvbvqN8qbWphxvnZvyWPeM7e1Yy4Om/qmuLJZQhCOwmsYaa13dN93n7H2IFVcqDNCq71L43VT29rMLRBRME9wNBeXZ0fsjOxcN0Wj2otChiRDWbtSu3zAJQUSm5vr1cpWUrTGd6sKifQ/hDe+EbXquoj1Je3Y+r9vg+O/BCOC8p81zQ38T/EVDbIkPzbN5H+GjFGKMRDjHvS5hbTW7Gk39Yq7oSzEulUKaBWiMMzdNBFJ2wmZHmiAbMDGrcW2Ep02MzPkfNuJTJQYwJuXYVcwmbHiGa2K8E0IMMhozIcIgp3L/WRfRLxNCAJtzrdfLmyjrS4yOvj6w7jnOpcYiQt/eXkTQx0GRL7XjsHUYtO/jGjzWr0gqHDlybJdxyO8YpTxNMCLC1M+OdlM0AI2l8Te/qbHRHEbpovTt/lCGQOHyOCXW6/BikMbkksF23Tsh90NMO0Pr6+9NH4EnK/mJ1R1CqYY0LssRaHMQRxycZ3Pshw8NvMaF9Lec73B+XeJYip+GWByeHtG4uyryi/VAGFHMfJ/gUSnlWXVM46LEZh2GMh+i63PCKRHmKzGY9H2DgwttZEUC8zg5AiAAr2otWvDhoCX0XPp4f91zbdCyrrI3W/k4QiPKIA7HUu3uravXkPu04e5dFSnknsYS4DURddDEszgqIr9JfKLZhhnCjCHvvrpyALPDJFCLLySaqOxwhOCR6x0cNmlXa/GI+JelIaD1+w9/s3rXEiHDY/uA1YqNxQhOqRgn0SuILU/u77BG4iiiZNK4ef5ARMVQHIxth2Mi8pvEJ9qtvlhA29/Rse4xCbRsCsnRS04viW2su37jX9zJEQABVv9aJbV3GUGJfksXv4bc63NW1ldEtNRT6jeF1CHmHfQNsJaKMZPrw8T6+bUU7XtYRGEQiGIw5RuOcGdJnB/HgmLx3Q8qiwLOZpZG5xIRQhNbYKhNIybewNLaayn1tXDkhftaCxpLAMB8kAlG269yf39w5ZU0JlKrRVvFpIFFQixGx0Zk6AJAB2hs/Wol/thGxKnNkqO74bcfE8dY/Cy+QwBz7f+OjrHAW+cwCNnN1rsVP40lAIwVvTS2P7M6xepgarSLYuxjB3UouQCwBjGNNmYs04a4tV1T3FndZrBEYSoWR+13j5kVml4ZDQIE09Lyk6XS2RgCAKZiGgc1WvyGfM/Cje3+qbrv1lh5YP00lFwAWIMYoSCHMJ723ecHBrZZU9xZ3t5rBOXAv/W4FZ4l0F6pTgSIoqmd+NC8tzx7HkMAeEvmsTBmLMWbH8HB8JMwZcLXREz9+Yaxayi5ALAGMc68NLGShzQi7i+duhHAFE8TJnNIO/DuXOKld6Ppd0MR4BhQE3Sn4Tvr4DK5BQBwwOV4U5/Srjj6wl23JrpiKE/keA8X8rEYI6wOPWpyAWBDq75R0RihjYiCkdNmBPARnisoyJS9LG5G0Z8OQQCvaqF9eN17nENbO5vJLQBoY2msw0Z7/4gqJPN9JrzVv4kXNX5o0KEaQi4AbEDr+gaDwCZGn104xQ1Yah9dSunWd1M7NM8+qS1kYd+zhY3b5Q+JCCFoDxQRjlUw53JajwBa43806PvaqH9dJcwtAGi9aTZ9y+KKE5+XFOa7v6uNNPcIiqQ5dhp63OQCwIbWAkzcZ1ow72oaMLLTMATwWnV8ovagfebi+e/CIoIws8pzzf/4hEcQcNoeAba8scRpsIq94hFv6GC8fWm2v5NbAECTPhYDi++I7YEFws1nutpfbWHcKMfi9o/VxAL+dwGgByQLG+CuBi0tCEUPDMU8xnNVChNNS1OtMcHiuIRBs4vnVu+hNOW0LQJW1ie32jZZs/9yCwA3DuSlVd6K/Z/tbwQw9KJwDpZCiDJrjAQJ4QslFjt2rYaSCwA9iDFR/13RKOsa8w49+frjbgTYvkbSXYdr7H2sPqZOKEIR3nQIBvhwdzoRAY5M/j0Qvy6sv5AQ0NwCQGqnaAjzH6nNfjlyJRbLkuliCv5DIXIouQAQgBhBLro6uubeKwPy9Ve2R4CtQA3uXd/ifXCo9uz2JRv/DtHAuuq36R7C1FXGL/roJcD86kcR+K1iSyCcKySsTW4BQBN7YBUbVveEkMXNNj7vcXozh35n2dwoIa/iFvo/x05DyQWAAMRgVIuVQbshZxtIIQBPzSsMHm0cLX5buWnV1Ev7LcpDsZYS6LnsrC3AhL/H9OpjRnxFmNmUlFsA0DimoW/iQ+ChtZA5Vec8KdtzNW2NzsUnVhML+N8FgACQeMXCI9jqZMV5ttMwBL5nNFA3bRETQWtYifO8fQklLoeKCBPhEomImw0/aK6/ymCPnlsA4AxeE6nz3EtkKEWd8WkQy4NvjsjXBYBA0C6YQBfgUYF5+2snInARRefo6lR4zqJd50DXM8AGvxdL25J9ggFuDW/liN6ZWwCgb+DPoKnj0OsN5tC5MtYBU92hGDfvHxBRThcABoC2v6JxmkZqX7XhOQcUfRavamOyt7HnN+nNhYheuFq/mP9jBpGpYngnpc11G1+OEHIIT2MIAJ9T8Bbb/07hCHxRgfUDw7M56U0XAE6Cov8HGqrfUjRQe8Bofl+oP1t/o0bgKEPsCRM6JxOjMxnqqSwhGNJNDXf0CMKSa6t7DAFAExjt5T56DUIAHx3N3DD0ihXFUHIBYCBiTNhDTa02NSRnPk79CFi6JMWxyBwVkj6uGDzaPIonMiKqzZWIzqdxt9rGit97ZgRqDAHgcQq++mxGbKae1fkUOMOHMUKoCwARXHMWEXmXiGDyszoYDP3/u5m2DiOqWdQnz1ZijXOct1Xa3myVz5WubrilDR8/c4a8eW/DnRIwOigzM40hAGhMb08QkaH+6TNDWkx2eyjGOALXxRxBuQCgaH6cNqDIp92aRoHLaT0CrNZDvdt1CWBEE1yKgxFrM8nXzOiohL6q8bO+ylvsBJ55PdsmeTKGAIC10mrdh/yPgyWnfgRepcA51vmUCwD97dL7BluKQzrE6rvv7c1h2S+gXb2K2ZD/MeFcChF9DsdGQ/Dpexd9CXQMpkqYN1oLRjhQGiNy5BgCAD4mCMTTxyfrnvsxZ1jPYTd4HYZ9918QlsV2b7kAsB0kw2/sICIoAvU10rrnOBmiIZy6EfiqAlswx5/5koizQM2OSRefstrFLezU6Owiwjl0V50092I0ri2wG0MAoNy4643F66MWFZ95Gric1+xO3TUSHxcAIoFb/UzrTAQ3rk7bI8C5duzAw3e/FBEivC2N0Ai29l6JQ5jHRp41joE/AXmsBSF4aswdpbEEgCcr+iFHcHNUurXkaSZwzTiHt9oYcgEgBrWOb66lbEAiORHMxWlbBN6vxPWF2ya3qP8eosRu3YCEtUHJ5qucy6eI3wEenxl5MhtLAMChzzp+CLmPIqHTegTeo8D35wqh3AWA9W0y6AnnZNpgIvsNynH+LxPaVrMtxsCUMjDLFFrgOYqBZdPAjhfFpxSmXIlfh/uKiMaWelOdOaMdW0gfSwDYSWk6iemtUzcCp67Mbv+q6KcxLoCbkrgA0CBhcH2SohEZeNAjOINBOeaSBH76Nw3Ifc8OmwsQinogmL5dieMmnFl9cB4+pqkX5k+E19Za42yqJ6FWS4jdMZYAAAt+SsFHBKpa4lFcSNe9jQJXePaeIZmseccFgDXAxNzGPwB2r5sGkr5nT43JeIbfWKz+7zJDXGKqxPkrkcL6eE/zHEFgbxGhD+QiTDvvV03+30lcN2LWXy5XpXryGVMA0MZNmEPUzZ7miXrMCl7T984bleuJH7kAoACv69NXKhsThw6E4Fw6ab3a/UxEMIlzOhEBthlTCwEMYpjHvU9EWNWQpzWxo3HtyusZ/gk0ljehAy6TP5NuKTSmAIBQHopb13soSjtti8COIoL+VxdeIfe+uW1yg/9zAWAwZJs/uLjBuTVR2ZZMt1Z0iKbTcBzjtC0CTMiHGGDbYNx3RU8AEzAc8FxTRDhHHkrY8O8qInjw4yiDreS+fK2elzb5g92YAgDC108V+LO4Oe1QBpj5+/C1hl+1emMuACRgMI3NLMyA4tuVE5RrCkmyXX2MslP8XUR2nkJlRygjQgCTsmbQif0W19lH10IISmHPqALy4Gf+EbUeASaG+1be9V5cbblj/XGkYcCeoWX+lYiw4i2NxhQAwIK2GYpl+32UNJ22EPiKEk/t7pQLAFttYfbruspGpcPgzQ2Je2mE17D2gBHz+yVLA21gfVlVMwHHYLuEb74nIhcciGmu18cWAHZT8g0TntOJCGiPVI5TmP81beACQIOE8fWTyo7CQIsd95II23KNOQyYoYR5jiWBpqgrxyRaM8u5CQSfK9zt8dgCAKaWONfStLt21apg+aI+1fj+B3+CdWnJBQAtgmu+x22qppPwLWdmJZgerami6W12Oz5tgNkBpqWaf2KPMcBcy+elfI81Qeke68YWAOgRONfStNlb5t+temuItQzjuwbHS/Tm0v+CCwD9GEW/QRAVTQPzLTsJMWEeows90ocWXuvoUPjUdgpHQBPqVcvbpX2PnXvpVIIAcFnluIaL6pI9Sebggf2VGFodpbgAkLC16SgWW6xjBR5JCM02SXPeqpWGmUz+Z5tU/Z8QBFwA2BLSXQAI4ZgT30FBUyPAvSw8q9m9eXoDE1ar42EXABKz11uVHYVOhjnVZRKXc6zk8SB3uAFGaG27F8XhregCwNZE5gJAOP9od+wY084Wnt2s3sRhlkZ4Qk/KyiW1CwCJWetcIkI0LE2D8+33I+2oE1dPnbz2PLHBdS91SZaZgAsAW33TBYDwPsAqVjuuPTc8u9m8ifdKbYRKS4dKLgBkYK1HGwgATHQ4QpkT3c4Ily8v1GTSghdcAHABIJaPMLdtBPCYK14jSzW3jMWk7ztNWOUGY0srChcA+lrM4Dl2199Sdpam8R9pUJ4SksBjosYFZoMHzmVKdNhSAsYhZXABYGsS8x2AEI7ZeueiBjpOmkh2WyWZxi/Mk7W6Tp83rqoLAMaArksOV6gWCoFMeLdcl8lE7uOl71gjgejlE6lzqcV0AcAFAA1vfljZjxkTLVe0mrqk/tbC+Zb12O8CQOpWb6VvwQCsfJEisTCYImFn/QXloNGs/vFLbqUMM0UsLcrsAoALABo+YmHT9MfY6xJMnRmvWbzFYsR37CJbm4S7AKDh/oHfnk5EfqRkgoaBjp+gkyC8iFnFpmflcKOB+Pvr2yOgEQAQ5AgRe4QRTze8HXMlSBDKURoNaz8C2J4/Qu58xqD97xaS0UTfYdK28Ax71wT1dwEgAaibkryWgSTYDJA/rMKinntTZgU9w9Pf6w0GiqbuLy2oblMuikYAIGBPQ3isRNmVSRR3zE07pbx+tzIl4wjo+iJy8rog9K/YPF0AaFpz2PWGCsybtsKM90zDsp3M21goNfWMvf6gxeOWFXcBwBLNwLSeZcAQDSNhHnj2wHzHeg0J+JXGdcacxkmPgJUA0C4JSq9EsyTK37tE5Nu1L4uGZ4de2e1hx4sJGtMxwkWvi/boAsD6yQZrmVT0RYP+bWnelqqeQ9NF8e/3BtjcZWjGge+7ABAIlOVrOL/5ugFTNAMpPsxL3Qlg5Y/Xr6as2uu/Fhwq2ZIHm7RSCABN2u0rQiA+MTgzvruI3K8SCgj/+1QReXa1+ntRKzzwQ6u488RJp2z4Ox/in98FgPV9LaUAoMG9GRMQ9Ig2OCd6r8HYx1yRKjKsCwAjcdvFqhXSnwyYo+k8PxYRTOtKIgSddxrWkbo+qqQKzqAsuQSAXFBpJiI/AtC10gcN+johbnEyNAe6gwEejHn00VTkAkAqZAPSvZWRaWAjBPxWRK4akG+OV1B4tFB8aerGFQVCay3YHFiUnIcLAFsrZhcAdJx6aSP9JtynT52YWBmP2+NXzO/UPOkCwMictp8Bk7QZ6+8icp+R67SLoeOjpm5HVee/px25XnPM3gWArUE69WBrwT8lRAPcVI9XGI1nU7YKQCH1cwY4EDVx101gGzxzAcAARE0SnO1YhA1uJsrmitIdW/C5iW0vrY/wpg7NFSWaC+euyELycwHABQBLVkeT32Lli5fQi1gWLGNaVkreL85QZhcAMoDclwVnXmhKNxOe1RX77Ev1ZW70fEcR0foG76o3Sn83NiqjJ7M9Ai4AbPU73wHYnj9i7qDg2dWXh95DuXlqu343NTrWJWBQDidnLgDEcHiCb9DiR5FvaCfpe5+AG/uICKZZqeh6lWY3Pgn6yjL0OVrBaIw7pUPABYAtvnUBwIbPcPhlEeKb8QJfE6k04G1qu5UKStgWJn/Ue4+tZJP+cgEgKbzDEoeB8Gg2dKIMef+bIoJ0akk4f3mTkcTbVQccyzilRcAFgK3+5gKAHa+x88jio6tfD72HnlTpZBnf5CMZK+sCQEawQ7K6SuVR7a9GHaero+G2U2try24F2/3/TFjOA0LA8nfUCLgAsDVJuQCgZqdtErAIfcsYxk7gvbZJuax/dhARC0dI1BX9qfNlrJ4LABnBDs0KH/d/Szi5wmicrz2smsjPElgojhCYLD5Q+VtHO7VLuLC69xo39wtsFf1rLgBs8bILAHp+aqfwX4YOzxhzbttOvJDfHHfg7dJq7HtA5nq5AJAZ8NDsrmsQOzqEKYlQdWTtYnXP6uzuJiJy+XqX4M4i8sTKt8DHMpWF8rKz4Lb+oVyif88FgK3B2wUAPT+tpnBJw9gQmDgzLpZCTP5vMZz8WVzlHvtcACiFmzrKcbVqlf4HQwYLEQjGfOc5I3SADtgXdcsFABcAUjP8Aw3HMLbIUToem5j832xYr58P2I21rLsLAJZoJkgLxx+pFAPHnOxX88YnvFN+BFwAcAEgNdexqj3IcLJkJ4CAUGMRjn4sJ392YYmoOAa5ADAG6gPzZHJcnTDn9D8+EJzGQcAFgK2+5UcA6XgQm/ZjDccx/IOMYSKMi/OPGtaDcfwp6WDvTdkFgF6Ixn8BBpnThL9al2+MD/FiS+ACwFbfcgEgbTcgVoC1hROuh1P6OGkjcv4EDtvQr+I4YSxyAWAs5Afk6wLAALD81UEIuADgAsAghlG+fNcEi5mPi8iZleXq+/zaIvJL47Ifk8nb36a6uQCwCZ1CnrkAUEhDzLAYt1AManhpK4004YA/XVplOspTejCgjiJvd+sZCp5b3T1s/ieM8A22y0l/Axv/5xlFOWzKyhWPgYSEH5tcABi7BQLydwEgACR/ZRACRGxkYNO4Lp2bAIDDmUMrHxkEtMq1rTyo0So/HHMQAFAKfFsCIYCJ9UARISCRBV259pfSnrgtfuMh8ToWBTRIwwUAAxBTJ+ECQGqEl5E+2ss4UznEyH3z3ASA9uD+s+psFhe0eL0sieYgAIDnqYxC5rbbrPn9q0rXADfiBCiLoUtUQdTebdRHmjI119Lim7gAEMMhmb9xASAz4DPL7pxVfeChnxqvuvBWyWq5FMIf+xeM64gHuvfW28u5nbR04ToXAYC6naF2QtZMjtZXzKdxR3zBLiBX7rHjgwdWHPtglmddlia9R6zkO/a/LgCM3QIB+bsAEACSv7INAkxWeE3DTSkmU80AZH1lRYO3yLEjthF8BqUq6/q10zu68tX+SMMt5m0aLPCfOQkAVBlX5Lglb+Oc4jfB0NA9uGctzIEj2/D3EZHXishvM5SBcbw0cgGgtBbpKI8LAB2g+K1OBFhVEePhuxkGtPZAzbECOw25CUHnIRliZ7Trys7H60XkSrkrOxMdgFXYziEiv87Mr+32zPGbnYUSyQWAEltlpUwaASB14J6m82i2zdwPwEqDR/xL/AaCKFnbWTftG3L9XT0Z51Kgu6yIoLkfUrZU7xxRR6o7TUSbxXwytx2ABgPGgFRtVEK6Ja7+wd4FgIYDC75qBIB9ReTGtdZtigiDX65cFT+oDh4U29FcAIhjPkyU7lEFcDq8sMGTLd07iQhKhykI86nXJT6rHcrLWFO8oOpnF01R4VaaLgBMU1BwAaDFxP5zGAIaAQAlmIbYHt69PvM6PnLSOEFEPiIiD18Z7DiDHTpoNu+7ANC0UNj1InX0RlbcDYYlXn8kIo83im+O1jj+37E80Ow2pcapMSW8fSJTQhcAyub5dfzlAkDY2OZvdSBgJQCsJo1rSzzBPa4+03yfiHxSRL4iIp8XkQ+JyFtr5Rk8eF1ORE65mkj9vwsAa4Axus1q+jYigtczJpl1A02J9ynvYSLyP7WmdYjXNmLJw1NEknv7RKNiYkpIHI9zGfEAybgAMC3eb/qjCwCGnWBpSaUSACxxdAHAEs2ttFCQ2qc6Z47dsWkGoNKu7F4gaCLQvFNE3iEiH6wFUILG5NJdyYELVhjvqYTq6xuEu3YBwAWArdFB/8t1APQYJk/BBYDkEBeXAQP9G0TknxNb7eeYUKecB6aEj1X4rncBwAUAy8HKBQBLNBOl5QJAImALS/a0tV0yNstTnuS87P3tR0x7dj2uN5AHXQDox7ZE/vMjgIGM7q9vIeACwBYWc/yFbgVhTf/iE/8iBR9MCXFIE2JK6AKACwCWY6DvAFiimSgtFwASATtispjw7Vkrx5W4YsnhGW2senOs8ucChS1MCZ+/Yl2zyqIuALgAsMoTmv9dANCgl+lbFwAyAZ0hmwvVVhUlej7DTwR6BzjYweyO32NN0qnyxT88LmB3qlfdXyu0jihI7tFhSugCwDR50o8AMgyuc83CBYBpt+zJRORWIvLRQk34vl07czrdCsy42cWOv2S7+yGCwlcrB0LnXakj/16zNnclTOuQ9HK8SwAnnHk1bpZdANi+jb6UgUfZndHo5rgA0NHx/FYYAi4AhOFU2ltnrwamJ4nITwqcWNgGx75+twDQUFQ7rsA6hE7ACDAvFBGOXTbRWWuBBwdGoWnneg9TQkLUEk0uNk+8dpZKGlfAmCBfoNKheHaCoD5fb+ln4FQtFnsXAErlvAmUywWACTRSq4is0ko14WNFSVS0oXHusVBAUXFqToh+WG/5t5qn9yeRDRF60NKfkz+COQsATaOy23b12i3zjyMnbHbEGHPpx21yAWBbAYhFgVMGBFwAyACyMgu2z4lKlyO06dBVCCtg3DffUkQYIDVEiOFSz83buOCyGs+DIZr1m/BgZflMEflV5GTSLtPYv5cgAKy2JYLuLWpnWgfWrqQ/Wzuh+kQdLvtldd+9RuViG0F3HbkA4ALAOt5Ich9FLDTFj1IMPu1YAEkKWSeq8QSI+RtCTnPOmbKc1mljwvfKwk34bmhcaVbIKKiVeCzAip2oiJbud4EP98WcA489iWvyL1EAoJ3QcdCYwDL25CCNAMAYzljedwyVox7tPNwKoI1GIb/RFH+O0XnWFASAZlBrzjnZfkUBrVQi3O2dReSLE5kQUJJKEZmPuBB7VUF6OCdt2nCsK2Z9LxERAiWlIFaPY9XNKt9SBAD6Nm6RcY9Mn9fWbwoCQFNHzGsZ2y+cgkkj0nQBIAK0FJ+0NcUtta5xMoI/+ZRE2QmF2jC5xfV7dcRBIhiWQkx4Dy1Uqa8P8/0Sg3jtWqnwr8Z80FcvhI9HVfbzp09YP4S9vnJM4fnYAsAZayXG7xvjOSUBoOETdGmwCsI6SHssp2F9FwA06Bl8e7ZK0WhvEYlVWGkYatMVxS/rbeCm6jAQZ2mb8tc84yz3tSJyhSbDka7Ety9xyzsUW7bGOeNMTacWEULhYmGQwpkQK8bDqxgJT0i42m9jRMTMPyTk79D2s3hvLAGAvksfpi9b1GM1jSkKAO06YCWEtRBWQ7nJBYDciNf5XaseJHMFe0HiZBvT6myU1TAmSX9M1KnbHaT5zQB2TxFhkslF7J4Qg74pw5SvmLfhACcXsdV7idqM6vVVKGCOIoY4QMJfPkqV4I+OCNvGO+YqfBXKF12Hz82k7eFbTO1yHa3RR+mr9NnUfWbqAkCDD3MBlifspuVqJxcAMg4oaJg+qFohYWbSNHruK1L4Syvh42KR9War9ZEjr4YJJfu8ynnLLpF1CP3sHjNQ/Frlr5eHVj7he1hMXLoKBXy1elJnx4C/m9Ume5hfMTAxAY9JGpv7VdxL+f8Dla7EWRKCSp+kb+ZUmJyLANDmEQTfB1dYrjrnsm46FwCsEe1Ib1cRYeAtzf/4kbUGLisrtJy7CK1VBmRM3A6uHKWU5C2NXY1DKg9dtzVWckNQe++IQlp7IKCOH6t1DyywJz1M+Zw2I4AyodWWNd4UnzVw96PNA9a/fx7oAGozQltPUTClD9IX4S/r8valhzCZgzTm2H11WPcc6wisjHDPnYJcAEiBqoiwRX7XaoXz+RE6xDpm6rvPWecxld0sLlNR1EF3oO+bUp5TVgtTQiwwSrDl5/z8gBVtYYQwC7xxjpPzKCBRF0uWLDsPVv32da1SYtZ7NxH5glE7aniB7WYiEGoIs1363NjjRC4BAHNFDebab7E6wvwWPrIiFwCskKzTQWkIT2tzcByiZdgxvkdJ7F31KnfoORpS9i9G7uSH9dgLv9OofC825vs5JYelhwXvYqGwTl/lMoWEgGZnYkg/4V12kOhjFiZ8Fjizw5qDnmrEF9o6E9AKt8cXNKi0CwAGILJi4PySLXJLEz4toyz9+yGmhEz+Y2l7Yzr36g7Xo12syZng0QYDEXw6tmVFV/3GvoeS7J8M8EU5NsQnAe05tl4QcRL6hAB0fx4mIt81wMZ6XEKYykGlCAANfhYePl0AUHDOziLyOBFhS7VpFL+WhwVnuXiHu/yatkaSHmMnsGYEAAAX5klEQVTlz2DKanOoDfsVKzM4C+sRfESMaYO8pjlGvY1zGos+zFbtUCIwE+aTFm07tA748egi+gx9J7d/hyHlT3U+vooHvjSGlCvnu5iRP7HSNcOsfAi5ADAErfpdlOIIjGKlJJSTUZaeF3HWOftsfMSjEc1OQS5csMdHE1vr7XAfozIjgDidiMCNjTBle1xDRCV87AgLCxwqQegvYZXxcSM8UvetXALA/hPAY+j44gJAzfR9F5Sm7leI29PUHWoJ6WNK+Nxa4TFHfY+vA5JYeWVk5W6hqMZW9RgOSPr6W+7nnNVbOHpiJWblvZI2JoATgZxyHC2Sx5sSOXBK2ceIx5GDpiAAtHHG3JzjpU2mhC4A9HDOJWsf4zkd3rQb0X/nW51bY41JFKuo2xibKTYsS6Q6C9PStqZ6k/bSrppALw3f0N7XSQQc1ikofqEA1uTn1xOxWA3bm6gJ/i+65BQxZ4xgx7pLV8IFgA5u+a9K2eWOlUemTxfa2XCFipMatpFZWU6BKdEYfrSI4AHxbYX5E7DGr9ldCFEC62C/QbdwFqItPyu/XIPooMplepmQsRZn3DjYSk2YgN299qqobfe5fH+l1KDX6SOATR0zTFAxRW1MCV0AaDEPYLDNM4ZCWB9jMUB1KbKhiIgDjr7vx3yOkLLqhx5lFZRWLLZdx6xbO2+UQe+bOeQnFijEN2+XI+Y3afRpgre6yqx+vtkAv9xulmkAtr7RNxjD+U4Mj6X65uqZuPH5BnySCoOh6eKS+5n1gmzot837jN2zIOxI31KQXWsDMFc0xTG/2XSuyCRw/xHN2Nrlbf9mYHpVT9lzn3O2y2f1m3Pfe1fCI2GCxyDcr/7NYHC6wxiFHznPKxtMoPA53jTHIhzhWFkvWPWJ0HTYffpw5eDmWAX/pjp2WW1PdnhC67X6Hou0Ek0oNcLj5AWA81b+5N9qMACsNrb2/1hnNnjmQpChU2nLoP0eN8Ns9w8hzPFwTDKlc843VMqEuA4em4iOp20zvD+OJcSMhd9nDHArRYcCd7xT6TusQOnrjTMbzS5mqkinqzzJYia2jz2g3mErzYlSbH34brICAL6rsd+3WDVpAFz9lq1ylJG0muLsaBBBTSPdrZYt9P+jKle6rCQ128mcT2FHjevL0Hxzv4dSaEkrZvRWwF6LA0cYS6GbGuCFy+aUwXWGtgVjx6EG9dLy0brv6dPtM+imfjhRW/dN3/2bN4kkvhJNta8s657vtVK2UtworytvyP1JCgBo06JEF1LBHO8wSSP9Wge0gd+I+PeiDCF72XHAth07ao4jLAkbX4JhEBQjR3uE5MGgX6IXPVYXIeXf9A5+3QkANXeCT3HVuwmLkGclCkwIg+gGhJQ/xzshAW00RxhY2eQgdldj8SIuTBeNHUgptj58NzkBAEkxZ5jKTeDmCmkL0+H05na1ja9V/TmmQHDBzhT3qakJW1Y03scO1IOCaK7wozGYYmGxie9Cnj0mJuOJfcOAHILFpneI22At8FrByMTC8dSm8qd+NiSkrYZvsdjKQZo4HIy/fdSEUmZuSN02FulPSgBAka6Es/Evi8g9NwQJ6WMS7XMGBlbVDxQRtrQwC+mzesA3OqslpPS9a1vnHbUFUXw/lstUjozWuRNWVMf0U7YWtSZtnM+O2b6mgHQkhuIp+g6aQZCdO1wyl0zU86PKeg7FCDfGuDOmjw45BtRsr3OkkIMOUmA55JgCp1TMEcwV/3975xqyTVHG8fnUgU6SVkRFVmhWRlEfwuSVirAsO0iRSWoqiJ1LU9BKKzqYvYlpBYYVpRhEB99As6JIrMhC7KSVphVEimWURXnADz2/fAbmWfa+7539z8zO7F7Xl91779ndmev6z8y1M9chlv8lyzejAJw9MSMJGfyFSpeNfcdh2ZcQpASXQUHYb/vLfl0UKX/vVEdcCVFIsMIvAXws/VugFGlLidkwV0rx9X9JI8zZeyu7JC6KufsHfZC+ODaqJNt8Y+uopjUeKkpFmTp06Es65dhqZO6oMex8EwrAlBmcYrLRdeRuPyM4UMKVsJUBH7bx9X6rMKAyELMqNEdbAJbs1W0kVlhKbHtFdIG1RZlEcqTuZRWESfHVCZJKYas0VgEopaxeI9TxkLUS2vwnbuAnF85bskke1SsAKaKkbWJC93862tcTJHvZDAkr0ceBHCFTsfhndaQlYgmxi83Y33NMFHRkAr6wwtIaKT7sXdxgBPuJ7VXCVHxQ4uyTpa8EKV42qRIWsa1CBFjmmBxKXVfW635XrQDgG1qSQVhPMzCwB2s0PQe8K6GitXvwt2gUx6rI9eJkh1sqFuVzIQZP1fL/r43aR+Cq+E8RD6SPPi7TyhDZD31/iz1eUAigyqoaW6upibmGOYe5J5ZnKcpXqwCwPIeWmqKRQ59xVYJlsNQAsefdb6WtJHJiEiQ9aouEa+lQ/K4qV8rAqgR/2Ydd1c6h11mGbZXYox/azr5yZEPNRTy7751Drn0xV6U6z1WMa7HFyEUE78LL4PuFY79UqQCwx6dElRoCuFVlSi1F5QLSHJ9LNsdV8hpynaXJVokv3uvE9hPRcS6kGHGBFZRBn0SlRZ5goKesihI1NRcdJeD0slyVCp7LStiQ8WJVGbyvStABzjlyFqRy917VHq5XqQBgqb2u0jn/w81wypjgJQDW2jsUPGDk5EOVttZuX9/DE/SHUrHWfZ1zHImXjzyV/p/zCzhHm/ueuUfgAZb+uUiJykjkw9zEFspY7BAIqTThSkj0wWuFem9qb3UKAEIqvfTfZRLW02NdYUqDZAnvw4WmK6Ohv380Ewap/sSXz4APLBMPlXtfOSa/OdhDEDWvr31Dr61LSqbAhIx+Q+vQLYdtQm7CuLj73qG/sR2YkohXQZwFYjQMrfOQcv92zlXlJn5+4gYOYUJfGTRSjLCMpufAjwVMtLz8H3JetQVgZavllZB9EuT9eEfI0IbP4YWyEhKb4Gsoq5StOjIJ5iYCgPWN9UOu4T1QA2GIyAdRyoB4Z9XQMOpAEoyagiV8oBbGLLwe7NsO6aR9ZV42E95hF3ODwAd4Q+a2Vgkvjj75Dr1GZETCac+FlLS0x2digrLEfndk1MExTThCwFCJLYqYNh20lZDpFqE9Yb/BsyTXqlBMm9y5iRr0x0TPQcuaw95plBAqK4zhzX2CPB9ZWXuU6jBwhx039pxJsEVvCJSfm8W2n6EwvsJ7SV8cK39fHk+CHITB6j1CvYgKmpNYAfI8iD2SRKg22iuhsfzkcTHQzlNYPWJNipXvlYKwQ3Dc1mAAmdqAqtRnf0GOUxjuKG3ddC/716q/8KqMZpvePeX/LxUwQF9mn5PBck6kREf9dEZGYFQWjp8x57nzMuwW6kbQpBqJuY608TF87it7x9T2MW9M0Iirg0awHKUsHYdMwiWRrxCjshwgjC25x0NZxJxXZ+GagH2qHzh9pDVS0syCl5wT3lS8JMJjTF8Iy+b0uVeCdg3JtqfwW8lWeIry4sz3EkMAY+dQxmPO8TaajNQvdr7UmfRDInazsnwcMvHM8MF2np0DKFxK6k5kNyf/d89wME5GwxCbMeetuUVi8KYsK9NeUrTOjZRkSGT6y0WKspZ7kiVrakxfCcuWSlc8Vi7YzzEHhnWOPb907MvV+1ieU90bXrmiEuoXk2ciigTpMY3KcOAcEczI7Ydlqlr8LYpbJHxpybhV2belrd8qLp0yLyR5jx+bYo85g+6w2hJbH1/+vMysU1aEc3lOpGyyYuSIDNgyncRQVgEzFSc62CriS/K7Aig9ODmy//roVS+y68k4QGrQkO9jz+eqADxH5A8uVxhstUBqFMS5eIF0ZaWMmTkVgPcK2CQ5Ti5imVxZDSa1egv0A4H/jLOTbAOQCGLsIM99z9sgGbLAKUkgwrqhbJg9wAaGC3+nTAA1VwUA9hI4JcRl7Lma2lQQ8eBbifwX266wPDYgc43lUasCwFJ5KIOYcyLe5aInCfUi9HIrAaRwD4zhebfsJN4AiqEXEdKGEEs4igYYMuo9Q15oZaI58PREniBeVnNWAN4sdnRSy9ZOHxPbWE2AkwyMrlUBIGWu73+xR7w1cq1MsRIUWx9f/sYM8sv5yF8Ibb0iZ8X6ns3XNIL3zI49xkT3er/wnrBeaIS7+hpj10ZzgNDLigtRKB9/PmcFgPCdSmaz2xv4OlYCnaDsk1F0rlSrAkD8eiVKHV/qOUhJVfzNHBXK+EyMKf0YGHtkXChKdNLYSoblYyx8UTZItxjeP/Ycg5Ku10FRxs3oZRie5Eh4MWcFAPETG3wsfrmv5iBXSthW2jaH3AfrunitCgB1VgKxvWJdo4X/LhH6CgbJLZG6dYZHQTFS9iwIXhBLRJsi2Y8ycPp7sTA2e4BYCewszx4tGrbnacrj3BUAslYq/Lpwpyiq+kXYYqVttbttqcyuWQFQXLpzba/+UsDTCaqwCt/PmHqn0N5NNnVJm6Nkthob1OTF4jJVODCxtGQ0ngPkvQ75mfJ87goAHV3x/a15GwBPhbFY+NdW3gOWoudMNSsAuPONlV0ODwVWGNm2HVun5zcIJCXmwatKtvcYQTBEdhpLSijNEEgAizSYRvEcSOXuF8ojPJ+7AgDHVQWqxsFNXcLMGekuHuV57qhZAXiTMKbn2IN+oVAfxpMW84koq6pvyAPZ/qeeKAjnov5HDrrK15PqM+knG/KM7z3orVbIc4C9vlReGV4O3eMSFADip3fbHfP7o14gFR1ZBo5pQ7fsoRW1JVdValYAVEymNgQ8XcAT9gwtkhIsjDm5GCnuTKorE8YOaJzdAWTMb4yOcrmwFBNGoRcRyEbx/BgqnyUoAGBO8Z74VSGZx7xGWb78u3OOoC9zp5oVAPiveKik/gJVkuVMFh5XBDBz49BxsluOObkYTakA0EgsoVN9iZ5ajGvtvgil688COLtgXfd7CQoASDhf5Oe+FcGJSJuKGxlpcpdANSsA8P8qAZN8vaYi0omT737dOLHuv7ekqkjh55gCEMHwjwgACcFDPgO8Goz6OfBw55xijRvyesj5UhQAdY/zpH5xTXJVsQkCE0UNmCbh0P0vrV0BOFsYU3GxTrWaSsTLIWPFqjIENmqRTAGIkBpaIh4Fq0AQc/1PjRqNRLBrVFF4rLgHxcjAl12KAgBv/ybgl6yLtRAGfF5+sUeSmZBCeglUuwKAjU+s/MLyByYS4oeFeuBNgq1Yi2QKQKTUHicOoiF4scBMpcFGNqPa4vichzwqcb4UBQChK4FOUB5qiWehbA/tqRb96StWuwJAGmdSMY/t56clYpmSM+N7ieowxWNMARjB9cPE/ccQ7CePeP9cb6Ezh7wpdb4kBUDJD488aljqPEDECe5nS6HaFQDk8DtBnj9LIMgnC++nT7SUNrvLLlMAuhwZ+FtNQOInt3u2cpHjDrN0ek1CpcrzduhxSQoAYakV47lUX1wK3t8qDtip3ceUtuS+twUFQJmEWD1gAlfoDBFPJJBrlRTeL8oLoCtg9lOZOIZOMuvK4Z7VYhCJLk/G/iaeO/uy63iU878lKQDIiMyYY/lZQ8KTrwj1/+1YkDZ6XwsKgGoHwASukJIVD8+Blt1JTQEQkPME5xx5BsYOpuF931ioPQBfY6lyLoT8jDlfmgJAUJ8Y/oRlsQOY2m5F2f+/QOjvLd7aggJAOOa7BEzeIAgGI8IQ37HnKKMtkykAovQOF41YQsDFpCwWq13F7Xs5534jdsCQf2PPl6YAvETk+f4ToueJYt3JKbIkakEBQB4kTBvbf7lv7DL8Z8T34o7aMpkCkEB6u0UQeeBjD8By+BLoAQlTLsM/JYnH0hSAh4n8Om5CgB4l9DX2i5eWmrsVBQBM+XFwzHFMvhf6AS58Y97HPXc75x4xYV9I8WpTABJwkT2gnwhACgF4ywxANYSlRGIL262c/3erI58iPG9pCgDyUewAPjtEwJnKfEqQ868z1anmx7aiALAayIQ6dhzg44kU7jFE9L6x7+O+GuxhYtrbV9YUgD6ujLjG0iTxxRVA+XtrCrgyghUbb3lfIj7BLyzaWdYl06LnX+xxiQrAuQK/rt0o4XwFlPj/LPcujVpRAJCLEoufPn9OhHAx4r5Z6AO8L3UugojqJytqCkAyVjr38oT2ALg6zZFel5BHdMJ3bzPJFIA4tCCHWEXJl+driy2c0kS0NSV5TOv7tWP43ZIC8FoBk2ATTyJyRAwhdcsB6/+HDHlR5WVMAUgsoPNEEPtBluUwsuHNiZiklWU+zxt/DNM8mwIQhxS8LzwfxxyfFfe6JKWfIdb5qUlq0dZDWlIAUCrVrKvkFthEKJI3ilhi4pwDmQKQWIqA+KciuPyA/HvnHIlx5kD7JXSZhD9YDbOM58kUAM+J4UclL8AUhoAsufq+EXvki62WMMbDJaSXbEkBoLWqQTXpwzfZAhwv4Mjj7rm6aKp4gikAGcTA19U/EoAMsI2xbs3QJOmRezvnbkrED3hC4A4seEMyBSDkxrBzxfXqk8NekbSUMjm0HK9dYWJrCgAfCkqkSsaHL61hGFb7atyRFOGH11Sx6F+mAGRiN4ZpSpILr2lybDl2+QMTRkyEF39xzj2+R2amAPQwZcMlJQPadzY8O8fflwtK5MdzVKiBZ7amAMDSywQ5M0Yw7h68QjYptmhfv+LZLV42BSCj1Ig6Fk7kY8+JkvXsjPXM9Wgixn05EQ/gHct7q5LRmAIQL0XFp57w1aUJF9mxfejY0pWt5H0tKgC7BDl7fPy8s0WIOJ4pxr/g2aRxD7ceKxHz6GqYAjCadZtv5OtX8bf2YOaI0Up32XtzDaYt8aEEHdnz4D7nHFEXV5EpAKs4s/o6A6Lnb+yRr6yHrn508n8eLC4Nr1Ick1e0sge2qADAwhRxVc4KZIFtlpLy1/ePdwXPnMOpKQCZpfgU5xwGSB5AyrGluNOqm02XT2/fICdTADYwqOdvAljh0tfl9dDfJb1UWAEbWq9uOZRHFIglUqsKgBquGgwQHfSgbaHjHdDFRezvW51z5C2YE5kCUECaqn9rCNQTC9RXfcWLnHP3Juhwvt3s220iUwA2caj//+sFOZXcC1XiFpBvfqnUqgKAvK4WsOnHDoL9EJ9FNSzkeW+bIYhMASgkVDXphAc0YW9Zuq2VnpbQA4I27xnovmUKwDhEwF+Prdjj6eNeOequ04R6Yjy4VGpZASDBTywm+8qnmPzZ+2dLd27UjAJwkgCGz1cgtQc5564T2hACm5zmJfdfh7LvMc65PyRqI+3FfmJotC1TAIZKaWc5JSTwhTsflfWXokCfn7VmdT+8ZQUAzpImPRz7pjovudpVElHMjWN5ypxcjI4WKsoSYA2Wm/i43im0IxTUxcU4P+xF7LFek6httBON+7HDXv3/UqYARDArKKokRLkyeE7u0ysEbC0tzXYoi9YVAGKqsOoZjn2lz9mKwKNpbsScyNw4lp9FcyEcJlSUBl7qnNu3AgkeKbYjFNYJFbSHKhBh7WsJ24XR5IGRbTMFIJJh28UVYytWokqRYqvAHvBSqXUFALl9MOHYEo6fQ84xIG3RBXsT3lGsVBdtxo5ihDX9EIFZGeOTYcAwYBgwDBgG8mKg6Ac1X5lK7HIDQ14wGH+Nv4YBw4BhYBkYuGOgcXbSFYKv2iqArYIYBgwDhgHDgGFgUgxMkqMmpT+9aarL0FRNziZnw4BhwDCQFgNHJP20H/gw/DBvM81vUs3POlLajmT8NH4aBgwDLWGAhGyEVp6ETjUFwBQAw4BhwDBgGDAMTIKBSfMhsAqg+C62pGlZXe3LwDBgGDAMGAZqwcBNNUREfIFzDv/MWphi9TBZGAYMA4YBw8CcMcCce8gk6/49Lz3TFABTgAwDhgHDgGHAMFAEAyVzf/RM+TsvEZrxIhN8EcHPWau1ttlXm2HAMGAYWI+Bknk/ds70a36hBOw2JcCUAMOAYcAwYBgwDGTBAMm0CMRXLR3rnPuPCT+L8E0zXq8ZG3+MP4YBw8AcMXDXVmr3d1Y763cqRqa9b5sSYEqAYcAwYBgwDBgGJAyQfZP8O83Rrq3sTXucc/caACQAzFGjtTbZl5phwDBgGOjHAHPmZc65g5ub9Xsq/Cjn3DHOuc9t56m/3TnHkoYJ33hgGDAMGAYMA0vGAHMhc+I128b0Rzvn9umZR5Nf+h/dYNYfg3c/oQAAAABJRU5ErkJggg==">
							</image>
						</defs>
					</svg> </span>
				<div class="advantage-content">
					<h3>Tạo kết nối chân thực</h3>
					<p>TikTok cho phép thương hiệu xây dựng nội dung gần gũi, tương tác trực tiếp với người dùng, giúp
						tạo dựng lòng tin và sự gắn kết.</p>
				</div>
			</div>
		</div>
	</section>
	<section class="why-choose">
		<div class="why-choose-header">
			<h2 class="why-choose-title">
				Vì sao chọn Homenest<br>
				cho <span>chiến dịch Tiktok ads</span> của bạn?
			</h2>
			<img src="https://homenest.com.vn/wp-content/uploads/2024/11/Group-1203-1.png" alt="Floating Cube"
				 class="floating-image">
		</div>

		<div class="why-choose-grid">
			<div class="why-choose-item">
				<div class="item-header">
					<img src="https://homenest.com.vn/wp-content/uploads/2024/11/2b86011f5a960e881a06864bdf31104e.webp"
						 alt="Experience" class="item-icon">
					<div>
						<h3 class="item-title">Đội ngũ giàu kinh nghiệm</h3>
						<p class="item-text">HomeNest có đội ngũ giàu chuyên môn và am hiểu sâu về nền tảng TikTok, giúp
							bạn xây dựng chiến dịch tối ưu và hiệu quả nhất.</p>
					</div>
				</div>
			</div>

			<div class="why-choose-item">
				<div class="item-header">
					<img src="https://homenest.com.vn/wp-content/uploads/2024/11/742d8124a092da46c719c0830e8acd75.webp"
						 alt="Strategy" class="item-icon">
					<div>
						<h3 class="item-title">Chiến lược sáng tạo và tùy chỉnh</h3>
						<p class="item-text">HomeNest không chỉ triển khai quảng cáo mà còn thiết kế nội dung sáng tạo,
							bắt trend phù hợp và đối tượng mục tiêu, đảm bảo sự tương tác cao và tiếp cận mạnh mẽ.</p>
					</div>
				</div>
			</div>

			<div class="why-choose-item">
				<div class="item-header">
					<img src="https://homenest.com.vn/wp-content/uploads/2024/11/c0a48c68e1b1cd5c6114f5bb10159b56.webp"
						 alt="Results" class="item-icon">
					<div>
						<h3 class="item-title">Cam kết hiệu quả & tối ưu liên tục</h3>
						<p class="item-text">HomeNest theo dõi sát sao, phân tích dữ liệu và điều chỉnh chiến lược trong
							suốt quá trình chạy quảng cáo để đảm bảo đạt hiệu quả tối đa và tối ưu hóa chi phí.</p>
					</div>
				</div>
			</div>

			<div class="why-choose-item">
				<div class="item-header">
					<img src="https://homenest.com.vn/wp-content/uploads/2024/11/faf489feea0c06b26b8ac0a88b870386.webp"
						 alt="Success" class="item-icon">
					<div>
						<h3 class="item-title">Minh chứng thành công</h3>
						<p class="item-text">Nhiều chiến dịch thành công với kết quả vượt trội đã giúp HomeNest khẳng
							định vị thế là đối tác quảng cáo tin cậy trên TikTok.</p>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="service-categories-section">
		<h1 class="service-categories-title">Danh mục dịch vụ</h1>
		<h1 class="service-categories-title1">Tiktok ads tại homenest</h1>

		<div class="service-categories">

			<div class="service-category">
				<span class="elementor-icon">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="64"
						 height="64" viewBox="0 0 64 64" fill="none">
						<rect width="64" height="64" rx="12" fill="#D9EBFE"></rect>
						<mask id="mask0_3799_23358" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="12" y="12"
							  width="40" height="40">
							<rect x="12" y="12" width="40" height="40" fill="url(#pattern0_3799_23358)"></rect>
						</mask>
						<g mask="url(#mask0_3799_23358)">
							<rect x="0.890625" y="-14.1113" width="76.6667" height="95.5555"
								  fill="url(#paint0_linear_3799_23358)"></rect>
						</g>
						<defs>
							<pattern id="pattern0_3799_23358" patternContentUnits="objectBoundingBox" width="1"
									 height="1">
								<use xlink:href="#image0_3799_23358" transform="scale(0.00195312)"></use>
							</pattern>
							<linearGradient id="paint0_linear_3799_23358" x1="0.890625" y1="-14.1113" x2="80.3797"
											y2="-11.7027" gradientUnits="userSpaceOnUse">
								<stop stop-color="#020C6A"></stop>
								<stop offset="0.567007" stop-color="#1A85F8"></stop>
								<stop offset="1" stop-color="#66E5FB"></stop>
							</linearGradient>
							<image id="image0_3799_23358" width="512" height="512"
								   xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAAAXNSR0IArs4c6QAAIABJREFUeAHtnQfYLVV19/+ggkoTowgohmAXSLDX2GJU8qnYe4hGY0clGhsYQI2fivSi2EtUIJZobIkUe0GMBSwRRcUCSi8qgvp974rvubz33HNm9sxaM3tm9m+e5z7vPWf23mvt31p7r3Wm7C1xQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAQB8EtpH0cEkHSHqvpK9K+pGkCyRdKen/8Q8G+AA+gA+M0gdsDre53Ob0U1fneJvrbc63uZ+jQAK3l3SwpNMl/YGBPcqBTWJGcooP4AMeH7C532LAQZIsJnBMmMAWkl4g6TsEfAI+PoAP4AP4wJwPWGywGGGxgmMiBK4r6RWrl4E82SJ1+bWBD+AD+MD0fcBuGVjM2HoiMbDIbmwkaU9Jv5jL8hjA0x/A2Bgb4wP4gNcHzpf0XEkbFxlBR9zpm0r6AoGfS3z4AD6AD+ADTh+wWGIxhWMEBOzpzgudBvdmjtTn1wc+gA/gA9PxgUskPX4E8a9YFe0yzaEEfrJ9fAAfwAfwgY58wGIMtwQGlmZsIuk9HRmcLH46WTy2xJb4AD7g9YEPSLrmwGJgsepY8P8YwZ+MHx/AB/ABfKAnH/iEJIs9HBkJ2JP+7+jJ4N6skfr88sAH8AF8YDo+cCy3AzJGf0mHEPzJ+PEBfAAfwAcy+YDFII4MBB6ZyeBk8NPJ4LEltsQH8AGvD/B2QM8JwE0kXUQCQNaPD+AD+AA+kNkHLl15CP3mPcfAYsXZKxgs8kPW7s3aqY8P4QP4QJQPWEzi9cAe0pInZ872ohyGdph88AF8AB+Yjg/8fQ/xr2gRtjnDLztKAGylp/dKeurKa4V3lHR9SVcvmjadhwAEIDBuAjaH21xuc7rN7fbkvl2y7yLxstjEBkId+svLOzDcOStJxTMlbdah3jQNAQhAAALDIGBzvc35NvdHJwIWozg6IGB7NNs2jVEGu3ylrf0kbd6BrjQJAQhAAALDJmBz//6SLBZExRXbQdBiFUcwgecHGskyv7sG60dzEIAABCAwPgJ3C9423mIVRzCBbwclAKdLunGwbjQHAQhAAALjJWAxwWJDxJUAi1UcgQRuH2SYcyXtFKgXTUEAAhCAwDQIWBIQ9VzAbaeBZBi9OCggAbD7PHaphwMCEIAABCCwiIDFiIhnAl63qHG+a0cg4tKMPezBAQEIQAACEKgi8JKAH5ynVQngXDqBbST9wWkQu6zD0/7pzCkJAQhAoFQCts3vD5wxx2KWrT/A4STwCKch7KGOZzl1oDoEIAABCJRDwBYN8j4Q+PBycHXX0wOchriMX//dGYeWIQABCEyQgC0W5F0xkNvOAY7xHmcCYEs/ckAAAhCAAASaEDjOGXssdnE4CZzqNIJdyuGAAAQgAAEINCHgvQ3wlSbCKLuYwFnOBMA2geCAAAQgAAEINCFwZ2fs+XETYZRdTMDWVvY8jMGTmIu58i0EIAABCCwnYLHDE3ts7xoOJ4ErnEawVzo4IAABCEAAAk0IXMMZe65sIoyyiwl4MjCr2+dhS0nuJekTkr4ryd5AsH/2f/vu2ZJ26FOhOVnoNweEjxCAAAQqCPzemQRsXNE2pxIIjCEBuKGkYyT9LsFZzKGOl7RjQt+jiqBfFEnagQAESiJAApDZ2kNPAB7S8n3RSyQ9uAe26NcDZERAAAKTJEACkNmsQ04AnivJ4yBW9zkd8kW/DuHSNAQgMHkCnvndYhe3AJwuMtQEwH5Ze53D+mZtdHElAP2cjkd1CECgeALeOZ4EwOlCQ0wAbtTysv+yvtjtgO2dnNZWR7+1NPg/BCAAgXYESADacQurtSxopn4fpsiaht6a8LBfqn6zcm9a0773v+jnJUh9CEAAAv6rvFwBcHrRLEC2/esUv0F1e5Uu5Wn/pvpam/bL3Xugn5cg9SEAAQj8kQBXADJ7QtNAOl8+Wn17aG9eRtTniG2L0S/a4rQHAQiUSoAEILPlvcE1Wv2Pd5gAfDRAWfQLgEgTEIAABAIe9OYWgNONhpYAnNFhAmArBnoP9PMSpD4EIACBPxLgCkBmTxhaAnBphwmAte090M9LkPoQgAAE/kiABCCzJ5SUAFwcwLrLBKAE/QJMQBMQgMBECJAAZDbk0BKA/+nwCsB3AlijXwBEmoAABCDAMwD5fWBoCQAP2fl8Yuj8fL2jNgQgMCUCXAHIbM2hJQC2pa9Xp2X1nxHAGv0CINIEBCAAAa4A5PeBZcEy9fvoHuzQ0UJAVwYtBIR+0RanPQhAoFQCXAHIbPnUQL+sXBfqv7mDqwBvCFQU/QJh0hQEIFAsARKAzKZfFthTv+9C/RtKsg18UnWoK2dP128XqCj6BcKkKQhAoFgCJACZTV8XPOvOd6X+7kG3AszBHtSBkujXAVSahAAEiiJAApDZ3HUBvu58l+rbuvseB7G6e3WoIPp1CJemIQCByRPwzO8Wm1gK2OkidQG+7rxTfG31B7e8HWCX/R9Y27q/APr5GdICBCBQJgESgMx2rwvwdef7UP/6kg6TZE/y1+ljDvXO4Hv+dX1EvzpCnIcABCCwIQESgA2Z9PpNXUCtO9+nsjeSZFv6fkySrepny/LaP/u/7fT3zKBX/dr2Cf3akqMeBCBQIgESgMxWrwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwnJdgAAN8AB/AB4bnAxtnjp+jF49TD8+psQk2wQfwAXyg3gdIAJwpCE5W72QwghE+gA/gA8PzARIAEgAu0Wt4A5PJEpvgA/hA1z5AAkACQAJAAoAP4AP4QIE+QAJAAsDAL3Dgd/3Lgvb59YoPDN8HSABIAEgASADwAXwAHyjQB0gASAAY+AUOfH6dDf/XGTbCRl37AAkACQAJAAkAPoAP4AMF+gAJAAkAA7/Agd/1Lwva59crPjB8HyABIAEgASABwAfwAXygQB8gASABYOAXOPD5dTb8X2fYCBt17QMkACQAJAAkAPgAPoAPFOgDJAAkAAz8Agd+178saJ9fr/jA8H2ABIAEgASABAAfwAfwgQJ9gASABICBX+DA59fZ8H+dYSNs1LUPkABkTgCc4qkOAQhAAAKFEvi988cLCYDTcbwZmlM81SEAAQhAoFACJACZDU8CkNkAiIcABCBQKAESgMyGJwHIbADEQwACECiUAAlAZsOTAGQ2AOIhAAEIFErgdzwDkNfyJAB5+SMdAhCAQKkEznUkABeUCi2y3yQAkTRpCwIQgAAEUgl8yZEAnJIqhHLLCZAALGfDGQhAAAIQ6I7AyxwJwH7dqVVOyyQA5diankIAAhAYEoFtJF3SIgm4VNJ2Q+rIWHUhARir5dAbAhCAwPgJ7NUiAbA6HAEESAACINIEBCAAAQi0JnBQgyTg4NZSqLgBARKADZDwBQQgAAEI9ExgT0lnVyQCds7KcAQSIAEIhElTEIAABCDQmsBmkh4n6W2STl799/bV7zZv3SoVlxIgAViKhhMQgAAEIACB6RIgAZiubekZBCAAAQhAYCkBEoClaDgBAQhAAAIQmC4BEoDp2paeQQACEIAABJYSIAFYioYTEIAABCAAgekSIAGYrm3pGQQgAAEIQGApARKApWg4AQEIQAACEJguARKA6dqWnkEAAhCAAASWEiABWIqGExCAAAQgAIHpEiABmK5t6RkEIAABCEBgKQESgKVoOAEBCEAAAhCYLgESgOnalp5BAAIQgAAElhIgAViKhhMQgAAEIACB6RIgAZiubekZBCAAAQhAYCkBEoClaDgBAQhAAAIQmC4BEoDp2paeQQACEBgbgWtL2knSbSTdTtJNJG0+tk6MRV8SgLFYCj0hAAEITIvAJpLuJ+k1kk6SdJ6kZTHpQkmflnSopN1X6lxrWijy9GYZ7NTv82iNVAhAAAIQGCsB+2X/ZkkW1FNjzXy5X69cHXiXpLuPFcIQ9J6H2vTzEPqADhCAAAQgMHwCd139Fd80ztSV/9JKu/cefveHp2Ed2Lrzw+sRGkEAAhCAwJAIbCPpWMev/bo4NDv/IUnbD6njQ9dlBq7t36H3D/0gAAEIQCAfgQdL+mUPwX8Wwy6Q9Ih83R2X5Bm0tn/H1Vu0hQAEIACBPghsJOlFkn7fY/CfxbE/SHq1pI376OiYZcyAtf075r6jOwQgAAEIxBOw4H9khsA/H8feRhJQbdx5YE0/V7ced3ZLSY+V9CZJp6xeUrpiAA7WlBfl2z/12wU78yG7PGk+9UZJj5G0RZzbNm5p19XXnE6XdBn+3foJ8S58ZUhtmt/+RNLxkh4qyQLukI5jBuS7FjOGxmcwtvI6ddcd2U7S6yX9akAO5WVG/WElAfP2MF+zScMWIOnr2FTS0Zkul873n8/D9s9F9vny6uI5fflrlZwXDnCufnGVwiWfW+RMTb7rit01Vy7dvJxfQfwCyjiZ2K8su49owbnLwxZDOTFjP5uMd8oONzmwRXR27tJRE9q2RX1y3POv80vTyXTjmCNQB67u/FxzIR+v19G7onV94fxwJ7ectvmCpG1DPHtxI/bLP2f/kD0d/t+XtNliN+v8260knTVgX/6ZpK07pzAyAd7BH93dXQbuRF5e1B/nZGsTm/lm9GFt/m7Akyb+Oj5/3TfaSRPbs2dohu4vb0jsSzHFvAaLBHUDgv/gB5DXX8Zc335BRC8yYuuaj5kJug/Pfj/N8NDbLSRdOQJftmT71pFBa+xteQdwVP/tnr9davXqQ30YdukD5qORzwTY0/5d6kvbZfK9VdTEnNjO+0bkx8cl9qmIYt4JIgqSPfDn1YX6MOzDB/aPcnpJl+L3jPsOfOD+gT5a19QtB/rg37K5wK5U3KiuU6WcXwYp9fsITvaqH+88E7xTfS53OQvaUQ8FXtzB5J+bD/Lzj+U+n3h/a0c+fEmHcSEyiY+Igdna8A7WCMXtPX+vHtSHYZ8+cFSE46+sWc4tAPy2C7/t6xaA/ZL+bdD8bcv3fkLSQ1YWw7rOmvFlyfYTJX0xSI7xtnHHEQDUC9FW+GORHybBLibBLtu0K1abe51f0iEBY7DLftL2+MamvbHS18p3BwX57y8k7V4znqxPT1rZX+A3QTL7XOirpmv5TnsHuFdzW97XqwP1YZjDBx7tdf7VhVt4DRD/jfTffQL8MqWJ60qyy/Re3c+V1OSKxT0lXR4g164qFH94jecFaEuuenWgPgxz+ICtdx5xHMEYYA4I8oEzelwIyNYbiBh3D2wxiJ4TIDvqNl4L9YdTxWtAb09sExavDtSHYQ4fsHuSEYctBXwC44B5wOkD9ku6r3fcry3JLtt7x91HWw6gq0uyZMcj/6SWsidVzQPQ6noPc1qvDtSHYQ4fsF0Eow5LAg5nVUDmgpbzoSWjfxbljAntPKulnvPj9O4JspYVeYlTh+8ta7ik7+cN0vSzl1XUE6RN9aY8SYPXB8x3ow/bzOVgSaexRgDJQEWAM9/7saRjJe3R40N/5u/26/vMCt1Sx9VnnYPnzk4dLnLKn0T1VGMtK+eFsKzd1O+98qlfNgF79SjV1xaV6+tp67KtRO+HRODxzjEzG0dt7v2v5bCDUw97k6f4Y2aMtn+9ANvKndXzyqd+2QRIAMq2P71vRsAS3q87A6/N3fYevjd5vrFTD3udsPhjFkjb/vUCbCt3Vs8rn/plEyABKNv+9L4ZAXtXfzb3ev7u2UzswtL3cury84WtFvalx4hW13vklu/Vn/rjJkACMG77oX2/BD7lDLqz+d6ec7El4D3Ha5y62JWM4o+ZQdr+9QJsK3dWzyuf+mUTIAEo2/70Pp2A96G72Zw9+2uL+dg6MDdPV2FdSXtr5ifOBOD961or+D8zY7T960XXVu6snlc+9csmQAJQtv3pfTqBf3cG3NmcPf/395L+Y2UfAEswUg9bEni+naafX5YqbMrlmkKbL+9lM99e089e+dQvmwAJQNn2p/dpBGypXgvUTefnpuVPlFS3k+HGkr4doEvd3gNpZEZeqqmB5st7uz/fXtPPXvnUL5sACUDZ9qf3aQS62vJ32Xz/jZW1BuxBQVtzYP6w3QKX1Uv9/teSbDXD4o9UYMvKeQEuazf1e6986pdNgASgbPvT+3oCNwzc8jd1Xp+V+/7KksPPkHTNNWp+ISAB+PCa9or+7wx0279eeG3lzup55VO/bAIkAGXbn97XE3hdQMCdzddt/54j6aWSHhyky0Pru11GibYGmdXzUpq10/avVz71yyZAAlC2/el9NYGtg7b8bTu/d1HP3v9fdGuhmsREz3oBe7Hklu/Vn/rjJkACMG77oX23BKK2/PXO85H1bRMhjlUCXrBekLnle/Wn/rgJkACM235o3x0Bu+9+dtAld+88H1X/EknX6Q7Z+Fr2gvX2OLd8r/7UHzcBEoBx2w/tuyMQteWvd46PrP/a7nCNs2UvXG+vc8v36k/9cRMgARi3/dC+GwJXk2RP4Hvn5yHVt5UHt+8G13hb9RrI2/Pc8r36U3/cBEgAxm0/tO+GwOMmFvwtztiywxxzBHIH4Nzy53DwsTACJACFGZzuJhH474klALaKoa1myDFHIHcAzi1/DgcfCyNAAlCYweluLYEHBAX/XwS1440RVp+Nf5aY3Qt3SbPJX+eWn6woBSdJgARgkmalUw4CEVv+2k59m0p60Mra/hEr93njRJONhhzoxlfVC9bb49zyvfpTf9wESADGbT+0jyVwh6Bf7c+bU+vuqzv+ecdbm3hx0pwufFxDoA3QtXXWNNXqv2vbavP/VkKpBIFVAt4JaSNIQmBCBD4QkACcL2nzJUz+XNI7JV0ZICc1Xtx/iS58HWAEL8RUIy4r55VP/bIJkACUbX96fxWBWwRt+XvAVU0u/d+Okg6T9KuAGLQsNtj3X5dEkr7UDP73PCuaTjpVZbyUc0lCKASBJQRIAJaA4eviCLwlIBhbQL9+A3JWdn9JdtUgZb5vWuYxDXQpsmhToPPlvdDm22v62Suf+mUTIAEo2/70/o8Eorb8PbwlULtl8FxJZwUmAmey6U+9NZoG3Pny9RKqS8y31/RzdeuchUA1gaElALuurFV+qKTTJV0WOBk2HVd9lbc+Wl+tz7tUm4qzHRI4MMDX7L6+Xdr3HJtIsuV6I/zvmR5FSqnrBe3llFu+V3/qj5vAUBIAe2Xq6KB7sN4xlau+LdZylCQLAhz9EdhK0kUBQfddQSp/JEAXW4PgWkH6TLoZ72D3wskt36s/9cdNYAgJgAW8EwMmPe9YGkp9Y0ES0N+42ifI93YLUNmugHnHpPnxSwN0KaIJ76D3Qsot36s/9cdNwDvZRDxhbL/8veNgavWPHLdbjUb7qC1/PxrUY7uK4PVl2/J36yB9Jt+MF7YXUG75Xv2pP24CuRMAu+/9u4BJzzuOhlbfmPBMQPdjy+6TR9j+HgGq7rDyy/2KAH3seQaORAJe4yeKWVost/ylinGiCAK5EwB7+M07BqZa/5AiPDBfJ23L3zMC/O/LQV2wNwi8vmwJhCUSHIkEvMATxSwtllv+UsU4UQSB3AmAPQHvHQNTrW9sOLojYO/IR/jOHgEq/omkSwP0sbUMOBoQ8DpAA1ELi+aWv1ApviyGQO4EIGLS846hodY3NhzdEfhqQMD9jqSNA1S01QO9fmhj+dYBuhTVhBe6F1Zu+V79qT9uArkTgIsDJj7vGBpqfXuYi6MbArY+foTdnxig3rUlnRugj+1jwNGQgNcJGorboHhu+RsoxBdFEcidAHALYHkg4hZAd0PRdsjzzr225W/E65q2c6BXF6t/l+5wTbdlL3gvmdzyvfpTf9wEcicA9qCbdwxMtf7B43atwWofteXv3gE9vIakHwWMgZMDdCmyCe/k4YWWW75Xf+qPm0DuBGBnXgNcmADZa4DGhiOewPsDAu4FkrYIUG3PAF0shjwgQJcim8gdgHPLL9LodHodAVt+1uODEQsBHeHUwaP/UOu23VRmnWH5z0ICUVv+vnxh682+tLFzWoDvf4Mtf5uBX1vaOwGsbavN/3PLb6MzdaZDYAgJgN1HPSFgIvSOpaHU/2TQveXpeGlcT94c4Ge/kbRtgEoPCtDFfPaxAboU24R30HvB5Zbv1Z/64yYwhATACFoSYL96S14V0Pp+GMG/swFlQduCt3fOtStWEcfnAnRhy1+nJbzO4BTvdkavfOqXTWAoCcDMCnbf2x5+s0ujJawRYH20vlqfuec/84Ju/kZss2tJ2k0C1Lt7QPC32PWsAF2KboIEoGjzF9/5oSUAxRsEAJ0Q2DJoy993B2n3HwEJAFv+BhiDBCAAIk2MlgAJwGhNh+INCNj2uN653urfpoHMZUVvJck77kyXfZcJ4Pt0Al6nSJe0uGRu+Yu14ttSCHgnooi3AEphTT/zENhU0s8DEoCPBan/zgBdLpNk+wdwOAnkDsC55TvxUX3kBEgARm5A1K8l8PSAgGvz9D1rJdUXuJGk3wboc1C9KEqkEMgdgHPLT2FEmekSIAGYrm3pmWRb/n4vIOBGbfkbsf21bfl7Y4wbQyB3AM4tP4YirYyVAAnAWC2H3ikEHh0Q/G2OfkiKsJoy1w16s+WtNXI43YBA7gCcW34DVBSdIAESgAkalS6tI3BqQALw3aAtf/cP0MWW7uZ10XXm9f8ndwDOLd9PkBbGTIAEYMzWQ/cqAvcLCLg2Pz+pSkjiuagtfz+YKI9iiQRyB+Dc8hMxUWyiBEgAJmpYuqUTAxKAnwatzPicAF0sVtwVu8YSyB2Ac8uPpUlrYyNAAjA2i6FvCoGoLX+fnyKspkzUlr+frpHD6RYEcgfg3PJbIKPKhAiQAEzImHRlHYH3BfzivkjSVutabP+fvw3QxeLE37RXgZrLCOQOwLnlL+PC92UQIAEow84l9dLW6o/YVOqVAdCitvz9Jlv+BlhjQRO5A3Bu+QuQ8FVBBEgACjJ2IV19Y8Av7qgtfx8YoIvFiMcXYrveu5k7AOeW3ztwBA6KAAnAoMyBMk4CNwja8vcopx6z6p8NSADOkmTPEXB0QCB3AM4tvwOkNDkiAiQAIzIWqtYSeE1AwLXbBzetlVRf4E4Bulh8eHa9KEq0JZA7AOeW35Yb9aZBgARgGnakF5Jt+XthQNB9TxDMDwfocp6kzYL0oZkFBHIH4NzyFyDhq4IIkAAUZOyJd/XFAQHX5uPbBnC6ZdCWvy8L0IUmKgjkDsC55Veg4VQBBEgACjByAV2M2vL340Gs3h6QjNiWv9cL0odmlhDIHYBzy1+Cha8LIUACUIihJ97NpwUEXJuL7xXAKWrL34MDdKGJGgK5A3Bu+TV4OD1xAiQAEzdwAd2L2vL3lCBWhwQkI2z5G2SMumZyB+Dc8uv4cH7aBEgApm3fEnr3qICAa/PwwwJgRW35a7cQOHogkDsA55bfA2JEDJgACcCAjYNqSQSGtOXvPwckI7bl7y5JPaeQm0DuAJxbvhsgDYyaAAnAqM1XvPL3DQi4Ngc/OYCkbfn7ywB9PhSgC00kEsgdgHPLT8REsYkSIAGYqGEL6dYnAwLu2ZKuGcBrrwBdLB7cLUAXmkgkkDsA55afiIliEyUwtARgV0mHSjpdkr0G5R0f1Pcz/JWkb6+8knakpN0GNA5MF7tc7rXxCwL6dHVJPwzQ5TMButBEAwJe52kgamHR3PIXKsWXxRAYSgJg73EfHbR4indMUX95UDV/eXPQL2bvIDs+IOBGbfn7hABdzO/+jxcK9ZsR8A72ZtJu333zAAAgAElEQVQ2LJ1b/oYa8U1JBIaQAGwi6cSgCdQ7nqi/PPivZfN5SdfKOFB2Ctry91+C+vC1AP+1qywbB+lDM4kE1jp1m/8nillarI3MtXWWNswJCCQQGEICYL/81/o0/x8Hj7cl+FdXRY4J8JnLJW0XoKD9ao/wWbuKwNEzAa/hvOrmlu/Vn/rjJpA7AbDXnWz3Ne84oH7/DO3+++0zuL9t+fvrAJ+xxDPisPv2Xv9jy98IS7Row2u4FiLXq5Jb/nrK8KE4ArkTAHvgzzsGqJ+P4RszjJhXB/hM1Ja/dwzQxfz3ORk4IjLAeF6I3snLK5/6ZRPInQDY0/7eMUD9fAztyfc+j6gtf48NUvrfA/z3fEmbB+lDMw0JeCePhuI2KJ5b/gYK8UVRBHInAJcGTKDeMUT99gnElZJsLf6+jhcF+cvtAhSO2vJ3vwBdaKIlAe/gbyl2XbXc8tcpwn+KJOC9/76Rk9rFQRO6dxxRv10SYAlAX0+u26uiPwvwl/90+uysuj0E6fUbW2OBLX9nRDP89RrQq3Ju+V79qT9uArkTAG4B+IOIdw7x1O/zFsBTAwKu9fU+AUM2astfewaGIyMBj/NbXe+RW75Xf+qPm0DuBCBi61TvGKJ++yTEXsfr47CrDN8LSACitvw9OEAX2/L3T/uAh4zlBLyDf3nLaWdyy0/TklJTJZA7AdiZ1wDdl5G9c0jb+vYaYMS99JSx9YiAgGv9fHiKsJoytuXvJQH6vKNGDqd7INDW+Wf1vCrO2mn71yuf+mUTyJ0AGP0jAibTtuOHeu1//b+1x6HzxQAf+X7QA4svC9CFLX97dJ4qUd4JoKrtlHO55afoSJnpEhhCAmBLAZ8QMKl6xxL105OBPpcC/qsg33hKwDCO2vL3wwG60EQAAe+g96qQW75Xf+qPm8AQEgAjaEnA4dwOGPztAHtt1Bb/idg+N3Xk/FdAAnBOkM7PDtDF5ny2/E21fsflcgfg3PI7xkvzAycwlARghsmeCbAHrE6TxBoB6b/IvfNIVX3blvlbq7dq/mJmqJ7+mryILX9fGKCvrXdgtxGqWKWc+1KALjQRRCDFYFVlvGpUtZ1yziuf+mUTGFoCULY16P08geMCAq6tNbHVfMMtPj8+QBeb0x/UQjZVOiKQEmSrynjVqmo75ZxXPvXLJkACULb9h9x72/LXFhpKmQeryrwqqJP/HaALW/4GGSOqmSrHSTnn1SNFRlUZr3zql02ABKBs+w+5968PCLhRW/7uHqCLzeN7Dhl4ibpVBdeUc15mKTKqynjlU79sAiQAZdt/qL3fJmjL3zcEdfBTAQnAT1Yfdg1SiWYiCFQF15RzXh1SZFSV8cqnftkESADKtv9Qe2+X7avmvZRz5ts3C+hg1Ja/zw3QhSaCCaQ4UlUZrzpVbaec88qnftkESADKtv8Qe7+FpAsDEgB7gDDi+GCALmz5G2GJDtpICbJVZbwqVbWdcs4rn/plEyABKNv+Q+z9PwUEXJs7I5YpvoUk75bZpsv+QwSNTv7LTF6GKUG+qoxXPvXLJkACULb9h9b7qC1/bfGgiMOWO66af1PO2Za/149QhjbiCaQYsKqMV6OqtlPOeeVTv2wCJABl239ovbflelPmvboytnyw97ihpN8G6HOYVxHqd0egzpHqzns1q2u/7rxXPvXLJkACULb9h9R72/LX3pOvm/Pqzn9N0kYBHTsoQBdbx4AtfwOM0VUTdc5Ud96rV137dee98qlfNgESgLLtP6Te21a9dfNdynnbOth7bB205e+7vIpQv1sCKQ5VVcarXVXbKee88qlfNgESgLLtP6TeR2z5+4OgLX/3DUhGbA+D3YYEGF02JJASZKvKbNhis2+q2k4510wapSGwPgESgPV58CkPgfsEBFybL58aoL7tdHh2gD4fCdCFJjomkBJkq8p41atqO+WcVz71yyZAAlC2/YfS+/8MCLhRW/4+K0AXm7v/cihw0WM5gZQgW1VmectpZ6raTjmXJoVSEFhMgARgMRe+7Y9A1Ja/LwpQmS1/AyCOqYmUIFtVxtvXqrZTznnlU79sAiQAZdt/CL1/b8Avbtvy9zoBnXlsgC42bz84QBea6IFASpCtKuNVsartlHNe+dQvmwAJQNn2z937Pwva8vfVQR35akAC8B1J9kojxwgIpATZqjLeLla1nXLOK5/6ZRMgASjb/rl7f3RAwLUtf7cP6MgDAnSxOfvvAnShiZ4IpATZqjJeNavaTjnnlU/9sgmQAJRt/5y9j9ry95igTpwckACw5W+QMfpqJiXIVpXx6lnVdso5r3zql02ABKBs++fs/b8EBFzbqCdiy987BOhi8/XeOYEiuzmBlCBbVaa5xPVrVLWdcm791vgEgWYESACa8aJ0DAHb8veCgKB7fIw6+kCALmz5G2SMPptJCbJVZby6VrWdcs4rn/plEyABKNv+uXr/goCAa/PjnQI6ELXl7wEButBEzwRSgmxVGa+6VW2nnPPKp37ZBEgAyrZ/jt5fQ9JZAQnACUHKvyVAF7b8DTJG382kBNmqMl59q9pOOeeVT/2yCZAAlG3/HL1/ckDAtbnxrwOUj9ry94gAXWgiA4GUIFtVxqtyVdsp57zyqV82gaElALuuLOhyqKTTJV0WFChSxtHUytg+9vYr+zhJewRtjxsxUmyb3m8F2PXrQX06MEAXG0M3iYBDG/0T8A58r8a55Xv1p/64CQwlAdhUkr0Tbk91e8cE9Tdk+CVJtuhO7uOhQfZ9VEBHtpJ0UYA+/xqgC01kIuCdLLxq55bv1Z/64yYwhARgk5WNU04MmIi9Y2nq9c+VtHNmd/1CgJ1ty9+rB/RjnwBdzGduE6DLrAlbQfAeK1sav2IlYXvH6j/7v33H6oIzSoF/vYPeq0pu+V79qT9uAkNIACJWg/OOo1Lqf1/SZplc9l5BAfdpAfpHbfn70QBdZk3cV9JpFYzsnJXhCCTgHfheVXLL9+pP/XETuLJiwknxTbun6zl2keRNQlL0pMxVtwXsl2+O4+NOXzMb2pa/1wpQ/hkBupg+9ss84nhe4u0vu0X2/AiBtPFHAt6Jwcsxt3yv/tQfN4HcCYA98OcdA9RvxtAeDvQmbk29/s8l/SHA1i9uKnhBedvy94wAXb68oO02Xz26IRvjaLsWcgQQ8E4eXhVyy/fqT/1xE8idANjT/t4xQP3mDG/Zs9u+J8DOlwRt+fuYAF3M5x4SwNAeRDyvhT4XSrpugPzim/BOHl6AueV79af+uAnkTgAubTH5eccM9aX79ei2UVv+viZI54gtf78b9FCeZ0XEFwbxKLoZ72TghZdbvld/6o+bQO4E4GISgCxXQCIW0Un1/KMCbBy15e/9A3SxOftJqZ2vKfcZhz6fq2mb0wkEcgfg3PITEFFkwgRyJwDcAmh++d47Z1j9vm4BRG35+6agMXiSI+DOuP9Ukr26GnH80qGP3TrgcBKYGbXtX6d4d/bvlU/9sgnkTgAOcUyAbcds6fV+3ONDgPYOu5e3Pfl+q4BhGrXl7z8G6DJrwvMGjD0M2PfDnDO9J/PX65xeELnle/Wn/rgJ5E4AbGEazyToHT8l1n9pTy5r6w20ecBt3ibvC9L3/QHJiG1hbFsZRx3elS9ZHMhpiXlna/rZKd6dHXvlU79sArkTAKNvG6k0HXeUb8fMXn/rayEge189wk53DhiiN098z75OX7uiEXmQAETSbNFWncHrzrcQuV6Vuvbrzq/XGB8g0JDAEBIAu59qW7vW+TrnfYzs13hfSwHblr92q8FrM1siOuKwZwi8uvxG0rYRyqxpgwRgDYwc//U6hVfn3PK9+lN/3ASGkAAYQUsCDud2gDtILZtP+t4MyJ6SX6ZLk+8jXle0oG3Bu4ncRWWP7GCokwB0ALVJk4sM3eS7JrIWlW0ia1HZRW3yHQRSCQwlAZjpa79QD15dE501AtoHLdsO2H6BH5thO2B7MC3i7Y6oLX9fGxD87TmVLrb8JQGYjfxMfxcF1SbfedVuImtRWa986pdNYGgJQNnWmEbvbYW8RXNV0+9siVzvsWXQlr+2kmEXBwlAF1QbtNnUKefLNxC1sOh8e00/L2yULyGQSIAEIBEUxZIJfD4gATgzaMvflwToYnPybZN736wgCUAzXuGlmwbc+fJehebba/rZK5/6ZRMgASjb/tG9v2dQwLXd+rzHppJ+HqCP7WLY1UEC0BXZxHabBtz58olilhabb6/p56UNcwICCQRIABIgUSSZwMcCAu4vgrb8fXqALjYf3yu5980LkgA0ZxZao2nAnS/vVWa+vaafvfKpXzYBEoCy7R/Z+6gtfyMWKrItf78XkACcEgloQVskAAug9PlV04A7X96r63x7TT975VO/bAIkAGXbP7L37w4IuLbl79YBStkDhE3n0kXlHxqgS1UTJABVdHo4t8joTb7zqthE1qKyXvnUL5sACUDZ9o/q/Y6SvL5k89uBQQqdGpAARG35W9UlEoAqOj2cWxRUm3znVbGJrEVlvfKpXzYB76TNZiRl+8+s9xHLOV8haYdZg46/tnjQormy6Xd/79AhtSoJQCqpjso1dYr58l615ttr+tkrn/plEyABKNv+Eb3/E0mXBQTdN0coI8mWD246j86Xj9zyt6pbJABVdHo4N2/4pp+9KjaVN1/eK5/6ZRMgASjb/hG9f3lAwLWtbW8doMztA3SxOfYFAbqkNEECkEKpwzLzAbXpZ69qTeXNl/fKp37ZBEgAyra/t/e2s+C5AUHXtuqNOP4tQJeLJG0VoUxCGyQACZC6LDIfUJt+9urWVN58ea986pdNgASgbPt7e793QMC1Oe0uXkVW1+q3Nfvn58imn18ZoEtqEyQAqaQ6KtfUOebLe9Wab6/pZ6986pdNgASgbPt7eh+15e/JHiXW1H1jQPDvYsvfNSpu8F8SgA2Q9PtF04A7X96r7Xx7TT975VO/bAIkAGXb39P7JwYEXJvvHuBRYrXuDYK2/D06QJcmTZAANKHVQdmmAXe+vFel+faafvbKp37ZBEgAyrZ/295Hbfn7DUkRr5K+JiAZsdsHN20LpGU9EoCW4KKqNQ248+W9esy31/SzVz71yyZAAlC2/dv2fo+AgGtz3WPbKrCmnm35e2GAPu9d02Zf/yUB6Iv0EjlNA+58+SXNJn89317Tz8mCKAiBBQRIABZA4ataAkPa8vfFAcHf5t2utvytgkkCUEWnh3NNA+58ea+K8+01/eyVT/2yCZAAlG3/Nr3/y6CA+8w2wufqRG35+4m5dvv6SALQF+klcpoG3PnyS5pN/nq+vaafkwVREAILCJAALIDCV5UEPhKQAERt+fu0AF1szr13ZY+7O0kC0B3bpJabBtz58klCKgrNt9f0c0XTnIJALQESgFpEFFhDYFdJtmpf03lqvvw+a9ps+9+xbPlb1T8SgCo6PZybd8ymn70qNpU3X94rn/plEyABKNv+TXv/roDgb/sG2P4B3uNRAbrYfPpwryKO+iQADngRVecDatPPXh2aypsv75VP/bIJkACUbf8mvbed+mzHvvk5qOnn1zURWlE2Ysvf/5G0cYWMrk+RAHRNuKb9ps47X76m+drT8+01/VwrgAIQqCBAAlABh1PrETg8IPhbAnHj9Vpt9+G+AbrYXPuUduLDapEAhKFs11DTgDtfvp3Uq2rNt9f081Ut8T8INCdAAtCcWYk17JL9pQFB9y1B8D4ZoMvZkq4ZpE/bZkgA2pILqtc04M6X96rx2wBHnteJz/7LlDCsZ2i+G33YQ2aHSjo9aI/5sdrR7pMbA2OxSzTkFu0dEDBPRW35u1vQg4j/1IJDdBUSgGiiDdvzThANxW1QPGIrTW8fqF8f7GC0ISN7lSvqsPe5bR1274Q4RTsZk6MkbRIFu2E71w7a8veDDeUuK358QDJycY9b/i7rh33v9feczy9U9Ws057wThrejpwQ4s7cP1N8wuMGknskXvc6/Wt8C24mMg9qH64xRjiTgeUG2uWuAv+wkKWLL31cF6BLRBAlABEVHG96J3iH6f6tGbGHp7QP164MdjDZk9Aav86/Wt1/+8E1jcGQQ89RmbMvfHwXY51OpAmvKHROgy+WStquR09dpEoC+SC+R4514ljSb/PVjAhza2wfqp02+cFqf0yOTvXx5Qbu/HfGLrhTbGKs+nwn4u6D5afflLpB8xrb8/XWAPq9Plth9QRKA7hlXSvBOHJWNJ5zcPOjpWm8/qL9+cINHNQ97SM1813vYQ26wbsbgEC/0xPq2Te9pAfaJ2vL31QG6WAJ1s8T+91GMBKAPyhUyvJNPRdPJp7gN0GwC9NqM+n7eUZf/7Ul37NGMgTHr43hQkG0eF6Bs1Ja/xwXoEtkECUAkzRZteSefFiI3qHITSbwO2GwS9NqN+u152z3UHTfw4nZfRLxbXpotjVkfx+cCEoAzJV09QNkXBehifnK7AF0imyABiKTZoi3v5NFC5MIq/zfIwb39oX77wFgKu1cu9OB2X16C3ze+AmLMuj4sUEb4814BikZt+WuLBw3tIAHIbBGvk0epb0/b2pOyXn2oD8MufeDzkmxCjjq4BdDcX/u4BXBgwFx0nqTNAhzlqQG62Jj4qwBdopsgAYgm2rA972TZUFxlcXvK9cdBzu7tF/WbT8xTZ2a+aT4aedgDbVPnFt2/gyMNsKStzwbY5Z+XtN3ka1voxjbs8TK0jYOGeJAAZLaK17Gi1bdXfEgC/APea1fqr28D88kuXj/jNcD1Odf5nT3FvnP0pLOgvTOcQdeeU7jugnabfmVb9dYxSTkf8cpqU91TypMApFDqsEyK81SV6UK163E7IGTQV9mNc+kTq13237YLR19t0xa3wR5pDGxHvj6Os5w2ibpKYatNen3j+5Ku1ge0FjJIAFpAi6zida5IXda2ZfdZ92ONAPfg99q35Pr2tL898Nf18rPW/gkBE/3UbWWMurbFbA6yoOnh+Rezhhx/7+PUYaa/PUMw1IMEILNlZk7S9m/X6ts9V/uFxOtSvgmprX1LrGe+ZqulRb3qlzJGLLAdwaqAC4OuXfa3X/59BX+z13edwffWKUavKfNfTh1s7J4zgC1/q7pJAlBFp4dz3gm+BxX/V4Stuvao1YnZLovZTmz2C82rP/XLZmg+ZL5kPmVr8tu90ognt9uOC7u/bZePbQW6kpNe67sxMBZ93POft9c3nXOL9wqA1bftg73zk60fMOSDBCCzdbwOlll9xEMAAhAIJ/BVZ/C9vVMjW7HPOzfblr/XcerRdXUSgK4J17TvdbKa5jkNAQhAYHQEvuQMwHdx9Ni2/L3SKd/mdVtcbegHCUBmC5EAZDYA4iEAgcER8K4DcA9Hj2yfCe+8bLe2hrLlbxUKEoAqOj2c8zpaDyoiAgIQgECvBE5yBuG2q+5tE7Tl7zG90movjASgPbuQmiQAIRhpBAIQmBCBTzgTgN1bsNhaUsST/0Pb8rcKBQlAFZ0ezpEA9AAZERCAwKgIfMSZANhWwk2OW0j6jlPmbC4/vongzGVJADIbYOY0bf9mVh/xEIAABMIJfNAZjB/WQKMHSrrIKW/t/H2nBrJzFyUByGyBtY7T5v+Z1Uc8BCAAgXAC9iu6zXw4q/PoBI02kmTv6XuD4Eym/R3ilr9VKLx9t82SOBwE1jpPm/87RFMVAhCAwCAJvNuZADyhpldbSPqAU8ai+fq+NXKHdpoEILNFFjlRk+8yq494CEAAAuEE3u4Mzk+q0OhmKytOfsvZ/qI5+uuS7KrCmA4SgMzWWuRITb7LrD7iIQABCIQTeJMzQC/bgMfeDrjQ2fay+dmWSh/bQQKQ2WLLnCn1+8zqIx4CEIBAOAHbFyJ1DlxU7tlzGnVxv3+t3B8MeMvfORTrfSQBWA9H/x/WOlGb//evMRIhAAEIdEvgUGcCsPca9Wwjs39ztlc3N//DGnlj+i8JQGZr1TlW3fnM6iMeAhCAQDiB1zkD9gtXNbqxpFOdbdXNwdb+1cIJ9NMgCUA/nJdKqXOuuvNLG+YEBCAAgZESeJUzaO8j6a8lne9sp27+PVvSzUfK2NQmAchsvDoHqzufWX3EQwACEAgncIAzcH9Tki3JWzd/es6fKelW4T3vt0ESgH55byDN44BWlwMCEIDA1Ajs23Hw9s67n5ZkGweN/SAByGxBryNmVh/xEIAABMIJ2Ap93rmxq/q20981wnucp0ESgDzc10n1Oum6hvgPBCAAgYkQ+McBJgCXS6paYGiM6EkAMluNBCCzARAPAQgMjsBeA0sAfirpjoOj5FeIBMDP0NUCCYALH5UhAIEJEnj6gBKAz0nadoKMrUskAJkNSwKQ2QCIhwAEBkfgyQNJAOx+/yaDoxOnEAlAHMtWLZEAtMJGJQhAYMIE9sycANj9/qdMmO+sayQAMxKZ/pIAZAKPWAhAYLAEHpsxAfi5pLsMlkysYiQAsTwbtza0BGAXSYdIOl3SpRkHoZcL9Yf7GhW2GYdtzpN0ysocsJ+k7RrPbL4Kj8g093xVki0fXMpBApDZ0t7JMEp9u89lO3B5HcLbH+qPIzhgp7LsdNnKNrrPjZpsEtrZI0MC8C5J10rQbUpFvPP9xlOCkaMv3ok0QmcL/idmGHDevlO/rCCEvfPb++CICSehjb/pcT66UpItPFTiQQKQ2ereSS1Cfe/e294+UD//xI4NsEGqDzwxYtKpacM28knVx1PuXEn3qdFlyqdJADJb1+O8Vtd77Mpl/14mGq+dqd9PQIBzPedzJG3unXhq6t+rhwTga5J2rNFj6qdJADJb2DvheNU/rIeB5u0j9esnZRjBqE8feLx34qmpf7eO56X3Srp2jQ4lnCYByGxl76D1qv+tjgeat3/UJ7DhA8Pzgbd7J56a+nfoaF6yLYJLvd+/CDkJwCIqPX7nndy8qvKq3/AmV69PUB+bdu0DJ3snnpr6u3WQAJwvyZ4t4LiKAAnAVSyy/M87UL1KkwAQLLw+SP3yfOgk78RTU/9mwQnANyTtVCOzxNMkAJmt7p08vepzC6C8ydvrc9THZ7q+BWD35+31vAhfO17SZt6JcqL1SQAyG9br4F71Dw0aZN5+UD9msoMjHPvwgcd5J56E+p9xzk0W3F4qaaMEWaUWIQHIbHnvYPWqb0v/2oMxXj2oD0N8oAwfOLuH1wBtXrMko61PXbiyjLEtJsRRTYAEoJpP52fbOvisXoSCRzkG2kwP/rafrGAHuzH5gO3U18dhy8x+tsXc9G1JN+9DwQnIIAHIbETvwI9Qn6WACUBeP6R+GT7U11LAs3lte0lnNEgCPiRpy1ll/tYSIAGoRdRtAe/EGaWdJQFHcjug9SVHrx2pX0YAHaud7W2hvaImm4btbCPpIzVJwG8kvZD7/Q3J+jd/YzOgxsjXr+CdENZvzf9p7XbAtgOYVz/qwxAfGKcP2Hvzs+2At/VPLe4W7i3pHZJ+KOlySZdI+oqkV0i6obv1MhvgCkBmu3snx8zqIx4CEIAABEZKgAQgs+FIADIbAPEQgAAECiVAApDZ8CQAmQ2AeAhAAAKFEiAByGx4EoDMBkA8BCAAgUIJkABkNjwJQGYDIB4CEIBAoQRIADIbngQgswEQDwEIQKBQAiQAmQ1PApDZAIiHAAQgUCgBEoDMhicByGwAxEMAAhAolAAJQGbDkwBkNgDiIQABCBRKgAQgs+FJADIbAPEQgAAECiVAApDZ8CQAmQ2AeAhAAAKFEiAByGx4EoDMBkA8BCAAgUIJkABkNjwJQGYDIB4CEIBAoQRIADIbngQgswEQDwEIQKBQAiQAmQ1PApDZAIiHAAQgUCgBEoDMhicByGwAxEMAAhAolAAJQGbDkwBkNgDiIQABCBRKgAQgs+FJADIbAPEQgAAECiVAApDZ8CQAmQ2AeAhAAAKFEiAByGx4EoDMBkA8BCAAgUIJkABkNvwVkjxJwCaZ9Uc8BCAAAQiMj8A1nLHHYheHk8D5TiNc3ymf6hCAAAQgUB4Bix2eH58WuzicBH7sNMKdnPKpDgEIQAAC5RGw2OFJAH5YHrL4Hp/qNMLT4lWiRQhAAAIQmDiBpzpjz1cmzqeX7r3HaYTjetESIRCAAAQgMCUCxzpjz7unBCNXX/Z3GuEySZvnUh65EIAABCAwOgKbSbrUGXteNrpeD1DhhzuNYPdwnj3AfqESBCAAAQgMk4D38r/FnYcNs2vj0sqexPyDMwn4paQtx9VttIUABCAAgQwE7NXxHzhjjsUs3kALMt5pTmNYNvbyIF1oBgIQgAAEpkvgJQHx5uvTxdN/z14XYJDfSrp7/6ojEQIQgAAERkLgrpIuD4g3B46kv6NQ83YBBrGrAOdJ2mkUPUZJCEAAAhDok8D2kn4WFGt261PxEmR9O8gw35L0pyUAo48QgAAEIJBEYIeVh/a+GRRj7JY1RzCB5wcZx64E/ILbAcHWoTkIQAAC4yRgl/3PCYwve48Tw7C13kKSd18AC/6zf/ZMwD6SNh12t9EOAhCAAAQ6IGBP+7806J7/LK7YbWbWnenAWNbkAWsC+Ay49++ZK9nf0zFaRxajWQhAAALDImCL/NgS8Tb3e+PHfP19h9XVaWmz9erl+3noEZ9txcDjV9p/hqQ7S9pGElsJT8t/6A0EIFAWAdvS1+Zy29jHgr4tDe9d4W9ZvDlb0lZl4e2/t0/qIGtbZtCU7y+RdPqK4Q+RtHMPOHZZlWUyu3LklH5TJv7XA0xhig+M1wee0MP8X7yIjSR9fmBJwGzQ/k7SER1dObCrEUdL+v1A+z5jwN/xTmDYDtvhA+184OSVW9QWmzh6IGDv8l804EB4QnASYMH/xAH3l0mj3aQBN7jhA+P3gQsk7dhD3EPEGgKPHnhAPHyNrt7/2i9/JgoY4AP4AD4wLB+wNf/38E7w1G9H4OABB0a7HRDxTMCuXPYn+RmwnxOQhhWQsEe/9nhVu9BFrQgCds/l7VAJMTYAAARVSURBVAOeHC1B8R6HDbh/TDb9Tjbwhjc+MBwf+Ffu+3vDm7++3R//2ECDZMSSkLZ0MYMeBvgAPoAPDMcHPiTJXjHkGAABSwLePcBAaa8Ieg9e9RvOoGcCxhb4AD7wToK/N6zF199Y0kEDSwIiEgBrg0kHBvgAPoAP5PUBe+DP7vnzul98/A5r8ZEDekWQWwB5BywTJvzxAXwgwgfsVT+e9g8L0902ZOsEfG4Av5wjHgI8dAD9iBhAtMFEjA/gA2P0AVvkh/f8u43Z4a3bZRpbNti2/s3hdPYa4K0DemVL/1pbOfqATLjjA/hAqT5ga/vb8r5c8g8IZLmauM6K4P2DtxJOGRD2+l7UcRQJAAkQPoAP4AO9+MC5q1vFbxk1gdNOfgK2R/Pekvp4rY6lgPnVlJIkUgY/wQeG4wPfXHl+7HlsDZ8/WHetwW0kHSjJDG5PdkYNQrtUb0sA22uJ0Ye1eSS3A8JsFWVz2okbP7CEZZ8+YBurfU3SayXtFj1h0944CFxvJRF42EoSsN/qWgJfkXSmJHvq88qE5OCyjNsBm+w+Bwyy4I0P4ANj8oErVufyH0iyud3Wi9lX0kNXflDZ3M8BAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACAyfw/wFF/IQkTID3lgAAAABJRU5ErkJggg==">
							</image>
						</defs>
					</svg> </span>
				<h3>Phân tích và nghiên cứu thị trường</h3>
				<p>HomeNest đảm bảo chiến dịch được xây dựng dựa trên hiểu biết sâu sắc về thị trường và đối tượng mục
					tiêu, giúp chiến dịch tiếp cận chính xác khách hàng tiềm năng.</p>
				<div class="tiktok-driver"></div>
			</div>
			<div class="service-category service-category-border">
				<span class="elementor-icon">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="64"
						 height="64" viewBox="0 0 64 64" fill="none">
						<rect width="64" height="64" rx="12" fill="#D9EBFE"></rect>
						<mask id="mask0_3799_23358" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="12" y="12"
							  width="40" height="40">
							<rect x="12" y="12" width="40" height="40" fill="url(#pattern0_3799_23358)"></rect>
						</mask>
						<g mask="url(#mask0_3799_23358)">
							<rect x="0.890625" y="-14.1113" width="76.6667" height="95.5555"
								  fill="url(#paint0_linear_3799_23358)"></rect>
						</g>
						<defs>
							<pattern id="pattern0_3799_23358" patternContentUnits="objectBoundingBox" width="1"
									 height="1">
								<use xlink:href="#image0_3799_23358" transform="scale(0.00195312)"></use>
							</pattern>
							<linearGradient id="paint0_linear_3799_23358" x1="0.890625" y1="-14.1113" x2="80.3797"
											y2="-11.7027" gradientUnits="userSpaceOnUse">
								<stop stop-color="#020C6A"></stop>
								<stop offset="0.567007" stop-color="#1A85F8"></stop>
								<stop offset="1" stop-color="#66E5FB"></stop>
							</linearGradient>
							<image id="image0_3799_23358" width="512" height="512"
								   xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAAAXNSR0IArs4c6QAAIABJREFUeAHtnQfYLVV19/+ggkoTowgohmAXSLDX2GJU8qnYe4hGY0clGhsYQI2fivSi2EtUIJZobIkUe0GMBSwRRcUCSi8qgvp974rvubz33HNm9sxaM3tm9m+e5z7vPWf23mvt31p7r3Wm7C1xQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAQB8EtpH0cEkHSHqvpK9K+pGkCyRdKen/8Q8G+AA+gA+M0gdsDre53Ob0U1fneJvrbc63uZ+jQAK3l3SwpNMl/YGBPcqBTWJGcooP4AMeH7C532LAQZIsJnBMmMAWkl4g6TsEfAI+PoAP4AP4wJwPWGywGGGxgmMiBK4r6RWrl4E82SJ1+bWBD+AD+MD0fcBuGVjM2HoiMbDIbmwkaU9Jv5jL8hjA0x/A2Bgb4wP4gNcHzpf0XEkbFxlBR9zpm0r6AoGfS3z4AD6AD+ADTh+wWGIxhWMEBOzpzgudBvdmjtTn1wc+gA/gA9PxgUskPX4E8a9YFe0yzaEEfrJ9fAAfwAfwgY58wGIMtwQGlmZsIuk9HRmcLH46WTy2xJb4AD7g9YEPSLrmwGJgsepY8P8YwZ+MHx/AB/ABfKAnH/iEJIs9HBkJ2JP+7+jJ4N6skfr88sAH8AF8YDo+cCy3AzJGf0mHEPzJ+PEBfAAfwAcy+YDFII4MBB6ZyeBk8NPJ4LEltsQH8AGvD/B2QM8JwE0kXUQCQNaPD+AD+AA+kNkHLl15CP3mPcfAYsXZKxgs8kPW7s3aqY8P4QP4QJQPWEzi9cAe0pInZ872ohyGdph88AF8AB+Yjg/8fQ/xr2gRtjnDLztKAGylp/dKeurKa4V3lHR9SVcvmjadhwAEIDBuAjaH21xuc7rN7fbkvl2y7yLxstjEBkId+svLOzDcOStJxTMlbdah3jQNAQhAAALDIGBzvc35NvdHJwIWozg6IGB7NNs2jVEGu3ylrf0kbd6BrjQJAQhAAALDJmBz//6SLBZExRXbQdBiFUcwgecHGskyv7sG60dzEIAABCAwPgJ3C9423mIVRzCBbwclAKdLunGwbjQHAQhAAALjJWAxwWJDxJUAi1UcgQRuH2SYcyXtFKgXTUEAAhCAwDQIWBIQ9VzAbaeBZBi9OCggAbD7PHaphwMCEIAABCCwiIDFiIhnAl63qHG+a0cg4tKMPezBAQEIQAACEKgi8JKAH5ynVQngXDqBbST9wWkQu6zD0/7pzCkJAQhAoFQCts3vD5wxx2KWrT/A4STwCKch7KGOZzl1oDoEIAABCJRDwBYN8j4Q+PBycHXX0wOchriMX//dGYeWIQABCEyQgC0W5F0xkNvOAY7xHmcCYEs/ckAAAhCAAASaEDjOGXssdnE4CZzqNIJdyuGAAAQgAAEINCHgvQ3wlSbCKLuYwFnOBMA2geCAAAQgAAEINCFwZ2fs+XETYZRdTMDWVvY8jMGTmIu58i0EIAABCCwnYLHDE3ts7xoOJ4ErnEawVzo4IAABCEAAAk0IXMMZe65sIoyyiwl4MjCr2+dhS0nuJekTkr4ryd5AsH/2f/vu2ZJ26FOhOVnoNweEjxCAAAQqCPzemQRsXNE2pxIIjCEBuKGkYyT9LsFZzKGOl7RjQt+jiqBfFEnagQAESiJAApDZ2kNPAB7S8n3RSyQ9uAe26NcDZERAAAKTJEACkNmsQ04AnivJ4yBW9zkd8kW/DuHSNAQgMHkCnvndYhe3AJwuMtQEwH5Ze53D+mZtdHElAP2cjkd1CECgeALeOZ4EwOlCQ0wAbtTysv+yvtjtgO2dnNZWR7+1NPg/BCAAgXYESADacQurtSxopn4fpsiaht6a8LBfqn6zcm9a0773v+jnJUh9CEAAAv6rvFwBcHrRLEC2/esUv0F1e5Uu5Wn/pvpam/bL3Xugn5cg9SEAAQj8kQBXADJ7QtNAOl8+Wn17aG9eRtTniG2L0S/a4rQHAQiUSoAEILPlvcE1Wv2Pd5gAfDRAWfQLgEgTEIAABAIe9OYWgNONhpYAnNFhAmArBnoP9PMSpD4EIACBPxLgCkBmTxhaAnBphwmAte090M9LkPoQgAAE/kiABCCzJ5SUAFwcwLrLBKAE/QJMQBMQgMBECJAAZDbk0BKA/+nwCsB3AlijXwBEmoAABCDAMwD5fWBoCQAP2fl8Yuj8fL2jNgQgMCUCXAHIbM2hJQC2pa9Xp2X1nxHAGv0CINIEBCAAAa4A5PeBZcEy9fvoHuzQ0UJAVwYtBIR+0RanPQhAoFQCXAHIbPnUQL+sXBfqv7mDqwBvCFQU/QJh0hQEIFAsARKAzKZfFthTv+9C/RtKsg18UnWoK2dP128XqCj6BcKkKQhAoFgCJACZTV8XPOvOd6X+7kG3AszBHtSBkujXAVSahAAEiiJAApDZ3HUBvu58l+rbuvseB7G6e3WoIPp1CJemIQCByRPwzO8Wm1gK2OkidQG+7rxTfG31B7e8HWCX/R9Y27q/APr5GdICBCBQJgESgMx2rwvwdef7UP/6kg6TZE/y1+ljDvXO4Hv+dX1EvzpCnIcABCCwIQESgA2Z9PpNXUCtO9+nsjeSZFv6fkySrepny/LaP/u/7fT3zKBX/dr2Cf3akqMeBCBQIgESgMxWrwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwnJdgAAN8AB/AB4bnAxtnjp+jF49TD8+psQk2wQfwAXyg3gdIAJwpCE5W72QwghE+gA/gA8PzARIAEgAu0Wt4A5PJEpvgA/hA1z5AAkACQAJAAoAP4AP4QIE+QAJAAsDAL3Dgd/3Lgvb59YoPDN8HSABIAEgASADwAXwAHyjQB0gASAAY+AUOfH6dDf/XGTbCRl37AAkACQAJAAkAPoAP4AMF+gAJAAkAA7/Agd/1Lwva59crPjB8HyABIAEgASABwAfwAXygQB8gASABYOAXOPD5dTb8X2fYCBt17QMkACQAJAAkAPgAPoAPFOgDJAAkAAz8Agd+178saJ9fr/jA8H2ABIAEgASABAAfwAfwgQJ9gASABICBX+DA59fZ8H+dYSNs1LUPkABkTgCc4qkOAQhAAAKFEvi988cLCYDTcbwZmlM81SEAAQhAoFACJACZDU8CkNkAiIcABCBQKAESgMyGJwHIbADEQwACECiUAAlAZsOTAGQ2AOIhAAEIFErgdzwDkNfyJAB5+SMdAhCAQKkEznUkABeUCi2y3yQAkTRpCwIQgAAEUgl8yZEAnJIqhHLLCZAALGfDGQhAAAIQ6I7AyxwJwH7dqVVOyyQA5diankIAAhAYEoFtJF3SIgm4VNJ2Q+rIWHUhARir5dAbAhCAwPgJ7NUiAbA6HAEESAACINIEBCAAAQi0JnBQgyTg4NZSqLgBARKADZDwBQQgAAEI9ExgT0lnVyQCds7KcAQSIAEIhElTEIAABCDQmsBmkh4n6W2STl799/bV7zZv3SoVlxIgAViKhhMQgAAEIACB6RIgAZiubekZBCAAAQhAYCkBEoClaDgBAQhAAAIQmC4BEoDp2paeQQACEIAABJYSIAFYioYTEIAABCAAgekSIAGYrm3pGQQgAAEIQGApARKApWg4AQEIQAACEJguARKA6dqWnkEAAhCAAASWEiABWIqGExCAAAQgAIHpEiABmK5t6RkEIAABCEBgKQESgKVoOAEBCEAAAhCYLgESgOnalp5BAAIQgAAElhIgAViKhhMQgAAEIACB6RIgAZiubekZBCAAAQhAYCkBEoClaDgBAQhAAAIQmC4BEoDp2paeQQACEBgbgWtL2knSbSTdTtJNJG0+tk6MRV8SgLFYCj0hAAEITIvAJpLuJ+k1kk6SdJ6kZTHpQkmflnSopN1X6lxrWijy9GYZ7NTv82iNVAhAAAIQGCsB+2X/ZkkW1FNjzXy5X69cHXiXpLuPFcIQ9J6H2vTzEPqADhCAAAQgMHwCd139Fd80ztSV/9JKu/cefveHp2Ed2Lrzw+sRGkEAAhCAwJAIbCPpWMev/bo4NDv/IUnbD6njQ9dlBq7t36H3D/0gAAEIQCAfgQdL+mUPwX8Wwy6Q9Ih83R2X5Bm0tn/H1Vu0hQAEIACBPghsJOlFkn7fY/CfxbE/SHq1pI376OiYZcyAtf075r6jOwQgAAEIxBOw4H9khsA/H8feRhJQbdx5YE0/V7ced3ZLSY+V9CZJp6xeUrpiAA7WlBfl2z/12wU78yG7PGk+9UZJj5G0RZzbNm5p19XXnE6XdBn+3foJ8S58ZUhtmt/+RNLxkh4qyQLukI5jBuS7FjOGxmcwtvI6ddcd2U7S6yX9akAO5WVG/WElAfP2MF+zScMWIOnr2FTS0Zkul873n8/D9s9F9vny6uI5fflrlZwXDnCufnGVwiWfW+RMTb7rit01Vy7dvJxfQfwCyjiZ2K8su49owbnLwxZDOTFjP5uMd8oONzmwRXR27tJRE9q2RX1y3POv80vTyXTjmCNQB67u/FxzIR+v19G7onV94fxwJ7ectvmCpG1DPHtxI/bLP2f/kD0d/t+XtNliN+v8260knTVgX/6ZpK07pzAyAd7BH93dXQbuRF5e1B/nZGsTm/lm9GFt/m7Akyb+Oj5/3TfaSRPbs2dohu4vb0jsSzHFvAaLBHUDgv/gB5DXX8Zc335BRC8yYuuaj5kJug/Pfj/N8NDbLSRdOQJftmT71pFBa+xteQdwVP/tnr9davXqQ30YdukD5qORzwTY0/5d6kvbZfK9VdTEnNjO+0bkx8cl9qmIYt4JIgqSPfDn1YX6MOzDB/aPcnpJl+L3jPsOfOD+gT5a19QtB/rg37K5wK5U3KiuU6WcXwYp9fsITvaqH+88E7xTfS53OQvaUQ8FXtzB5J+bD/Lzj+U+n3h/a0c+fEmHcSEyiY+Igdna8A7WCMXtPX+vHtSHYZ8+cFSE46+sWc4tAPy2C7/t6xaA/ZL+bdD8bcv3fkLSQ1YWw7rOmvFlyfYTJX0xSI7xtnHHEQDUC9FW+GORHybBLibBLtu0K1abe51f0iEBY7DLftL2+MamvbHS18p3BwX57y8k7V4znqxPT1rZX+A3QTL7XOirpmv5TnsHuFdzW97XqwP1YZjDBx7tdf7VhVt4DRD/jfTffQL8MqWJ60qyy/Re3c+V1OSKxT0lXR4g164qFH94jecFaEuuenWgPgxz+ICtdx5xHMEYYA4I8oEzelwIyNYbiBh3D2wxiJ4TIDvqNl4L9YdTxWtAb09sExavDtSHYQ4fsHuSEYctBXwC44B5wOkD9ku6r3fcry3JLtt7x91HWw6gq0uyZMcj/6SWsidVzQPQ6noPc1qvDtSHYQ4fsF0Eow5LAg5nVUDmgpbzoSWjfxbljAntPKulnvPj9O4JspYVeYlTh+8ta7ik7+cN0vSzl1XUE6RN9aY8SYPXB8x3ow/bzOVgSaexRgDJQEWAM9/7saRjJe3R40N/5u/26/vMCt1Sx9VnnYPnzk4dLnLKn0T1VGMtK+eFsKzd1O+98qlfNgF79SjV1xaV6+tp67KtRO+HRODxzjEzG0dt7v2v5bCDUw97k6f4Y2aMtn+9ANvKndXzyqd+2QRIAMq2P71vRsAS3q87A6/N3fYevjd5vrFTD3udsPhjFkjb/vUCbCt3Vs8rn/plEyABKNv+9L4ZAXtXfzb3ev7u2UzswtL3cury84WtFvalx4hW13vklu/Vn/rjJkACMG77oX2/BD7lDLqz+d6ec7El4D3Ha5y62JWM4o+ZQdr+9QJsK3dWzyuf+mUTIAEo2/70Pp2A96G72Zw9+2uL+dg6MDdPV2FdSXtr5ifOBOD961or+D8zY7T960XXVu6snlc+9csmQAJQtv3pfTqBf3cG3NmcPf/395L+Y2UfAEswUg9bEni+naafX5YqbMrlmkKbL+9lM99e089e+dQvmwAJQNn2p/dpBGypXgvUTefnpuVPlFS3k+HGkr4doEvd3gNpZEZeqqmB5st7uz/fXtPPXvnUL5sACUDZ9qf3aQS62vJ32Xz/jZW1BuxBQVtzYP6w3QKX1Uv9/teSbDXD4o9UYMvKeQEuazf1e6986pdNgASgbPvT+3oCNwzc8jd1Xp+V+/7KksPPkHTNNWp+ISAB+PCa9or+7wx0279eeG3lzup55VO/bAIkAGXbn97XE3hdQMCdzddt/54j6aWSHhyky0Pru11GibYGmdXzUpq10/avVz71yyZAAlC2/el9NYGtg7b8bTu/d1HP3v9fdGuhmsREz3oBe7Hklu/Vn/rjJkACMG77oX23BKK2/PXO85H1bRMhjlUCXrBekLnle/Wn/rgJkACM235o3x0Bu+9+dtAld+88H1X/EknX6Q7Z+Fr2gvX2OLd8r/7UHzcBEoBx2w/tuyMQteWvd46PrP/a7nCNs2UvXG+vc8v36k/9cRMgARi3/dC+GwJXk2RP4Hvn5yHVt5UHt+8G13hb9RrI2/Pc8r36U3/cBEgAxm0/tO+GwOMmFvwtztiywxxzBHIH4Nzy53DwsTACJACFGZzuJhH474klALaKoa1myDFHIHcAzi1/DgcfCyNAAlCYweluLYEHBAX/XwS1440RVp+Nf5aY3Qt3SbPJX+eWn6woBSdJgARgkmalUw4CEVv+2k59m0p60Mra/hEr93njRJONhhzoxlfVC9bb49zyvfpTf9wESADGbT+0jyVwh6Bf7c+bU+vuqzv+ecdbm3hx0pwufFxDoA3QtXXWNNXqv2vbavP/VkKpBIFVAt4JaSNIQmBCBD4QkACcL2nzJUz+XNI7JV0ZICc1Xtx/iS58HWAEL8RUIy4r55VP/bIJkACUbX96fxWBWwRt+XvAVU0u/d+Okg6T9KuAGLQsNtj3X5dEkr7UDP73PCuaTjpVZbyUc0lCKASBJQRIAJaA4eviCLwlIBhbQL9+A3JWdn9JdtUgZb5vWuYxDXQpsmhToPPlvdDm22v62Suf+mUTIAEo2/70/o8Eorb8PbwlULtl8FxJZwUmAmey6U+9NZoG3Pny9RKqS8y31/RzdeuchUA1gaElALuurFV+qKTTJV0WOBk2HVd9lbc+Wl+tz7tUm4qzHRI4MMDX7L6+Xdr3HJtIsuV6I/zvmR5FSqnrBe3llFu+V3/qj5vAUBIAe2Xq6KB7sN4xlau+LdZylCQLAhz9EdhK0kUBQfddQSp/JEAXW4PgWkH6TLoZ72D3wskt36s/9cdNYAgJgAW8EwMmPe9YGkp9Y0ES0N+42ifI93YLUNmugHnHpPnxSwN0KaIJ76D3Qsot36s/9cdNwDvZRDxhbL/8veNgavWPHLdbjUb7qC1/PxrUY7uK4PVl2/J36yB9Jt+MF7YXUG75Xv2pP24CuRMAu+/9u4BJzzuOhlbfmPBMQPdjy+6TR9j+HgGq7rDyy/2KAH3seQaORAJe4yeKWVost/ylinGiCAK5EwB7+M07BqZa/5AiPDBfJ23L3zMC/O/LQV2wNwi8vmwJhCUSHIkEvMATxSwtllv+UsU4UQSB3AmAPQHvHQNTrW9sOLojYO/IR/jOHgEq/omkSwP0sbUMOBoQ8DpAA1ELi+aWv1ApviyGQO4EIGLS846hodY3NhzdEfhqQMD9jqSNA1S01QO9fmhj+dYBuhTVhBe6F1Zu+V79qT9uArkTgIsDJj7vGBpqfXuYi6MbArY+foTdnxig3rUlnRugj+1jwNGQgNcJGorboHhu+RsoxBdFEcidAHALYHkg4hZAd0PRdsjzzr225W/E65q2c6BXF6t/l+5wTbdlL3gvmdzyvfpTf9wEcicA9qCbdwxMtf7B43atwWofteXv3gE9vIakHwWMgZMDdCmyCe/k4YWWW75Xf+qPm0DuBGBnXgNcmADZa4DGhiOewPsDAu4FkrYIUG3PAF0shjwgQJcim8gdgHPLL9LodHodAVt+1uODEQsBHeHUwaP/UOu23VRmnWH5z0ICUVv+vnxh682+tLFzWoDvf4Mtf5uBX1vaOwGsbavN/3PLb6MzdaZDYAgJgN1HPSFgIvSOpaHU/2TQveXpeGlcT94c4Ge/kbRtgEoPCtDFfPaxAboU24R30HvB5Zbv1Z/64yYwhATACFoSYL96S14V0Pp+GMG/swFlQduCt3fOtStWEcfnAnRhy1+nJbzO4BTvdkavfOqXTWAoCcDMCnbf2x5+s0ujJawRYH20vlqfuec/84Ju/kZss2tJ2k0C1Lt7QPC32PWsAF2KboIEoGjzF9/5oSUAxRsEAJ0Q2DJoy993B2n3HwEJAFv+BhiDBCAAIk2MlgAJwGhNh+INCNj2uN653urfpoHMZUVvJck77kyXfZcJ4Pt0Al6nSJe0uGRu+Yu14ttSCHgnooi3AEphTT/zENhU0s8DEoCPBan/zgBdLpNk+wdwOAnkDsC55TvxUX3kBEgARm5A1K8l8PSAgGvz9D1rJdUXuJGk3wboc1C9KEqkEMgdgHPLT2FEmekSIAGYrm3pmWRb/n4vIOBGbfkbsf21bfl7Y4wbQyB3AM4tP4YirYyVAAnAWC2H3ikEHh0Q/G2OfkiKsJoy1w16s+WtNXI43YBA7gCcW34DVBSdIAESgAkalS6tI3BqQALw3aAtf/cP0MWW7uZ10XXm9f8ndwDOLd9PkBbGTIAEYMzWQ/cqAvcLCLg2Pz+pSkjiuagtfz+YKI9iiQRyB+Dc8hMxUWyiBEgAJmpYuqUTAxKAnwatzPicAF0sVtwVu8YSyB2Ac8uPpUlrYyNAAjA2i6FvCoGoLX+fnyKspkzUlr+frpHD6RYEcgfg3PJbIKPKhAiQAEzImHRlHYH3BfzivkjSVutabP+fvw3QxeLE37RXgZrLCOQOwLnlL+PC92UQIAEow84l9dLW6o/YVOqVAdCitvz9Jlv+BlhjQRO5A3Bu+QuQ8FVBBEgACjJ2IV19Y8Av7qgtfx8YoIvFiMcXYrveu5k7AOeW3ztwBA6KAAnAoMyBMk4CNwja8vcopx6z6p8NSADOkmTPEXB0QCB3AM4tvwOkNDkiAiQAIzIWqtYSeE1AwLXbBzetlVRf4E4Bulh8eHa9KEq0JZA7AOeW35Yb9aZBgARgGnakF5Jt+XthQNB9TxDMDwfocp6kzYL0oZkFBHIH4NzyFyDhq4IIkAAUZOyJd/XFAQHX5uPbBnC6ZdCWvy8L0IUmKgjkDsC55Veg4VQBBEgACjByAV2M2vL340Gs3h6QjNiWv9cL0odmlhDIHYBzy1+Cha8LIUACUIihJ97NpwUEXJuL7xXAKWrL34MDdKGJGgK5A3Bu+TV4OD1xAiQAEzdwAd2L2vL3lCBWhwQkI2z5G2SMumZyB+Dc8uv4cH7aBEgApm3fEnr3qICAa/PwwwJgRW35a7cQOHogkDsA55bfA2JEDJgACcCAjYNqSQSGtOXvPwckI7bl7y5JPaeQm0DuAJxbvhsgDYyaAAnAqM1XvPL3DQi4Ngc/OYCkbfn7ywB9PhSgC00kEsgdgHPLT8REsYkSIAGYqGEL6dYnAwLu2ZKuGcBrrwBdLB7cLUAXmkgkkDsA55afiIliEyUwtARgV0mHSjpdkr0G5R0f1Pcz/JWkb6+8knakpN0GNA5MF7tc7rXxCwL6dHVJPwzQ5TMButBEAwJe52kgamHR3PIXKsWXxRAYSgJg73EfHbR4indMUX95UDV/eXPQL2bvIDs+IOBGbfn7hABdzO/+jxcK9ZsR8A72ZtJu333zAAAgAElEQVQ2LJ1b/oYa8U1JBIaQAGwi6cSgCdQ7nqi/PPivZfN5SdfKOFB2Ctry91+C+vC1AP+1qywbB+lDM4kE1jp1m/8nillarI3MtXWWNswJCCQQGEICYL/81/o0/x8Hj7cl+FdXRY4J8JnLJW0XoKD9ao/wWbuKwNEzAa/hvOrmlu/Vn/rjJpA7AbDXnWz3Ne84oH7/DO3+++0zuL9t+fvrAJ+xxDPisPv2Xv9jy98IS7Row2u4FiLXq5Jb/nrK8KE4ArkTAHvgzzsGqJ+P4RszjJhXB/hM1Ja/dwzQxfz3ORk4IjLAeF6I3snLK5/6ZRPInQDY0/7eMUD9fAztyfc+j6gtf48NUvrfA/z3fEmbB+lDMw0JeCePhuI2KJ5b/gYK8UVRBHInAJcGTKDeMUT99gnElZJsLf6+jhcF+cvtAhSO2vJ3vwBdaKIlAe/gbyl2XbXc8tcpwn+KJOC9/76Rk9rFQRO6dxxRv10SYAlAX0+u26uiPwvwl/90+uysuj0E6fUbW2OBLX9nRDP89RrQq3Ju+V79qT9uArkTAG4B+IOIdw7x1O/zFsBTAwKu9fU+AUM2astfewaGIyMBj/NbXe+RW75Xf+qPm0DuBCBi61TvGKJ++yTEXsfr47CrDN8LSACitvw9OEAX2/L3T/uAh4zlBLyDf3nLaWdyy0/TklJTJZA7AdiZ1wDdl5G9c0jb+vYaYMS99JSx9YiAgGv9fHiKsJoytuXvJQH6vKNGDqd7INDW+Wf1vCrO2mn71yuf+mUTyJ0AGP0jAibTtuOHeu1//b+1x6HzxQAf+X7QA4svC9CFLX97dJ4qUd4JoKrtlHO55afoSJnpEhhCAmBLAZ8QMKl6xxL105OBPpcC/qsg33hKwDCO2vL3wwG60EQAAe+g96qQW75Xf+qPm8AQEgAjaEnA4dwOGPztAHtt1Bb/idg+N3Xk/FdAAnBOkM7PDtDF5ny2/E21fsflcgfg3PI7xkvzAycwlARghsmeCbAHrE6TxBoB6b/IvfNIVX3blvlbq7dq/mJmqJ7+mryILX9fGKCvrXdgtxGqWKWc+1KALjQRRCDFYFVlvGpUtZ1yziuf+mUTGFoCULY16P08geMCAq6tNbHVfMMtPj8+QBeb0x/UQjZVOiKQEmSrynjVqmo75ZxXPvXLJkACULb9h9x72/LXFhpKmQeryrwqqJP/HaALW/4GGSOqmSrHSTnn1SNFRlUZr3zql02ABKBs+w+5968PCLhRW/7uHqCLzeN7Dhl4ibpVBdeUc15mKTKqynjlU79sAiQAZdt/qL3fJmjL3zcEdfBTAQnAT1Yfdg1SiWYiCFQF15RzXh1SZFSV8cqnftkESADKtv9Qe2+X7avmvZRz5ts3C+hg1Ja/zw3QhSaCCaQ4UlUZrzpVbaec88qnftkESADKtv8Qe7+FpAsDEgB7gDDi+GCALmz5G2GJDtpICbJVZbwqVbWdcs4rn/plEyABKNv+Q+z9PwUEXJs7I5YpvoUk75bZpsv+QwSNTv7LTF6GKUG+qoxXPvXLJkACULb9h9b7qC1/bfGgiMOWO66af1PO2Za/149QhjbiCaQYsKqMV6OqtlPOeeVTv2wCJABl239ovbflelPmvboytnyw97ihpN8G6HOYVxHqd0egzpHqzns1q2u/7rxXPvXLJkACULb9h9R72/LX3pOvm/Pqzn9N0kYBHTsoQBdbx4AtfwOM0VUTdc5Ud96rV137dee98qlfNgESgLLtP6Te21a9dfNdynnbOth7bB205e+7vIpQv1sCKQ5VVcarXVXbKee88qlfNgESgLLtP6TeR2z5+4OgLX/3DUhGbA+D3YYEGF02JJASZKvKbNhis2+q2k4510wapSGwPgESgPV58CkPgfsEBFybL58aoL7tdHh2gD4fCdCFJjomkBJkq8p41atqO+WcVz71yyZAAlC2/YfS+/8MCLhRW/4+K0AXm7v/cihw0WM5gZQgW1VmectpZ6raTjmXJoVSEFhMgARgMRe+7Y9A1Ja/LwpQmS1/AyCOqYmUIFtVxtvXqrZTznnlU79sAiQAZdt/CL1/b8Avbtvy9zoBnXlsgC42bz84QBea6IFASpCtKuNVsartlHNe+dQvmwAJQNn2z937Pwva8vfVQR35akAC8B1J9kojxwgIpATZqjLeLla1nXLOK5/6ZRMgASjb/rl7f3RAwLUtf7cP6MgDAnSxOfvvAnShiZ4IpATZqjJeNavaTjnnlU/9sgmQAJRt/5y9j9ry95igTpwckACw5W+QMfpqJiXIVpXx6lnVdso5r3zql02ABKBs++fs/b8EBFzbqCdiy987BOhi8/XeOYEiuzmBlCBbVaa5xPVrVLWdcm791vgEgWYESACa8aJ0DAHb8veCgKB7fIw6+kCALmz5G2SMPptJCbJVZby6VrWdcs4rn/plEyABKNv+uXr/goCAa/PjnQI6ELXl7wEButBEzwRSgmxVGa+6VW2nnPPKp37ZBEgAyrZ/jt5fQ9JZAQnACUHKvyVAF7b8DTJG382kBNmqMl59q9pOOeeVT/2yCZAAlG3/HL1/ckDAtbnxrwOUj9ry94gAXWgiA4GUIFtVxqtyVdsp57zyqV82gaElALuuLOhyqKTTJV0WFChSxtHUytg+9vYr+zhJewRtjxsxUmyb3m8F2PXrQX06MEAXG0M3iYBDG/0T8A58r8a55Xv1p/64CQwlAdhUkr0Tbk91e8cE9Tdk+CVJtuhO7uOhQfZ9VEBHtpJ0UYA+/xqgC01kIuCdLLxq55bv1Z/64yYwhARgk5WNU04MmIi9Y2nq9c+VtHNmd/1CgJ1ty9+rB/RjnwBdzGduE6DLrAlbQfAeK1sav2IlYXvH6j/7v33H6oIzSoF/vYPeq0pu+V79qT9uAkNIACJWg/OOo1Lqf1/SZplc9l5BAfdpAfpHbfn70QBdZk3cV9JpFYzsnJXhCCTgHfheVXLL9+pP/XETuLJiwknxTbun6zl2keRNQlL0pMxVtwXsl2+O4+NOXzMb2pa/1wpQ/hkBupg+9ss84nhe4u0vu0X2/AiBtPFHAt6Jwcsxt3yv/tQfN4HcCYA98OcdA9RvxtAeDvQmbk29/s8l/SHA1i9uKnhBedvy94wAXb68oO02Xz26IRvjaLsWcgQQ8E4eXhVyy/fqT/1xE8idANjT/t4xQP3mDG/Zs9u+J8DOlwRt+fuYAF3M5x4SwNAeRDyvhT4XSrpugPzim/BOHl6AueV79af+uAnkTgAubTH5eccM9aX79ei2UVv+viZI54gtf78b9FCeZ0XEFwbxKLoZ72TghZdbvld/6o+bQO4E4GISgCxXQCIW0Un1/KMCbBy15e/9A3SxOftJqZ2vKfcZhz6fq2mb0wkEcgfg3PITEFFkwgRyJwDcAmh++d47Z1j9vm4BRG35+6agMXiSI+DOuP9Ukr26GnH80qGP3TrgcBKYGbXtX6d4d/bvlU/9sgnkTgAOcUyAbcds6fV+3ONDgPYOu5e3Pfl+q4BhGrXl7z8G6DJrwvMGjD0M2PfDnDO9J/PX65xeELnle/Wn/rgJ5E4AbGEazyToHT8l1n9pTy5r6w20ecBt3ibvC9L3/QHJiG1hbFsZRx3elS9ZHMhpiXlna/rZKd6dHXvlU79sArkTAKNvG6k0HXeUb8fMXn/rayEge189wk53DhiiN098z75OX7uiEXmQAETSbNFWncHrzrcQuV6Vuvbrzq/XGB8g0JDAEBIAu59qW7vW+TrnfYzs13hfSwHblr92q8FrM1siOuKwZwi8uvxG0rYRyqxpgwRgDYwc//U6hVfn3PK9+lN/3ASGkAAYQUsCDud2gDtILZtP+t4MyJ6SX6ZLk+8jXle0oG3Bu4ncRWWP7GCokwB0ALVJk4sM3eS7JrIWlW0ia1HZRW3yHQRSCQwlAZjpa79QD15dE501AtoHLdsO2H6BH5thO2B7MC3i7Y6oLX9fGxD87TmVLrb8JQGYjfxMfxcF1SbfedVuImtRWa986pdNYGgJQNnWmEbvbYW8RXNV0+9siVzvsWXQlr+2kmEXBwlAF1QbtNnUKefLNxC1sOh8e00/L2yULyGQSIAEIBEUxZIJfD4gATgzaMvflwToYnPybZN736wgCUAzXuGlmwbc+fJehebba/rZK5/6ZRMgASjb/tG9v2dQwLXd+rzHppJ+HqCP7WLY1UEC0BXZxHabBtz58olilhabb6/p56UNcwICCQRIABIgUSSZwMcCAu4vgrb8fXqALjYf3yu5980LkgA0ZxZao2nAnS/vVWa+vaafvfKpXzYBEoCy7R/Z+6gtfyMWKrItf78XkACcEgloQVskAAug9PlV04A7X96r63x7TT975VO/bAIkAGXbP7L37w4IuLbl79YBStkDhE3n0kXlHxqgS1UTJABVdHo4t8joTb7zqthE1qKyXvnUL5sACUDZ9o/q/Y6SvL5k89uBQQqdGpAARG35W9UlEoAqOj2cWxRUm3znVbGJrEVlvfKpXzYB76TNZiRl+8+s9xHLOV8haYdZg46/tnjQormy6Xd/79AhtSoJQCqpjso1dYr58l615ttr+tkrn/plEyABKNv+Eb3/E0mXBQTdN0coI8mWD246j86Xj9zyt6pbJABVdHo4N2/4pp+9KjaVN1/eK5/6ZRMgASjb/hG9f3lAwLWtbW8doMztA3SxOfYFAbqkNEECkEKpwzLzAbXpZ69qTeXNl/fKp37ZBEgAyra/t/e2s+C5AUHXtuqNOP4tQJeLJG0VoUxCGyQACZC6LDIfUJt+9urWVN58ea986pdNgASgbPt7e793QMC1Oe0uXkVW1+q3Nfvn58imn18ZoEtqEyQAqaQ6KtfUOebLe9Wab6/pZ6986pdNgASgbPt7eh+15e/JHiXW1H1jQPDvYsvfNSpu8F8SgA2Q9PtF04A7X96r7Xx7TT975VO/bAIkAGXb39P7JwYEXJvvHuBRYrXuDYK2/D06QJcmTZAANKHVQdmmAXe+vFel+faafvbKp37ZBEgAyrZ/295Hbfn7DUkRr5K+JiAZsdsHN20LpGU9EoCW4KKqNQ248+W9esy31/SzVz71yyZAAlC2/dv2fo+AgGtz3WPbKrCmnm35e2GAPu9d02Zf/yUB6Iv0EjlNA+58+SXNJn89317Tz8mCKAiBBQRIABZA4ataAkPa8vfFAcHf5t2utvytgkkCUEWnh3NNA+58ea+K8+01/eyVT/2yCZAAlG3/Nr3/y6CA+8w2wufqRG35+4m5dvv6SALQF+klcpoG3PnyS5pN/nq+vaafkwVREAILCJAALIDCV5UEPhKQAERt+fu0AF1szr13ZY+7O0kC0B3bpJabBtz58klCKgrNt9f0c0XTnIJALQESgFpEFFhDYFdJtmpf03lqvvw+a9ps+9+xbPlb1T8SgCo6PZybd8ymn70qNpU3X94rn/plEyABKNv+TXv/roDgb/sG2P4B3uNRAbrYfPpwryKO+iQADngRVecDatPPXh2aypsv75VP/bIJkACUbf8mvbed+mzHvvk5qOnn1zURWlE2Ysvf/5G0cYWMrk+RAHRNuKb9ps47X76m+drT8+01/VwrgAIQqCBAAlABh1PrETg8IPhbAnHj9Vpt9+G+AbrYXPuUduLDapEAhKFs11DTgDtfvp3Uq2rNt9f081Ut8T8INCdAAtCcWYk17JL9pQFB9y1B8D4ZoMvZkq4ZpE/bZkgA2pILqtc04M6X96rx2wBHnteJz/7LlDCsZ2i+G33YQ2aHSjo9aI/5sdrR7pMbA2OxSzTkFu0dEDBPRW35u1vQg4j/1IJDdBUSgGiiDdvzThANxW1QPGIrTW8fqF8f7GC0ISN7lSvqsPe5bR1274Q4RTsZk6MkbRIFu2E71w7a8veDDeUuK358QDJycY9b/i7rh33v9feczy9U9Ws057wThrejpwQ4s7cP1N8wuMGknskXvc6/Wt8C24mMg9qH64xRjiTgeUG2uWuAv+wkKWLL31cF6BLRBAlABEVHG96J3iH6f6tGbGHp7QP164MdjDZk9Aav86/Wt1/+8E1jcGQQ89RmbMvfHwXY51OpAmvKHROgy+WStquR09dpEoC+SC+R4514ljSb/PVjAhza2wfqp02+cFqf0yOTvXx5Qbu/HfGLrhTbGKs+nwn4u6D5afflLpB8xrb8/XWAPq9Plth9QRKA7hlXSvBOHJWNJ5zcPOjpWm8/qL9+cINHNQ97SM1813vYQ26wbsbgEC/0xPq2Te9pAfaJ2vL31QG6WAJ1s8T+91GMBKAPyhUyvJNPRdPJp7gN0GwC9NqM+n7eUZf/7Ul37NGMgTHr43hQkG0eF6Bs1Ja/xwXoEtkECUAkzRZteSefFiI3qHITSbwO2GwS9NqN+u152z3UHTfw4nZfRLxbXpotjVkfx+cCEoAzJV09QNkXBehifnK7AF0imyABiKTZoi3v5NFC5MIq/zfIwb39oX77wFgKu1cu9OB2X16C3ze+AmLMuj4sUEb4814BikZt+WuLBw3tIAHIbBGvk0epb0/b2pOyXn2oD8MufeDzkmxCjjq4BdDcX/u4BXBgwFx0nqTNAhzlqQG62Jj4qwBdopsgAYgm2rA972TZUFxlcXvK9cdBzu7tF/WbT8xTZ2a+aT4aedgDbVPnFt2/gyMNsKStzwbY5Z+XtN3ka1voxjbs8TK0jYOGeJAAZLaK17Gi1bdXfEgC/APea1fqr28D88kuXj/jNcD1Odf5nT3FvnP0pLOgvTOcQdeeU7jugnabfmVb9dYxSTkf8cpqU91TypMApFDqsEyK81SV6UK163E7IGTQV9mNc+kTq13237YLR19t0xa3wR5pDGxHvj6Os5w2ibpKYatNen3j+5Ku1ge0FjJIAFpAi6zida5IXda2ZfdZ92ONAPfg99q35Pr2tL898Nf18rPW/gkBE/3UbWWMurbFbA6yoOnh+Rezhhx/7+PUYaa/PUMw1IMEILNlZk7S9m/X6ts9V/uFxOtSvgmprX1LrGe+ZqulRb3qlzJGLLAdwaqAC4OuXfa3X/59BX+z13edwffWKUavKfNfTh1s7J4zgC1/q7pJAlBFp4dz3gm+BxX/V4Stuvao1YnZLovZTmz2C82rP/XLZmg+ZL5kPmVr8tu90ognt9uOC7u/bZePbQW6kpNe67sxMBZ93POft9c3nXOL9wqA1bftg73zk60fMOSDBCCzdbwOlll9xEMAAhAIJ/BVZ/C9vVMjW7HPOzfblr/XcerRdXUSgK4J17TvdbKa5jkNAQhAYHQEvuQMwHdx9Ni2/L3SKd/mdVtcbegHCUBmC5EAZDYA4iEAgcER8K4DcA9Hj2yfCe+8bLe2hrLlbxUKEoAqOj2c8zpaDyoiAgIQgECvBE5yBuG2q+5tE7Tl7zG90movjASgPbuQmiQAIRhpBAIQmBCBTzgTgN1bsNhaUsST/0Pb8rcKBQlAFZ0ezpEA9AAZERCAwKgIfMSZANhWwk2OW0j6jlPmbC4/vongzGVJADIbYOY0bf9mVh/xEIAABMIJfNAZjB/WQKMHSrrIKW/t/H2nBrJzFyUByGyBtY7T5v+Z1Uc8BCAAgXAC9iu6zXw4q/PoBI02kmTv6XuD4Eym/R3ilr9VKLx9t82SOBwE1jpPm/87RFMVAhCAwCAJvNuZADyhpldbSPqAU8ai+fq+NXKHdpoEILNFFjlRk+8yq494CEAAAuEE3u4Mzk+q0OhmKytOfsvZ/qI5+uuS7KrCmA4SgMzWWuRITb7LrD7iIQABCIQTeJMzQC/bgMfeDrjQ2fay+dmWSh/bQQKQ2WLLnCn1+8zqIx4CEIBAOAHbFyJ1DlxU7tlzGnVxv3+t3B8MeMvfORTrfSQBWA9H/x/WOlGb//evMRIhAAEIdEvgUGcCsPca9Wwjs39ztlc3N//DGnlj+i8JQGZr1TlW3fnM6iMeAhCAQDiB1zkD9gtXNbqxpFOdbdXNwdb+1cIJ9NMgCUA/nJdKqXOuuvNLG+YEBCAAgZESeJUzaO8j6a8lne9sp27+PVvSzUfK2NQmAchsvDoHqzufWX3EQwACEAgncIAzcH9Tki3JWzd/es6fKelW4T3vt0ESgH55byDN44BWlwMCEIDA1Ajs23Hw9s67n5ZkGweN/SAByGxBryNmVh/xEIAABMIJ2Ap93rmxq/q20981wnucp0ESgDzc10n1Oum6hvgPBCAAgYkQ+McBJgCXS6paYGiM6EkAMluNBCCzARAPAQgMjsBeA0sAfirpjoOj5FeIBMDP0NUCCYALH5UhAIEJEnj6gBKAz0nadoKMrUskAJkNSwKQ2QCIhwAEBkfgyQNJAOx+/yaDoxOnEAlAHMtWLZEAtMJGJQhAYMIE9sycANj9/qdMmO+sayQAMxKZ/pIAZAKPWAhAYLAEHpsxAfi5pLsMlkysYiQAsTwbtza0BGAXSYdIOl3SpRkHoZcL9Yf7GhW2GYdtzpN0ysocsJ+k7RrPbL4Kj8g093xVki0fXMpBApDZ0t7JMEp9u89lO3B5HcLbH+qPIzhgp7LsdNnKNrrPjZpsEtrZI0MC8C5J10rQbUpFvPP9xlOCkaMv3ok0QmcL/idmGHDevlO/rCCEvfPb++CICSehjb/pcT66UpItPFTiQQKQ2ereSS1Cfe/e294+UD//xI4NsEGqDzwxYtKpacM28knVx1PuXEn3qdFlyqdJADJb1+O8Vtd77Mpl/14mGq+dqd9PQIBzPedzJG3unXhq6t+rhwTga5J2rNFj6qdJADJb2DvheNU/rIeB5u0j9esnZRjBqE8feLx34qmpf7eO56X3Srp2jQ4lnCYByGxl76D1qv+tjgeat3/UJ7DhA8Pzgbd7J56a+nfoaF6yLYJLvd+/CDkJwCIqPX7nndy8qvKq3/AmV69PUB+bdu0DJ3snnpr6u3WQAJwvyZ4t4LiKAAnAVSyy/M87UL1KkwAQLLw+SP3yfOgk78RTU/9mwQnANyTtVCOzxNMkAJmt7p08vepzC6C8ydvrc9THZ7q+BWD35+31vAhfO17SZt6JcqL1SQAyG9br4F71Dw0aZN5+UD9msoMjHPvwgcd5J56E+p9xzk0W3F4qaaMEWaUWIQHIbHnvYPWqb0v/2oMxXj2oD0N8oAwfOLuH1wBtXrMko61PXbiyjLEtJsRRTYAEoJpP52fbOvisXoSCRzkG2kwP/rafrGAHuzH5gO3U18dhy8x+tsXc9G1JN+9DwQnIIAHIbETvwI9Qn6WACUBeP6R+GT7U11LAs3lte0lnNEgCPiRpy1ll/tYSIAGoRdRtAe/EGaWdJQFHcjug9SVHrx2pX0YAHaud7W2hvaImm4btbCPpIzVJwG8kvZD7/Q3J+jd/YzOgxsjXr+CdENZvzf9p7XbAtgOYVz/qwxAfGKcP2Hvzs+2At/VPLe4W7i3pHZJ+KOlySZdI+oqkV0i6obv1MhvgCkBmu3snx8zqIx4CEIAABEZKgAQgs+FIADIbAPEQgAAECiVAApDZ8CQAmQ2AeAhAAAKFEiAByGx4EoDMBkA8BCAAgUIJkABkNjwJQGYDIB4CEIBAoQRIADIbngQgswEQDwEIQKBQAiQAmQ1PApDZAIiHAAQgUCgBEoDMhicByGwAxEMAAhAolAAJQGbDkwBkNgDiIQABCBRKgAQgs+FJADIbAPEQgAAECiVAApDZ8CQAmQ2AeAhAAAKFEiAByGx4EoDMBkA8BCAAgUIJkABkNjwJQGYDIB4CEIBAoQRIADIbngQgswEQDwEIQKBQAiQAmQ1PApDZAIiHAAQgUCgBEoDMhicByGwAxEMAAhAolAAJQGbDkwBkNgDiIQABCBRKgAQgs+FJADIbAPEQgAAECiVAApDZ8CQAmQ2AeAhAAAKFEiAByGx4EoDMBkA8BCAAgUIJkABkNvwVkjxJwCaZ9Uc8BCAAAQiMj8A1nLHHYheHk8D5TiNc3ymf6hCAAAQgUB4Bix2eH58WuzicBH7sNMKdnPKpDgEIQAAC5RGw2OFJAH5YHrL4Hp/qNMLT4lWiRQhAAAIQmDiBpzpjz1cmzqeX7r3HaYTjetESIRCAAAQgMCUCxzpjz7unBCNXX/Z3GuEySZvnUh65EIAABCAwOgKbSbrUGXteNrpeD1DhhzuNYPdwnj3AfqESBCAAAQgMk4D38r/FnYcNs2vj0sqexPyDMwn4paQtx9VttIUABCAAgQwE7NXxHzhjjsUs3kALMt5pTmNYNvbyIF1oBgIQgAAEpkvgJQHx5uvTxdN/z14XYJDfSrp7/6ojEQIQgAAERkLgrpIuD4g3B46kv6NQ83YBBrGrAOdJ2mkUPUZJCEAAAhDok8D2kn4WFGt261PxEmR9O8gw35L0pyUAo48QgAAEIJBEYIeVh/a+GRRj7JY1RzCB5wcZx64E/ILbAcHWoTkIQAAC4yRgl/3PCYwve48Tw7C13kKSd18AC/6zf/ZMwD6SNh12t9EOAhCAAAQ6IGBP+7806J7/LK7YbWbWnenAWNbkAWsC+Ay49++ZK9nf0zFaRxajWQhAAALDImCL/NgS8Tb3e+PHfP19h9XVaWmz9erl+3noEZ9txcDjV9p/hqQ7S9pGElsJT8t/6A0EIFAWAdvS1+Zy29jHgr4tDe9d4W9ZvDlb0lZl4e2/t0/qIGtbZtCU7y+RdPqK4Q+RtHMPOHZZlWUyu3LklH5TJv7XA0xhig+M1wee0MP8X7yIjSR9fmBJwGzQ/k7SER1dObCrEUdL+v1A+z5jwN/xTmDYDtvhA+184OSVW9QWmzh6IGDv8l804EB4QnASYMH/xAH3l0mj3aQBN7jhA+P3gQsk7dhD3EPEGgKPHnhAPHyNrt7/2i9/JgoY4AP4AD4wLB+wNf/38E7w1G9H4OABB0a7HRDxTMCuXPYn+RmwnxOQhhWQsEe/9nhVu9BFrQgCds/l7VAJMTYAAARVSURBVAOeHC1B8R6HDbh/TDb9Tjbwhjc+MBwf+Ffu+3vDm7++3R//2ECDZMSSkLZ0MYMeBvgAPoAPDMcHPiTJXjHkGAABSwLePcBAaa8Ieg9e9RvOoGcCxhb4AD7wToK/N6zF199Y0kEDSwIiEgBrg0kHBvgAPoAP5PUBe+DP7vnzul98/A5r8ZEDekWQWwB5BywTJvzxAXwgwgfsVT+e9g8L0902ZOsEfG4Av5wjHgI8dAD9iBhAtMFEjA/gA2P0AVvkh/f8u43Z4a3bZRpbNti2/s3hdPYa4K0DemVL/1pbOfqATLjjA/hAqT5ga/vb8r5c8g8IZLmauM6K4P2DtxJOGRD2+l7UcRQJAAkQPoAP4AO9+MC5q1vFbxk1gdNOfgK2R/Pekvp4rY6lgPnVlJIkUgY/wQeG4wPfXHl+7HlsDZ8/WHetwW0kHSjJDG5PdkYNQrtUb0sA22uJ0Ye1eSS3A8JsFWVz2okbP7CEZZ8+YBurfU3SayXtFj1h0944CFxvJRF42EoSsN/qWgJfkXSmJHvq88qE5OCyjNsBm+w+Bwyy4I0P4ANj8oErVufyH0iyud3Wi9lX0kNXflDZ3M8BAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACAyfw/wFF/IQkTID3lgAAAABJRU5ErkJggg==">
							</image>
						</defs>
					</svg> </span>
				<h3>Sản xuất nội dung video</h3>
				<p>HomeNest thiết kế và sản xuất các video độc đáo, thu hút, bắt kịp xu hướng TikTok, tạo ra nội dung
					nổi bật và hấp dẫn người xem.</p>
				<div class="tiktok-driver"></div>
			</div>
			<div class="service-category">
				<span class="elementor-icon">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="64"
						 height="64" viewBox="0 0 64 64" fill="none">
						<rect width="64" height="64" rx="12" fill="#D9EBFE"></rect>
						<mask id="mask0_3799_23358" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="12" y="12"
							  width="40" height="40">
							<rect x="12" y="12" width="40" height="40" fill="url(#pattern0_3799_23358)"></rect>
						</mask>
						<g mask="url(#mask0_3799_23358)">
							<rect x="0.890625" y="-14.1113" width="76.6667" height="95.5555"
								  fill="url(#paint0_linear_3799_23358)"></rect>
						</g>
						<defs>
							<pattern id="pattern0_3799_23358" patternContentUnits="objectBoundingBox" width="1"
									 height="1">
								<use xlink:href="#image0_3799_23358" transform="scale(0.00195312)"></use>
							</pattern>
							<linearGradient id="paint0_linear_3799_23358" x1="0.890625" y1="-14.1113" x2="80.3797"
											y2="-11.7027" gradientUnits="userSpaceOnUse">
								<stop stop-color="#020C6A"></stop>
								<stop offset="0.567007" stop-color="#1A85F8"></stop>
								<stop offset="1" stop-color="#66E5FB"></stop>
							</linearGradient>
							<image id="image0_3799_23358" width="512" height="512"
								   xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAAAXNSR0IArs4c6QAAIABJREFUeAHtnQfYLVV19/+ggkoTowgohmAXSLDX2GJU8qnYe4hGY0clGhsYQI2fivSi2EtUIJZobIkUe0GMBSwRRcUCSi8qgvp974rvubz33HNm9sxaM3tm9m+e5z7vPWf23mvt31p7r3Wm7C1xQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAQB8EtpH0cEkHSHqvpK9K+pGkCyRdKen/8Q8G+AA+gA+M0gdsDre53Ob0U1fneJvrbc63uZ+jQAK3l3SwpNMl/YGBPcqBTWJGcooP4AMeH7C532LAQZIsJnBMmMAWkl4g6TsEfAI+PoAP4AP4wJwPWGywGGGxgmMiBK4r6RWrl4E82SJ1+bWBD+AD+MD0fcBuGVjM2HoiMbDIbmwkaU9Jv5jL8hjA0x/A2Bgb4wP4gNcHzpf0XEkbFxlBR9zpm0r6AoGfS3z4AD6AD+ADTh+wWGIxhWMEBOzpzgudBvdmjtTn1wc+gA/gA9PxgUskPX4E8a9YFe0yzaEEfrJ9fAAfwAfwgY58wGIMtwQGlmZsIuk9HRmcLH46WTy2xJb4AD7g9YEPSLrmwGJgsepY8P8YwZ+MHx/AB/ABfKAnH/iEJIs9HBkJ2JP+7+jJ4N6skfr88sAH8AF8YDo+cCy3AzJGf0mHEPzJ+PEBfAAfwAcy+YDFII4MBB6ZyeBk8NPJ4LEltsQH8AGvD/B2QM8JwE0kXUQCQNaPD+AD+AA+kNkHLl15CP3mPcfAYsXZKxgs8kPW7s3aqY8P4QP4QJQPWEzi9cAe0pInZ872ohyGdph88AF8AB+Yjg/8fQ/xr2gRtjnDLztKAGylp/dKeurKa4V3lHR9SVcvmjadhwAEIDBuAjaH21xuc7rN7fbkvl2y7yLxstjEBkId+svLOzDcOStJxTMlbdah3jQNAQhAAALDIGBzvc35NvdHJwIWozg6IGB7NNs2jVEGu3ylrf0kbd6BrjQJAQhAAALDJmBz//6SLBZExRXbQdBiFUcwgecHGskyv7sG60dzEIAABCAwPgJ3C9423mIVRzCBbwclAKdLunGwbjQHAQhAAALjJWAxwWJDxJUAi1UcgQRuH2SYcyXtFKgXTUEAAhCAwDQIWBIQ9VzAbaeBZBi9OCggAbD7PHaphwMCEIAABCCwiIDFiIhnAl63qHG+a0cg4tKMPezBAQEIQAACEKgi8JKAH5ynVQngXDqBbST9wWkQu6zD0/7pzCkJAQhAoFQCts3vD5wxx2KWrT/A4STwCKch7KGOZzl1oDoEIAABCJRDwBYN8j4Q+PBycHXX0wOchriMX//dGYeWIQABCEyQgC0W5F0xkNvOAY7xHmcCYEs/ckAAAhCAAASaEDjOGXssdnE4CZzqNIJdyuGAAAQgAAEINCHgvQ3wlSbCKLuYwFnOBMA2geCAAAQgAAEINCFwZ2fs+XETYZRdTMDWVvY8jMGTmIu58i0EIAABCCwnYLHDE3ts7xoOJ4ErnEawVzo4IAABCEAAAk0IXMMZe65sIoyyiwl4MjCr2+dhS0nuJekTkr4ryd5AsH/2f/vu2ZJ26FOhOVnoNweEjxCAAAQqCPzemQRsXNE2pxIIjCEBuKGkYyT9LsFZzKGOl7RjQt+jiqBfFEnagQAESiJAApDZ2kNPAB7S8n3RSyQ9uAe26NcDZERAAAKTJEACkNmsQ04AnivJ4yBW9zkd8kW/DuHSNAQgMHkCnvndYhe3AJwuMtQEwH5Ze53D+mZtdHElAP2cjkd1CECgeALeOZ4EwOlCQ0wAbtTysv+yvtjtgO2dnNZWR7+1NPg/BCAAgXYESADacQurtSxopn4fpsiaht6a8LBfqn6zcm9a0773v+jnJUh9CEAAAv6rvFwBcHrRLEC2/esUv0F1e5Uu5Wn/pvpam/bL3Xugn5cg9SEAAQj8kQBXADJ7QtNAOl8+Wn17aG9eRtTniG2L0S/a4rQHAQiUSoAEILPlvcE1Wv2Pd5gAfDRAWfQLgEgTEIAABAIe9OYWgNONhpYAnNFhAmArBnoP9PMSpD4EIACBPxLgCkBmTxhaAnBphwmAte090M9LkPoQgAAE/kiABCCzJ5SUAFwcwLrLBKAE/QJMQBMQgMBECJAAZDbk0BKA/+nwCsB3AlijXwBEmoAABCDAMwD5fWBoCQAP2fl8Yuj8fL2jNgQgMCUCXAHIbM2hJQC2pa9Xp2X1nxHAGv0CINIEBCAAAa4A5PeBZcEy9fvoHuzQ0UJAVwYtBIR+0RanPQhAoFQCXAHIbPnUQL+sXBfqv7mDqwBvCFQU/QJh0hQEIFAsARKAzKZfFthTv+9C/RtKsg18UnWoK2dP128XqCj6BcKkKQhAoFgCJACZTV8XPOvOd6X+7kG3AszBHtSBkujXAVSahAAEiiJAApDZ3HUBvu58l+rbuvseB7G6e3WoIPp1CJemIQCByRPwzO8Wm1gK2OkidQG+7rxTfG31B7e8HWCX/R9Y27q/APr5GdICBCBQJgESgMx2rwvwdef7UP/6kg6TZE/y1+ljDvXO4Hv+dX1EvzpCnIcABCCwIQESgA2Z9PpNXUCtO9+nsjeSZFv6fkySrepny/LaP/u/7fT3zKBX/dr2Cf3akqMeBCBQIgESgMxWrwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwdeczq494CEAAAhAYKQESgMyGqwvwnJdgAAN8AB/AB4bnAxtnjp+jF49TD8+psQk2wQfwAXyg3gdIAJwpCE5W72QwghE+gA/gA8PzARIAEgAu0Wt4A5PJEpvgA/hA1z5AAkACQAJAAoAP4AP4QIE+QAJAAsDAL3Dgd/3Lgvb59YoPDN8HSABIAEgASADwAXwAHyjQB0gASAAY+AUOfH6dDf/XGTbCRl37AAkACQAJAAkAPoAP4AMF+gAJAAkAA7/Agd/1Lwva59crPjB8HyABIAEgASABwAfwAXygQB8gASABYOAXOPD5dTb8X2fYCBt17QMkACQAJAAkAPgAPoAPFOgDJAAkAAz8Agd+178saJ9fr/jA8H2ABIAEgASABAAfwAfwgQJ9gASABICBX+DA59fZ8H+dYSNs1LUPkABkTgCc4qkOAQhAAAKFEvi988cLCYDTcbwZmlM81SEAAQhAoFACJACZDU8CkNkAiIcABCBQKAESgMyGJwHIbADEQwACECiUAAlAZsOTAGQ2AOIhAAEIFErgdzwDkNfyJAB5+SMdAhCAQKkEznUkABeUCi2y3yQAkTRpCwIQgAAEUgl8yZEAnJIqhHLLCZAALGfDGQhAAAIQ6I7AyxwJwH7dqVVOyyQA5diankIAAhAYEoFtJF3SIgm4VNJ2Q+rIWHUhARir5dAbAhCAwPgJ7NUiAbA6HAEESAACINIEBCAAAQi0JnBQgyTg4NZSqLgBARKADZDwBQQgAAEI9ExgT0lnVyQCds7KcAQSIAEIhElTEIAABCDQmsBmkh4n6W2STl799/bV7zZv3SoVlxIgAViKhhMQgAAEIACB6RIgAZiubekZBCAAAQhAYCkBEoClaDgBAQhAAAIQmC4BEoDp2paeQQACEIAABJYSIAFYioYTEIAABCAAgekSIAGYrm3pGQQgAAEIQGApARKApWg4AQEIQAACEJguARKA6dqWnkEAAhCAAASWEiABWIqGExCAAAQgAIHpEiABmK5t6RkEIAABCEBgKQESgKVoOAEBCEAAAhCYLgESgOnalp5BAAIQgAAElhIgAViKhhMQgAAEIACB6RIgAZiubekZBCAAAQhAYCkBEoClaDgBAQhAAAIQmC4BEoDp2paeQQACEBgbgWtL2knSbSTdTtJNJG0+tk6MRV8SgLFYCj0hAAEITIvAJpLuJ+k1kk6SdJ6kZTHpQkmflnSopN1X6lxrWijy9GYZ7NTv82iNVAhAAAIQGCsB+2X/ZkkW1FNjzXy5X69cHXiXpLuPFcIQ9J6H2vTzEPqADhCAAAQgMHwCd139Fd80ztSV/9JKu/cefveHp2Ed2Lrzw+sRGkEAAhCAwJAIbCPpWMev/bo4NDv/IUnbD6njQ9dlBq7t36H3D/0gAAEIQCAfgQdL+mUPwX8Wwy6Q9Ih83R2X5Bm0tn/H1Vu0hQAEIACBPghsJOlFkn7fY/CfxbE/SHq1pI376OiYZcyAtf075r6jOwQgAAEIxBOw4H9khsA/H8feRhJQbdx5YE0/V7ced3ZLSY+V9CZJp6xeUrpiAA7WlBfl2z/12wU78yG7PGk+9UZJj5G0RZzbNm5p19XXnE6XdBn+3foJ8S58ZUhtmt/+RNLxkh4qyQLukI5jBuS7FjOGxmcwtvI6ddcd2U7S6yX9akAO5WVG/WElAfP2MF+zScMWIOnr2FTS0Zkul873n8/D9s9F9vny6uI5fflrlZwXDnCufnGVwiWfW+RMTb7rit01Vy7dvJxfQfwCyjiZ2K8su49owbnLwxZDOTFjP5uMd8oONzmwRXR27tJRE9q2RX1y3POv80vTyXTjmCNQB67u/FxzIR+v19G7onV94fxwJ7ectvmCpG1DPHtxI/bLP2f/kD0d/t+XtNliN+v8260knTVgX/6ZpK07pzAyAd7BH93dXQbuRF5e1B/nZGsTm/lm9GFt/m7Akyb+Oj5/3TfaSRPbs2dohu4vb0jsSzHFvAaLBHUDgv/gB5DXX8Zc335BRC8yYuuaj5kJug/Pfj/N8NDbLSRdOQJftmT71pFBa+xteQdwVP/tnr9davXqQ30YdukD5qORzwTY0/5d6kvbZfK9VdTEnNjO+0bkx8cl9qmIYt4JIgqSPfDn1YX6MOzDB/aPcnpJl+L3jPsOfOD+gT5a19QtB/rg37K5wK5U3KiuU6WcXwYp9fsITvaqH+88E7xTfS53OQvaUQ8FXtzB5J+bD/Lzj+U+n3h/a0c+fEmHcSEyiY+Igdna8A7WCMXtPX+vHtSHYZ8+cFSE46+sWc4tAPy2C7/t6xaA/ZL+bdD8bcv3fkLSQ1YWw7rOmvFlyfYTJX0xSI7xtnHHEQDUC9FW+GORHybBLibBLtu0K1abe51f0iEBY7DLftL2+MamvbHS18p3BwX57y8k7V4znqxPT1rZX+A3QTL7XOirpmv5TnsHuFdzW97XqwP1YZjDBx7tdf7VhVt4DRD/jfTffQL8MqWJ60qyy/Re3c+V1OSKxT0lXR4g164qFH94jecFaEuuenWgPgxz+ICtdx5xHMEYYA4I8oEzelwIyNYbiBh3D2wxiJ4TIDvqNl4L9YdTxWtAb09sExavDtSHYQ4fsHuSEYctBXwC44B5wOkD9ku6r3fcry3JLtt7x91HWw6gq0uyZMcj/6SWsidVzQPQ6noPc1qvDtSHYQ4fsF0Eow5LAg5nVUDmgpbzoSWjfxbljAntPKulnvPj9O4JspYVeYlTh+8ta7ik7+cN0vSzl1XUE6RN9aY8SYPXB8x3ow/bzOVgSaexRgDJQEWAM9/7saRjJe3R40N/5u/26/vMCt1Sx9VnnYPnzk4dLnLKn0T1VGMtK+eFsKzd1O+98qlfNgF79SjV1xaV6+tp67KtRO+HRODxzjEzG0dt7v2v5bCDUw97k6f4Y2aMtn+9ANvKndXzyqd+2QRIAMq2P71vRsAS3q87A6/N3fYevjd5vrFTD3udsPhjFkjb/vUCbCt3Vs8rn/plEyABKNv+9L4ZAXtXfzb3ev7u2UzswtL3cury84WtFvalx4hW13vklu/Vn/rjJkACMG77oX2/BD7lDLqz+d6ec7El4D3Ha5y62JWM4o+ZQdr+9QJsK3dWzyuf+mUTIAEo2/70Pp2A96G72Zw9+2uL+dg6MDdPV2FdSXtr5ifOBOD961or+D8zY7T960XXVu6snlc+9csmQAJQtv3pfTqBf3cG3NmcPf/395L+Y2UfAEswUg9bEni+naafX5YqbMrlmkKbL+9lM99e089e+dQvmwAJQNn2p/dpBGypXgvUTefnpuVPlFS3k+HGkr4doEvd3gNpZEZeqqmB5st7uz/fXtPPXvnUL5sACUDZ9qf3aQS62vJ32Xz/jZW1BuxBQVtzYP6w3QKX1Uv9/teSbDXD4o9UYMvKeQEuazf1e6986pdNgASgbPvT+3oCNwzc8jd1Xp+V+/7KksPPkHTNNWp+ISAB+PCa9or+7wx0279eeG3lzup55VO/bAIkAGXbn97XE3hdQMCdzddt/54j6aWSHhyky0Pru11GibYGmdXzUpq10/avVz71yyZAAlC2/el9NYGtg7b8bTu/d1HP3v9fdGuhmsREz3oBe7Hklu/Vn/rjJkACMG77oX23BKK2/PXO85H1bRMhjlUCXrBekLnle/Wn/rgJkACM235o3x0Bu+9+dtAld+88H1X/EknX6Q7Z+Fr2gvX2OLd8r/7UHzcBEoBx2w/tuyMQteWvd46PrP/a7nCNs2UvXG+vc8v36k/9cRMgARi3/dC+GwJXk2RP4Hvn5yHVt5UHt+8G13hb9RrI2/Pc8r36U3/cBEgAxm0/tO+GwOMmFvwtztiywxxzBHIH4Nzy53DwsTACJACFGZzuJhH474klALaKoa1myDFHIHcAzi1/DgcfCyNAAlCYweluLYEHBAX/XwS1440RVp+Nf5aY3Qt3SbPJX+eWn6woBSdJgARgkmalUw4CEVv+2k59m0p60Mra/hEr93njRJONhhzoxlfVC9bb49zyvfpTf9wESADGbT+0jyVwh6Bf7c+bU+vuqzv+ecdbm3hx0pwufFxDoA3QtXXWNNXqv2vbavP/VkKpBIFVAt4JaSNIQmBCBD4QkACcL2nzJUz+XNI7JV0ZICc1Xtx/iS58HWAEL8RUIy4r55VP/bIJkACUbX96fxWBWwRt+XvAVU0u/d+Okg6T9KuAGLQsNtj3X5dEkr7UDP73PCuaTjpVZbyUc0lCKASBJQRIAJaA4eviCLwlIBhbQL9+A3JWdn9JdtUgZb5vWuYxDXQpsmhToPPlvdDm22v62Suf+mUTIAEo2/70/o8Eorb8PbwlULtl8FxJZwUmAmey6U+9NZoG3Pny9RKqS8y31/RzdeuchUA1gaElALuurFV+qKTTJV0WOBk2HVd9lbc+Wl+tz7tUm4qzHRI4MMDX7L6+Xdr3HJtIsuV6I/zvmR5FSqnrBe3llFu+V3/qj5vAUBIAe2Xq6KB7sN4xlau+LdZylCQLAhz9EdhK0kUBQfddQSp/JEAXW4PgWkH6TLoZ72D3wskt36s/9cdNYAgJgAW8EwMmPe9YGkp9Y0ES0N+42ifI93YLUNmugHnHpPnxSwN0KaIJ76D3Qsot36s/9cdNwDvZRDxhbL/8veNgavWPHLdbjUb7qC1/PxrUY7uK4PVl2/J36yB9Jt+MF7YXUG75Xv2pP24CuRMAu+/9u4BJzzuOhlbfmPBMQPdjy+6TR9j+HgGq7rDyy/2KAH3seQaORAJe4yeKWVost/ylinGiCAK5EwB7+M07BqZa/5AiPDBfJ23L3zMC/O/LQV2wNwi8vmwJhCUSHIkEvMATxSwtllv+UsU4UQSB3AmAPQHvHQNTrW9sOLojYO/IR/jOHgEq/omkSwP0sbUMOBoQ8DpAA1ELi+aWv1ApviyGQO4EIGLS846hodY3NhzdEfhqQMD9jqSNA1S01QO9fmhj+dYBuhTVhBe6F1Zu+V79qT9uArkTgIsDJj7vGBpqfXuYi6MbArY+foTdnxig3rUlnRugj+1jwNGQgNcJGorboHhu+RsoxBdFEcidAHALYHkg4hZAd0PRdsjzzr225W/E65q2c6BXF6t/l+5wTbdlL3gvmdzyvfpTf9wEcicA9qCbdwxMtf7B43atwWofteXv3gE9vIakHwWMgZMDdCmyCe/k4YWWW75Xf+qPm0DuBGBnXgNcmADZa4DGhiOewPsDAu4FkrYIUG3PAF0shjwgQJcim8gdgHPLL9LodHodAVt+1uODEQsBHeHUwaP/UOu23VRmnWH5z0ICUVv+vnxh682+tLFzWoDvf4Mtf5uBX1vaOwGsbavN/3PLb6MzdaZDYAgJgN1HPSFgIvSOpaHU/2TQveXpeGlcT94c4Ge/kbRtgEoPCtDFfPaxAboU24R30HvB5Zbv1Z/64yYwhATACFoSYL96S14V0Pp+GMG/swFlQduCt3fOtStWEcfnAnRhy1+nJbzO4BTvdkavfOqXTWAoCcDMCnbf2x5+s0ujJawRYH20vlqfuec/84Ju/kZss2tJ2k0C1Lt7QPC32PWsAF2KboIEoGjzF9/5oSUAxRsEAJ0Q2DJoy993B2n3HwEJAFv+BhiDBCAAIk2MlgAJwGhNh+INCNj2uN653urfpoHMZUVvJck77kyXfZcJ4Pt0Al6nSJe0uGRu+Yu14ttSCHgnooi3AEphTT/zENhU0s8DEoCPBan/zgBdLpNk+wdwOAnkDsC55TvxUX3kBEgARm5A1K8l8PSAgGvz9D1rJdUXuJGk3wboc1C9KEqkEMgdgHPLT2FEmekSIAGYrm3pmWRb/n4vIOBGbfkbsf21bfl7Y4wbQyB3AM4tP4YirYyVAAnAWC2H3ikEHh0Q/G2OfkiKsJoy1w16s+WtNXI43YBA7gCcW34DVBSdIAESgAkalS6tI3BqQALw3aAtf/cP0MWW7uZ10XXm9f8ndwDOLd9PkBbGTIAEYMzWQ/cqAvcLCLg2Pz+pSkjiuagtfz+YKI9iiQRyB+Dc8hMxUWyiBEgAJmpYuqUTAxKAnwatzPicAF0sVtwVu8YSyB2Ac8uPpUlrYyNAAjA2i6FvCoGoLX+fnyKspkzUlr+frpHD6RYEcgfg3PJbIKPKhAiQAEzImHRlHYH3BfzivkjSVutabP+fvw3QxeLE37RXgZrLCOQOwLnlL+PC92UQIAEow84l9dLW6o/YVOqVAdCitvz9Jlv+BlhjQRO5A3Bu+QuQ8FVBBEgACjJ2IV19Y8Av7qgtfx8YoIvFiMcXYrveu5k7AOeW3ztwBA6KAAnAoMyBMk4CNwja8vcopx6z6p8NSADOkmTPEXB0QCB3AM4tvwOkNDkiAiQAIzIWqtYSeE1AwLXbBzetlVRf4E4Bulh8eHa9KEq0JZA7AOeW35Yb9aZBgARgGnakF5Jt+XthQNB9TxDMDwfocp6kzYL0oZkFBHIH4NzyFyDhq4IIkAAUZOyJd/XFAQHX5uPbBnC6ZdCWvy8L0IUmKgjkDsC55Veg4VQBBEgACjByAV2M2vL340Gs3h6QjNiWv9cL0odmlhDIHYBzy1+Cha8LIUACUIihJ97NpwUEXJuL7xXAKWrL34MDdKGJGgK5A3Bu+TV4OD1xAiQAEzdwAd2L2vL3lCBWhwQkI2z5G2SMumZyB+Dc8uv4cH7aBEgApm3fEnr3qICAa/PwwwJgRW35a7cQOHogkDsA55bfA2JEDJgACcCAjYNqSQSGtOXvPwckI7bl7y5JPaeQm0DuAJxbvhsgDYyaAAnAqM1XvPL3DQi4Ngc/OYCkbfn7ywB9PhSgC00kEsgdgHPLT8REsYkSIAGYqGEL6dYnAwLu2ZKuGcBrrwBdLB7cLUAXmkgkkDsA55afiIliEyUwtARgV0mHSjpdkr0G5R0f1Pcz/JWkb6+8knakpN0GNA5MF7tc7rXxCwL6dHVJPwzQ5TMButBEAwJe52kgamHR3PIXKsWXxRAYSgJg73EfHbR4indMUX95UDV/eXPQL2bvIDs+IOBGbfn7hABdzO/+jxcK9ZsR8A72ZtJu333zAAAgAElEQVQ2LJ1b/oYa8U1JBIaQAGwi6cSgCdQ7nqi/PPivZfN5SdfKOFB2Ctry91+C+vC1AP+1qywbB+lDM4kE1jp1m/8nillarI3MtXWWNswJCCQQGEICYL/81/o0/x8Hj7cl+FdXRY4J8JnLJW0XoKD9ao/wWbuKwNEzAa/hvOrmlu/Vn/rjJpA7AbDXnWz3Ne84oH7/DO3+++0zuL9t+fvrAJ+xxDPisPv2Xv9jy98IS7Row2u4FiLXq5Jb/nrK8KE4ArkTAHvgzzsGqJ+P4RszjJhXB/hM1Ja/dwzQxfz3ORk4IjLAeF6I3snLK5/6ZRPInQDY0/7eMUD9fAztyfc+j6gtf48NUvrfA/z3fEmbB+lDMw0JeCePhuI2KJ5b/gYK8UVRBHInAJcGTKDeMUT99gnElZJsLf6+jhcF+cvtAhSO2vJ3vwBdaKIlAe/gbyl2XbXc8tcpwn+KJOC9/76Rk9rFQRO6dxxRv10SYAlAX0+u26uiPwvwl/90+uysuj0E6fUbW2OBLX9nRDP89RrQq3Ju+V79qT9uArkTAG4B+IOIdw7x1O/zFsBTAwKu9fU+AUM2astfewaGIyMBj/NbXe+RW75Xf+qPm0DuBCBi61TvGKJ++yTEXsfr47CrDN8LSACitvw9OEAX2/L3T/uAh4zlBLyDf3nLaWdyy0/TklJTJZA7AdiZ1wDdl5G9c0jb+vYaYMS99JSx9YiAgGv9fHiKsJoytuXvJQH6vKNGDqd7INDW+Wf1vCrO2mn71yuf+mUTyJ0AGP0jAibTtuOHeu1//b+1x6HzxQAf+X7QA4svC9CFLX97dJ4qUd4JoKrtlHO55afoSJnpEhhCAmBLAZ8QMKl6xxL105OBPpcC/qsg33hKwDCO2vL3wwG60EQAAe+g96qQW75Xf+qPm8AQEgAjaEnA4dwOGPztAHtt1Bb/idg+N3Xk/FdAAnBOkM7PDtDF5ny2/E21fsflcgfg3PI7xkvzAycwlARghsmeCbAHrE6TxBoB6b/IvfNIVX3blvlbq7dq/mJmqJ7+mryILX9fGKCvrXdgtxGqWKWc+1KALjQRRCDFYFVlvGpUtZ1yziuf+mUTGFoCULY16P08geMCAq6tNbHVfMMtPj8+QBeb0x/UQjZVOiKQEmSrynjVqmo75ZxXPvXLJkACULb9h9x72/LXFhpKmQeryrwqqJP/HaALW/4GGSOqmSrHSTnn1SNFRlUZr3zql02ABKBs+w+5968PCLhRW/7uHqCLzeN7Dhl4ibpVBdeUc15mKTKqynjlU79sAiQAZdt/qL3fJmjL3zcEdfBTAQnAT1Yfdg1SiWYiCFQF15RzXh1SZFSV8cqnftkESADKtv9Qe2+X7avmvZRz5ts3C+hg1Ja/zw3QhSaCCaQ4UlUZrzpVbaec88qnftkESADKtv8Qe7+FpAsDEgB7gDDi+GCALmz5G2GJDtpICbJVZbwqVbWdcs4rn/plEyABKNv+Q+z9PwUEXJs7I5YpvoUk75bZpsv+QwSNTv7LTF6GKUG+qoxXPvXLJkACULb9h9b7qC1/bfGgiMOWO66af1PO2Za/149QhjbiCaQYsKqMV6OqtlPOeeVTv2wCJABl239ovbflelPmvboytnyw97ihpN8G6HOYVxHqd0egzpHqzns1q2u/7rxXPvXLJkACULb9h9R72/LX3pOvm/Pqzn9N0kYBHTsoQBdbx4AtfwOM0VUTdc5Ud96rV137dee98qlfNgESgLLtP6Te21a9dfNdynnbOth7bB205e+7vIpQv1sCKQ5VVcarXVXbKee88qlfNgESgLLtP6TeR2z5+4OgLX/3DUhGbA+D3YYEGF02JJASZKvKbNhis2+q2k4510wapSGwPgESgPV58CkPgfsEBFybL58aoL7tdHh2gD4fCdCFJjomkBJkq8p41atqO+WcVz71yyZAAlC2/YfS+/8MCLhRW/4+K0AXm7v/cihw0WM5gZQgW1VmectpZ6raTjmXJoVSEFhMgARgMRe+7Y9A1Ja/LwpQmS1/AyCOqYmUIFtVxtvXqrZTznnlU79sAiQAZdt/CL1/b8Avbtvy9zoBnXlsgC42bz84QBea6IFASpCtKuNVsartlHNe+dQvmwAJQNn2z937Pwva8vfVQR35akAC8B1J9kojxwgIpATZqjLeLla1nXLOK5/6ZRMgASjb/rl7f3RAwLUtf7cP6MgDAnSxOfvvAnShiZ4IpATZqjJeNavaTjnnlU/9sgmQAJRt/5y9j9ry95igTpwckACw5W+QMfpqJiXIVpXx6lnVdso5r3zql02ABKBs++fs/b8EBFzbqCdiy987BOhi8/XeOYEiuzmBlCBbVaa5xPVrVLWdcm791vgEgWYESACa8aJ0DAHb8veCgKB7fIw6+kCALmz5G2SMPptJCbJVZby6VrWdcs4rn/plEyABKNv+uXr/goCAa/PjnQI6ELXl7wEButBEzwRSgmxVGa+6VW2nnPPKp37ZBEgAyrZ/jt5fQ9JZAQnACUHKvyVAF7b8DTJG382kBNmqMl59q9pOOeeVT/2yCZAAlG3/HL1/ckDAtbnxrwOUj9ry94gAXWgiA4GUIFtVxqtyVdsp57zyqV82gaElALuuLOhyqKTTJV0WFChSxtHUytg+9vYr+zhJewRtjxsxUmyb3m8F2PXrQX06MEAXG0M3iYBDG/0T8A58r8a55Xv1p/64CQwlAdhUkr0Tbk91e8cE9Tdk+CVJtuhO7uOhQfZ9VEBHtpJ0UYA+/xqgC01kIuCdLLxq55bv1Z/64yYwhARgk5WNU04MmIi9Y2nq9c+VtHNmd/1CgJ1ty9+rB/RjnwBdzGduE6DLrAlbQfAeK1sav2IlYXvH6j/7v33H6oIzSoF/vYPeq0pu+V79qT9uAkNIACJWg/OOo1Lqf1/SZplc9l5BAfdpAfpHbfn70QBdZk3cV9JpFYzsnJXhCCTgHfheVXLL9+pP/XETuLJiwknxTbun6zl2keRNQlL0pMxVtwXsl2+O4+NOXzMb2pa/1wpQ/hkBupg+9ss84nhe4u0vu0X2/AiBtPFHAt6Jwcsxt3yv/tQfN4HcCYA98OcdA9RvxtAeDvQmbk29/s8l/SHA1i9uKnhBedvy94wAXb68oO02Xz26IRvjaLsWcgQQ8E4eXhVyy/fqT/1xE8idANjT/t4xQP3mDG/Zs9u+J8DOlwRt+fuYAF3M5x4SwNAeRDyvhT4XSrpugPzim/BOHl6AueV79af+uAnkTgAubTH5eccM9aX79ei2UVv+viZI54gtf78b9FCeZ0XEFwbxKLoZ72TghZdbvld/6o+bQO4E4GISgCxXQCIW0Un1/KMCbBy15e/9A3SxOftJqZ2vKfcZhz6fq2mb0wkEcgfg3PITEFFkwgRyJwDcAmh++d47Z1j9vm4BRG35+6agMXiSI+DOuP9Ukr26GnH80qGP3TrgcBKYGbXtX6d4d/bvlU/9sgnkTgAOcUyAbcds6fV+3ONDgPYOu5e3Pfl+q4BhGrXl7z8G6DJrwvMGjD0M2PfDnDO9J/PX65xeELnle/Wn/rgJ5E4AbGEazyToHT8l1n9pTy5r6w20ecBt3ibvC9L3/QHJiG1hbFsZRx3elS9ZHMhpiXlna/rZKd6dHXvlU79sArkTAKNvG6k0HXeUb8fMXn/rayEge189wk53DhiiN098z75OX7uiEXmQAETSbNFWncHrzrcQuV6Vuvbrzq/XGB8g0JDAEBIAu59qW7vW+TrnfYzs13hfSwHblr92q8FrM1siOuKwZwi8uvxG0rYRyqxpgwRgDYwc//U6hVfn3PK9+lN/3ASGkAAYQUsCDud2gDtILZtP+t4MyJ6SX6ZLk+8jXle0oG3Bu4ncRWWP7GCokwB0ALVJk4sM3eS7JrIWlW0ia1HZRW3yHQRSCQwlAZjpa79QD15dE501AtoHLdsO2H6BH5thO2B7MC3i7Y6oLX9fGxD87TmVLrb8JQGYjfxMfxcF1SbfedVuImtRWa986pdNYGgJQNnWmEbvbYW8RXNV0+9siVzvsWXQlr+2kmEXBwlAF1QbtNnUKefLNxC1sOh8e00/L2yULyGQSIAEIBEUxZIJfD4gATgzaMvflwToYnPybZN736wgCUAzXuGlmwbc+fJehebba/rZK5/6ZRMgASjb/tG9v2dQwLXd+rzHppJ+HqCP7WLY1UEC0BXZxHabBtz58olilhabb6/p56UNcwICCQRIABIgUSSZwMcCAu4vgrb8fXqALjYf3yu5980LkgA0ZxZao2nAnS/vVWa+vaafvfKpXzYBEoCy7R/Z+6gtfyMWKrItf78XkACcEgloQVskAAug9PlV04A7X96r63x7TT975VO/bAIkAGXbP7L37w4IuLbl79YBStkDhE3n0kXlHxqgS1UTJABVdHo4t8joTb7zqthE1qKyXvnUL5sACUDZ9o/q/Y6SvL5k89uBQQqdGpAARG35W9UlEoAqOj2cWxRUm3znVbGJrEVlvfKpXzYB76TNZiRl+8+s9xHLOV8haYdZg46/tnjQormy6Xd/79AhtSoJQCqpjso1dYr58l615ttr+tkrn/plEyABKNv+Eb3/E0mXBQTdN0coI8mWD246j86Xj9zyt6pbJABVdHo4N2/4pp+9KjaVN1/eK5/6ZRMgASjb/hG9f3lAwLWtbW8doMztA3SxOfYFAbqkNEECkEKpwzLzAbXpZ69qTeXNl/fKp37ZBEgAyra/t/e2s+C5AUHXtuqNOP4tQJeLJG0VoUxCGyQACZC6LDIfUJt+9urWVN58ea986pdNgASgbPt7e793QMC1Oe0uXkVW1+q3Nfvn58imn18ZoEtqEyQAqaQ6KtfUOebLe9Wab6/pZ6986pdNgASgbPt7eh+15e/JHiXW1H1jQPDvYsvfNSpu8F8SgA2Q9PtF04A7X96r7Xx7TT975VO/bAIkAGXb39P7JwYEXJvvHuBRYrXuDYK2/D06QJcmTZAANKHVQdmmAXe+vFel+faafvbKp37ZBEgAyrZ/295Hbfn7DUkRr5K+JiAZsdsHN20LpGU9EoCW4KKqNQ248+W9esy31/SzVz71yyZAAlC2/dv2fo+AgGtz3WPbKrCmnm35e2GAPu9d02Zf/yUB6Iv0EjlNA+58+SXNJn89317Tz8mCKAiBBQRIABZA4ataAkPa8vfFAcHf5t2utvytgkkCUEWnh3NNA+58ea+K8+01/eyVT/2yCZAAlG3/Nr3/y6CA+8w2wufqRG35+4m5dvv6SALQF+klcpoG3PnyS5pN/nq+vaafkwVREAILCJAALIDCV5UEPhKQAERt+fu0AF1szr13ZY+7O0kC0B3bpJabBtz58klCKgrNt9f0c0XTnIJALQESgFpEFFhDYFdJtmpf03lqvvw+a9ps+9+xbPlb1T8SgCo6PZybd8ymn70qNpU3X94rn/plEyABKNv+TXv/roDgb/sG2P4B3uNRAbrYfPpwryKO+iQADngRVecDatPPXh2aypsv75VP/bIJkACUbf8mvbed+mzHvvk5qOnn1zURWlE2Ysvf/5G0cYWMrk+RAHRNuKb9ps47X76m+drT8+01/VwrgAIQqCBAAlABh1PrETg8IPhbAnHj9Vpt9+G+AbrYXPuUduLDapEAhKFs11DTgDtfvp3Uq2rNt9f081Ut8T8INCdAAtCcWYk17JL9pQFB9y1B8D4ZoMvZkq4ZpE/bZkgA2pILqtc04M6X96rx2wBHnteJz/7LlDCsZ2i+G33YQ2aHSjo9aI/5sdrR7pMbA2OxSzTkFu0dEDBPRW35u1vQg4j/1IJDdBUSgGiiDdvzThANxW1QPGIrTW8fqF8f7GC0ISN7lSvqsPe5bR1274Q4RTsZk6MkbRIFu2E71w7a8veDDeUuK358QDJycY9b/i7rh33v9feczy9U9Ws057wThrejpwQ4s7cP1N8wuMGknskXvc6/Wt8C24mMg9qH64xRjiTgeUG2uWuAv+wkKWLL31cF6BLRBAlABEVHG96J3iH6f6tGbGHp7QP164MdjDZk9Aav86/Wt1/+8E1jcGQQ89RmbMvfHwXY51OpAmvKHROgy+WStquR09dpEoC+SC+R4514ljSb/PVjAhza2wfqp02+cFqf0yOTvXx5Qbu/HfGLrhTbGKs+nwn4u6D5afflLpB8xrb8/XWAPq9Plth9QRKA7hlXSvBOHJWNJ5zcPOjpWm8/qL9+cINHNQ97SM1813vYQ26wbsbgEC/0xPq2Te9pAfaJ2vL31QG6WAJ1s8T+91GMBKAPyhUyvJNPRdPJp7gN0GwC9NqM+n7eUZf/7Ul37NGMgTHr43hQkG0eF6Bs1Ja/xwXoEtkECUAkzRZteSefFiI3qHITSbwO2GwS9NqN+u152z3UHTfw4nZfRLxbXpotjVkfx+cCEoAzJV09QNkXBehifnK7AF0imyABiKTZoi3v5NFC5MIq/zfIwb39oX77wFgKu1cu9OB2X16C3ze+AmLMuj4sUEb4814BikZt+WuLBw3tIAHIbBGvk0epb0/b2pOyXn2oD8MufeDzkmxCjjq4BdDcX/u4BXBgwFx0nqTNAhzlqQG62Jj4qwBdopsgAYgm2rA972TZUFxlcXvK9cdBzu7tF/WbT8xTZ2a+aT4aedgDbVPnFt2/gyMNsKStzwbY5Z+XtN3ka1voxjbs8TK0jYOGeJAAZLaK17Gi1bdXfEgC/APea1fqr28D88kuXj/jNcD1Odf5nT3FvnP0pLOgvTOcQdeeU7jugnabfmVb9dYxSTkf8cpqU91TypMApFDqsEyK81SV6UK163E7IGTQV9mNc+kTq13237YLR19t0xa3wR5pDGxHvj6Os5w2ibpKYatNen3j+5Ku1ge0FjJIAFpAi6zida5IXda2ZfdZ92ONAPfg99q35Pr2tL898Nf18rPW/gkBE/3UbWWMurbFbA6yoOnh+Rezhhx/7+PUYaa/PUMw1IMEILNlZk7S9m/X6ts9V/uFxOtSvgmprX1LrGe+ZqulRb3qlzJGLLAdwaqAC4OuXfa3X/59BX+z13edwffWKUavKfNfTh1s7J4zgC1/q7pJAlBFp4dz3gm+BxX/V4Stuvao1YnZLovZTmz2C82rP/XLZmg+ZL5kPmVr8tu90ognt9uOC7u/bZePbQW6kpNe67sxMBZ93POft9c3nXOL9wqA1bftg73zk60fMOSDBCCzdbwOlll9xEMAAhAIJ/BVZ/C9vVMjW7HPOzfblr/XcerRdXUSgK4J17TvdbKa5jkNAQhAYHQEvuQMwHdx9Ni2/L3SKd/mdVtcbegHCUBmC5EAZDYA4iEAgcER8K4DcA9Hj2yfCe+8bLe2hrLlbxUKEoAqOj2c8zpaDyoiAgIQgECvBE5yBuG2q+5tE7Tl7zG90movjASgPbuQmiQAIRhpBAIQmBCBTzgTgN1bsNhaUsST/0Pb8rcKBQlAFZ0ezpEA9AAZERCAwKgIfMSZANhWwk2OW0j6jlPmbC4/vongzGVJADIbYOY0bf9mVh/xEIAABMIJfNAZjB/WQKMHSrrIKW/t/H2nBrJzFyUByGyBtY7T5v+Z1Uc8BCAAgXAC9iu6zXw4q/PoBI02kmTv6XuD4Eym/R3ilr9VKLx9t82SOBwE1jpPm/87RFMVAhCAwCAJvNuZADyhpldbSPqAU8ai+fq+NXKHdpoEILNFFjlRk+8yq494CEAAAuEE3u4Mzk+q0OhmKytOfsvZ/qI5+uuS7KrCmA4SgMzWWuRITb7LrD7iIQABCIQTeJMzQC/bgMfeDrjQ2fay+dmWSh/bQQKQ2WLLnCn1+8zqIx4CEIBAOAHbFyJ1DlxU7tlzGnVxv3+t3B8MeMvfORTrfSQBWA9H/x/WOlGb//evMRIhAAEIdEvgUGcCsPca9Wwjs39ztlc3N//DGnlj+i8JQGZr1TlW3fnM6iMeAhCAQDiB1zkD9gtXNbqxpFOdbdXNwdb+1cIJ9NMgCUA/nJdKqXOuuvNLG+YEBCAAgZESeJUzaO8j6a8lne9sp27+PVvSzUfK2NQmAchsvDoHqzufWX3EQwACEAgncIAzcH9Tki3JWzd/es6fKelW4T3vt0ESgH55byDN44BWlwMCEIDA1Ajs23Hw9s67n5ZkGweN/SAByGxBryNmVh/xEIAABMIJ2Ap93rmxq/q20981wnucp0ESgDzc10n1Oum6hvgPBCAAgYkQ+McBJgCXS6paYGiM6EkAMluNBCCzARAPAQgMjsBeA0sAfirpjoOj5FeIBMDP0NUCCYALH5UhAIEJEnj6gBKAz0nadoKMrUskAJkNSwKQ2QCIhwAEBkfgyQNJAOx+/yaDoxOnEAlAHMtWLZEAtMJGJQhAYMIE9sycANj9/qdMmO+sayQAMxKZ/pIAZAKPWAhAYLAEHpsxAfi5pLsMlkysYiQAsTwbtza0BGAXSYdIOl3SpRkHoZcL9Yf7GhW2GYdtzpN0ysocsJ+k7RrPbL4Kj8g093xVki0fXMpBApDZ0t7JMEp9u89lO3B5HcLbH+qPIzhgp7LsdNnKNrrPjZpsEtrZI0MC8C5J10rQbUpFvPP9xlOCkaMv3ok0QmcL/idmGHDevlO/rCCEvfPb++CICSehjb/pcT66UpItPFTiQQKQ2ereSS1Cfe/e294+UD//xI4NsEGqDzwxYtKpacM28knVx1PuXEn3qdFlyqdJADJb1+O8Vtd77Mpl/14mGq+dqd9PQIBzPedzJG3unXhq6t+rhwTga5J2rNFj6qdJADJb2DvheNU/rIeB5u0j9esnZRjBqE8feLx34qmpf7eO56X3Srp2jQ4lnCYByGxl76D1qv+tjgeat3/UJ7DhA8Pzgbd7J56a+nfoaF6yLYJLvd+/CDkJwCIqPX7nndy8qvKq3/AmV69PUB+bdu0DJ3snnpr6u3WQAJwvyZ4t4LiKAAnAVSyy/M87UL1KkwAQLLw+SP3yfOgk78RTU/9mwQnANyTtVCOzxNMkAJmt7p08vepzC6C8ydvrc9THZ7q+BWD35+31vAhfO17SZt6JcqL1SQAyG9br4F71Dw0aZN5+UD9msoMjHPvwgcd5J56E+p9xzk0W3F4qaaMEWaUWIQHIbHnvYPWqb0v/2oMxXj2oD0N8oAwfOLuH1wBtXrMko61PXbiyjLEtJsRRTYAEoJpP52fbOvisXoSCRzkG2kwP/rafrGAHuzH5gO3U18dhy8x+tsXc9G1JN+9DwQnIIAHIbETvwI9Qn6WACUBeP6R+GT7U11LAs3lte0lnNEgCPiRpy1ll/tYSIAGoRdRtAe/EGaWdJQFHcjug9SVHrx2pX0YAHaud7W2hvaImm4btbCPpIzVJwG8kvZD7/Q3J+jd/YzOgxsjXr+CdENZvzf9p7XbAtgOYVz/qwxAfGKcP2Hvzs+2At/VPLe4W7i3pHZJ+KOlySZdI+oqkV0i6obv1MhvgCkBmu3snx8zqIx4CEIAABEZKgAQgs+FIADIbAPEQgAAECiVAApDZ8CQAmQ2AeAhAAAKFEiAByGx4EoDMBkA8BCAAgUIJkABkNjwJQGYDIB4CEIBAoQRIADIbngQgswEQDwEIQKBQAiQAmQ1PApDZAIiHAAQgUCgBEoDMhicByGwAxEMAAhAolAAJQGbDkwBkNgDiIQABCBRKgAQgs+FJADIbAPEQgAAECiVAApDZ8CQAmQ2AeAhAAAKFEiAByGx4EoDMBkA8BCAAgUIJkABkNjwJQGYDIB4CEIBAoQRIADIbngQgswEQDwEIQKBQAiQAmQ1PApDZAIiHAAQgUCgBEoDMhicByGwAxEMAAhAolAAJQGbDkwBkNgDiIQABCBRKgAQgs+FJADIbAPEQgAAECiVAApDZ8CQAmQ2AeAhAAAKFEiAByGx4EoDMBkA8BCAAgUIJkABkNvwVkjxJwCaZ9Uc8BCAAAQiMj8A1nLHHYheHk8D5TiNc3ymf6hCAAAQgUB4Bix2eH58WuzicBH7sNMKdnPKpDgEIQAAC5RGw2OFJAH5YHrL4Hp/qNMLT4lWiRQhAAAIQmDiBpzpjz1cmzqeX7r3HaYTjetESIRCAAAQgMCUCxzpjz7unBCNXX/Z3GuEySZvnUh65EIAABCAwOgKbSbrUGXteNrpeD1DhhzuNYPdwnj3AfqESBCAAAQgMk4D38r/FnYcNs2vj0sqexPyDMwn4paQtx9VttIUABCAAgQwE7NXxHzhjjsUs3kALMt5pTmNYNvbyIF1oBgIQgAAEpkvgJQHx5uvTxdN/z14XYJDfSrp7/6ojEQIQgAAERkLgrpIuD4g3B46kv6NQ83YBBrGrAOdJ2mkUPUZJCEAAAhDok8D2kn4WFGt261PxEmR9O8gw35L0pyUAo48QgAAEIJBEYIeVh/a+GRRj7JY1RzCB5wcZx64E/ILbAcHWoTkIQAAC4yRgl/3PCYwve48Tw7C13kKSd18AC/6zf/ZMwD6SNh12t9EOAhCAAAQ6IGBP+7806J7/LK7YbWbWnenAWNbkAWsC+Ay49++ZK9nf0zFaRxajWQhAAALDImCL/NgS8Tb3e+PHfP19h9XVaWmz9erl+3noEZ9txcDjV9p/hqQ7S9pGElsJT8t/6A0EIFAWAdvS1+Zy29jHgr4tDe9d4W9ZvDlb0lZl4e2/t0/qIGtbZtCU7y+RdPqK4Q+RtHMPOHZZlWUyu3LklH5TJv7XA0xhig+M1wee0MP8X7yIjSR9fmBJwGzQ/k7SER1dObCrEUdL+v1A+z5jwN/xTmDYDtvhA+184OSVW9QWmzh6IGDv8l804EB4QnASYMH/xAH3l0mj3aQBN7jhA+P3gQsk7dhD3EPEGgKPHnhAPHyNrt7/2i9/JgoY4AP4AD4wLB+wNf/38E7w1G9H4OABB0a7HRDxTMCuXPYn+RmwnxOQhhWQsEe/9nhVu9BFrQgCds/l7VAJMTYAAARVSURBVAOeHC1B8R6HDbh/TDb9Tjbwhjc+MBwf+Ffu+3vDm7++3R//2ECDZMSSkLZ0MYMeBvgAPoAPDMcHPiTJXjHkGAABSwLePcBAaa8Ieg9e9RvOoGcCxhb4AD7wToK/N6zF199Y0kEDSwIiEgBrg0kHBvgAPoAP5PUBe+DP7vnzul98/A5r8ZEDekWQWwB5BywTJvzxAXwgwgfsVT+e9g8L0902ZOsEfG4Av5wjHgI8dAD9iBhAtMFEjA/gA2P0AVvkh/f8u43Z4a3bZRpbNti2/s3hdPYa4K0DemVL/1pbOfqATLjjA/hAqT5ga/vb8r5c8g8IZLmauM6K4P2DtxJOGRD2+l7UcRQJAAkQPoAP4AO9+MC5q1vFbxk1gdNOfgK2R/Pekvp4rY6lgPnVlJIkUgY/wQeG4wPfXHl+7HlsDZ8/WHetwW0kHSjJDG5PdkYNQrtUb0sA22uJ0Ye1eSS3A8JsFWVz2okbP7CEZZ8+YBurfU3SayXtFj1h0944CFxvJRF42EoSsN/qWgJfkXSmJHvq88qE5OCyjNsBm+w+Bwyy4I0P4ANj8oErVufyH0iyud3Wi9lX0kNXflDZ3M8BAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACAyfw/wFF/IQkTID3lgAAAABJRU5ErkJggg==">
							</image>
						</defs>
					</svg> </span>
				<h3>Triển khai và tối ưu hóa chiến dịch</h3>
				<p>HomeNest triển khai chiến dịch quảng cáo chuyên nghiệp và liên tục theo dõi, điều chỉnh để tối ưu
					hiệu quả, giúp chiến dịch đạt được kết quả tốt nhất.</p>
			</div>
			<div class="back-img">
				<img src="https://homenest.com.vn/wp-content/uploads/2024/11/Vector1-1.png" alt="">
			</div>
		</div>
	</section>

	<section class="homenest__professional_website_hn-pricing-section">
		<h2 class="homenest__professional_website_hn-pricing-title"> Bảng giá <span class="homenest__professional_website_heading-highlight"> Thiết kế website </span>
			 chuyên nghiệp  </h2>
		<div class="homenest__professional_website_pricing-section">
			<button class="homenest__professional_website_scroll-btn left" onclick="scrollCards(-1)">
				<svg xmlns="http://www.w3.org/2000/svg" width="31" height="24" viewBox="0 0 31 24" fill="none">
					<path d="M26 12H6" stroke="#0900FF" stroke-width="2" stroke-linecap="round"
						  stroke-linejoin="round"></path>
					<path d="M12.5938 19L5.8125 12L12.5938 5" stroke="#0900FF" stroke-width="2"
						  stroke-linecap="round" stroke-linejoin="round"></path>
				</svg>
			</button>

			<!-- Scrollable Wrapper -->
			<div class="homenest__professional_website_hn-pricing-cards-wrapper">
				<div class="homenest__professional_website_hn-pricing-cards">
				</div>
				<button class="homenest__professional_website_scroll-btn right" onclick="scrollCards(1)">
					<svg xmlns="http://www.w3.org/2000/svg" width="31" height="24" viewBox="0 0 31 24" fill="none">
						<path d="M5 12L25 12" stroke="#0900FF" stroke-width="2" stroke-linecap="round"
							  stroke-linejoin="round"></path>
						<path d="M18.4063 5L25.1875 12L18.4062 19" stroke="#0900FF" stroke-width="2"
							  stroke-linecap="round" stroke-linejoin="round"></path>
					</svg>
				</button>
			</div>
			</section>	

		<section class="quy-trinh-section">
			<div class="step-image">
				<img src="https://homenest.com.vn/wp-content/uploads/2024/11/homenest-com-vn-25.webp"
					 alt="Lập kế hoạch chi tiết">
				<div class="overlay-box box1">
					<div class="elementor-social-icons-wrapper elementor-grid">
						<span class="elementor-grid-item">
							<a class="elementor-icon elementor-social-icon elementor-social-icon-Quy trình thực hiện elementor-repeater-item-a9f5489"
							   target="_blank">

								<svg xmlns="http://www.w3.org/2000/svg" width="100" height="50" viewBox="0 0 40 40"
									 fill="none">
									<rect x="0.5" y="0.5" width="39" height="39" rx="7.5" stroke="#898384"></rect>
									<path
										  d="M21.4602 28.5V21.0621H23.9137L24.3805 17.9822H21.4602V15.9903C21.4602 15.1498 21.87 14.3266 23.1736 14.3266H24.5V11.7072C24.5 11.7072 23.2932 11.5 22.1433 11.5C19.741 11.5 18.1698 12.9738 18.1698 15.6392V17.9822H15.5V21.0621H18.1755V28.5H21.4602Z"
										  fill="#898384"></path>
								</svg> </a>
						</span>
						<span class="elementor-grid-item">
							<a class="elementor-icon elementor-social-icon elementor-social-icon-Quy trình thực hiện elementor-repeater-item-40e5f18"
							   target="_blank">

								<svg xmlns="http://www.w3.org/2000/svg" width="100" height="50" viewBox="0 0 40 40"
									 fill="none">
									<rect x="0.5" y="0.5" width="39" height="39" rx="7.5" stroke="#898384"></rect>
									<path
										  d="M24.1934 14.9082C23.6811 14.9082 23.2666 15.3227 23.2666 15.835C23.2666 16.3473 23.6811 16.7618 24.1934 16.7618C24.7057 16.7618 25.1202 16.3473 25.1202 15.835C25.1259 15.3227 24.7057 14.9082 24.1934 14.9082Z"
										  fill="#898384"></path>
									<path
										  d="M20.0659 16.0996C17.913 16.0996 16.1631 17.8495 16.1631 20.0024C16.1631 22.1553 17.913 23.9052 20.0659 23.9052C22.2188 23.9052 23.9687 22.1553 23.9687 20.0024C23.9687 17.8495 22.2188 16.0996 20.0659 16.0996ZM20.0659 22.5007C18.6901 22.5007 17.5676 21.3782 17.5676 20.0024C17.5676 18.6267 18.6901 17.5042 20.0659 17.5042C21.4417 17.5042 22.5642 18.6267 22.5642 20.0024C22.5642 21.3782 21.4417 22.5007 20.0659 22.5007Z"
										  fill="#898384"></path>
									<path
										  d="M23.1629 27.9234H16.8367C14.2118 27.9234 12.0762 25.7878 12.0762 23.1629V16.8367C12.0762 14.2118 14.2118 12.0762 16.8367 12.0762H23.1629C25.7878 12.0762 27.9234 14.2118 27.9234 16.8367V23.1629C27.9234 25.7878 25.7878 27.9234 23.1629 27.9234ZM16.8367 13.5671C15.0349 13.5671 13.5671 15.0349 13.5671 16.8367V23.1629C13.5671 24.9647 15.0349 26.4325 16.8367 26.4325H23.1629C24.9647 26.4325 26.4325 24.9647 26.4325 23.1629V16.8367C26.4325 15.0349 24.9647 13.5671 23.1629 13.5671H16.8367Z"
										  fill="#898384"></path>
								</svg> </a>
						</span>
						<span class="elementor-grid-item">
							<a class="elementor-icon elementor-social-icon elementor-social-icon-Quy trình thực hiện elementor-repeater-item-04bf73d"
							   target="_blank">

								<svg xmlns="http://www.w3.org/2000/svg" width="100" height="50" viewBox="0 0 40 40"
									 fill="none">
									<rect x="0.5" y="0.5" width="39" height="39" rx="7.5" stroke="#898384"></rect>
									<path
										  d="M27.5 18.2828C27.3544 18.2943 27.2143 18.3058 27.0687 18.3058C25.4892 18.3058 24.0161 17.489 23.1535 16.1314V23.5292C23.1535 26.5494 20.7674 29 17.8267 29C14.8861 29 12.5 26.5494 12.5 23.5292C12.5 20.5091 14.8861 18.0585 17.8267 18.0585C17.9388 18.0585 18.0452 18.07 18.1572 18.0757V20.768C18.0452 20.7565 17.9388 20.7335 17.8267 20.7335C16.3256 20.7335 15.1102 21.9818 15.1102 23.5235C15.1102 25.0652 16.3256 26.3135 17.8267 26.3135C19.3279 26.3135 20.6553 25.0997 20.6553 23.558L20.6833 11H23.1927C23.4279 13.3126 25.2427 15.1189 27.5 15.2857V18.2828Z"
										  fill="#898384"></path>
								</svg> </a>
						</span>
						<span class="elementor-grid-item">
							<a class="elementor-icon elementor-social-icon elementor-social-icon-Quy trình thực hiện elementor-repeater-item-41bf95f"
							   target="_blank">

								<svg xmlns="http://www.w3.org/2000/svg" width="100" height="50" viewBox="0 0 40 40"
									 fill="none">
									<rect x="0.5" y="0.5" width="39" height="39" rx="7.5" stroke="#898384"></rect>
									<path
										  d="M28.5 17.7634C28.5 15.6845 26.8296 14 24.7682 14H15.2318C13.1704 14 11.5 15.6845 11.5 17.7634V22.2366C11.5 24.3155 13.1704 26 15.2318 26H24.7682C26.8296 26 28.5 24.3155 28.5 22.2366V17.7634ZM22.8911 20.338L18.6173 22.4732C18.4497 22.5634 17.8799 22.4394 17.8799 22.2479V17.8704C17.8799 17.6732 18.4553 17.5549 18.6229 17.6507L22.7179 19.8986C22.8855 19.9944 23.0643 20.2423 22.8911 20.338Z"
										  fill="#898384"></path>
								</svg> </a>
						</span>
						<span class="elementor-grid-item">
							<a class="elementor-icon elementor-social-icon elementor-social-icon-Quy trình thực hiện elementor-repeater-item-40c2756"
							   target="_blank">

								<svg xmlns="http://www.w3.org/2000/svg" width="100" height="50" viewBox="0 0 40 40"
									 fill="none">
									<rect x="0.5" y="0.5" width="39" height="39" rx="7.5" stroke="#898384"></rect>
									<path
										  d="M12.3816 17.3608H15.6512V27.8546H12.3816V17.3608ZM14.0164 12.1455C15.0641 12.1455 15.9103 12.9917 15.9103 14.0336C15.9103 15.0755 15.0641 15.9274 14.0164 15.9274C12.9688 15.9274 12.1226 15.0813 12.1226 14.0336C12.1226 12.9917 12.9688 12.1455 14.0164 12.1455Z"
										  fill="#898384"></path>
									<path
										  d="M17.7007 17.3605H20.8321V18.7938H20.8724C21.3099 17.9707 22.3749 17.0957 23.9636 17.0957C27.2678 17.0957 27.8779 19.2659 27.8779 22.098V27.8543H24.6198V22.7484C24.6198 21.5281 24.5968 19.9624 22.9217 19.9624C21.2236 19.9624 20.9645 21.2863 20.9645 22.6563V27.8486H17.7064V17.3605H17.7007Z"
										  fill="#898384"></path>
								</svg> </a>
						</span>
					</div>
				</div>
				<div class="overlay-box box2"></div>
			</div>
			<div class="section-container">
				<div class="section-header">
					<h2 class="section-logo">HOMENEST</h2>
					<h3 class="section-title">Quy trình thực hiện</h3>

					<div class="step-image1">
						<h2 class="section-subtitle">Thiết kế website chuyên nghiệp</h2>
						<div class="img1">
							<img src="https://homenest.com.vn/wp-content/uploads/2024/11/Group-1203-1.png"
								 alt="Lập kế hoạch chi tiết">
						</div>
					</div>
				</div>

				<div class="process-steps">
					<div class="process-step">
						<div class="step-number">.01</div>
						<div class="step-content">
							<h4>Tư vấn & Báo giá</h4>
							<p>Tư vấn chi tiết về những mong muốn và ý tưởng của khách hàng, đưa ra tính năng và gói dịch vụ
								phù hợp với ngân sách và lên báo giá chi tiết</p>
						</div>
					</div>

					<div class="process-step">
						<div class="step-number">.02</div>
						<div class="step-content">
							<h4>Lập kế hoạch chi tiết</h4>
							<p>Sau khi tiếp nhận yêu cầu của khách hàng, bộ phận UI/UX và Dev sẽ thảo luận để đưa ra kế
								hoạch tối ưu nhất dành cho khách hàng</p>
						</div>
					</div>

					<div class="process-step">
						<div class="step-number">.03</div>
						<div class="step-content">
							<h4>Thiết kế và lập trình</h4>
							<p>Bộ phận UI/UX Design sau khi có kế hoạch sẽ tiến hành lên demo và gửi khách hàng bản Figma.
								Khách hàng duyệt xong sẽ bắt đầu lập trình</p>
						</div>
					</div>

					<div class="process-step slide-in">
						<div class="step-number">.04</div>
						<div class="step-content">
							<h4>Thử nghiệm và điều chỉnh</h4>
							<p>Khách hàng thử nghiệm website của họ sau khi lập trình và tiến hành điều chỉnh nếu có vấn đề
								phát sinh</p>
						</div>
					</div>

					<div class="process-step slide-out">
						<div class="step-number">.05</div>
						<div class="step-content">
							<h4>Hướng dẫn quản trị</h4>
							<p>Trao đổi và hướng dẫn khách hàng tự quản lí website của họ một cách chuyên nghiệp và chính
								xác</p>
						</div>
					</div>

					<div class="process-step slide-in">
						<div class="step-number">.06</div>
						<div class="step-content">
							<h4>Bàn giao và bảo hành</h4>
							<p>Sau khi hoàn thành các bước thử nghiệm và đào tạo, tiến hành bàn giao và bảo hành cho khách
								trong những trường hợp cụ thể về kĩ thuật</p>
						</div>
					</div>
				</div>
			</div>

		</section>
		<div class="section-divider">
		</div>
		<div class="homenest__professional_website_faq">
			<div class="homenest__professional_website_title-wrapper">
				<h2 class="homenest__professional_website_title">CÂU HỎI THƯỜNG GẶP</h2>
			</div>
			<div id="homenest__professional_website_faq-container">
				<div class="homenest__professional_website_question">
					<div class="homenest__professional_website_question-header-number">
						<span class="homenest__professional_website_question-number">01</span>
						<span class="homenest__professional_website_question-label">QUESTION - 01</span>
					</div>
					<div class="homenest__professional_website_question-header">
						<div style="width: 40px; height: 40px;"></div>
						<span class="homenest__professional_website_question-title">Tại sao phải thiết kế website theo yêu
							cầu?</span>
						<button class="homenest__professional_website_toggle-btn">
							+
						</button>
					</div>
					<div class="homenest__professional_website_answer-wrapper">
						<div style="width: 40px; height: 40px;"></div>
						<div class="homenest__professional_website_answer">Thiết kế website theo yêu cầu giúp doanh nghiệp
							có giao diện, tính năng phù hợp với đặc thù hoạt động, tăng hiệu quả kinh doanh và nhận diện
							thương hiệu.</div>
						<div style="width: 40px; height: 40px;"></div>
					</div>
				</div>
				<div class="homenest__professional_website_question">
					<div class="homenest__professional_website_question-header-number">
						<span class="homenest__professional_website_question-number">02</span>
						<span class="homenest__professional_website_question-label">QUESTION - 02</span>
					</div>
					<div class="homenest__professional_website_question-header">
						<div style="width: 40px; height: 40px;"></div>
						<span class="homenest__professional_website_question-title">Phí gia hạn web hàng năm là gì?</span>
						<button class="homenest__professional_website_toggle-btn">
							+
						</button>
					</div>
					<div class="homenest__professional_website_answer-wrapper">
						<div style="width: 40px; height: 40px;"></div>
						<div class="homenest__professional_website_answer">Phí gia hạn web hàng năm bao gồm chi phí duy trì
							tên miền, hosting và các dịch vụ kỹ thuật kèm theo để website hoạt động ổn định.</div>
						<div style="width: 40px; height: 40px;"></div>
					</div>
				</div>
				<div class="homenest__professional_website_question">
					<div class="homenest__professional_website_question-header-number">
						<span class="homenest__professional_website_question-number">03</span>
						<span class="homenest__professional_website_question-label">QUESTION - 03</span>
					</div>
					<div class="homenest__professional_website_question-header">
						<div style="width: 40px; height: 40px;"></div>
						<span class="homenest__professional_website_question-title">Thiết kế website chuẩn SEO là gì?</span>
						<button class="homenest__professional_website_toggle-btn">
							+
						</button>
					</div>
					<div class="homenest__professional_website_answer-wrapper">
						<div style="width: 40px; height: 40px;"></div>
						<div class="homenest__professional_website_answer">Website chuẩn SEO giúp tối ưu công cụ tìm kiếm,
							dễ được Google index và cải thiện thứ hạng trên kết quả tìm kiếm.</div>
						<div style="width: 40px; height: 40px;"></div>
					</div>
				</div>
				<div class="homenest__professional_website_question">
					<div class="homenest__professional_website_question-header-number">
						<span class="homenest__professional_website_question-number">04</span>
						<span class="homenest__professional_website_question-label">QUESTION - 04</span>
					</div>
					<div class="homenest__professional_website_question-header">
						<div style="width: 40px; height: 40px;"></div>
						<span class="homenest__professional_website_question-title">Hosting là gì và tại sao cần
							thiết?</span>
						<button class="homenest__professional_website_toggle-btn">
							+
						</button>
					</div>
					<div class="homenest__professional_website_answer-wrapper">
						<div style="width: 40px; height: 40px;"></div>
						<div class="homenest__professional_website_answer">Hosting là nơi lưu trữ toàn bộ dữ liệu website.
							Không có hosting thì website không thể hoạt động được trên internet.</div>
						<div style="width: 40px; height: 40px;"></div>
					</div>
				</div>
				<div class="homenest__professional_website_question">
					<div class="homenest__professional_website_question-header-number">
						<span class="homenest__professional_website_question-number">05</span>
						<span class="homenest__professional_website_question-label">QUESTION - 05</span>
					</div>
					<div class="homenest__professional_website_question-header">
						<div style="width: 40px; height: 40px;"></div>
						<span class="homenest__professional_website_question-title">Tên miền là gì?</span>
						<button class="homenest__professional_website_toggle-btn">
							+
						</button>
					</div>
					<div class="homenest__professional_website_answer-wrapper">
						<div style="width: 40px; height: 40px;"></div>
						<div class="homenest__professional_website_answer">Tên miền là địa chỉ của website trên internet, ví
							dụ như www.tenmien.com. Nó giúp người dùng truy cập nhanh chóng vào website.</div>
						<div style="width: 40px; height: 40px;"></div>
					</div>
				</div>
				<div class="homenest__professional_website_question">
					<div class="homenest__professional_website_question-header-number">
						<span class="homenest__professional_website_question-number">06</span>
						<span class="homenest__professional_website_question-label">QUESTION - 06</span>
					</div>
					<div class="homenest__professional_website_question-header">
						<div style="width: 40px; height: 40px;"></div>
						<span class="homenest__professional_website_question-title">Website có cần bảo mật SSL không?</span>
						<button class="homenest__professional_website_toggle-btn">
							+
						</button>
					</div>
					<div class="homenest__professional_website_answer-wrapper">
						<div style="width: 40px; height: 40px;"></div>
						<div class="homenest__professional_website_answer">Có. SSL giúp mã hóa dữ liệu giữa người dùng và
							máy chủ, tăng độ tin cậy và bảo vệ thông tin cá nhân, đặc biệt quan trọng với các website thương
							mại điện tử.</div>
						<div style="width: 40px; height: 40px;"></div>
					</div>
				</div>
				<div class="homenest__professional_website_question">
					<div class="homenest__professional_website_question-header-number">
						<span class="homenest__professional_website_question-number">07</span>
						<span class="homenest__professional_website_question-label">QUESTION - 07</span>
					</div>
					<div class="homenest__professional_website_question-header">
						<div style="width: 40px; height: 40px;"></div>
						<span class="homenest__professional_website_question-title">Tôi có thể chỉnh sửa nội dung website
							không?</span>
						<button class="homenest__professional_website_toggle-btn">
							+
						</button>
					</div>
					<div class="homenest__professional_website_answer-wrapper">
						<div style="width: 40px; height: 40px;"></div>
						<div class="homenest__professional_website_answer">Có. Với hệ thống quản trị nội dung (CMS), bạn có
							thể dễ dàng cập nhật nội dung mà không cần kiến thức lập trình.</div>
						<div style="width: 40px; height: 40px;"></div>
					</div>
				</div>
				<div class="homenest__professional_website_question">
					<div class="homenest__professional_website_question-header-number">
						<span class="homenest__professional_website_question-number">08</span>
						<span class="homenest__professional_website_question-label">QUESTION - 08</span>
					</div>
					<div class="homenest__professional_website_question-header">
						<div style="width: 40px; height: 40px;"></div>
						<span class="homenest__professional_website_question-title">Chi phí thiết kế website là bao
							nhiêu?</span>
						<button class="homenest__professional_website_toggle-btn">
							+
						</button>
					</div>
					<div class="homenest__professional_website_answer-wrapper">
						<div style="width: 40px; height: 40px;"></div>
						<div class="homenest__professional_website_answer">Chi phí tùy thuộc vào mức độ phức tạp và yêu cầu
							cụ thể. Bạn có thể liên hệ để được báo giá chi tiết.</div>
						<div style="width: 40px; height: 40px;"></div>
					</div>
				</div>
				<div class="homenest__professional_website_question">
					<div class="homenest__professional_website_question-header-number">
						<span class="homenest__professional_website_question-number">09</span>
						<span class="homenest__professional_website_question-label">QUESTION - 09</span>
					</div>
					<div class="homenest__professional_website_question-header">
						<div style="width: 40px; height: 40px;"></div>
						<span class="homenest__professional_website_question-title">Thời gian thiết kế website mất bao
							lâu?</span>
						<button class="homenest__professional_website_toggle-btn">
							+
						</button>
					</div>
					<div class="homenest__professional_website_answer-wrapper">
						<div style="width: 40px; height: 40px;"></div>
						<div class="homenest__professional_website_answer">Thông thường từ 7-20 ngày làm việc tùy theo mức
							độ phức tạp và số lượng tính năng yêu cầu.</div>
						<div style="width: 40px; height: 40px;"></div>
					</div>
				</div>
				<div class="homenest__professional_website_question">
					<div class="homenest__professional_website_question-header-number">
						<span class="homenest__professional_website_question-number">10</span>
						<span class="homenest__professional_website_question-label">QUESTION - 10</span>
					</div>
					<div class="homenest__professional_website_question-header">
						<div style="width: 40px; height: 40px;"></div>
						<span class="homenest__professional_website_question-title">Website có tương thích với điện thoại
							không?</span>
						<button class="homenest__professional_website_toggle-btn">
							+
						</button>
					</div>
					<div class="homenest__professional_website_answer-wrapper">
						<div style="width: 40px; height: 40px;"></div>
						<div class="homenest__professional_website_answer">Có. Website được thiết kế responsive, hiển thị
							tốt trên mọi thiết bị như điện thoại, máy tính bảng và laptop.</div>
						<div style="width: 40px; height: 40px;"></div>
					</div>
				</div>
			</div>
		</div>
		</div>
	<style>
		* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

.homenest__professional_website_hn-pricing-section {
  background-color: #ffffff;
  text-align: left;
	    width: 92%;
    max-width: 100%;
}
.homenest__professional_website_hn-pricing-title {
    font-size: 41px;
    text-transform: uppercase;
    font-weight: bold;
    margin-bottom: 20px;
    margin: 0 auto;
    display: flex;
    justify-content: center;
    margin-bottom: 40px;
}

.homenest__professional_website_hn-pricing-title span {
    background: linear-gradient(to right, #020C6A, #1A85F8, #66E5FB);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.homenest__professional_website_hn-pricing-cards {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 24px;
  width: 100%;
  height: auto;
  align-items: start;
}

.homenest__professional_website_hn-card {
  background: #f0f2f4;
  border-radius: 8px;
  border: #dddddd 1px solid;
  padding: 20px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  gap: 15px;
  position: relative;
  overflow: visible;
  text-align: left;
}

.homenest__professional_website_hn-card__header {
  color: white;
  font-weight: bold;
  font-size: 20px;
  padding: 10px;
  border-radius: 8px;
  text-transform: uppercase;
  display: flex;
  justify-content: center; /* horizontal */
  align-items: center;
  margin-bottom: 5px;
  position: relative;
  width: calc(60% + 25px);
  height: 57.5px;
  left: -30px;
  /* Lồi ra bên trái */
  z-index: 2;
  background-size: cover;
  background-repeat: no-repeat;
  background-position: center;
  text-align: center;
}

/* Mỗi loại gói có 1 ảnh nền riêng cho header */
.homenest__professional_website_hn-card--basic
  .homenest__professional_website_hn-card__header {
  background-image: url("https://homenest.com.vn/wp-content/uploads/2025/03/image-5-e1740151663487.png");
  box-shadow: 0px 4px 24px 0px
    rgba(44.999999999999986, 181, 177.00000000000003, 0.34901960784313724);
}

.homenest__professional_website_hn-card--golden
  .homenest__professional_website_hn-card__header {
  background-image: url("https://homenest.com.vn/wp-content/uploads/2025/03/image-1-1-e1740152512465.png");
  box-shadow: 0px 4px 24px 0px rgba(185, 162, 80, 0.34901960784313724);
}

.homenest__professional_website_hn-card--diamond
  .homenest__professional_website_hn-card__header {
  background-image: url("https://homenest.com.vn/wp-content/uploads/2025/03/image-2-1-e1740152586784.png");
  box-shadow: 0px 4px 24px 0px
    rgba(1.9999999999999996, 11.999999999999963, 106, 0.34901960784313724);
}

.homenest__professional_website_hn-card--platinum
  .homenest__professional_website_hn-card__header {
  background-image: url("https://homenest.com.vn/wp-content/uploads/2025/03/image-3-1-e1740152632310.png");
  box-shadow: 0px 4px 24px 0px
    rgba(151, 34.00000000000001, 149.0000000000001, 0.34901960784313724);
}

.homenest__professional_website_hn-card__features {
  list-style: none;
  padding: 0;
  margin: 0;
}

.homenest__professional_website_hn-card__features li {
  position: relative;
  padding-left: 30px;
  margin: 10px;
  font-size: 15px;
}

.homenest__professional_website_hn-card__features li::before {
  content: "";
  position: absolute;
  left: 0;
  top: 2px;
  width: 20px;
  height: 20px;
  background-size: contain;
  background-repeat: no-repeat;
}

.homenest__professional_website_hn-card--platinum
  .homenest__professional_website_hn-card__features
  li::before {
  background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='24' height='25' viewBox='0 0 24 25' fill='none'><g clip-path='url(%23clip0_2797_23609)'><path d='M18 4.5H6C4.89543 4.5 4 5.39543 4 6.5V18.5C4 19.6046 4.89543 20.5 6 20.5H18C19.1046 20.5 20 19.6046 20 18.5V6.5C20 5.39543 19.1046 4.5 18 4.5Z' stroke='%23972295' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/><path d='M15 9.5H9V15.5H15V9.5Z' stroke='%23972295' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/><path d='M9 1.5V4.5' stroke='%23972295' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/><path d='M15 1.5V4.5' stroke='%23972295' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/><path d='M9 20.5V23.5' stroke='%23972295' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/><path d='M15 20.5V23.5' stroke='%23972295' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/><path d='M20 9.5H23' stroke='%23972295' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/><path d='M20 14.5H23' stroke='%23972295' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/><path d='M1 9.5H4' stroke='%23972295' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/><path d='M1 14.5H4' stroke='%23972295' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/></g><defs><clipPath id='clip0_2797_23609'><rect width='24' height='24' fill='white' transform='translate(0 0.5)'/></clipPath></defs></svg>");
}

.homenest__professional_website_hn-card--diamond
  .homenest__professional_website_hn-card__features
  li::before {
  background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='24' height='25' viewBox='0 0 24 25' fill='none'><g clip-path='url(%23clip0_2797_23411)'><path d='M18 4.5H6C4.89543 4.5 4 5.39543 4 6.5V18.5C4 19.6046 4.89543 20.5 6 20.5H18C19.1046 20.5 20 19.6046 20 18.5V6.5C20 5.39543 19.1046 4.5 18 4.5Z' stroke='%23020C6A' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/><path d='M15 9.5H9V15.5H15V9.5Z' stroke='%23020C6A' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/><path d='M9 1.5V4.5' stroke='%23020C6A' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/><path d='M15 1.5V4.5' stroke='%23020C6A' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/><path d='M9 20.5V23.5' stroke='%23020C6A' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/><path d='M15 20.5V23.5' stroke='%23020C6A' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/><path d='M20 9.5H23' stroke='%23020C6A' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/><path d='M20 14.5H23' stroke='%23020C6A' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/><path d='M1 9.5H4' stroke='%23020C6A' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/><path d='M1 14.5H4' stroke='%23020C6A' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/></g><defs><clipPath id='clip0_2797_23411'><rect width='24' height='24' fill='white' transform='translate(0 0.5)'/></clipPath></defs></svg>");
}

.homenest__professional_website_hn-card--golden
  .homenest__professional_website_hn-card__features
  li::before {
  background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='24' height='25' viewBox='0 0 24 25' fill='none'><g clip-path='url(%23clip0_2797_23227)'><path d='M18 4.5H6C4.89543 4.5 4 5.39543 4 6.5V18.5C4 19.6046 4.89543 20.5 6 20.5H18C19.1046 20.5 20 19.6046 20 18.5V6.5C20 5.39543 19.1046 4.5 18 4.5Z' stroke='%23FD7401' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/><path d='M15 9.5H9V15.5H15V9.5Z' stroke='%23FD7401' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/><path d='M9 1.5V4.5' stroke='%23FD7401' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/><path d='M15 1.5V4.5' stroke='%23FD7401' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/><path d='M9 20.5V23.5' stroke='%23FD7401' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/><path d='M15 20.5V23.5' stroke='%23FD7401' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/><path d='M20 9.5H23' stroke='%23FD7401' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/><path d='M20 14.5H23' stroke='%23FD7401' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/><path d='M1 9.5H4' stroke='%23FD7401' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/><path d='M1 14.5H4' stroke='%23FD7401' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/></g><defs><clipPath id='clip0_2797_23227'><rect width='24' height='24' fill='white' transform='translate(0 0.5)'/></clipPath></defs></svg>");
}

.homenest__professional_website_hn-card--basic
  .homenest__professional_website_hn-card__features
  li::before {
  background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none"><g clip-path="url(%23clip0_2797_23085)"><path d="M18 4.5H6C4.89543 4.5 4 5.39543 4 6.5V18.5C4 19.6046 4.89543 20.5 6 20.5H18C19.1046 20.5 20 19.6046 20 18.5V6.5C20 5.39543 19.1046 4.5 18 4.5Z" stroke="%232DB5B1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M15 9.5H9V15.5H15V9.5Z" stroke="%232DB5B1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M9 1.5V4.5" stroke="%232DB5B1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M15 1.5V4.5" stroke="%232DB5B1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M9 20.5V23.5" stroke="%232DB5B1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M15 20.5V23.5" stroke="%232DB5B1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M20 9.5H23" stroke="%232DB5B1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M20 14.5H23" stroke="%232DB5B1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M1 9.5H4" stroke="%232DB5B1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M1 14.5H4" stroke="%232DB5B1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></g><defs><clipPath id="clip0_2797_23085"><rect width="24" height="24" fill="white" transform="translate(0 0.5)"/></clipPath></defs></svg>');
}

.homenest__professional_website_hn-card__link {
  color: #f90;
  text-decoration: none;
  font-weight: 500;
}

.homenest__professional_website_hn-card__footer {
  margin-top: auto;
  border-top: 1px solid #eee;
  padding-top: 15px;
  display: flex;
  gap: 20px;
  align-items: center;
}

.homenest__professional_website_hn-card__price {
  flex: 1;
  font-size: 26px;
  font-weight: bold;
  color: #001880;
  width: fit-content;
    height: 32px;
  position: relative;
  overflow: hidden;
}
.homenest__professional_website_hn-card__price_price-text,
.homenest__professional_website_hn-card__price_hover-text {
  position: absolute;
  left: 0;
  top: 0;
  transition: all 0.5s ease-in-out;
  width: 100%;
  text-align: left;
  font-size: 26px;
  font-weight: 700;
  color: #020C6A;
  opacity: 1;
}

.homenest__professional_website_hn-card__price_hover-text {
  transform: translateY(100%);
}

/* On hover: animate price up and show hover text from below */
.homenest__professional_website_hn-card__price:hover .homenest__professional_website_hn-card__price_price-text {
  transform: translateY(-50px) rotate(120deg) scale(0.3);;
}

.homenest__professional_website_hn-card__price:hover .homenest__professional_website_hn-card__price_hover-text {
  transform: translateY(0%);
}
.homenest__professional_website_hn-card_hidden-features {
  max-height: 0;
  overflow: hidden;
  transition: max-height 0.4s ease;
  display: block; /* Important for the slide effect */
}

@keyframes moveGradient {
  0% {
    background-position: 0% 50%;
  }

  50% {
    background-position: 100% 50%;
  }

  100% {
    background-position: 0% 50%;
  }
}

.homenest__professional_website_hn-card__button {
  background: linear-gradient(
    to right,
    #e64b48,
    #2463ff,
    #ff7a1a,
    #5bb9ff,
    #ff2831
  );
  background-size: 500% 200%;
  /* Important for smooth animation */
  color: white;
  border: none;
  padding: 8px 16px;
  border-radius: 8px;
  animation: moveGradient 5s linear infinite;
  cursor: pointer;
  width: 30%;
}

.homenest__professional_website_elementor-divider-black {
  box-sizing: border-box;
  display: flex;
  align-items: center;
  width: 100%;
  height: 0.25px;
  margin: 0;
  padding: 0.15px 0;
  color: #909090;
}

.homenest__professional_website_elementor-divider {
  box-sizing: border-box;
  display: flex;
  align-items: center;
  /* căn icon và text theo chiều dọc nếu cần */
  width: 100%;
  height: 6px;
  /* KHÔNG PHÙ HỢP nếu muốn chứa text — nên xóa hoặc tăng lên */
  margin: 0;
  padding: 2px 0;
  list-style: none;

  font-family: "Neue Einstellung", sans-serif;
  font-size: 16px;
  font-weight: 400;
  font-style: normal;
  line-height: 24px;
  letter-spacing: normal;
  word-spacing: 0;
  text-align: start;
  text-transform: none;
  color: rgb(33, 37, 41);
}

.homenest__professional_website_elementor-divider {
  box-sizing: border-box;
  display: flex;
  align-items: center;
  /* căn icon và text theo chiều dọc nếu cần */
  width: 100%;
  height: 6px;
}

.homenest__professional_website_elementor-divider-separator {
  box-sizing: border-box;
  display: flex;
  width: 100%;
  height: 2px;
  border-top: 2px solid rgb(255, 255, 255);
  color: rgb(33, 37, 41);
}
.homenest__professional_website_pricing-section {
  padding: 40px 0;
  position: relative;
  display: flex;
  align-items: center;
  width: 100%;
  overflow: hidden;
}

.homenest__professional_website_hn-pricing-cards-wrapper {
  overflow-x: auto;
  scroll-behavior: smooth;
  padding: 0 20px; /* Leave space for scroll buttons */
  -ms-overflow-style: none; /* IE and Edge */
  scrollbar-width: none; /* Firefox */
}
.homenest__professional_website_hn-pricing-cards-wrapper::-webkit-scrollbar {
  display: none; /* Chrome, Safari, Opera */
}
.homenest__professional_website_scroll-btn {
  position: absolute;
  top: 50%;
  z-index: 10;
  font-size: 2rem;
  border: none;
  background-color: transparent;
  cursor: pointer;
}

.homenest__professional_website_scroll-btn.left {
  left: 10px;
}

.homenest__professional_website_scroll-btn.right {
  right: 10px;
}
@media only screen and (max-width: 1468px) {
  .homenest__professional_website_hn-pricing-cards {
    display: flex;
    gap: 24px;
  }
  .homenest__professional_website_hn-card {
    flex: 0 0 33.3333%;
    max-width: 33.3333%;
  }
}
@media only screen and (max-width: 1309px) {
    .homenest__professional_website_hn-pricing-cards {
    display: flex;
    gap: 24px;
  }
  .homenest__professional_website_hn-card__price {
    font-size: 22px;
  }
  .homenest__professional_website_hn-pricing-section {
    padding: 20px;
    margin-top: -110px;
  }
  .homenest__professional_website_hn-pricing-title {
    font-size: 28px;
    text-transform: uppercase;
    font-weight: bold;
    margin-bottom: 20px;
    margin: 0 auto;
    justify-content: center;
    display: contents !important;
}
.section-header {
    text-align: left;
    margin-bottom: 10px !important;
    background-image: url(https://homenest.com.vn/wp-content/uploads/2024/11/Frame.png);
    background-position: right;
    background-repeat: no-repeat;
}
.homenest__professional_website_question-title {
    padding: 20px 0px;
    text-align: left;
    font-size: 18px;
    color: #111111;
    font-weight: 600;
    padding-left: 44px !important;
}
.homenest__professional_website_question {
    border-bottom: 1px solid #adadad;
    padding: 35px 10px !important;
}
.homenest__professional_website_question-label {
    font-size: 16px;
    color: #1A85F8;
    margin-left: -176px !important;
    margin-top: -33px !important;
}
}
@media only screen and (max-width: 1023px) {
    .homenest__professional_website_hn-card__price {
    font-size: 20px;
  }
  .homenest__professional_website_hn-card {
    flex: 0 0 50%;
    max-width: 50%;
  }
}
@media only screen and (max-width: 767px) {
    .homenest__professional_website_scroll-btn.left {
    left: 0px;
  }
  .homenest__professional_website_scroll-btn.right {
    right: 0px;
  }
  .homenest__professional_website_hn-card {
    flex: 0 0 70%;
    max-width: 70%;
  }
}
@media only screen and (max-width: 610px) {
  .homenest__professional_website_hn-card {
    flex: 0 0 90%;
    max-width: 90%;
  }
}
@media only screen and (max-width: 520px) {
  .homenest__professional_website_hn-card {
    flex: 0 0 100%;
    max-width: 100%;
  }
}

		.homenest__professional_website_title-wrapper {
			display: flex;
			justify-content: center;
			padding: 20px;
			margin-bottom: 40px;
		}
		.homenest__professional_website_answer {
			padding: 0px 264px;
			font-size: 17px;
			line-height: 1.5;
			font-weight: 300;
		}

		.homenest__professional_website_title {
			font-weight: bold;
			background: linear-gradient(92.16deg, #2f3fcf 0%, #1a85f8 56.7%, #66e5fb 100%);
			-webkit-background-clip: text;
			-webkit-text-fill-color: transparent;
			display: inline-block;
			font-size: 40px;
		}
		div#homenest__professional_website_faq-container {
			width: 65%;
			margin: 0 auto;
		}

		.homenest__professional_website_faq {
			width: 100%;
			/* padding: 80px 128px; */
			padding: 50px 0px;
			background-image: url(/wp-content/uploads/2025/06/1-3.webp);
			background-size: 16% auto;
			background-repeat: no-repeat;
			background-position: left top;
		}

		.homenest__professional_website_question:first-child {
			border-top: 1px solid #adadad;
		}

		.homenest__professional_website_question {
			border-bottom: 1px solid #adadad;
			padding: 20px 0;
		}

		.homenest__professional_website_question-header-number {
			display: grid;
			grid-template-columns: 250px 1.5fr 40px;
			align-items: center;
			padding: 10px 0;
			cursor: pointer;
			gap: 10px;
			margin-bottom: -42px;
		}

		.homenest__professional_website_question-number {
			font-weight: 600;
			font-size: 64px;
			white-space: nowrap;
			text-align: left;
			position: relative;
			top: 21px;
			background: linear-gradient(-5.84deg, #2f3fcf 0%, #1A85E6 56.7%, #66e5fb 100%);
			-webkit-background-clip: text;
			-webkit-text-fill-color: transparent;
		}

		.homenest__professional_website_question-label {
			font-size: 16px;
			color: #1A85F8;
		}

		.homenest__professional_website_question-header {
			display: grid;
			grid-template-columns: 250px 1.5fr 40px;
			align-items: center;
			padding: 10px 0;
			cursor: pointer;
			gap: 10px;
		}

		.homenest__professional_website_question-title {
			padding: 20px 0;
			text-align: left;
			font-size: 18px;
			color: #111111;
			font-weight: 600;
		}
		.homenest__professional_website_answer-wrapper {
			max-height: 0;
			overflow: hidden;
			transition: max-height 0.3s ease-out;
		}

		.homenest__professional_website_question.active .homenest__professional_website_answer-wrapper {
			max-height: 200px; /* Điều chỉnh giá trị này tùy theo độ dài của câu trả lời */
		}

		.homenest__professional_website_toggle-btn {
			transition: transform 0.3s ease;
			height: 38px;
			border-radius: 7px;
			width: 38px;
			font-size: 23px;
			border: 1px solid;
			/* align-items: center; */
			display: flex;
			flex-direction: column;
			/* justify-content: center; */
			/* text-align: center; */
			margin-top: -40px;
			padding: 0;
		}

		.homenest__professional_website_question.active .homenest__professional_website_toggle-btn {
			transform: rotate(45deg);
		}

		.section-divider {
			width: 100%;
			height: 500px;
			margin: 0 auto;
			position: relative;
			background-image: url(/wp-content/uploads/2025/06/1.webp);
			background-size: cover;
			background-position: center;
			background-repeat: no-repeat;
		}

		/* Thêm lớp overlay tối */
		.section-divider::before {
			content: '';
			position: absolute;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
			background-color: rgba(0, 0, 0, 0.5);
			/* Điều chỉnh độ tối bằng cách thay đổi giá trị alpha (0.3) */
		}

		.homenest-tiktokads-container {
			max-width: 100vw;
			width: 100%;
			display: flex;
			justify-content: center;
			align-items: center;
			flex-direction: column;
		}


		.homenest__professional_website_hn-card {
			background:
				#f0f2f4;
			border-radius:
				8px;
			border:
				#dddddd 1px solid;
			padding: 20px;
			display: flex;
			flex-direction: column;
			justify-content: space-between;
			gap:
				15px;
			position: relative;
			overflow:
				visible;
			text-align: left;
		}
		ol,
		ul {
			box-sizing: border-box;
		}
		.homenest__professional_website_scroll-btn.right {
			right: 10px;
		}

		.homenest__professional_website_scroll-btn {
			position: absolute;
			top: 50%;
			z-index: 10;
			font-size: 2rem;
			border: none;
			background-color: transparent;
			cursor: pointer;
		}

		@media (max-width: 768px) {
			.section-divider {
				height: 100px;
			}

			.homenest__professional_website_hn-card {
				background: #f0f2f4;
				border-radius: 8px;
				border: #dddddd 1px solid;
				padding: 20px;
				display: flex;
				flex-direction: column;
				justify-content: space-between;
				gap: 15px;
				position: relative;
				overflow: visible;
				text-align: left;
				margin-bottom: 30px !important;
			}


			.step-image img {
				width: 100%;
				height: auto;
				border-radius: 25px;
				display: none;
			}
			.homenest__professional_website_question-number {
				font-weight: 600;
                font-size: 33px !important;
                padding: 7px 14px;
                white-space: nowrap;
                margin-top: 0px;
                text-align: left;
                position: relative;
                top: 7px;
                background: linear-gradient(-5.84deg, #2f3fcf 0%, #1A85E6 56.7%, #66e5fb 100%);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
			}
            .tiktok-advantages img {
                position: absolute;
                right: 0;
                left: 71%;
                bottom: 10%;
                display: none !important;
                padding: 20px;
            }

			.faq-container {
				max-width: 100%;
				background-image: url(https://homenest.com.vn/wp-content/uploads/2024/11/Frame-1.png);
				background-position: left;
				background-repeat: no-repeat;
				background-size: contain;
			}
			.homenest__professional_website_faq {
				width: 100%;
			}
			div#homenest__professional_website_faq-container {
				width: 100%;
				/* margin: 0 auto; */
			}
			.homenest__professional_website_toggle-btn {
				display:none;
			}
			/* Hero section */
			.tiktok-ads-hero {
				flex-direction: column;
				padding: 0;
				gap: 40px;
				margin-left: 0;
				max-width: 100%;
			}

			.tiktok-ads-content {
				max-width: 100%;
				width: 100%;
			}

			.tiktok-ads-title {
				font-size: 32px;
			}

			.tiktok-ads-subtitle {
				font-size: 31px;
			}

			.tiktok-ads-image img {
				width: 100%;
			}

			/* Advantages section */
			.tiktok-advantages {
				padding: 23px;
				flex-direction: column;
				gap: 40px;
			}

			.advantages-grid {
				max-width: 100%;
			}

			.tiktok-advantages-title {
				font-size: 28px;
				width: 100%;
				margin-bottom: 0;
			}

			/* Why choose section */
			.why-choose {
				margin-right: 0;
				padding: 40px 20px;
			}

			.why-choose-header {
				flex-direction: column;
				max-width: 100%;
			}

			.why-choose-title {
				font-size: 28px;
                text-align: center;
                width: 100%;
                padding: 0px 0px;
                align-items: center;
                margin: 0 auto;
                display: flex;
                flex-direction: column;
                justify-content: center;
			}

			.why-choose-item {
				padding: 20px;
			}

			/* Service categories */
			.service-categories-title,
			.service-categories-title1 {
				font-size: 28px;
				width: 100%;
				text-align: center;
			}

			.service-categories {
				width: 100%;
				margin: 0;
			}

			/* FAQ section */

			.faq-section .section-title {
				width: 100%;
			}

			.faq-header h3 {
				font-size: 18px;
			}

			/* Banner section */
			.banner-content {
				position: relative;
				top: 0;
				left: 0;
				transform: none;
				max-width: 100%;
				padding: 40px 20px;
			}

			.img-inside {
				width: 100%;
				position: relative;
				top: 0;
				right: 0;

			}

			.img-overlap {
				display: none;
			}

			/* Process section */
			.quy-trinh-section {
				flex-direction: column;
				padding: 0;
				gap: 0;
			}

			.step-image {
				width: 100%;
				margin-left: 0;
				position: relative;
			}

			.process-step:nth-child(even) {
				padding-left: 0;
			}
            .tiktok-ads-description {
                font-family: 'HomeNest', sans-serif;
                font-weight: 400;
                font-size: 18px;
                color: black;
                margin-bottom: 40px;
                line-height: 32px;
                padding-right: 0 !important;
            }

			p {
				font-size: 15px !important;
				font-weight: 100;
				line-height: 35px;
			}
		}
	</style>
	<style>
		.step-image {
			position: relative;
			width: 40%;
			margin-left: 100px;
			position: sticky;
			top: 10%;
			height: 33%;
            z-index: 10;
		}

		.step-image img {
			width: 100%;
			height: auto;
			border-radius: 25px;
		}

		.overlay-box {
			position: absolute;
			background-color: white;
			border-radius: 10px;
		}

		.box1 {
			width: 92px;
			height: 279px;
			top: 0%;
			/* left: 1%; */
			z-index: 2;
			position: absolute;
		}

		.box1::before {
			content: "";
			position: absolute;
			top: 0;
			right: -46px;
			padding: 23px;
			background-color: transparent;
			border-top-left-radius: 25px;
			box-shadow: -7px -14px 0 white;
		}

		.box1::after {
			background: black;
			content: "";
			position: absolute;
			bottom: -46px;
			left: 0;
			padding: 23px;
			background-color: transparent;
			border-top-left-radius: 25px;
			box-shadow: -19px -8px 0 white;
		}

		.box2 {
			width: 371px;
			height: 90px;
			bottom: -4%;
			right: 0%;
			z-index: 2;
		}

		.box2::before {
			content: "";
			position: absolute;
			bottom: 27px;
			left: -46px;
			padding: 23px;
			background-color: transparent;
			border-bottom-right-radius: 15px;
			box-shadow: 17px 15px 0 white;
		}

		.box2::after {
			background: black;
			content: "";
			position: absolute;
			top: -46px;
			right: 0;
			padding: 23px;
			background-color: transparent;
			border-bottom-right-radius: 25px;
			box-shadow: 8px 19px 0 white;
		}

		/* Responsive */
		@media (max-width: 768px) {
			.overlay-box {
				width: 120px;
				height: 120px;
				display: none;
			}

			.faq-item {
				margin-bottom: 20px;
				border-radius: 5px;
				width: 100% !important;
			}
		}

		/* Tùy chỉnh khoảng cách */


		.faq-section {
			padding-top: 40px;
			/* Giảm padding top của section sau */
		}

		.faq-img1 {
			width: 15%;
			margin-top: -90px;
			height: 0;
			margin-right: 140px;
		}

		.faq-img {
			display: flex;
			flex-direction: row-reverse;
			margin: 0 auto;
		}
	</style>
	<style>
		.banner {
			position: relative;
			width: 100%;
			height: auto;
			overflow: visible;
		}

		.banner-content {
			position: absolute;
			top: 49%;
			left: 23%;
			transform: translateY(-50%);
			color: #fff;
			z-index: 2;
			max-width: 30%;
		}

		.banner-title {
			font-size: 48px;
			font-weight: 700;
			margin-bottom: 20px;
		}

		.banner-subtitle {
			font-size: 18px;
			line-height: 1.5;
		}

		.img-inside {
			width: 100%;
			height: 281px;
		}

		.img-overlap {
			position: absolute;
			right: 50px;
			width: 299px;
			height: auto;
			top: -90px;
			z-index: 1;
		}

		section.service-categories-section {
			background-image: url(/wp-content/uploads/2025/06/1-3.webp);
			background-size: contain;
			background-repeat: no-repeat;
			margin-bottom: 70px;
		}

		/* Style cho quy trình section */

		/* Thêm vào CSS hiện có */

		.faq-section {
			padding: 80px 0;
			background: #fff;
			width: 100%;
		}

		.faq-section .section-title {
			font-size: 35px;
			font-weight: 700;
			text-align: center;
			margin-bottom: 50px;
			width: 50%;
		}

		.faq-container {
			max-width: 100%;
			background-image: url(https://homenest.com.vn/wp-content/uploads/2024/11/Frame-1.png);
			background-position: left;
			background-repeat: no-repeat;
			background-size: contain;
		}

		.faq-item {
			margin-bottom: 20px;
			border-radius: 5px;
			margin: 0 auto;
			width: 61%;
		}

		.faq-header {
			cursor: pointer;
			position: relative;
			padding: 35px;
			border-bottom: 1px solid #eee;
			display: flex;
		}

		.faq-header .number {
			font-size: 24px;
			font-weight: 100;
			color: black;
			margin-right: 20px;
			min-width: 50px;
		}

		.faq-header h3 {
			font-size: 25px;
			font-weight: 600;
			flex: 1;
			margin: 0;
		}

		.faq-header .arrow {
			font-size: 24px;
			transition: transform 0.5s ease;
		}

		.faq-content {
			max-height: 0;
			overflow: hidden;
			transition: max-height 0.5s ease-out, padding 0.5s ease-out;
			padding: 0 20px;
			border-top: 1px solid #eee;
			/* Thêm thanh ngang */
		}

		.faq-item.active .arrow {
			transform: rotate(180deg);
		}

		.faq-item.active .faq-content {
			max-height: 500px;
			padding: 12px 75px;
		}

		/* Optional: Add hover effect */
		.faq-header:hover {
			background-color: rgba(26, 133, 248, 0.05);
		}

		/* Responsive */
		@media (max-width: 768px) {
			.faq-section .section-title {
				font-size: 28px;
			}

			.faq-header .number {
				font-size: 20px;
				min-width: 40px;
			}

			.faq-header h3 {
				font-size: 16px;
			}

			.faq-content {
				padding-left: 40px;
			}

			.section-container {
				width: 87%;
			}

			.tiktok-ads-pricing-section .package-features li {
				font-size: 14px !important;
			}
		}

		.img1 {
			width: 25%;
			margin-top: -113px;
			margin-left: 33px;
		}

		.step-image1 {
			display: flex;
		}



		.section-header {
			text-align: left;
			margin-bottom: 60px;
			background-image: url(https://homenest.com.vn/wp-content/uploads/2024/11/Frame.png);
			background-position: right;
			background-repeat: no-repeat;
		}

		.section-logo {
			font-size: 125px;
			font-weight: 900;
			color: transparent;
			-webkit-text-stroke: 1px #1A85F8;
			margin: 0;
		}

		.section-title {
			font-size: 35px;
			font-weight: 700;
			color: #333;
			margin-bottom: 10px;
		}

		.section-subtitle {
			font-size: 35px;
			font-weight: 700;
			background: linear-gradient(to right, #020C6A, #1A85F8, #66E5FB);
			-webkit-background-clip: text;
			-webkit-text-fill-color: transparent;
			margin: 0;
		}

		.process-steps {
			display: flex;
			flex-direction: column;
			gap: 40px;
			width: 85%;
		}

		.process-step {
			display: flex;
			gap: 15px;
			align-items: center;
			margin-bottom: 67px;
			margin-top: -65px;
		}

		.process-step:nth-child(even) {
			padding-left: 190px;
		}

		.step-number {
			font-size: 150px;
			font-weight: 900;
			background-image: var(--gradient);
			-webkit-text-stroke-width: 2px;
			-webkit-text-stroke-color: transparent;
			-webkit-text-fill-color: #fff;
			background-clip: text;
		}

		.step-content h4 {
			font-size: 24px;
			font-weight: 700;
			color: #333;
			margin-bottom: 15px;
		}

		.step-content p {
			font-size: 19px;
			line-height: 1.6;
			font-weight: 300;
			color: #666;
		}

		/* Responsive */
		@media (max-width: 768px) {
			.section-logo {
				font-size: 35px;
			}

			.section-title,
			.section-subtitle {
				font-size: 28px;
			}

			.process-step:nth-child(even) {
				padding-left: 25px;
			}

			.step-number {
				font-size: 50px;
			}

			.step-content h4 {
				font-size: 20px;
			}
		}

		@media (max-width: 480px) {
			.process-step:nth-child(even) {
				padding-left: 10px;
			}

			.homenest-tiktokads-container {
				max-width: 100vw;
				width: 100%;
				display: flex;
				justify-content: center;
				align-items: center;
				flex-direction: column;
				overflow: hidden !important;
			}
		}
	</style>

	<script>
		document.addEventListener('DOMContentLoaded', function () {
			const faqHeaders = document.querySelectorAll('.faq-header');

			faqHeaders.forEach(header => {
				header.addEventListener('click', function () {
					// Close all other FAQs
					const allFaqs = document.querySelectorAll('.faq-item');
					allFaqs.forEach(faq => {
						if (faq !== this.parentElement) {
							faq.classList.remove('active');
						}
					});

					// Toggle current FAQ
					this.parentElement.classList.toggle('active');

					// Rotate arrow icon
					const arrow = this.querySelector('.arrow');
					if (this.parentElement.classList.contains('active')) {
						arrow.style.transform = 'rotate(180deg)';
					} else {
						arrow.style.transform = 'rotate(0deg)';
					}
				});
			});
		});
	</script>
	</body>
<script>
	document.addEventListener("DOMContentLoaded", function () {
  const container = document.querySelector(
    ".homenest__professional_website_hn-pricing-cards"
  );

  const pricingPlans = [
    {
      title: "Basic",
      color: "#2db5b1",
      description:
        "Gói Basic tại HomeNest mang đến website chuyên nghiệp với thiết kế đơn giản.",
      features: [
        "Giao diện đa dạng có sẵn",
        "Đầy đủ chức năng cơ bản",
        "Thiết kế chuẩn SEO",
        "Công cụ hỗ trợ SEO Google",
        "Hướng dẫn quản trị website",
        "Hỗ trợ live chat, fanpage, Google map...",
        "Miễn phí bảo mật SSL năm đầu",
      ],
      hiddenFeatures: [
        "Bàn giao mã nguồn (Source code) và tên miền hosting sau khi hoàn thiện",
        "Thời gian hoàn thiện trong 5 ngày làm việc",
      ],
      price: "8.000.000",
      typeClass: "basic",
    },
    {
      title: "Golden",
      color: "#fd7401",
      description:
        "Gói Golden tại HomeNest mang đến website cao cấp với thiết kế tinh xảo.",
      features: [
        "Giao diện theo mẫu hoặc theo yêu cầu",
        "Chức năng nâng cao",
        "Website song ngữ",
        "Thiết kế chuẩn SEO",
        "Công cụ hỗ trợ SEO Google",
        "Thiết kế Figma: 1",
        "Giao diện chuẩn UI/UX",
      ],
      hiddenFeatures: [
        "Hướng dẫn quản trị website",
        "Bàn giao mã nguồn (Source code) và tên miền hosting sau khi hoàn thiện",
        "Hỗ trợ live chat, fanpage, Google map...",
        "Miễn phí bảo mật SSL năm đầu",
        "Miễn phí tên miền .com hoặc .net năm đầu tiên",
        "Thời gian hoàn thiện trong 15 - 20 ngày",
      ],
      price: "16.000.000",
      typeClass: "golden",
    },
    {
      title: "Diamond",
      color: "#020c6a",
      description:
        "Gói Diamond tại HomeNest cung cấp website đỉnh cao với thiết kế hoàn hảo.",
      features: [
        "Giao diện độc quyền theo thương hiệu",
        "Chức năng theo nhu cầu",
        "Website đa ngôn ngữ",
        "Thiết kế chuẩn SEO",
        "Công cụ hỗ trợ SEO Google",
        "Thiết kế Figma: 2",
        "Giao diện chuẩn UI/UX",
      ],
      hiddenFeatures: [
        "Tối ưu SEO",
        "Hướng dẫn viết bài chuẩn SEO",
        "Content chuẩn SEO: 5 bài",
        "Hướng dẫn đi internal link và external link",
        "Hướng dẫn quản trị website",
        "Bàn giao mã nguồn (Source code) và tên miền hosting sau khi hoàn thiện",
        "Miễn phí gói hosting năm đầu",
        "Nút Live chat, Call now Fanpage, Google map tương tác trực tiếp",
        "Miễn phí bảo mật SSL năm đầu",
        "Miễn phí tên miền .com hoặc .net năm đầu tiên",
      ],
      price: "40.000.000",
      typeClass: "diamond",
    },
    {
      title: "Platinum",
      color: "#972295",
      description:
        "Gói Platinum tại HomeNest mang đến website tối ưu với thiết kế sang trọng.",
      features: [
        "Giao diện độc quyền theo thương hiệu",
        "Chức năng theo nhu cầu",
        "Website đa ngôn ngữ",
        "Thiết kế chuẩn SEO",
        "Công cụ hỗ trợ SEO Google",
        "Thiết kế Figma: 3",
        "Giao diện chuẩn UI/UX",
      ],
      hiddenFeatures: [
        "Tối ưu SEO",
        "Hướng dẫn viết bài chuẩn SEO",
        "Content chuẩn SEO: 10 bài",
        "Hướng dẫn đi internal link và external link",
        "Hướng dẫn quản trị website",
        "Bàn giao mã nguồn (Source code) và tên miền hosting sau khi hoàn thiện",
        "Miễn phí gói hosting năm đầu",
        "Nút Live chat, Call now Fanpage, Google map tương tác trực tiếp",
        "Miễn phí bảo mật SSL năm đầu",
        "Miễn phí tên miền .com hoặc .net năm đầu tiên",
        "Xử lý dữ liệu lớn",
        "Hướng dẫn quảng cáo Facebook Ads hoặc Google Ads",
        "Website thương mại điện tử và hệ thống",
      ],
      price: "Linh hoạt",
      typeClass: "platinum",
    },
  ];

  pricingPlans.forEach((plan) => {
    const card = document.createElement("div");
    card.className = `homenest__professional_website_hn-card homenest__professional_website_hn-card--${plan.typeClass}`;
    card.innerHTML = `
        <div class="homenest__professional_website_hn-card__header">${
          plan.title
        }</div>
        <div style="display: flex; flex-direction: column; gap: 20px; margin-top: 10px; margin-bottom: 10px;">
        <div style="margin-top: 10px; margin-bottom: 10px;">
          <p>
            <span class="homenest__professional_website_black_normal" style="font-weight: 300;">
              <span style="color: ${plan.color}; font-weight: bold;">Gói ${
      plan.title
    }</span> ${plan.description}
            </span>
          </p>
        </div>
        <div class="homenest__professional_website_elementor-divider">
          <span class="homenest__professional_website_elementor-divider-separator"></span>
        </div>
        </div>
        <div class="homenest__professional_website_hn-card__body">
          <ul class="homenest__professional_website_hn-card__features" style="margin-top: 20px; margin-bottom: 20px;">
            ${plan.features.map((f) => `<li>${f}</li>`).join("")}
            <span class="homenest__professional_website_hn-card_hidden-features" style="max-height: 0; overflow: hidden; display: flex; flex-direction: column">
              ${plan.hiddenFeatures.map((f) => `<li>${f}</li>`).join("")}
            </span>
            <li><a href="#" class="homenest__professional_website_hn-card__link">Xem thêm</a></li>
          </ul>
        </div>
        <div style="display: flex; flex-direction: column; gap: 20px; margin-top: 10px; margin-bottom: 10px;">
        <div class="homenest__professional_website_elementor-divider">
          <span class="homenest__professional_website_elementor-divider-separator"></span>
        </div>
        <p class="homenest__professional_website_black_normal" > *Liên hệ ngay để được tư vấn miễn phí
            </p>
        <div class="homenest__professional_website_hn-card__footer">
          <button class="homenest__professional_website_hn-card__button">
            <div style="display: flex; justify-content: center; align-items: center; margin: 0 auto;">
              <img src="https://homenest.media/wp-content/uploads/2025/02/Icon-Call-Homenest.media_.svg" alt>
            </div>
          </button>
          <div class="homenest__professional_website_hn-card__price">
  <p class="homenest__professional_website_hn-card__price_price-text">${plan.price}</p>
  <p class="homenest__professional_website_hn-card__price_hover-text">Tư vấn ngay</p>
</div>

        </div>
        </div>
        </div>
      `;
    container.appendChild(card);
  });

  container.addEventListener("click", function (e) {
    if (e.target.matches(".homenest__professional_website_hn-card__link")) {
      e.preventDefault();
      const link = e.target;
      const hiddenFeatures = link
        .closest("ul")
        .querySelector(
          ".homenest__professional_website_hn-card_hidden-features"
        );

      const isCollapsed =
        hiddenFeatures.style.maxHeight === "" ||
        hiddenFeatures.style.maxHeight === "0px";

      if (isCollapsed) {
        hiddenFeatures.style.maxHeight = hiddenFeatures.scrollHeight + "px";
        link.textContent = "Thu hồi";
      } else {
        hiddenFeatures.style.maxHeight = "0";
        link.textContent = "Xem thêm";
      }
    }
  });
});
function scrollCards(direction) {
  const container = document.querySelector(
    ".homenest__professional_website_hn-pricing-cards-wrapper"
  );
  const card = document.querySelector(
    ".homenest__professional_website_hn-card"
  );

  if (!card) return;

  const cardWidth = card.offsetWidth + 24; // adjust based on card width
  container.scrollBy({
    left: direction * cardWidth,
    behavior: "smooth",
  });
}
	document.addEventListener('DOMContentLoaded', function () {
		const container = document.querySelector('.pricing-cards-container');
		const prevBtn = document.querySelector('.prev');
		const nextBtn = document.querySelector('.next');
		const cards = document.querySelectorAll('.pricing-card');

		let currentIndex = 0;
		let cardWidth = cards[0].offsetWidth + 20; // Thêm khoảng cách margin 20px
		const maxIndex = cards.length - Math.floor(container.offsetWidth / cardWidth);

		// Xử lý nút Previous
		prevBtn.addEventListener('click', function () {
			if (currentIndex > 0) {
				currentIndex--;
				updateSlidePosition();
			}
		});

		// Xử lý nút Next
		nextBtn.addEventListener('click', function () {
			if (currentIndex < maxIndex) {
				currentIndex++;
				updateSlidePosition();
			}
		});

		function updateSlidePosition() {
			container.style.transform = `translateX(-${currentIndex * cardWidth}px)`;

			// Cập nhật trạng thái nút
			prevBtn.style.opacity = currentIndex === 0 ? '0.5' : '1';
			nextBtn.style.opacity = currentIndex >= maxIndex ? '0.5' : '1';
		}

		// Cập nhật kích thước khi resize
		window.addEventListener('resize', function () {
			cardWidth = cards[0].offsetWidth + 20;
			maxIndex = cards.length - Math.floor(container.offsetWidth / cardWidth);
			currentIndex = Math.min(currentIndex, maxIndex);
			updateSlidePosition();
		});

		// Khởi tạo trạng thái ban đầu
		updateSlidePosition();
	});
</script>
<script>
	// JavaScript để xử lý click event
	document.addEventListener('DOMContentLoaded', function() {
		const questions = document.querySelectorAll('.homenest__professional_website_question');

		questions.forEach(question => {
			const header = question.querySelector('.homenest__professional_website_question-header');

			header.addEventListener('click', () => {
				// Đóng tất cả các câu hỏi khác
				questions.forEach(q => {
					if (q !== question) {
						q.classList.remove('active');
					}
				});

				// Toggle active class cho câu hỏi được click
				question.classList.toggle('active');
			});
		});
	});
</script>

<script>
	document.addEventListener('DOMContentLoaded', function () {
		document.addEventListener('scroll', function () {
			const elements = document.querySelectorAll('.scrollTextEffect');
			const windowHeight = window.innerHeight;

			elements.forEach(element => {
				const rect = element.getBoundingClientRect();
				const elementY = rect.top;

				// Calculate scroll progress (from 100% to 50% of viewport height)
				const startPoint = windowHeight * 0.8; // 100% viewport height
				const endPoint = windowHeight * 0.35; // 50% viewport height

				if (elementY <= startPoint && elementY >= endPoint) {
					// Linear interpolation for smooth transition
					const progress = (startPoint - elementY) / (startPoint - endPoint);
					const xValue = progress * 100; // Map to 0-100

					element.style.setProperty('--x', `${xValue}%`);
				} else if (elementY > startPoint) {
					element.style.setProperty('--x', '0%');
				} else if (elementY < endPoint) {
					element.style.setProperty('--x', '100%');
				}
			});
		});

	})
</script>

<?php get_footer(); ?>