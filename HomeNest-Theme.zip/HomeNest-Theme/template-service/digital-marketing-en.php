<?php
/**
 * Template Name: Digital Marketing - En
 * Template Post Type: service
 */
get_header(); ?>

<main>
	<section class="section1">
		<section class="section1_col1 background_caro">
			<div class="sub_title ">
				<svg aria-hidden="true" class="sub_title_icon e-font-icon-svg e-fas-circle" viewBox="0 0 512 512"
					 xmlns="http://www.w3.org/2000/svg">
					<path d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8z"></path>
				</svg>

				<span>Digital Marketing Services</span>
			</div>

			<h1 class="section1_col1_main_title first">
				HomeNest Software
				<div class="section1_col1_main_title_highligt promt_font">
					<span class="main_title_highligt"> Digital</span>
					<span class="section1_col1_main_title_highligt2"> Marketing.</span>
				</div>
			</h1>

			<p class="section1_col1_content">We move beyond theory. Our focus is on tangible growth metrics (ROI), ensuring your business connects with the right audience at the perfect moment, all while maximizing budget efficiency.</p>

			<div class="section1_col1_list_btt">
				<a href="#" class="button_gradient section1_col1_button_white section1_col1_button">
					Learn More
					<svg aria-hidden="true"
						 class="button_gradient_icon button_white_icon e-font-icon-svg e-fas-arrow-circle-right"
						 viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
						<path
							  d="M256 8c137 0 248 111 248 248S393 504 256 504 8 393 8 256 119 8 256 8zm-28.9 143.6l75.5 72.4H120c-13.3 0-24 10.7-24 24v16c0 13.3 10.7 24 24 24h182.6l-75.5 72.4c-9.7 9.3-9.9 24.8-.4 34.3l11 10.9c9.4 9.4 24.6 9.4 33.9 0L404.3 273c9.4-9.4 9.4-24.6 0-33.9L271.6 106.3c-9.4-9.4-24.6-9.4-33.9 0l-11 10.9c-9.5 9.6-9.3 25.1.4 34.4z">
						</path>
					</svg>
				</a>

				<a href="#" class="button_gradient section1_col1_button">
					Contact us
					<svg aria-hidden="true" class="button_gradient_icon  e-font-icon-svg e-fas-arrow-circle-right"
						 viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
						<path
							  d="M256 8c137 0 248 111 248 248S393 504 256 504 8 393 8 256 119 8 256 8zm-28.9 143.6l75.5 72.4H120c-13.3 0-24 10.7-24 24v16c0 13.3 10.7 24 24 24h182.6l-75.5 72.4c-9.7 9.3-9.9 24.8-.4 34.3l11 10.9c9.4 9.4 24.6 9.4 33.9 0L404.3 273c9.4-9.4 9.4-24.6 0-33.9L271.6 106.3c-9.4-9.4-24.6-9.4-33.9 0l-11 10.9c-9.5 9.6-9.3 25.1.4 34.4z">
						</path>
					</svg>
				</a>
			</div>

<!-- 			<div class="section1_col1_play_btt">
				<div class="section1_col1_play_btt_wrap_icon">
					<i class="fas fa-play section1_col1_play_btt_icon"></i>
					<span class="section1_col1_play_btt_wrap_icon_animation "></span>
					<span class="section1_col1_play_btt_wrap_icon_animation delay1"></span>
					<span class="section1_col1_play_btt_wrap_icon_animation delay2"></span>
					<span class="section1_col1_play_btt_wrap_icon_animation delay3"></span>
				</div>
				CLICK FOR PORTFOLIO
			</div> -->

			<section class="section1_col1_list_counter">
				<div class="section1_col1_counter1 section1_col1_counter background_gradient">
					<div class="section1_col1_counter_icon icon1">
						<svg class="section1_up_right_icon" width="800px" height="800px" color="white"
							 viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill="none" stroke="#000000"
							 stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
							 class="feather feather-arrow-up-right">
							<line x1="7" y1="17" x2="17" y2="7"></line>
							<polyline points="7 7 17 7 17 17"></polyline>
						</svg>
					</div>

					<div class="section1_col1_counter1_align_text">
						<div class="section1_col1_counter1_value orbitron_font">
							1000+
						</div>
						<div class="section1_col1_counter1_content">
							Projects
						</div>
					</div>
				</div>

				<div class="section1_col1_counter2 section1_col1_counter">
					<div class="section1_col1_counter_icon">
						<svg class="section1_up_right_icon" width="800px" height="800px" color="white"
							 viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill="none" stroke="#000000"
							 stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
							 class="feather feather-arrow-up-right">
							<line x1="7" y1="17" x2="17" y2="7"></line>
							<polyline points="7 7 17 7 17 17"></polyline>
						</svg>
					</div>

					<div class="section1_col1_counter2_value orbitron_font">
						50
					</div>


					<div class="section1_col1_counter2_content">
						Niches
					</div>

				</div>

				<div class="section1_col1_counter3 section1_col1_counter">
					<div class="section1_col1_counter_icon">
						<svg class="section1_up_right_icon" width="800px" height="800px" color="white"
							 viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill="none" stroke="#000000"
							 stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
							 class="feather feather-arrow-up-right">
							<line x1="7" y1="17" x2="17" y2="7"></line>
							<polyline points="7 7 17 7 17 17"></polyline>
						</svg>
					</div>

					<div class="section1_col1_counter3_value orbitron_font">
						+ <span class="section1_col1_counter3_value_value">300</span>
					</div>


					<div class="section1_col1_counter3_content">
						Clients
					</div>
				</div>
			</section>
		</section>

		<section class="section1_col2 background_gradient">
			<section class="section1_col2_wrap_wrap">
				<section class="section1_col2_wrap box2">
					<div class="section1_col2_wrap_img">
						<div class="section1_col2_img">
							<img class="section1_col2_image1 box2" loading="lazy" decoding="async" src="/wp-content/uploads/2025/08/Image2.jpg" alt="Homenest" title="Homenest">
						</div>
					</div>

					<div class="section1_col2_hidden_box2">
						<h3 class="section1_col2_title">Holistic Development</h3>

						<div class="section1_col2_text">
							<div class="section1_col2_text1a">
								<svg aria-hidden="true" class="e-font-icon-svg e-fab-diaspora" viewBox="0 0 512 512"
									 xmlns="http://www.w3.org/2000/svg">
									<path
										  d="M251.64 354.55c-1.4 0-88 119.9-88.7 119.9S76.34 414 76 413.25s86.6-125.7 86.6-127.4c0-2.2-129.6-44-137.6-47.1-1.3-.5 31.4-101.8 31.7-102.1.6-.7 144.4 47 145.5 47 .4 0 .9-.6 1-1.3.4-2 1-148.6 1.7-149.6.8-1.2 104.5-.7 105.1-.3 1.5 1 3.5 156.1 6.1 156.1 1.4 0 138.7-47 139.3-46.3.8.9 31.9 102.2 31.5 102.6-.9.9-140.2 47.1-140.6 48.8-.3 1.4 82.8 122.1 82.5 122.9s-85.5 63.5-86.3 63.5c-1-.2-89-125.5-90.9-125.5z">
									</path>
								</svg>
							</div>

							<div class="section1_col2_text1b">
								We leverage deep behavioral insights to personalize messaging and drive maximum conversions for your enterprise.
							</div>
						</div>
					</div>
				</section>

				<div class="section1_col2_wrap">
					<div class="section1_col2_wrap_img">
						<div class="section1_col2_img">
							<img class="section1_col2_image1" loading="lazy" decoding="async"
								 src="/wp-content/uploads/2025/08/four-female-partners-sitting-at-desk-and-discussin-2024-12-13-13-45-03-utc.jpg" alt="Homenest" title="Homenest">
						</div>
						<img class="section1_col2_image2" loading="lazy" decoding="async"
							 src="/wp-content/uploads/2025/08/satisfied-young-woman-reads-interesting-invitation-2025-01-23-21-30-28-utc-2.png" alt="Homenest" title="Homenest">
					</div>


					<h3 class="section1_col2_title">Holistic Development</h3>

					<div class="section1_col2_text">
						<div class="section1_col2_text1a">
							<svg aria-hidden="true" class="e-font-icon-svg e-fab-diaspora" viewBox="0 0 512 512"
								 xmlns="http://www.w3.org/2000/svg">
								<path
									  d="M251.64 354.55c-1.4 0-88 119.9-88.7 119.9S76.34 414 76 413.25s86.6-125.7 86.6-127.4c0-2.2-129.6-44-137.6-47.1-1.3-.5 31.4-101.8 31.7-102.1.6-.7 144.4 47 145.5 47 .4 0 .9-.6 1-1.3.4-2 1-148.6 1.7-149.6.8-1.2 104.5-.7 105.1-.3 1.5 1 3.5 156.1 6.1 156.1 1.4 0 138.7-47 139.3-46.3.8.9 31.9 102.2 31.5 102.6-.9.9-140.2 47.1-140.6 48.8-.3 1.4 82.8 122.1 82.5 122.9s-85.5 63.5-86.3 63.5c-1-.2-89-125.5-90.9-125.5z">
								</path>
							</svg>
						</div>

						<div class="section1_col2_text1b">
							We leverage deep behavioral insights to personalize messaging and drive maximum conversions for your enterprise.
						</div>
					</div>
				</div>
			</section>
		</section>
	</section>

	<section class="section2">
		<section class="section2_row1">
			<section class="section2_row1_col1">
				<div class="sub_title ">
					<svg aria-hidden="true" class="sub_title_icon e-font-icon-svg e-fas-circle" viewBox="0 0 512 512"
						 xmlns="http://www.w3.org/2000/svg">
						<path d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8z"></path>
					</svg>

					<span>Our Services</span>
				</div>

				<h2 class="section1_col1_main_title">
					Digital Marketing Solutions by
					<span class="main_title_highligt"> HomeNest</span>
				</h2>
			</section>


			<section class="section2_row1_col2">
				Providing a comprehensive marketing toolkit—from branding and content creation to optimizing multi-channel advertising performance.

				<a href="#" class="section2_row1_col2_button button_gradient">
					Learn More
					<svg aria-hidden="true" class="button_gradient_icon  e-font-icon-svg e-fas-arrow-circle-right"
						 viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
						<path
							  d="M256 8c137 0 248 111 248 248S393 504 256 504 8 393 8 256 119 8 256 8zm-28.9 143.6l75.5 72.4H120c-13.3 0-24 10.7-24 24v16c0 13.3 10.7 24 24 24h182.6l-75.5 72.4c-9.7 9.3-9.9 24.8-.4 34.3l11 10.9c9.4 9.4 24.6 9.4 33.9 0L404.3 273c9.4-9.4 9.4-24.6 0-33.9L271.6 106.3c-9.4-9.4-24.6-9.4-33.9 0l-11 10.9c-9.5 9.6-9.3 25.1.4 34.4z">
						</path>
					</svg>
				</a>
			</section>
		</section>

		<section class="section2_row2">
			<div class="section2_row2_item ">
				<h3 class="section2_row2_title">Social Media</h3>

				<p class="section2_row2_content">Building creative and consistent content strategies across multiple channels.</p>

				<div class="section2_row2_item_stack">
					<div class="section2_row2_item_stack1">
					</div>
					<div class="section2_row2_item_stack2">
					</div>
					<div class="section2_row2_item_stack_icon">
						<i class="fas fa-share-alt section2_row2_item_stack_icon_icon"></i>
					</div>

					<div class="section2_row2_img">
						<img class="section2_row2_image" loading="lazy" decoding="async"
							 src="/wp-content/uploads/2025/08/person-studying-digital-marketing-online-2025-02-11-13-58-52-utc-1536x1024-1.jpg" alt="Homenest" title="Homenest">
					</div>
				</div>
			</div>

			<div class="section2_row2_item middle background_gradient ">
				<h3 class="section2_row2_title middle ">Overall SEO</h3>

				<p class="section2_row2_content">Comprehensive keyword strategy aligned with the customer journey.</p>

				<div class="section2_row2_item_stack">
					<div class="section2_row2_item_stack1">
					</div>
					<div class="section2_row2_item_stack2">
					</div>
					<div class="section2_row2_item_stack_icon middle ">
						<i class="fas fa-bullseye section2_row2_item_stack_icon_icon"></i>
					</div>

					<div class="section2_row2_img">
						<img class="section2_row2_image" loading="lazy" decoding="async"
							 src="/wp-content/uploads/2025/08/four-female-partners-sitting-at-desk-and-discussin-2024-12-13-13-45-03-utc-1536x1024-1.jpg" alt="Homenest" title="Homenest">
					</div>
				</div>
			</div>

			<div class="section2_row2_item">
				<h3 class="section2_row2_title">Brand Identity</h3>

				<p class="section2_row2_content">Systematizing professional visual language to ensure brand consistency.</p>

				<div class="section2_row2_item_stack">
					<div class="section2_row2_item_stack1">
					</div>
					<div class="section2_row2_item_stack2">
					</div>
					<div class="section2_row2_item_stack_icon">
						<i class="fas fa-tag section2_row2_item_stack_icon_icon"></i>
					</div>

					<div class="section2_row2_img">
						<img class="section2_row2_image" loading="lazy" decoding="async"
							 src="/wp-content/uploads/2025/08/brainstorming-session-2025-02-11-13-52-36-utc-1536x1025-1.jpg" alt="Homenest" title="Homenest">
					</div>
				</div>
			</div>
		</section>
	</section>

	<section class="section3">
		<section class="section2_row1">
			<section class="section2_row1_col1">
				<div class="sub_title ">
					<svg aria-hidden="true" class="sub_title_icon e-font-icon-svg e-fas-circle" viewBox="0 0 512 512"
						 xmlns="http://www.w3.org/2000/svg">
						<path d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8z"></path>
					</svg>

					<span>Our Services</span>
				</div>

				<h2 class="section1_col1_main_title">
					Unlock breakthrough growth with cutting-edge
					<span class="main_title_highligt"> digital solutions.</span>
				</h2>
			</section>


			<section class="section2_row1_col2">
				HomeNest delivers all-in-one digital solutions designed to help enterprises scale market share, enhance brand authority, and drive revenue growth in the digital age.

				<a href="#" class="section2_row1_col2_button button_gradient">
					Learn More
					<svg aria-hidden="true" class="button_gradient_icon  e-font-icon-svg e-fas-arrow-circle-right"
						 viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
						<path
							  d="M256 8c137 0 248 111 248 248S393 504 256 504 8 393 8 256 119 8 256 8zm-28.9 143.6l75.5 72.4H120c-13.3 0-24 10.7-24 24v16c0 13.3 10.7 24 24 24h182.6l-75.5 72.4c-9.7 9.3-9.9 24.8-.4 34.3l11 10.9c9.4 9.4 24.6 9.4 33.9 0L404.3 273c9.4-9.4 9.4-24.6 0-33.9L271.6 106.3c-9.4-9.4-24.6-9.4-33.9 0l-11 10.9c-9.5 9.6-9.3 25.1.4 34.4z">
						</path>
					</svg>
				</a>
			</section>
		</section>

		<section class="section3_row2">
			<div class="section3_row2_col1">
				<div class="section3_row2_col1_img">
					<img class="section3_row2_col1_image" loading="lazy" decoding="async"
						 src="/wp-content/uploads/2025/08/Frame-1321315563-1.png" alt="Homenest" title="Homenest">
				</div>

				<h3 class="section3_row2_col1_title">Comprehensive weekly updates</h3>
			</div>

			<div class="section3_row2_col2">
				<div class="section3_row2_col2_img">
					<img class="section3_row2_col2_image" loading="lazy" decoding="async"
						 src="/wp-content/uploads/2025/08/Frame-1000006299.png" alt="Homenest" title="Homenest">
				</div>

				<h3 class="section3_row2_col2_title">Comprehensive weekly updates</h3>

				<p class="section3_row2_col2_content">Data Analytics & Transparent Reporting HomeNest offers a visual, real-time reporting system that empowers you to track growth metrics, understand customer behavior, and optimize ROI instantly.</p>
			</div>
		</section>
	</section>

	<section class="section4 ">
		<div class="section4_text_wrapper">
			<div class="section4_text orbitron_font">
				<!-- 2 thẻ span viết liên tục để tránh tạo khoảng trắng giữa 2 thẻ làm hiệu ứng bị giật thay vào đó sẽ dùng thêm padding right -->
				<span>HomeNest Software 
					<svg aria-hidden="true" class="star_icon e-font-icon-svg e-fab-diaspora" viewBox="0 0 512 512"
						 xmlns="http://www.w3.org/2000/svg">
						<path
							  d="M251.64 354.55c-1.4 0-88 119.9-88.7 119.9S76.34 414 76 413.25s86.6-125.7 86.6-127.4c0-2.2-129.6-44-137.6-47.1-1.3-.5 31.4-101.8 31.7-102.1.6-.7 144.4 47 145.5 47 .4 0 .9-.6 1-1.3.4-2 1-148.6 1.7-149.6.8-1.2 104.5-.7 105.1-.3 1.5 1 3.5 156.1 6.1 156.1 1.4 0 138.7-47 139.3-46.3.8.9 31.9 102.2 31.5 102.6-.9.9-140.2 47.1-140.6 48.8-.3 1.4 82.8 122.1 82.5 122.9s-85.5 63.5-86.3 63.5c-1-.2-89-125.5-90.9-125.5z">
						</path>
					</svg>
					Digital Marketing
					<svg aria-hidden="true" class="star_icon e-font-icon-svg e-fab-diaspora" viewBox="0 0 512 512"
						 xmlns="http://www.w3.org/2000/svg">
						<path
							  d="M251.64 354.55c-1.4 0-88 119.9-88.7 119.9S76.34 414 76 413.25s86.6-125.7 86.6-127.4c0-2.2-129.6-44-137.6-47.1-1.3-.5 31.4-101.8 31.7-102.1.6-.7 144.4 47 145.5 47 .4 0 .9-.6 1-1.3.4-2 1-148.6 1.7-149.6.8-1.2 104.5-.7 105.1-.3 1.5 1 3.5 156.1 6.1 156.1 1.4 0 138.7-47 139.3-46.3.8.9 31.9 102.2 31.5 102.6-.9.9-140.2 47.1-140.6 48.8-.3 1.4 82.8 122.1 82.5 122.9s-85.5 63.5-86.3 63.5c-1-.2-89-125.5-90.9-125.5z">
						</path>
					</svg>
					HomeNest Software 
					<svg aria-hidden="true" class="star_icon e-font-icon-svg e-fab-diaspora" viewBox="0 0 512 512"
						 xmlns="http://www.w3.org/2000/svg">
						<path
							  d="M251.64 354.55c-1.4 0-88 119.9-88.7 119.9S76.34 414 76 413.25s86.6-125.7 86.6-127.4c0-2.2-129.6-44-137.6-47.1-1.3-.5 31.4-101.8 31.7-102.1.6-.7 144.4 47 145.5 47 .4 0 .9-.6 1-1.3.4-2 1-148.6 1.7-149.6.8-1.2 104.5-.7 105.1-.3 1.5 1 3.5 156.1 6.1 156.1 1.4 0 138.7-47 139.3-46.3.8.9 31.9 102.2 31.5 102.6-.9.9-140.2 47.1-140.6 48.8-.3 1.4 82.8 122.1 82.5 122.9s-85.5 63.5-86.3 63.5c-1-.2-89-125.5-90.9-125.5z">
						</path>
					</svg></span><span>Digital Marketing
				<svg aria-hidden="true" class="star_icon e-font-icon-svg e-fab-diaspora" viewBox="0 0 512 512"
					 xmlns="http://www.w3.org/2000/svg">
					<path
						  d="M251.64 354.55c-1.4 0-88 119.9-88.7 119.9S76.34 414 76 413.25s86.6-125.7 86.6-127.4c0-2.2-129.6-44-137.6-47.1-1.3-.5 31.4-101.8 31.7-102.1.6-.7 144.4 47 145.5 47 .4 0 .9-.6 1-1.3.4-2 1-148.6 1.7-149.6.8-1.2 104.5-.7 105.1-.3 1.5 1 3.5 156.1 6.1 156.1 1.4 0 138.7-47 139.3-46.3.8.9 31.9 102.2 31.5 102.6-.9.9-140.2 47.1-140.6 48.8-.3 1.4 82.8 122.1 82.5 122.9s-85.5 63.5-86.3 63.5c-1-.2-89-125.5-90.9-125.5z">
					</path>
				</svg>
				HomeNest Software 
				<svg aria-hidden="true" class="star_icon e-font-icon-svg e-fab-diaspora" viewBox="0 0 512 512"
					 xmlns="http://www.w3.org/2000/svg">
					<path
						  d="M251.64 354.55c-1.4 0-88 119.9-88.7 119.9S76.34 414 76 413.25s86.6-125.7 86.6-127.4c0-2.2-129.6-44-137.6-47.1-1.3-.5 31.4-101.8 31.7-102.1.6-.7 144.4 47 145.5 47 .4 0 .9-.6 1-1.3.4-2 1-148.6 1.7-149.6.8-1.2 104.5-.7 105.1-.3 1.5 1 3.5 156.1 6.1 156.1 1.4 0 138.7-47 139.3-46.3.8.9 31.9 102.2 31.5 102.6-.9.9-140.2 47.1-140.6 48.8-.3 1.4 82.8 122.1 82.5 122.9s-85.5 63.5-86.3 63.5c-1-.2-89-125.5-90.9-125.5z">
					</path>
				</svg>
				Digital Marketing
				<svg aria-hidden="true" class="star_icon e-font-icon-svg e-fab-diaspora" viewBox="0 0 512 512"
					 xmlns="http://www.w3.org/2000/svg">
					<path
						  d="M251.64 354.55c-1.4 0-88 119.9-88.7 119.9S76.34 414 76 413.25s86.6-125.7 86.6-127.4c0-2.2-129.6-44-137.6-47.1-1.3-.5 31.4-101.8 31.7-102.1.6-.7 144.4 47 145.5 47 .4 0 .9-.6 1-1.3.4-2 1-148.6 1.7-149.6.8-1.2 104.5-.7 105.1-.3 1.5 1 3.5 156.1 6.1 156.1 1.4 0 138.7-47 139.3-46.3.8.9 31.9 102.2 31.5 102.6-.9.9-140.2 47.1-140.6 48.8-.3 1.4 82.8 122.1 82.5 122.9s-85.5 63.5-86.3 63.5c-1-.2-89-125.5-90.9-125.5z">
					</path>
				</svg>
				</span>
			</div>
			<div class="section4_layout layout_left"></div>
			<div class="section4_layout layout_right"></div>
		</div>


	</section>

	<section class="section5 background_caro">
		<section class="section5_row1">
			<div class="sub_title section5_row1_sub_title ">
				<svg aria-hidden="true" class="sub_title_icon e-font-icon-svg e-fas-circle" viewBox="0 0 512 512"
					 xmlns="http://www.w3.org/2000/svg">
					<path d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8z"></path>
				</svg>

				<span>Service Overview</span>
			</div>

			<h2 class="section5_row1_main_title">
				Comprehensive
				<span class="main_title_highligt"> Digital Solutions </span> 
				for the New Era
			</h2>
		</section>

		<section class="section5_row2">
			<section class=" section5_row2_col1 ">
				<div class="section5_row2_item ">
					<div class="section5_row2_icon">
						<i class="fas fa-rocket"></i>
					</div>

					<div class="section5_row2_item_row2">
						<h3 class=" section2_row2_title">Digital Marketing</h3>

						<p class="section2_row2_content">Strategic multi-channel planning to engage your ideal audience and drive sustainable business growth.</p>

						<div class="button_gradient section2_row2_btt">
							Learn More
							<svg aria-hidden="true"
								 class="button_gradient_icon e-font-icon-svg e-fas-arrow-circle-right"
								 viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
								<path
									  d="M256 8c137 0 248 111 248 248S393 504 256 504 8 393 8 256 119 8 256 8zm-28.9 143.6l75.5 72.4H120c-13.3 0-24 10.7-24 24v16c0 13.3 10.7 24 24 24h182.6l-75.5 72.4c-9.7 9.3-9.9 24.8-.4 34.3l11 10.9c9.4 9.4 24.6 9.4 33.9 0L404.3 273c9.4-9.4 9.4-24.6 0-33.9L271.6 106.3c-9.4-9.4-24.6-9.4-33.9 0l-11 10.9c-9.5 9.6-9.3 25.1.4 34.4z">
								</path>
							</svg>
						</div>
					</div>
				</div>

				<div class="section5_row2_item ">
					<div class="section5_row2_icon">
						<i class="fas fa-volume-up"></i>
					</div>

					<div class="section5_row2_item_row2">
						<h3 class=" section2_row2_title">Brand Identity</h3>

						<p class="section2_row2_content">Crafting distinct visual identities—from logos to full brand systems—that elevate your market presence.</p>

						<div class="button_gradient section2_row2_btt">
							Learn more
							<svg aria-hidden="true"
								 class="button_gradient_icon e-font-icon-svg e-fas-arrow-circle-right"
								 viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
								<path
									  d="M256 8c137 0 248 111 248 248S393 504 256 504 8 393 8 256 119 8 256 8zm-28.9 143.6l75.5 72.4H120c-13.3 0-24 10.7-24 24v16c0 13.3 10.7 24 24 24h182.6l-75.5 72.4c-9.7 9.3-9.9 24.8-.4 34.3l11 10.9c9.4 9.4 24.6 9.4 33.9 0L404.3 273c9.4-9.4 9.4-24.6 0-33.9L271.6 106.3c-9.4-9.4-24.6-9.4-33.9 0l-11 10.9c-9.5 9.6-9.3 25.1.4 34.4z">
								</path>
							</svg>
						</div>
					</div>
				</div>

				<div class="section5_row2_item ">
					<div class="section5_row2_icon">
						<i class="fas fa-chart-line"></i>
					</div>

					<div class="section5_row2_item_row2">
						<h3 class=" section2_row2_title">Performance Ads</h3>

						<p class="section2_row2_content">Optimized campaigns on Facebook, Google, and TikTok designed to maximize conversion rates and ROI.</p>

						<div class="button_gradient section2_row2_btt">
							Learn more
							<svg aria-hidden="true"
								 class="button_gradient_icon e-font-icon-svg e-fas-arrow-circle-right"
								 viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
								<path
									  d="M256 8c137 0 248 111 248 248S393 504 256 504 8 393 8 256 119 8 256 8zm-28.9 143.6l75.5 72.4H120c-13.3 0-24 10.7-24 24v16c0 13.3 10.7 24 24 24h182.6l-75.5 72.4c-9.7 9.3-9.9 24.8-.4 34.3l11 10.9c9.4 9.4 24.6 9.4 33.9 0L404.3 273c9.4-9.4 9.4-24.6 0-33.9L271.6 106.3c-9.4-9.4-24.6-9.4-33.9 0l-11 10.9c-9.5 9.6-9.3 25.1.4 34.4z">
								</path>
							</svg>
						</div>
					</div>
				</div>
				
				<div class="section5_row2_item ">
					<div class="section5_row2_icon">
						<i class="fas fa-bullseye"></i>
					</div>

					<div class="section5_row2_item_row2">
						<h3 class=" section2_row2_title">Overall SEO</h3>

						<p class="section2_row2_content">Build long-term search authority via White-Hat methodologies, capturing qualified organic growth.</p>

						<div class="button_gradient section2_row2_btt">
							Learn more
							<svg aria-hidden="true"
								 class="button_gradient_icon e-font-icon-svg e-fas-arrow-circle-right"
								 viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
								<path
									  d="M256 8c137 0 248 111 248 248S393 504 256 504 8 393 8 256 119 8 256 8zm-28.9 143.6l75.5 72.4H120c-13.3 0-24 10.7-24 24v16c0 13.3 10.7 24 24 24h182.6l-75.5 72.4c-9.7 9.3-9.9 24.8-.4 34.3l11 10.9c9.4 9.4 24.6 9.4 33.9 0L404.3 273c9.4-9.4 9.4-24.6 0-33.9L271.6 106.3c-9.4-9.4-24.6-9.4-33.9 0l-11 10.9c-9.5 9.6-9.3 25.1.4 34.4z">
								</path>
							</svg>
						</div>
					</div>
				</div>
			</section>

		</section>
	</section>

	<section class="section6 ">
		<section class="section2_row1">
			<section class="section2_row1_col1">
				<div class="sub_title ">
					<svg aria-hidden="true" class="sub_title_icon e-font-icon-svg e-fas-circle" viewBox="0 0 512 512"
						 xmlns="http://www.w3.org/2000/svg">
						<path d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8z"></path>
					</svg>

					<span>Our Achievements</span>
				</div>

				<h2 class="section1_col1_main_title">
					HomeNest: A Journey of
					<span class="main_title_highligt"> Creating Value </span>
				</h2>
			</section>


			<section class="section2_row1_col2">
				Proud to be a trusted partner for thousands of businesses, we are dedicated to delivering optimal Marketing & Technology solutions.

				<a href="#" class="section2_row1_col2_button button_gradient">
					Learn more
					<svg aria-hidden="true" class="button_gradient_icon  e-font-icon-svg e-fas-arrow-circle-right"
						 viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
						<path
							  d="M256 8c137 0 248 111 248 248S393 504 256 504 8 393 8 256 119 8 256 8zm-28.9 143.6l75.5 72.4H120c-13.3 0-24 10.7-24 24v16c0 13.3 10.7 24 24 24h182.6l-75.5 72.4c-9.7 9.3-9.9 24.8-.4 34.3l11 10.9c9.4 9.4 24.6 9.4 33.9 0L404.3 273c9.4-9.4 9.4-24.6 0-33.9L271.6 106.3c-9.4-9.4-24.6-9.4-33.9 0l-11 10.9c-9.5 9.6-9.3 25.1.4 34.4z">
						</path>
					</svg>
				</a>
			</section>
		</section>

		<section class="section6_row2">
			<div class="section6_row2_item">
				<div class="section6_row2_item_icon">
					<i class="fas fa-users"></i>
				</div>

				<div class="section6_row2_item_text">
					<h2 class="section6_row2_item_text_value">
						<span class="section6_row2_item_text_value_HC">10</span>+
					</h2>
					<h4 class="section6_row2_item_text_content">Years of Experience</h4>
				</div>
			</div>

			<div class="section6_row2_item second">
				<div class="section6_row2_item_icon second">
					<i class="fas fa-check"></i>
				</div>

				<div class="section6_row2_item_text">
					<h2 class="section6_row2_item_text_value">
						<span class="section6_row2_item_text_value_integer_PD">2</span><span
																							  class="section6_row2_item_text_value_decimal_PD">000</span>+
					</h2>
					<h4 class="section6_row2_item_text_content">Successful Projects</h4>
				</div>
			</div>

			<div class="section6_row2_item">
				<div class="section6_row2_item_icon">
					<i class="fas fa-star-half-alt"></i>
				</div>

				<div class="section6_row2_item_text">
					<h2 class="section6_row2_item_text_value">
						<span class="section6_row2_item_text_value_integer_CR">50</span><span
																							  class="section6_row2_item_text_value_decimal_CR"></span>+
					</h2>
					<h4 class="section6_row2_item_text_content">Talented Experts</h4>
				</div>
			</div>

			<div class="section6_row2_item">
				<div class="section6_row2_item_icon">
					<i class="fas fa-award"></i>
				</div>

				<div class="section6_row2_item_text">
					<h2 class="section6_row2_item_text_value">
						<span class="section6_row2_item_text_value_YE">99</span>%
					</h2>
					<h4 class="section6_row2_item_text_content">Satisfaction Rate</h4>
				</div>
			</div>

		</section>
	</section>

	<section class="section7">
		<section class="section7_col1 background_gradient">
			<section class="section1_col2_wrap_wrap">
				<section class="section1_col2_wrap box2">
					<div class="section1_col2_wrap_img">
						<div class="section1_col2_img">
							<img class="section1_col2_image1 box2" loading="lazy" decoding="async" src="/wp-content/uploads/2025/08/Image2.jpg" alt="Homenest" title="Homenest">
						</div>
					</div>

					<div class="section1_col2_hidden_box2">
						<h3 class="section1_col2_title">Learn Digital Marketing Workflow</h3>

						<div class="section1_col2_text">
							<div class="section1_col2_text1a">
								<svg aria-hidden="true" class="e-font-icon-svg e-fab-diaspora" viewBox="0 0 512 512"
									 xmlns="http://www.w3.org/2000/svg">
									<path
										  d="M251.64 354.55c-1.4 0-88 119.9-88.7 119.9S76.34 414 76 413.25s86.6-125.7 86.6-127.4c0-2.2-129.6-44-137.6-47.1-1.3-.5 31.4-101.8 31.7-102.1.6-.7 144.4 47 145.5 47 .4 0 .9-.6 1-1.3.4-2 1-148.6 1.7-149.6.8-1.2 104.5-.7 105.1-.3 1.5 1 3.5 156.1 6.1 156.1 1.4 0 138.7-47 139.3-46.3.8.9 31.9 102.2 31.5 102.6-.9.9-140.2 47.1-140.6 48.8-.3 1.4 82.8 122.1 82.5 122.9s-85.5 63.5-86.3 63.5c-1-.2-89-125.5-90.9-125.5z">
									</path>
								</svg>
							</div>

							<div class="section1_col2_text1b">
								We cut out the fluff to focus entirely on maximizing budget efficiency and delivering long-term growth.
							</div>
						</div>
					</div>
				</section>

				<div class="section1_col2_wrap">
					<div class="section1_col2_wrap_img">
						<div class="section1_col2_img">
							<img class="section1_col2_image1" loading="lazy" decoding="async"
								 src="/wp-content/uploads/2025/08/four-female-partners-sitting-at-desk-and-discussin-2024-12-13-13-45-03-utc.jpg" alt="Homenest" title="Homenest">
						</div>
						<img class="section1_col2_image2" loading="lazy" decoding="async"
							 src="/wp-content/uploads/2025/08/surprised-female-model-searches-information-online-2025-01-24-01-56-11-utc-1.png" alt="Homenest" title="Homenest">
					</div>


					<h3 class="section1_col2_title">Learn Digital Marketing Workflow</h3>

					<div class="section1_col2_text">
						<div class="section1_col2_text1a">
							<svg aria-hidden="true" class="e-font-icon-svg e-fab-diaspora" viewBox="0 0 512 512"
								 xmlns="http://www.w3.org/2000/svg">
								<path
									  d="M251.64 354.55c-1.4 0-88 119.9-88.7 119.9S76.34 414 76 413.25s86.6-125.7 86.6-127.4c0-2.2-129.6-44-137.6-47.1-1.3-.5 31.4-101.8 31.7-102.1.6-.7 144.4 47 145.5 47 .4 0 .9-.6 1-1.3.4-2 1-148.6 1.7-149.6.8-1.2 104.5-.7 105.1-.3 1.5 1 3.5 156.1 6.1 156.1 1.4 0 138.7-47 139.3-46.3.8.9 31.9 102.2 31.5 102.6-.9.9-140.2 47.1-140.6 48.8-.3 1.4 82.8 122.1 82.5 122.9s-85.5 63.5-86.3 63.5c-1-.2-89-125.5-90.9-125.5z">
								</path>
							</svg>
						</div>

						<div class="section1_col2_text1b">
							We cut out the fluff to focus entirely on maximizing budget efficiency and delivering long-term growth.
						</div>
					</div>
				</div>
			</section>
		</section>

		<section class="section7_col2 background_caro ">
			<div class="sub_title ">
				<svg aria-hidden="true" class="sub_title_icon e-font-icon-svg e-fas-circle" viewBox="0 0 512 512"
					 xmlns="http://www.w3.org/2000/svg">
					<path d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8z"></path>
				</svg>

				<span>Our Process</span>
			</div>

			<h2 class="section1_col1_main_title">
				HomeNest
				<span class="main_title_highligt"> Service Workflow</span>
			</h2>

			<div class="section7_col2_list_item">
				<div class="section7_col2_item">
					<h3 class="section7_col2_item_number">01.</h3>

					<div class="section7_col2_item_text">
						<h3 class="section7_col2_item_text_title">Consultation & Analysis</h3>

						<p class="section7_col2_item_text_content">We listen to your business goals, audit your brand's current status, and analyze competitors to identify key bottlenecks.</p>
					</div>

					<div class="section7_col2_item_icon"><svg class="section7_up_right_icon" width="800px"
															  height="800px" color="white" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"
															  fill="none" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
															  class="feather feather-arrow-up-right">
						<line x1="7" y1="17" x2="17" y2="7"></line>
						<polyline points="7 7 17 7 17 17"></polyline>
						</svg></div>
				</div>

				<div class="section7_col2_item">
					<h3 class="section7_col2_item_number">02.</h3>

					<div class="section7_col2_item_text">
						<h3 class="section7_col2_item_text_title">Strategic Planning</h3>

						<p class="section7_col2_item_text_content">Developing a master plan, defining committed KPIs, allocating budgets, and selecting the most optimal communication channels.</p>
					</div>

					<div class="section7_col2_item_icon"><svg class="section7_up_right_icon" width="800px"
															  height="800px" color="white" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"
															  fill="none" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
															  class="feather feather-arrow-up-right">
						<line x1="7" y1="17" x2="17" y2="7"></line>
						<polyline points="7 7 17 7 17 17"></polyline>
						</svg></div>
				</div>

				<div class="section7_col2_item">
					<h3 class="section7_col2_item_number">03.</h3>

					<div class="section7_col2_item_text">
						<h3 class="section7_col2_item_text_title">Multi-channel Execution</h3>

						<p class="section7_col2_item_text_content">Producing creative content, optimizing Web/App infrastructure, and operating targeted ad campaigns aligned with your goals.</p>
					</div>

					<div class="section7_col2_item_icon"><svg class="section7_up_right_icon" width="800px"
															  height="800px" color="white" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"
															  fill="none" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
															  class="feather feather-arrow-up-right">
						<line x1="7" y1="17" x2="17" y2="7"></line>
						<polyline points="7 7 17 7 17 17"></polyline>
						</svg></div>
				</div>

				<div class="section7_col2_item">
					<h3 class="section7_col2_item_number">04.</h3>

					<div class="section7_col2_item_text">
						<h3 class="section7_col2_item_text_title">Measurement & Optimization</h3>

						<p class="section7_col2_item_text_content">Tracking real-time metrics and continuously adjusting to maximize cost efficiency, supported by transparent periodic reporting.</p>
					</div>

					<div class="section7_col2_item_icon"><svg class="section7_up_right_icon" width="800px"
															  height="800px" color="white" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"
															  fill="none" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
															  class="feather feather-arrow-up-right">
						<line x1="7" y1="17" x2="17" y2="7"></line>
						<polyline points="7 7 17 7 17 17"></polyline>
						</svg></div>
				</div>

			</div>
		</section>
	</section>

	<section class="section8">
		<section class="section8_row1">
			<div class="sub_title section8_row1_sub_title ">
				<svg aria-hidden="true" class="sub_title_icon e-font-icon-svg e-fas-circle" viewBox="0 0 512 512"
					 xmlns="http://www.w3.org/2000/svg">
					<path d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8z"></path>
				</svg>

				<span>FAQS</span>
			</div>

			<h2 class="section8_row1_main_title">
				Quick question
				<span class="main_title_highligt"> and </span>
				answer corner
			</h2>
		</section>

		<section class="section8_row2">
			<section class="section8_row2_col section8_row2_col1">
				<div class="section8_row2_col_item">
					<div class="section8_row2_col_item_question">
						<div class="section8_row2_col_item_question_icon">+</div>
						<p class="section8_row2_col_item_question_content orbitron_font">How does HomeNest differ from typical advertising agencies?</p>
					</div>

					<p class="section8_row2_col_item_answer">Our core differentiator is our "Tech-Driven Marketing" mindset. Originating as a software and app development firm, we go beyond simply running ads. We possess the technical capability to deeply optimize your entire digital ecosystem (Website speed, App UX, CRM systems) to ensure that once customers arrive, they stay and convert.</p>
				</div>

				<div class="section8_row2_col_item">
					<div class="section8_row2_col_item_question">
						<div class="section8_row2_col_item_question_icon">+</div>
						<p class="section8_row2_col_item_question_content orbitron_font">Is HomeNest a good fit for SMEs or Start-ups?</p>
					</div>

					<p class="section8_row2_col_item_answer">Absolutely. HomeNest designs flexible solution packages tailored to the specific budget and development stage of each business, ranging from the initial Market Entry phase to the Scale-up phase.</p>
				</div>

				<div class="section8_row2_col_item">
					<div class="section8_row2_col_item_question">
						<div class="section8_row2_col_item_question_icon">+</div>
						<p class="section8_row2_col_item_question_content orbitron_font">What is the minimum advertising budget required?</p>
					</div>

					<p class="section8_row2_col_item_answer">HomeNest does not impose a rigid minimum budget. Instead, we analyze your business objectives to propose the most optimal budget allocation. All costs are transparent and strictly focused on maximizing your ROI (Return on Investment).</p>
				</div>
			</section>

			<section class="section8_row2_col section8_row2_col2">
				<div class="section8_row2_col_item">
					<div class="section8_row2_col_item_question">
						<div class="section8_row2_col_item_question_icon">+</div>
						<p class="section8_row2_col_item_question_content orbitron_font">Does HomeNest guarantee specific sales figures?</p>
					</div>

					<p class="section8_row2_col_item_answer">We commit to specific Performance KPIs such as Qualified Leads, Traffic, and Conversion Rates. Furthermore, we work closely with your Sales team to optimize the closing rate from these generated leads.</p>
				</div>

				<div class="section8_row2_col_item">
					<div class="section8_row2_col_item_question">
						<div class="section8_row2_col_item_question_icon">+</div>
						<p class="section8_row2_col_item_question_content orbitron_font">How can I monitor campaign performance?</p>
					</div>

					<p class="section8_row2_col_item_answer">We prioritize transparency. You will receive detailed periodic reports (Weekly/Monthly) with clear metrics. Additionally, HomeNest can set up customized Dashboards to allow you to monitor results in Real-time.</p>
				</div>

				<div class="section8_row2_col_item">
					<div class="section8_row2_col_item_question">
						<div class="section8_row2_col_item_question_icon">+</div>
						<p class="section8_row2_col_item_question_content orbitron_font">Do I need to provide images or content?</p>
					</div>

					<p class="section8_row2_col_item_answer">HomeNest features a professional in-house Content and Design team to handle full-scale production. However, if you already have existing brand assets, we will coordinate to utilize them most effectively.</p>
				</div>
			</section>
		</section>
	</section>

	<section class="section9">
		<section class="section2_row1">
			<section class="section2_row1_col1">
				<div class="sub_title ">
					<svg aria-hidden="true" class="sub_title_icon e-font-icon-svg e-fas-circle" viewBox="0 0 512 512"
						 xmlns="http://www.w3.org/2000/svg">
						<path d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8z"></path>
					</svg>

					<span>Expert Insights</span>
				</div>

				<h2 class="section1_col1_main_title">
					Trends &
					<span class="main_title_highligt"> Success Stories.</span>
					
				</h2>
			</section>


			<section class="section2_row1_col2">
				Stay updated with the latest digital marketing trends, real-world insights, and in-depth analyses designed to optimize your business performance.

				<a href="#" class="section2_row1_col2_button button_gradient">
					Learn More
					<svg aria-hidden="true" class="button_gradient_icon  e-font-icon-svg e-fas-arrow-circle-right"
						 viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
						<path
							  d="M256 8c137 0 248 111 248 248S393 504 256 504 8 393 8 256 119 8 256 8zm-28.9 143.6l75.5 72.4H120c-13.3 0-24 10.7-24 24v16c0 13.3 10.7 24 24 24h182.6l-75.5 72.4c-9.7 9.3-9.9 24.8-.4 34.3l11 10.9c9.4 9.4 24.6 9.4 33.9 0L404.3 273c9.4-9.4 9.4-24.6 0-33.9L271.6 106.3c-9.4-9.4-24.6-9.4-33.9 0l-11 10.9c-9.5 9.6-9.3 25.1.4 34.4z">
						</path>
					</svg>
				</a>
			</section>
		</section>

		<section class="section9_row2">
			<?php
/**
 * Lấy 3 bài post từ danh mục 'wiki-software' và hiển thị theo cấu trúc tùy chỉnh mới.
 */

// ⚠️ CHỈ ĐỊNH SLUG CỦA DANH MỤC
$category_slug = 'wiki-marketing'; 

// 1. Định nghĩa tham số truy vấn
$args = array(
	'post_type'      => 'post',
	'post_status'    => 'publish',
	'posts_per_page' => 4, 
	'orderby'        => 'date',
	'order'          => 'DESC',

	// Điều kiện truy vấn theo Taxonomy
	'tax_query' => array(
		array(
			'taxonomy' => 'category', 
			'field'    => 'slug',   
			'terms'    => $category_slug, 
		),
	),
);

// 2. Tạo đối tượng WP_Query
$the_query = new WP_Query( $args );

// 3. Vòng lặp để hiển thị các bài post
if ( $the_query->have_posts() ) {

	while ( $the_query->have_posts() ) {
		$the_query->the_post();

		// Lấy danh mục đầu tiên của bài viết
		$categories = get_the_category();
		$first_category = !empty($categories) ? $categories[0] : null;
		$category_name = $first_category ? $first_category->name : 'Uncategorized';
		
		// Lấy URL ảnh đại diện
		$featured_image_url = has_post_thumbnail() ? get_the_post_thumbnail_url(get_the_ID(), 'full') : 'https://placehold.co/600x400/CCCCCC/333333?text=No+Image';
		
		// Lấy tiêu đề và URL bài viết
		$post_title = get_the_title();
		$post_url = get_the_permalink();
		$post_date = get_the_date( 'F j, Y' ); // Định dạng: April 25, 2025

		// Lấy nội dung tóm tắt (20 từ)
		// Dùng get_the_excerpt() nếu có, nếu không thì lấy nội dung và cắt ngắn
		$excerpt_raw = get_the_excerpt() ?: get_the_content();
		// Cắt ngắn chuỗi thành 20 từ, thêm dấu "..."
		$excerpt_20_words = wp_trim_words( $excerpt_raw, 20, '...' );


		// --- BẮT ĐẦU CẤU TRÚC ITEM MỚI ---
?>

<div class="section9_row2_item">
	<div class="section9_row2_item_row1">

		<div class="section9_row2_item_img">
			<!-- Danh mục (Category) -->
			<div class="section9_row2_item_img_category"><?php echo esc_html( $category_name ); ?></div>

			<!-- Ảnh đại diện -->
			<img class="section9_row2_item_image" loading="lazy" decoding="async"
				 src="<?php echo esc_url( $featured_image_url ); ?>"
				 alt="<?php echo esc_attr( $post_title ); ?>"
				 title="<?php echo esc_attr( $post_title ); ?>">
		</div>

		<!-- Ngày tháng -->
		<div class="section9_row2_item_calendar">
			<i class="fas fa-calendar section9_row2_item_calendar_icon"></i>
			<?php echo esc_html( $post_date ); ?>
		</div>
	</div>

	<div class="section9_row2_item_row2">
		<!-- Tiêu đề -->
		<h3 class="section9_row2_item_title">
			<a href="<?php echo esc_url( $post_url ); ?>"><?php echo esc_html( $post_title ); ?></a>
		</h3>

		<!-- Nội dung tóm tắt 20 từ -->
		<p class="section9_row2_item_content"><?php echo esc_html( $excerpt_20_words ); ?></p>

		<!-- Nút "Learn more" -->
		<a href="<?php echo esc_url( $post_url ); ?>" class="section9_row2_item_btt button_gradient">
			Xem thêm
		</a>
	</div>
</div>

<?php
		// --- KẾT THÚC CẤU TRÚC ITEM MỚI ---
	}

	// 4. Đặt lại dữ liệu Post toàn cục (RẤT QUAN TRỌNG)
	wp_reset_postdata();

} else {
	// Trường hợp không tìm thấy bài viết
	echo '<p>Không tìm thấy bài viết nào trong danh mục "' . esc_html( $category_slug ) . '".</p>';
}
?>
		</section>
	</section>


</main>

<?php get_footer(); ?>