<?php
/**
 * Template Name: Thiết kế website
 * Template Post Type: service
 */
get_header(); ?>


<body>
	<div class="service-wrapper">
		<div class="homenest__website-design__section1">
			<div class="homenest__website-design__section1-wrapper">
				<div class="homenest__website-design__hero-sup fadeInLeft-Webdesign">
					<img src=" /wp-content/uploads/2025/05/stars.svg" alt>
					<p>Introducing the multipurpose</p>
				</div>
				<h1 class="homenest__website-design__section1__title fadeInUp-Webdesign">
					Dịch vụ<br>
					Thiết kế website
				</h1>
				<p class="homenest__website-design__section1__des fadeInLeft-Webdesign">
					Thiết kế website hiện đại, chuẩn SEO, tối ưu trải nghiệm người dùng
				</p>
				<div class="homenest__website-design__section1__wrap-btn fadeInRight-Webdesign">
					<div class="homenest__website-design__section1__wrap-btn--get">
						<img src=" /wp-content/uploads/2025/05/9e4463d8-978b-434c-a262-32735b1878e7-removebg-preview.webp"
							 alt>
						<a href="#">Liên hệ ngay!</a>
					</div>
					<div class="homenest__website-design__section1__wrap-btn--demos">
						<a href="/project/">Tìm hiểu thêm</a>
					</div>
				</div>

				<div class="homenest__website-design__section1__grid">
					<div class="homenest__website-design__section1__grid-1 fadeInUp-Webdesign">
						<div class="homenest__website-design__section1__grid--img">
							<img src=" /wp-content/uploads/2025/05/gl-1.webp" alt>
						</div>
					</div>
					<div class="homenest__website-design__section1__grid-2 fadeInUp-Webdesign">
						<div class="homenest__website-design__section1__grid--img">
							<img src=" /wp-content/uploads/2025/05/gl-2.webp" alt>
						</div>
					</div>
					<div class="homenest__website-design__section1__grid-3">
						<div class="homenest__website-design__section1__grid--img fadeInUp-Webdesign">
							<img src=" /wp-content/uploads/2025/05/gl-3.webp" alt>
						</div>
					</div>
					<div class="homenest__website-design__section1__grid-4 fadeInUp-Webdesign">
						<div class="homenest__website-design__section1__grid--img">
							<img src=" /wp-content/uploads/2025/05/gl-4.webp" alt>
						</div>
					</div>
					<div class="homenest__website-design__section1__grid-5 fadeInUp-Webdesign">
						<div class="homenest__website-design__section1__grid--img">
							<img src=" /wp-content/uploads/2025/05/gl-5.webp" alt>
						</div>
					</div>
				</div>

				<div class="homenest__website-design__section1__brand">
					<p id="homenest__website-design__section1__hover-text">HomeNest
					</p>
				</div>
			</div>
		</div>

		<div class="homenest__website-design__section2">
			<canvas class="homenest__website-design__section2--canvas"
					id="homenest__website-design__section2--canvas"></canvas>
			<div class="homenest__website-design__section2-wrapper">
				<div class="homenest__website-design__section2__video">
					<video autoplay muted loop playsinline src=" /wp-content/uploads/2025/05/video_sup-1.mp4"></video>
				</div>

				<div class="homenest__website-design__section2__title ">
					<span>Điều làm gì chúng tôi khác biệt?</span>
					<p>Dịch vụ thiết kế hiện đại, tốc độ vượt trội, trải nghiệm tối ưu <br>
						<a class="homenest__website-design__highlight-link">giúp bạn nổi bật
						</a>trên thị trường.
					</p>
				</div>

				<div class="homenest__website-design__section2__grid">
					<div class="homenest__website-design__section2__grid-1">
						<div class="homenest__website-design__section2__wrap-card">
							<div class="homenest__website-design__section2__wrap-card__img">
								<img class="img-overlay" src=" /wp-content/uploads/2025/05/item-1.webp" alt="Thiết kế website chuyên nghiệp homenest">
								<img class="img-background" src=" /wp-content/uploads/2025/05/item-1-2.webp" alt="Thiết kế website chuyên nghiệp homenest 1">
							</div>
							<h6 class="homenest__website-design__section2--title-card">
								<span style="color: #ab003a;">Thiết kế đa dạng</span> <br> sáng tạo
							</h6>
						</div>
					</div>
					<div class="homenest__website-design__section2__grid-2">
						<div class="homenest__website-design__section2__wrap-card-2">
							<div class="homenest__website-design__section2__grid-2__img">
								<img class="img-zoom-in-out-1" src=" /wp-content/uploads/2025/05/item-2.webp" alt="Thiết kế website chuyên nghiệp homenest 2">
								<img class="img-zoom-in-out-2" src=" /wp-content/uploads/2025/05/item-2-2.webp" alt="Thiết kế website chuyên nghiệp homenest 3">
							</div>
							<h6 class="homenest__website-design__section2--title-card">
								Cấu trúc <br> Chuẩn SEO
							</h6>
						</div>
					</div>
					<div class="homenest__website-design__section2__grid-3">
						<div class="wrap-card3">
							<div class="wrap-card3__num-wrap">
								<p class="numb">50</p>
								<img class="rotating-plus" src=" /wp-content/uploads/2025/05/plus.svg" alt="Thiết kế website chuyên nghiệp homenest 4" >
							</div>
							<hr style="border: none; height: 1px;background-color: #e9e9e9; opacity: 0.4;">
							<h6 class="title-card-3" style="color: white;">
								Lĩnh vực</h6>
						</div>
					</div>
					<div class="homenest__website-design__section2__grid-4">
						<div class="website-design__section2__grid-4__video">
							<video autoplay muted loop playsinline src=" /wp-content/uploads/2025/05/robot.mp4"></video>
							<img src=" /wp-content/uploads/2025/05/stars.webp" alt>
						</div>
						<div class="website-design__section2__grid-4__img">
							<img src=" /wp-content/uploads/2025/05/z6627033053412_622e7b0e6d98945f9af9fd6fcc9aa66a.webp"
								 alt="Thiết kế website chuyên nghiệp homenest 5">
							<img src=" /wp-content/uploads/2025/05/z6627032940827_373612a20499774486e7688d63196500.webp"
								 alt="Thiết kế website chuyên nghiệp homenest 6">
							<img src=" /wp-content/uploads/2025/05/z6627032885818_f81e64dcaa8f63831fab1fc2137d8604.webp"
								 alt="Thiết kế website chuyên nghiệp homenest 7">
						</div>
						<div class="website-design__section2__grid-4__title">
							<h6>Thiết kế website hiện đại phù hợp với xu hướng</h6>
						</div>
					</div>
					<div class="homenest__website-design__section2__grid-5">
						<div class="website-design__section2__grid-5__wrap">
							<div class="website-design__section2__grid-5__wrap--content">
								<div class="website-design__section2__grid-5__wrap--content-img">
									<img class="move-right" src=" /wp-content/uploads/2025/05/item-5.webp" alt="Thiết kế website chuyên nghiệp homenest 8">
									<img class="move-left" src=" /wp-content/uploads/2025/05/item-5-2.webp" alt="Thiết kế website chuyên nghiệp homenest 9">
								</div>
								<div class="website-design__section2__grid-5__wrap--content-text">
									<p>Tốc độ tải trang nhanh chóng</p>
								</div>
							</div>
						</div>
					</div>
					<div class="homenest__website-design__section2__grid-6">
						<div class="section2__grid-6__wrap">
							<div class="section2__grid-6__wrap--img">
								<img src=" /wp-content/uploads/2025/05/item-6.svg" alt="Thiết kế website chuyên nghiệp homenest 10">
							</div>

							<div class="section2__grid-6__wrap--text">
								<p>
									Thiết kế website chuyên nghiệp, ấn tượng
								</p>
							</div>
						</div>
					</div>
					<div class="homenest__website-design__section2__grid-7">
						<div class="website-design__section2__grid-7__wrap">
							<div class="website-design__section2__grid-7__wrap--content">
								<div class="website-design__section2__grid-7__wrap--content-img">
									<img src=" /wp-content/uploads/2025/05/item-9-2.webp" alt class="img-top-left">
									<img src=" /wp-content/uploads/2025/05/item-9.webp" alt class="img-middle">
									<img src=" /wp-content/uploads/2025/05/item-9-3.webp" alt class="img-bottom-right">
								</div>
								<div class="website-design__section2__grid-7__wrap--content-text">
									<p>Chính sách bảo hành minh bạch và uy tín</p>
								</div>
							</div>
						</div>

					</div>
					<div class="homenest__website-design__section2__grid-8">
						<div class="section2__grid-8__wrap">
							<div class="section2__grid-8__wrap--img">
								<img src=" /wp-content/uploads/2025/05/item-8.svg" alt="Thiết kế website chuyên nghiệp homenest 11">
								<div class="badge">60+</div>
							</div>
							<div class="section2__grid-8__wrap--text">
								<p>
									Giao diện thân thiện với người dùng
								</p>
							</div>
						</div>

					</div>
					<div class="homenest__website-design__section2__grid-9">
						<div class="section2__grid-9__wrapper">
							<div class="section2__grid-9__wrapper--content">
								<div class="section2__grid-9__wrapper--content-numb">
									<p class="numb">5</p>
									<img class="rotating-plus" src=" /wp-content/uploads/2025/05/item-7-2.webp" alt="Thiết kế website chuyên nghiệp homenest 12">
								</div>

								<div class="section2__grid-9__wrapper--content-text">
									<p>Hỗ trợ <br>
									<p style="opacity: 0.5;">Cập nhật <br>24/7</p>
								</div>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>
	</div>

	<div class="homenest__website-design__section3">
		<div class="homenest__website-design__section3-wrapper">
			<div class="homenest__website-design__section3--text-run__header">
				<div class="text-run"><img src=" /wp-content/uploads/2025/05/speed.webp" alt="Thiết kế website chuyên nghiệp homenest 13">
					<div class="wrap-clock"><img src=" /wp-content/uploads/2025/05/arrow.webp" alt="Thiết kế website chuyên nghiệp homenest 14">
					</div>
				</div>
				<div class="homenest__website-design__section3__title">
					<span>Thiết kế landing chuyên nghiệp</span>
					<p>Giải pháp thiết kế <a class="homenest__website-design__highlight-link">landingpage chuyên nghiệp</a><br> Giúp tôi sưu trang đích, gia tăng chuyển đổi, bứt phá doanh thu.</p>
				</div>

			</div>
			<div class="homenest__website-design__section3--content">
				<img class src=" /wp-content/uploads/2025/05/bg-sc2.webp" alt="">
				<img class="fadeInUp-Webdesign" src=" /wp-content/uploads/2025/05/daaa.webp" alt="Thiết kế website chuyên nghiệp homenest 15">
				<img class="fadeInRight-Webdesign" src=" /wp-content/uploads/2025/05/eqq.webp" alt="Thiết kế website chuyên nghiệp homenest 16">
				<img class="fadeInUp-Webdesign" src=" /wp-content/uploads/2025/05/ajsdjasd.webp" alt="Thiết kế website chuyên nghiệp homenest 17">
				<img class="fadeInLeft-Webdesign" src=" /wp-content/uploads/2025/05/jkas.webp" alt="Thiết kế website chuyên nghiệp homenest 18">
				<img class="fadeInRight-Webdesign" src=" /wp-content/uploads/2025/05/kjjiasd.webp" alt="Thiết kế website chuyên nghiệp homenest 19">
			</div>
			<div class="homenest__website-design__section3--footer">
				<a class="homenest__website-design__section3--footer-btn fadeInUp-Webdesign" href="/contact/">
					Liên hệ ngay!</a>
			</div>
		</div>
	</div>

	<div class="homenest__website-design__section4">
		<div class="homenest__website-design__section4-wrapper">
			<div class="homenest__website-design__section4__title fadeInLeft-Webdesign">
				<h2><span>
					HomeNest - Thiết kế website
					</span></h2>
				<p>
					Dịch vụ thiết kế website chuyên nghiệp, giải pháp hiệu quả cho những điều bạn cần khi kinh doanh online.
				</p>
			</div>
			<div class="homenest__website-design__section4--video-content">
				<div class="homenest__website-design__section4--video-content-video">
					<img src=" /wp-content/uploads/2025/05/jsjjsj.webp" alt="">
					<a id="open-popup-video" data-video-url="https://www.youtube.com/embed/askvjHBrbIQ"
					   href="#"></a>
				</div>
				<img src=" /wp-content/uploads/2025/05/blob1-1.png" alt="">
				<img src=" /wp-content/uploads/2025/05/blob2.webp" alt="">

			</div>
			<!-- Popup Overlay -->
			<div id="popup-overlay" class="homenest__website-design__section4__popup-overlay">
				<div class="popup-content">
					<button class="homenest__website-design__section4__close-popup" id="close-popup" aria-label="Đóng popup thiết kế web"></button>
					<iframe id="video-frame" class="video-frame" src="" frameborder="0"
							allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
							allowfullscreen></iframe>
				</div>
			</div>
			<p class="section4-text">HomeNest - Giải pháp chuyển đổi số hiệu quả.</p>

		</div>

		<div class="homenest__website-design__section5">
			<div class="homenest__website-design__section5-wrapper">
				<div class="homenest__website-design__section5--title">
					<div class="homenest__website-design__section5--title-num">
						<span class="homenest__website-design__section5--title-num-count">
							<span class="digit" data-value="1">
								<span>0</span>
								<span>1</span>
								<span>2</span>
							</span>
							<span class="digit" data-value="5">
								<span>0</span>
								<span>1</span>
								<span>2</span>
								<span>3</span>
								<span>4</span>
								<span>5</span>
							</span>
							<span class="digit" data-value="5">
								<span>0</span>
								<span>1</span>
								<span>2</span>
								<span>3</span>
								<span>4</span>
								<span>5</span>
							</span>
							<span class="digit" data-value="0">
								<span>0+</span>
							</span>
							</div>
						<div class="homenest__website-design__section5--title-img">
							<img src=" /wp-content/uploads/2025/05/demos-badge.webp" alt="Thiết kế website chuyên nghiệp homenest 15">
						</div>
					</div>
					<div class="homenest__website-design__section5--title-text">
						<h2>Case-study thực tiễn<br> Cho mỗi lĩnh vực & ngành nghề
						</h2>
					</div>

				</div>
			</div>

			<section id="project" class="homenest__archive-project__show-project">
				<div class="project-archive">
					<!-- Form lọc -->


					<?php
					// Assuming this is within a WordPress theme or plugin file
					echo do_shortcode('[tim-kiem-du-an-va-chon-nganh]');
					echo do_shortcode('[tat-ca-danh-muc-du-an]');
					echo do_shortcode('[tat-ca-du-an]');
					?>

				</div>
			</section>
			<div class="homenest__website-design__section7">
				<div class="homenest__website-design__section7-wrapper">
					<div class="homenest__website-design__section7--title">
						<div class="homenest__website-design__section5--title-num">
							<span class="homenest__website-design__section5--title-num-count">
								<span class="digit" data-value="2">
									<span>0</span>
									<span>1</span>
									<span>2</span>
								</span>
								<span class="digit" data-value="5">
									<span>0</span>
									<span>1</span>
									<span>2</span>
									<span>3</span>
									<span>4</span>
									<span>5</span>
								</span>
								<span class="digit" data-value="0">
									<span>0+</span>
								</span>
							</span>
						</div>
						<h2>
							Website chuyên biệt cho đa lĩnh vực
						</h2>
					</div>
					<div class="homenest__website-design__section7--category">
						<ul class="homenest__website-design__section7--category-grid">
							<li class="category-item">Bất động sản</li>
							<li class="category-item">Du lịch</li>
							<li class="category-item">Tài chính - Bảo hiểm</li>
							<li class="category-item">Giáo dục - Đào tạo</li>
							<li class="category-item">Y tế</li>
							<li class="category-item">Nhà hàng</li>
							<li class="category-item">Khách sạn</li>
							<li class="category-item">Thương mại điện tử</li>
							<li class="category-item">Nội thất</li>
							<li class="category-item">Logistics</li>
							<li class="category-item">Công nghiệp</li>
							<li class="category-item">Nông nghiệp - Thức phẩm</li>
							<li class="category-item">Spa - Làm đẹp</li>
							<li class="category-item">Dịch vụ vận chuyển</li>
							<li class="category-item">Ô tô - Xe máy</li>
							<li class="category-item">Mỹ phẩm</li>
							<li class="category-item">Dịch vụ sửa chữa</li>
							<li class="category-item">Dịch vụ chăm sóc thú cưng</li>
							<li class="category-item">Dịch vụ tư vấn</li>
						</ul>
					</div>

					<div class="homenest__website-design__section7--content">
						<div class="homenest__website-design__section7--content-left">
							<p class="sup">
								Ngôn ngữ lập trình
							</p>
							<h2 class="section7--content-left__title">
								<span>
									Các ngôn ngữ lập trình phổ biến
								</span>
							</h2>
							<p class="section7--content-left__title-sup">
								Dưới đây là 6 ngôn ngữ thiết kế webiste phổ biến nhất hiện nay
							</p>
							<div class="list-wrap">
								<ul>
									<li>HTML</li>
									<li>CSS</li>
									<li>JavaScript</li>
									<li>NodeJS</li>
								</ul>

								<ul>
									<li>PHP</li>
									<li>Python</li>
									<li>Java</li>
									<li>Framework</li>
								</ul>
							</div>
						</div>
						<div class="homenest__website-design__section7--content-right">
							<div class="section7--content-right__wrap">
								<div class="content">
									<div class="section7--content-right__wrap-header">
										<img src=" /wp-content/uploads/2025/05/part1.webp" alt="">
									</div>
									<div class="section7--content-right__wrap-body">
										<img src=" /wp-content/uploads/2025/05/part2.svg" alt="">
										<img src=" /wp-content/uploads/2025/05/part3.webp" alt="">
									</div>

								</div>
								<img class="fadeInUp-Webdesign" src=" /wp-content/uploads/2025/05/2-1.webp" alt="">
								<img class="fadeInUp-Webdesign" src=" /wp-content/uploads/2025/05/3-1.webp" alt="">
							</div>
						</div>
					</div>

					<div class="homenest__website-design__section7--footer">
						<div class="homenest__website-design__section7--footer-wapper">
							<span href="#" class="open-tooltip">
							</span>
							<div class="homenest__website-design__section7--footer-main-content">
								<h2 class="section7__footer--title">
									Quy trình
									<span>
										thiết kế website tại HomeNest
									</span>
								</h2>

								<div class="content-wrap fadeInUp-Webdesign">
									<div class="content-wrap-item">
										<div class="img-wrap">
											<span class="item-num">1</span>
											<img src=" /wp-content/uploads/2025/05/check-1.svg" alt="">
										</div>
										<div class="item-cont">
											<p class="step">Bước 1</p>
											<h6 class="item-title">Tư vấn</h6>
										</div>
									</div>
									<img src=" /wp-content/uploads/2025/05/step.svg" alt="">
									<div class="content-wrap-item">
										<div class="img-wrap">
											<span class="item-num">2</span>
											<img src=" /wp-content/uploads/2025/05/check-1.svg" alt="">
										</div>
										<div class="item-cont">
											<p class="step">Bước 2</p>
											<h6 class="item-title">Thiết kế và lập trình</h6>
										</div>
									</div>
									<img src=" /wp-content/uploads/2025/05/step.svg" alt="">
									<div class="content-wrap-item">
										<div class="img-wrap">
											<span class="item-num">3</span>
											<img src=" /wp-content/uploads/2025/05/check-1.svg" alt="">
										</div>
										<div class="item-cont">
											<p class="step">Bước 3</p>
											<h6 class="item-title">Bàn giao sản phẩm</h6>
										</div>
									</div>
								</div>
							</div>

							<div class="section7__footer--tooltip">
								<h3 class="tooltip-title">Quy trình dịch vụ <span>chi tiết</span></h3>
								<p>
									Tại HomeNest, quy trình thiết kế website rõ ràng: đầu tiên chúng tôi tiếp nhận yêu cầu từ khách hàng. Tiếp theo, thiết kế giao diện và lập trình các tính năng cần thiết. Sau đó kiểm tra kỹ lưỡng để đảm bảo website hoạt động tốt. Cuối cùng, bàn giao website và hỗ trợ khắc phục sự dụng.
								</p>
								<a href="#" id="open-popup-video" class="btn-play-tooltip">
									Nhấn Để Tìm Hiểu Thêm
								</a>
							</div>
						</div>
					</div>
				</div>

			</div>
		</div>
		<div class="homenest__website-design__section8">
			<div class="homenest__website-design__section8-wrapper">
				<div class="homenest__website-design__section8--logo">
					<img src=" /wp-content/uploads/2025/05/logo-1.webp" alt="">
					<img src=" /wp-content/uploads/2025/05/logo-2.webp" alt="">
				</div>

				<h2 class="homenest__website-design__section8--title">Dịch vụ <span>thiết kế website</span> <br> theo mẫu có sẵn
				</h2>

				<div class="homenest__website-design__section8--content">
					<div class="box fadeInLeft-Webdesign">
						<img src=" /wp-content/uploads/2025/05/icon1.svg" alt="icon">
						<h6>
							Get <br>
							AI-powered <br>
							images instantly
						</h6>
					</div>
					<img class="fadeInUp-Webdesign" src=" /wp-content/uploads/2025/05/1-13.webp" alt="">
					<img class="fadeInLeft-Webdesign" src=" /wp-content/uploads/2025/05/2-2.webp" alt="">
					<img class="fadeInRight-Webdesign" src=" /wp-content/uploads/2025/05/3-2.webp" alt="">
					<img class="fadeInUp-Webdesign" src=" /wp-content/uploads/2025/05/4-1.webp" alt="">
					<div class="box fadeInUp-Webdesign">
						<img src=" /wp-content/uploads/2025/05/icon3.svg" alt="icon">
						<h6>
							Create <br>
							AI-written Texts <br>
							in few click
						</h6>
					</div>
					<img src=" /wp-content/uploads/2025/05/6.webp" alt="">
					<div class="box fadeInRight-Webdesign">
						<img src=" /wp-content/uploads/2025/05/icon2.svg" alt="icon">
						<h6>
							Install <br>
							AI chat-bot <br>
							on your website
						</h6>
					</div>
				</div>
				<div class="homenest__website-design__section8--btn-wrap fadeInUp-Webdesign">
					<a class="homenest__website-design__section8--footer-btn" href="#">Tìm hiểu thêm</a>
				</div>
			</div>
		</div>

		<div class="homenest__website-design__section9">
			<div class="homenest__website-design__section9-wrapper">
				<h2 class="homenest__website-design__section9--title"><span>Các mẫu website mà bạn có thể tham khảo</span></h2>
				<p class="homenest__website-design__section9--title-decs">
					Đa dạng màu sắc nổi bật linh vực khác nhau, đảm bảo ngày, chuẩn SEO, đáp ứng tính năng với chi phí hợp lý.
				</p>
			</div>
		</div>

		<?php
		// Lấy danh sách dự án từ CPT "project"
		$args = array(
			'post_type' => 'project',
			'posts_per_page' => 10
		);

		$query = new WP_Query($args);
		$projects = [];

		if ($query->have_posts()) {
			while ($query->have_posts()) {
				$query->the_post();
				$projects[] = [
					'image' => get_the_post_thumbnail_url(get_the_ID(), 'full'),
					'link'  => get_permalink(get_the_ID()),
				];
			}
			wp_reset_postdata();
		}
		?>

		<section class="homenest__web-services__intigration">

			<div class="intigration__st-marquee">
				<div class="intigration-marquee">
					<div class="intigration-container">
						<?php foreach ($projects as $project): ?>
						<div class="intigration-item">
							<a href="<?php echo esc_url($project['link']); ?>">
								<img src="<?php echo esc_url($project['image']); ?>" alt="Dự án">
							</a>
						</div>
						<?php endforeach; ?>
					</div>
				</div>
			</div>

			<!-- Nếu muốn tạo 2 dòng chạy khác nhau -->
			<div class="intigration__nd-marquee">
				<div class="intigration-marquee">
					<div class="intigration-container">
						<?php foreach ($projects as $project): ?>
						<div class="intigration-item">
							<a href="<?php echo esc_url($project['link']); ?>">
								<img src="<?php echo esc_url($project['image']); ?>" alt="Dự án">
							</a>
						</div>
						<?php endforeach; ?>
					</div>
				</div>
			</div>

		</section>

		<div class="homenest__website-design__section11">
			<div class="homenest__website-design__section11-wrapper">
				<div class="homenest__website-design__section11--header">
					<div class="section11--header-left">
						<p class="sup">
							Tiêu chí
						</p>
						<h2 class="section11--header-left__title">Thiết kế website <span>tại HomeNest</span>
						</h2>
						<div class="experience-descr">
							<p>Luôn đề cao chất lượng trong từng sản phẩm, mỗi website do HomeNest thiết kế trước khi bàn giao đến khách hàng và phải đảm bảo được các tiêu chí sau đây.</p>
						</div>
					</div>
					<div class="section11--header-right">
						<ul class="section11--header-right--list">
							<li class="list-item">
								<img src=" /wp-content/uploads/2025/05/score.webp" alt="image">
								<p class="title">Pingdom Score</p>
							</li>
							<li class="list-item">
								<h6>Elementra</h6>
								<div class="progress">
									<div class="progress-done" style="width: 92%;height: 10px; opacity: 1;">
									</div>
								</div>
							</li>
							<li class="list-item">
								<h6>Other Themes</h6>
								<div class="progress">
									<div class="progress-done" style="width: 36%; opacity: 1;">
									</div>
								</div>
							</li>
						</ul>
					</div>
				</div>

				<div class="homenest__website-design__section11--body fadeInUp-Webdesign">
					<div class="homenest__website-design__section11--body-item1">
						<div class="homenest__website-design__section11--box">
							<span class="box-image">
								<img src=" /wp-content/uploads/2025/05/1-1-1.webp" alt="">
							</span>
							<h4 class="box-title">
								Tương thích tốt
							</h4>
						</div>
					</div>
					<div class="homenest__website-design__section11--body-item2">
						<div class="homenest__website-design__section11--box">
							<span class="box-image">
								<img src=" /wp-content/uploads/2025/05/2-3.webp" alt="">
							</span>
							<h4 class="box-title">
								Giao diện thân thiện
							</h4>
						</div>
					</div>
					<div class="homenest__website-design__section11--body-item3">
						<div class="homenest__website-design__section11--box">
							<span class="box-image">
								<img src=" /wp-content/uploads/2025/05/3-3.webp" alt="">
							</span>
							<h4 class="box-title">
								Bảo mật tốt
							</h4>
						</div>
					</div>
					<div class="homenest__website-design__section11--body-item4">
						<div class="homenest__website-design__section11--box">
							<span class="box-image">
								<img src=" /wp-content/uploads/2025/05/4-2.webp" alt="">
							</span>
							<h4 class="box-title">
								Tốc độ tải nhanh
							</h4>
						</div>
					</div>
				</div>
			</div>
		</div>


		<section class="homenest__professional_website_hn-pricing-section">
			<h2 class="homenest__professional_website_hn-pricing-title"> Bảng giá <span
																						class="homenest__professional_website_heading-highlight">Thiết kế website</span>
				chuyên nghiệp</h2>
			<div class="homenest__professional_website_pricing-section">
				<button class="homenest__professional_website_scroll-btn left" onclick="scrollCards(-1)">
					<svg xmlns="http://www.w3.org/2000/svg" width="31" height="24" viewBox="0 0 31 24" fill="none">
						<path d="M26 12H6" stroke="#0900FF" stroke-width="2" stroke-linecap="round"
							  stroke-linejoin="round"></path>
						<path d="M12.5938 19L5.8125 12L12.5938 5" stroke="#0900FF" stroke-width="2"
							  stroke-linecap="round" stroke-linejoin="round"></path>
					</svg>
				</button>

				<!-- Scrollable Wrapper -->
				<div class="homenest__professional_website_hn-pricing-cards-wrapper">
					<div class="homenest__professional_website_hn-pricing-cards">
					</div>
					<button class="homenest__professional_website_scroll-btn right" onclick="scrollCards(1)">
						<svg xmlns="http://www.w3.org/2000/svg" width="31" height="24" viewBox="0 0 31 24" fill="none">
							<path d="M5 12L25 12" stroke="#0900FF" stroke-width="2" stroke-linecap="round"
								  stroke-linejoin="round"></path>
							<path d="M18.4063 5L25.1875 12L18.4062 19" stroke="#0900FF" stroke-width="2"
								  stroke-linecap="round" stroke-linejoin="round"></path>
						</svg>
					</button>
				</div>
			</div>
		</section>


		<div class="homenest__website-design__section12">
			<div class="homenest__website-design__section12-wrapper">
				<div class="homenest__website-design__section12--icon fadeInUp-Webdesign">
					<img src=" /wp-content/uploads/2025/05/icon.webp" alt="">
				</div>
				<h2 class="homenest__website-design__section12--title">
					<span>Cam kết về dịch vụ</span>
				</h2>

				<div class="installation-gallery">
					<img src=" /wp-content/uploads/2025/05/1-14.webp" alt="">
					<img class="fadeInLeft-Webdesign" src=" /wp-content/uploads/2025/05/2-4.webp" alt="">
					<img class="fadeInRight-Webdesign" src=" /wp-content/uploads/2025/05/3-4.webp" alt="">
					<img class="fadeInUp-Webdesign" src=" /wp-content/uploads/2025/05/4-3.webp" alt="">
					<img src=" /wp-content/uploads/2025/05/5-1.webp" alt="">
					<img src=" /wp-content/uploads/2025/05/6-1.webp" alt="">
				</div>

				<div class="installation-info">

					<div class="info-item">
						<div class="img-wrap">
							<img src=" /wp-content/uploads/2025/05/icon1-1.svg" alt="">
						</div>
						<h3 class="info-title">
							Phù hợp nhu cầu 
						</h3>
						<p class="info-descr">
							Website được thiết kế theo yêu cầu, đảm bảo phản ánh đúng thương hiệu và mục tiêu kinh doanh của khách hàng 
						</p>
					</div>

					<div class="info-item">
						<div class="img-wrap">
							<img src=" /wp-content/uploads/2025/05/icon2-1.svg" alt="">
						</div>
						<h3 class="info-title">
							Đúng tiến độ 
						</h3>
						<p class="info-descr">
							Cam kết hoàn thành đúng thời hạn và chi phí đã thống nhất, không phát sinh phí ngoài.
						</p>
					</div>

					<div class="info-item">
						<div class="img-wrap">
							<img src=" /wp-content/uploads/2025/05/icon3-1.svg" alt="">
						</div>
						<h3 class="info-title">
							Hỗ trợ trọn đời 
						</h3>
						<p class="info-descr">
							Đội ngũ chuyên nghiệp hỗ trợ sửa chữa, bảo trì và nâng cấp website sau khi bàn giao, giúp khách hàng an tâm phát triển.
						</p>
					</div>
				</div>
			</div>
		</div>

		<!-- 	
<div class="homenest__website-design__section13">
<div class="homenest__website-design__section13-wrapper">
<div class="homenest__website-design__section13--header">
<div class="section13--header-left">
<div class="section13--header__img-wrap">
<img src=" /wp-content/uploads/2025/05/1-15.webp" alt="">
<img class="fadeInUp-Webdesign" src=" /wp-content/uploads/2025/05/3-1-1.webp" alt="">
<img class="fadeInRight-Webdesign" src=" /wp-content/uploads/2025/05/4-2-1.webp" alt="">
<img class="fadeInLeft-Webdesign" src=" /wp-content/uploads/2025/05/2-1-1.webp" alt="">
</div>
</div>
<div class="section13--header-right">
<div class="section13--header-right-wrap">
<p class="sup">
Get Your Own Online Store
</p>

<h2 class="section_title">
<span>Sell Like a Pro with WooCommerce</span>
</h2>

<div class="desc-right">
<p>
Build your online store with WooCommerce — the most popular
WordPress plugin that lets you create a digital shop for free!</p>
</div>

<a class="homenest__website-design__section13--footer-btn" href="">
View Demo</a>
</div>

</div>
</div>

<div class="homenest__website-design__section13--variants ">
<div class="variant-banner">
<p class="banner-num">200+ Blocks</p>
<h2 class="banner-title">Premade Inner Pages and Templates</h2>
<p class="banner-descr">Hundreds of ready-made solutions for every website. All you have to do
is
choose.</p>
<img src=" /wp-content/uploads/2025/05/banner-1.webp" alt="banner">
</div>
<div class="variant-banner">
<p class="banner-num">20+ Variations</p>
<h2 class="banner-title">Flexible Header and Footer Layouts</h2>
<p class="banner-descr">Pre-built header and footer combinations. Mix them up and choose what
suits
you best.</p>
<img src=" /wp-content/uploads/2025/05/banner-2.webp" alt="banner">
</div>
<div class="variant-info fadeInUp-Webdesign">
<div class="info-item">
<div class="image-wrap">
<img src=" /wp-content/uploads/2025/05/icon-1.webp" alt="icon">
</div>
<h4 class="info-title">
Drag &amp; Drop Editing
</h4>
<p class="info-descr">
Takes seconds to set up everything
</p>
</div>

<div class="info-item">
<div class="image-wrap">
<img src=" /wp-content/uploads/2025/05/icon-2.webp" alt="icon">
</div>
<h4 class="info-title">
Template Library
</h4>
<p class="info-descr">
360+ ready-made blocks for every use case
</p>
</div>

<div class="info-item">
<div class="image-wrap">
<img src=" /wp-content/uploads/2025/05/icon-3.webp" alt="icon">
</div>
<h4 class="info-title">
Responsive Design
</h4>
<p class="info-descr">
Mobile-friendly homepages that look great on any device
</p>
</div>

<div class="info-item">
<div class="image-wrap">
<img src=" /wp-content/uploads/2025/05/icon-4.webp" alt="icon">
</div>
<h4 class="info-title">
AI Building Assistant
</h4>
<p class="info-descr">
AI tools to simplify and speed up your design process
</p>
</div>
</div>
</div>
</div>
</div>
-->


		<div class="homenest__website-design__section14">
			<div class="marquee-wrapper">
				<div class="marquee-box-one">
					<div class="marquee-content-one">
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/1-16.webp" alt="icon">
							<p>Cookie Notice</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/2-5.webp" alt="icon">
							<p>GDPR Compliance</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/3-5.webp" alt="icon">
							<p>Figma Source Files</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/4-4.webp" alt="icon">
							<p>Detailed Docs</p>
						</div>

						<!-- content-dublicate -->
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/5-2.webp" alt="icon">
							<p>Multilingual Support</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/6-2.webp" alt="icon">
							<p>Fast & Lightweight</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/7.webp" alt="icon">
							<p>Fully Responsive</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/8.webp" alt="icon">
							<p>One-Click Updates</p>
						</div>

					</div>
					<div class="marquee-content-one">
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/1-16.webp" alt="icon">
							<p>Cookie Notice</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/2-5.webp" alt="icon">
							<p>GDPR Compliance</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/3-5.webp" alt="icon">
							<p>Figma Source Files</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/4-4.webp" alt="icon">
							<p>Detailed Docs</p>
						</div>

						<!-- content-dublicate -->
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/5-2.webp" alt="icon">
							<p>Multilingual Support</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/6-2.webp" alt="icon">
							<p>Fast & Lightweight</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/7.webp" alt="icon">
							<p>Fully Responsive</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/8.webp" alt="icon">
							<p>One-Click Updates</p>
						</div>

					</div> <!-- marquee-content -->
				</div> <!-- marquee-box-one -->

				<div class="marquee-box-two">
					<div class="marquee-content-two">
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/5-2.webp" alt="icon">
							<p>Lifetime Updates</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/5-2.webp" alt="icon">
							<p>Excellent Support</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/5-2.webp" alt="icon">
							<p>Flexible Theme Options</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/r4.webp" alt="icon">
							<p>AI Fully-Equipped</p>
						</div>

						<!-- content-dublicate -->
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/r5.webp" alt="icon">
							<p>Newsletter Integration & Popups</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/5-2.webp" alt="icon">
							<p>Subscription Forms & Dialogs</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/r6.webp" alt="icon">
							<p>Template Library</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/r8.webp" alt="icon">
							<p>Translation Ready</p>
						</div>

					</div>
					<div class="marquee-content-two">
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/r1.webp" alt="icon">
							<p>Lifetime Updates</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/r2.webp" alt="icon">
							<p>Excellent Support</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/r3.webp" alt="icon">
							<p>Flexible Theme Options</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/r4.webp" alt="icon">
							<p>AI Fully-Equipped</p>
						</div>

						<!-- content-dublicate -->
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/r5.webp" alt="icon">
							<p>Newsletter Integration & Popups</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/r6.webp" alt="icon">
							<p>Subscription Forms & Dialogs</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/r7.webp" alt="icon">
							<p>Template Library</p>
						</div>
						<div class="homenest__web-design__marquee-text">
							<img src=" /wp-content/uploads/2025/05/r8.webp" alt="icon">
							<p>Translation Ready</p>
						</div>

					</div> <!-- marquee-content -->
				</div> <!-- marquee-box-two -->
			</div> <!-- marquee -->
		</div>

		<div class="homenest__website-design__section15">
			<div class="homenest__website-design__section15-wrapper">
				<div class="homenest__website-design__section15--head">
					<div class="item fadeInUp-Webdesign">
						<div class="content-wrap">
							<p class="sup">Tại sao chọn chúng tôi</p>

							<h2 class="section_title">
								<span>
									HomeNest
									<br>
									Thiết kế website chuyên nghiệp
								</span>
							</h2>
							<p class="desc">
								Trong thời đại công nghệ, website là lợi thế cạnh tranh không thể thiếu của mọi doanh nghiệp. HomeNest tự hào là đơn vị thiết kế website chuyên nghiệp, cam kết mang đến cho bạn sản phẩm chất lượng, hỗ trợ tận tâm và giải pháp phát triển bền vững.
							</p>

							<div class="homenest__website-design__section15--btn-wrap">
								<a class="homenest__website-design__section15--btn" href="#">Khám phá ngay!</a>
							</div>

						</div>
					</div>
					<div class="item ">
						<div class="img-wrap">
							<img src=" /wp-content/uploads/2025/05/1-17.webp" alt="1">
							<img src=" /wp-content/uploads/2025/05/2-6.webp" alt="2">
							<img class="fadeInLeft-Webdesign" src=" /wp-content/uploads/2025/05/3-6.webp" alt="3" </div>
						</div>
					</div>
				</div>
			</div>

			<div class="homenest__website-design__section15--content">
				<div class="homenest__website-design__section15--content-left">
					<div class="item-1">
						<ul class="list">
							<li class="list-item">HTML</li>
							<li class="list-item">CSS</li>
							<li class="list-item">JavaScript</li>
							<li class="list-item">PHP</li>
							<li class="list-item">Python</li>
						</ul>
					</div>
					<div class="item-2">
						<div>
							<h4 class="item-title">Mobile Friendly</h4>
							<p class="item-descr">Đảm bảo thân thiện, giúp tăng trải nghiệm người dùng</p>
						</div>
						<img src=" /wp-content/uploads/2025/05/item2.webp" alt="image">
					</div>
					<div class="item-3">
						<h4 class="item-title">Website đẹp mắt</h4>
						<p class="item-descr">Thu hút khách hàng tiềm năng chỉ sau lần đầu truy cập</p>
						<img src=" /wp-content/uploads/2025/05/item3.webp" alt="image">
					</div>
					<div class="item-4">
						<h3 class="item-title">
							Hỗ trợ nhiệt tình 24/7
							<br>
							<span>
								Không lo gặp lỗi.
							</span>
						</h3>
						<p class="item-descr">Chính sách bảo hành rõ ràng và minh bạch, khắc phục nhanh chóng, không lo mất khách. </p>
					</div>
				</div>
				<div class="homenest__website-design__section15--content-right">
					<div class="item-wrap">
						<p class="sup">
							Liên hệ ngay
						</p>
						<h2 class="section_title">
							<span>
								Liên hệ thiết kế webiste ngay hôm nay
							</span>
						</h2>
					</div>

					<div class="item-wrap">
						<ul class="list fadeInUp-Webdesign">
							<li class="list-item">
								<h3 class="item-title">
									Website chuẩn SEO
								</h3>
								<p class="item-descr">Tối ưu dễ dàng, nhanh chóng leo hạng!</p>
							</li>
							<li class="list-item">
								<h3 class="item-title">
									Thiết kế độc đáo
								</h3>
								<p class="item-descr">Thiết kế độc bản, mang đậm dấu ấn thương hiệu</p>
							</li>
							<li class="list-item">
								<h3 class="item-title">
									Chính sách minh bạch
								</h3>
								<p class="item-descr">Đảm bảo chính sách minh bạch, giá cả hợp lý, bảo hành rõ ràng</p>
							</li>
						</ul>
						<div class="homenest__website-design__section15--btn-wrap-footer fadeInLeft-Webdesign">
							<a class="homenest__website-design__section15--footer-btn" href="#">Liên hệ ngay!</a>
						</div>
					</div>
				</div>
			</div>



			<div class="homenest__web-design__popular-question">
				<div class="container__about-us">
					<div class="header">
						<div class="popular-questions">
							<p style="color: #111 !important; font-weight: 500;">FAQ</p>
						</div>
						<h2 class="homenest__website-design__section12--title">
							<span>Những câu hỏi phổ biến</span>
						</h2>
					</div>

					<div class="divider"></div>

					<div class="faq-item">
						<div class="question-header">
							<div class="question-number">01</div>
							<div class="question-label">Câu hỏi 1</div>
						</div>
						<div class="question">
							<p>Thiết kế website tại HomeNest mang lại lợi ích gì cho doanh nghiệp của tôi?</p>
							<div class="button-container">
								<button class="toggle-button minus" aria-label="Thu gọn nội dung">−</button>
							</div>
						</div>
						<div class="answer">
							HomeNest giúp doanh nghiệp xây dựng sự hiện diện trực tuyến chuyên nghiệp, tiếp cận khách hàng mới, tăng doanh thu và nâng cao uy tín thương hiệu.
						</div>
					</div>

					<div class="divider"></div>

					<div class="faq-item">
						<div class="question-header">
							<div class="question-number">02</div>
							<div class="question-label">Câu hỏi 2</div>
						</div>
						<div class="question">
							<p>Chi phí thiết kế website tại HomeNest là bao nhiêu và có phát sinh thêm chi phí nào không?</p>
							<div class="button-container">
								<button class="toggle-button" aria-label="Hiển thị câu trả lời">+</button>
							</div>
						</div>
						<div class="answer hidden">
							HomeNest cung cấp nhiều gói dịch vụ phù hợp với mọi ngân sách, cam kết minh bạch chi phí và không phát sinh phí ẩn
						</div>
					</div>

					<div class="divider"></div>

					<div class="faq-item">
						<div class="question-header">
							<div class="question-number">03</div>
							<div class="question-label">Câu hỏi 3</div>
						</div>
						<div class="question">
							<p>Thời gian hoàn thành website tại HomeNest là bao lâu?</p>
							<div class="button-container">
								<button class="toggle-button" aria-label="Hiển thị câu trả lời">+</button>
							</div>
						</div>
						<div class="answer hidden">
							Thời gian hoàn thành phụ thuộc vào yêu cầu cụ thể của từng dự án, HomeNest luôn cam kết đúng tiến độ và bàn giao đúng hẹn.
						</div>
					</div>

					<div class="divider"></div>

					<div class="faq-item">
						<div class="question-header">
							<div class="question-number">04</div>
							<div class="question-label">Câu hỏi 4</div>
						</div>
						<div class="question">
							<p>Tôi có thể tự cập nhật nội dung trên website do HomeNest thiết kế không?</p>
							<div class="button-container">
								<button class="toggle-button" aria-label="Hiển thị câu trả lời">+</button>
							</div>
						</div>
						<div class="answer hidden">
							Đúng vậy, HomeNest thiết kế hệ thống quản trị dễ sử dụng, giúp khách hàng dễ dàng cập nhật nội dung, sản phẩm và bài viết.
						</div>
					</div>

					<div class="divider"></div>

					<div class="faq-item">
						<div class="question-header">
							<div class="question-number">05</div>
							<div class="question-label">Câu hỏi 5</div>
						</div>
						<div class="question">
							<p>HomeNest hỗ trợ, bảo hành và nâng cấp website như thế nào?</p>
							<div class="button-container">
								<button class="toggle-button" aria-label="Hiển thị câu trả lời">+</button>
							</div>
						</div>
						<div class="answer hidden">
							HomeNest hỗ trợ kỹ thuật 24/7, bảo hành lâu dài và sẵn sàng nâng cấp, mở rộng tính năng theo nhu cầu phát triển của doanh nghiệp.
						</div>
					</div>

					<div class="divider"></div>
				</div>
			</div>
		</div>
	</div>
		<script src="https://cdn.jsdelivr.net/npm/curtainsjs@8.0.2/dist/curtains.min.js"></script>
<!-- 		<script src="./main.js"></script> -->
<script>
        // ==============================
        // Dữ liệu bảng giá thiết kế website (Internal)
        // ==============================
        const pricingPlans = [
            {
                tag: "Basic",
				title: "Gói Basic ",
                color: "#2db5b1",
                description: "tại HomeNest mang đến website chuyên nghiệp với thiết kế đơn giản.",
                features: [
                    "Giao diện đa dạng có sẵn",
                    "Đầy đủ chức năng cơ bản",
                    "Thiết kế chuẩn SEO",
                    "Công cụ hỗ trợ SEO Google",
                    "Hướng dẫn quản trị website",
                    "Hỗ trợ live chat, fanpage, Google map...",
                    "Miễn phí bảo mật SSL năm đầu",
                ],
                hiddenFeatures: [
                    "Bàn giao mã nguồn (Source code) và tên miền hosting sau khi hoàn thiện",
                    "Thời gian hoàn thiện trong 5 ngày làm việc",
                ],
                price: "8.000.000",
                typeClass: "basic",
            },
            {
                tag: "Golden",
				title: "Gói Golden ",
                color: "#fd7401",
                description: "tại HomeNest mang đến website cao cấp với thiết kế tinh xảo.",
                features: [
                    "Giao diện theo mẫu hoặc theo yêu cầu",
                    "Chức năng nâng cao",
                    "Website song ngữ",
                    "Thiết kế chuẩn SEO",
                    "Công cụ hỗ trợ SEO Google",
                    "Thiết kế Figma: 1",
                    "Giao diện chuẩn UI/UX",
                ],
                hiddenFeatures: [
                    "Hướng dẫn quản trị website",
                    "Bàn giao mã nguồn (Source code) và tên miền hosting sau khi hoàn thiện",
                    "Hỗ trợ live chat, fanpage, Google map...",
                    "Miễn phí bảo mật SSL năm đầu",
                    "Miễn phí tên miền .com hoặc .net năm đầu tiên",
                    "Thời gian hoàn thiện trong 15 - 20 ngày",
                ],
                price: "16.000.000",
                typeClass: "golden",
            },
            {
                tag: "Diamond",
				title: "Gói Diamond ",
                color: "#020c6a",
                description: "tại HomeNest cung cấp website đỉnh cao với thiết kế hoàn hảo.",
                features: [
                    "Giao diện độc quyền theo thương hiệu",
                    "Chức năng theo nhu cầu",
                    "Website đa ngôn ngữ",
                    "Thiết kế chuẩn SEO",
                    "Công cụ hỗ trợ SEO Google",
                    "Thiết kế Figma: 2",
                    "Giao diện chuẩn UI/UX",
                ],
                hiddenFeatures: [
                    "Tối ưu SEO",
                    "Hướng dẫn viết bài chuẩn SEO",
                    "Content chuẩn SEO: 5 bài",
                    "Hướng dẫn đi internal link và external link",
                    "Hướng dẫn quản trị website",
                    "Bàn giao mã nguồn (Source code) và tên miền hosting sau khi hoàn thiện",
                    "Miễn phí gói hosting năm đầu",
                    "Nút Live chat, Call now Fanpage, Google map tương tác trực tiếp",
                    "Miễn phí bảo mật SSL năm đầu",
                    "Miễn phí tên miền .com hoặc .net năm đầu tiên",
                ],
                price: "40.000.000",
                typeClass: "diamond",
            },
            {
                tag: "Platinum",
				title: "Gói Platinum ",
                color: "#972295",
                description: "tại HomeNest mang đến website tối ưu với thiết kế sang trọng.",
                features: [
                    "Giao diện độc quyền theo thương hiệu",
                    "Chức năng theo nhu cầu",
                    "Website đa ngôn ngữ",
                    "Thiết kế chuẩn SEO",
                    "Công cụ hỗ trợ SEO Google",
                    "Thiết kế Figma: 3",
                    "Giao diện chuẩn UI/UX",
                ],
                hiddenFeatures: [
                    "Tối ưu SEO",
                    "Hướng dẫn viết bài chuẩn SEO",
                    "Content chuẩn SEO: 10 bài",
                    "Hướng dẫn đi internal link và external link",
                    "Hướng dẫn quản trị website",
                    "Bàn giao mã nguồn (Source code) và tên miền hosting sau khi hoàn thiện",
                    "Miễn phí gói hosting năm đầu",
                    "Nút Live chat, Call now Fanpage, Google map tương tác trực tiếp",
                    "Miễn phí bảo mật SSL năm đầu",
                    "Miễn phí tên miền .com hoặc .net năm đầu tiên",
                    "Xử lý dữ liệu lớn",
                    "Hướng dẫn quảng cáo Facebook Ads hoặc Google Ads",
                    "Website thương mại điện tử và hệ thống",
                ],
                price: "Linh hoạt",
                typeClass: "platinum",
            },
        ];
	const textViewMore = 'Xem thêm';
	const textCollapse = 'Thu hồi';
	const textConsult = 'Tư vấn ngay';
	const textQuote = '*Liên hệ ngay để được tư vấn miễn phí';
    </script>
		</body>
	<?php get_footer(); ?>