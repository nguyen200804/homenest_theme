<?php
/**
 * Template Name: Chăm sóc website
 * Template Post Type: service
 */
get_header();
?>

<body>
	<div class="homenest_design_template">
		<section class="sc1">
			<img class="background_banner" style="top: 50%; left:50%; z-index: -1; transform: translate(-50%, -50%);"
src="/wp-content/uploads/2025/07/shape-1.webp" alt="homenest.tech">
			<img class="ma0101 right" src="/wp-content/uploads/2025/07/shape-2.webp" alt="0101 right">
			<img class="ma0101 left" src="/wp-content/uploads/2025/07/shape-3.webp" alt="0101 left">
			<img class="shape shape1" src="/wp-content/uploads/2025/07/shape-4.webp" alt="homenest">
			<img class="shape shape2" src="/wp-content/uploads/2025/07/shape-5.webp" alt="homenest">
			<img class="shape shape3" src="/wp-content/uploads/2025/07/shape-6.webp" alt="homenest">
			<img class="shape shape4" src="/wp-content/uploads/2025/07/shape-7.webp" alt="homenest">
			<img class="shape shape5" src="/wp-content/uploads/2025/07/shape-8.webp" alt="homenest">
			<div class="container_banner">
				<p class="text-gradient fade-element fade-up">
					HomeNest - Dịch vụ chăm sóc website
				</p>
				<h1 class="text-gradient fade-element fade-up">
					Giải pháp chăm sóc website toàn diện cho doanh nghiệp
				</h1>
				<div class="group_button">
					<div class="btn button1 fade-element fade-up delay-2">
						<a href="#" class="text-gradient" style="display: inline-flex;
align-items:center;">Về chúng tôi <i class="homenest-icon-arrow-right"></i></a>
					</div>
					<div class="btn button2 fade-element fade-up delay-1">
						<a href="#" style="display: inline-flex;
align-items:center;">Khám phá gói dịch vụ <i class="homenest-icon-google_fullCOLOR"></i></a>
					</div>
				</div>
			</div>
		</section>
		<section class="sc2">
			<img src="/wp-content/uploads/2025/07/shape-9.webp" style="position: absolute; top: 0;
right: 0;" alt="Homenest" title="Homenest">
			<div class="container">
				<div class="title_content">
					<div class="title">
						<p class="fade-element fade-up delay-0">
							Lợi ích từ dịch vụ
						</p>
						<h2 class="fade-element fade-up delay-1">
							Tại sao bạn nên dùng dịch vụ chăm sóc website chuyên nghiệp
						</h2>
					</div>
					<p class="content fade-element fade-up delay-0">
						Dịch vụ chăm sóc website giúp doanh nghiệp duy trì hiệu suất ổn định bằng cách kiểm tra lỗi, cập nhật nội dung, tối ưu tốc độ và bảo mật. Website hoạt động mượt mà tạo ấn tượng tốt, giữ chân khách hàng và thu hút khách mới hiệu quả
					</p>
				</div>
				<div class="group_card">
					<div class="card fade-element fade-up delay-0">
						<div class="main_card">
							<div class="icon">
								<img src="/wp-content/uploads/2025/07/office.svg" alt="Homenest" title="Homenest">
							</div>
							<h3>
								<a href="#">Đảm bảo hoạt động ổn định và tối ưu 
hiệu suất</a>
							</h3>
							<a href="#"><i class="homenest-icon-arrow-right"></i></a>
						</div>
					</div>
					<div class="card fade-element fade-up delay-1">
						<div class="main_card">
							<div class="icon">
								<img src="/wp-content/uploads/2025/07/magnet1.svg" alt="Homenest" title="Homenest">
							</div>
							<h3>
								<a href="#">Nâng cao bảo mật và cải thiện hiệu suất tải trang</a>
							</h3>
							<a href="#"><i class="homenest-icon-arrow-right"></i></a>
						</div>
					</div>
					<div class="card fade-element fade-up delay-2">
						<div class="main_card">
							<div class="icon">
								<img src="/wp-content/uploads/2025/07/coffe-mug.svg" alt="Homenest" title="Homenest">
							</div>
							<h3>
								<a href="#">Tiết kiệm chi phí và thời gian quản lý</a>
							</h3>
							<a href="#"><i class="homenest-icon-arrow-right"></i></a>
						</div>
					</div>
					<div class="card fade-element fade-up delay-3">
						<div class="main_card">
							<div class="icon">
								<img src="/wp-content/uploads/2025/07/concept.svg" alt="Homenest" title="Homenest">
							</div>
							<h3>
								<a href="#">Nâng cao uy tín thương hiệu</a>
							</h3>
							<a href="#"><i class="homenest-icon-arrow-right"></i></a>
						</div>
					</div>
				</div>
			</div>
		</section>
		<section class="sc3">
			<div class="group_img">
				<img class="main_img fade-element fade-left delay-0" src="/wp-content/uploads/2025/07/about-img.webp" alt="Homenest" title="Homenest">
				<img class="img_absolute fade-element fade-left delay-1" src="/wp-content/uploads/2025/07/shape-4.webp" alt="Homenest" title="Homenest">
			</div>
			<div class="group_content fade-element fade-up">
				<div class="main_content">
					<p class="title_p text-gradient">
						Về dịch vụ của chúng tôi
					</p>
					<h2 class="text-gradient">
						HomeNest - Dịch vụ chăm sóc website chuyên nghiệp
					</h2>
					<p>
						Trong thời 
đại số hóa bùng nổ như hiện nay, website không chỉ là "cánh cửa" kết nối doanh nghiệp với khách hàng mà còn là "bộ mặt" giúp thương hiệu của bạn tỏa sáng.
Tại Homenest, chúng tôi tin rằng một website hoạt động mượt mà, an toàn tuyệt đối và được tối ưu thông minh chính là nền tảng vững chắc để doanh nghiệp bạn phát triển bền lâu và ghi dấu ấn sâu đậm trên thị trường
					</p>
					<div class="group_card">
						<div class="card">
							<i class="homenest-icon-tick"></i>Nâng cao hiệu suất ổn định
						</div>
						<div class="card">
							<i class="homenest-icon-tick"></i>Tăng tốc độ tải trang nhanh chóng
						</div>
						<div class="card">
							<i class="homenest-icon-tick"></i>Chăm sóc website 24/7
						</div>
						<div class="card">
							<i class="homenest-icon-tick"></i>Tăng cường bảo mật website
						</div>
					</div>
					<div class="button">
						<a href="#">Xem chi tiết</a>
					</div>
				</div>
			</div>
		</section>
		<section class="container sc4">
			<div class="title">
				<p class="text-gradient">
					Điều Gì Làm HomeNest Khác Biệt?
</p>
				<h2 class="text-gradient">
					HomeNest - Đối tác đáng tin cậy cho webiste của bạn
				</h2>
			</div>
			<div class="group_card">
				<div class="card fade-element fade-up delay-0">
					<div class="main_card">
						<div class="icon">
							<img src="/wp-content/uploads/2025/07/ai.svg"  alt="Homenest" title="Homenest">
						</div>
						<h3>
							<a class="text-gradient" href="#">Đội ngũ giàu kinh nghiệm</a>
						</h3>
						<p>
							HomeNest sở hữu đội ngũ Kỹ sư website nhiều năm kinh nghiệm, am hiểu công nghệ web hiện đại và được đào tạo cập nhật liên tục
						</p>
						<a href="#"><i class="homenest-icon-arrow-right"></i></a>
					</div>
				</div>
				<div class="card fade-element fade-up delay-1">
					<div class="main_card">
						<div class="icon">
							<img src="/wp-content/uploads/2025/07/product.svg"  alt="Homenest" title="Homenest">
						</div>
						<h3>
							<a class="text-gradient" href="#">Cập nhật liên tục</a>
						</h3>
						<p>
							Liên tục làm mới nội dung chuẩn SEO, hình ảnh và thông tin sản phẩm, giúp website luôn hấp dẫn, tăng trải nghiệm người dùng và duy trì thứ 
hạng trên công cụ tìm kiếm.
						</p>
						<a href="#"><i class="homenest-icon-arrow-right"></i></a>
					</div>
				</div>
				<div class="card fade-element fade-up delay-2">
					<div class="main_card">
						<div class="icon">
							<img src="/wp-content/uploads/2025/07/suggest.svg" alt="Homenest" title="Homenest">
						</div>
						<h3>
							<a class="text-gradient" href="#">Chăm sóc website 24/7</a>
						</h3>
						<p>
							Đội ngũ HomeNest luôn sẵn sàng 24/7, phản hồi nhanh chóng và xử lý sự cố kịp thời để website của bạn luôn hoạt động ổn định.
						</p>
						<a href="#"><i class="homenest-icon-arrow-right"></i></a>
					</div>
				</div>
				<div class="card fade-element fade-up delay-0">
					<div class="main_card">
						<div class="icon">
							<img src="/wp-content/uploads/2025/07/social.svg" alt="Homenest" title="Homenest">
						</div>
						<h3>
							<a class="text-gradient" href="#">Báo cáo minh bạch</a>
						</h3>
						<p>
							Báo cáo định kỳ chi tiết về tình trạng website, hoạt động bảo trì và chỉ số hiệu suất, khách hàng luôn nắm rõ giá trị nhận được.
						</p>
						<a href="#"><i class="homenest-icon-arrow-right"></i></a>
					</div>
				</div>
				<div class="card fade-element fade-up delay-1">
					<div class="main_card">
						<div class="icon">
							<img src="/wp-content/uploads/2025/07/blog.svg" alt="Homenest" title="Homenest">
						</div>
						<h3>
							<a class="text-gradient" href="#">Chi phí hợp lý</a>
						</h3>
						<p>
							HomeNest có đa dạng gói dịch vụ cho mọi quy mô doanh nghiệp, chi phí minh bạch không phát sinh và ROI cao.
						</p>
						<a href="#"><i class="homenest-icon-arrow-right"></i></a>
					</div>
				</div>
				<div class="card fade-element fade-up delay-2">
					<div class="main_card">
						<div class="icon">
							<img src="/wp-content/uploads/2025/07/landing.svg" alt="Homenest" title="Homenest">
						</div>
						<h3>
							<a class="text-gradient" href="#">Cam kết chất lượng</a>
						</h3>
						<p>
							Cam kết chính sách rõ ràng, bảo hành toàn diện và hoàn tiền 100% trong 30 ngày đầu nếu không hài lòng.
						</p>
						<a href="#"><i class="homenest-icon-arrow-right"></i></a>
					</div>
				</div>
			</div>
		</section>
		<section class="container sc5">
			<div class="group_content fade-element fade-up delay-0">
				<div class="main_content">
					<p class="title_p text-gradient">
						Dịch vụ chăm sóc website chuyên nghiệp
					</p>
					<h2 class="text-gradient">
						Nâng tầm website, mở rộng thương hiệu
					</h2>
					<p>
						Nâng tầm vị thế website của bạn trên Google với dịch vụ tối ưu hóa toàn diện, chúng tôi kiến tạo giải pháp tổng thể, từ tinh chỉnh mã nguồn đến chiến lược nội dung chuyên sâu, nhằm thu hút đúng khách hàng mục tiêu và tối đa hóa lợi nhuận bền vững.
					</p>
					<div class="icon_text">
						<div class="icon">
							<i class="homenest-icon-robot"></i>
						</div> 
						<p>
							1000+ dự án.
						</p>
					</div>
					<div class="icon_text">
						<div class="icon">
							<i class="homenest-icon-robot"></i>
						</div> 
						<p>
							99% hài lòng từ khách hàng.
						</p>
					</div>
				</div>
			</div>
			<div class="group_img">
				<img class="main_img fade-element fade-right delay-0" src="/wp-content/uploads/2025/07/generate-img.webp" alt="Homenest" title="Homenest">
				<img class="img_absolute fade-element fade-right delay-1" src="/wp-content/uploads/2025/07/shape-6.webp" alt="Homenest" title="Homenest">
			</div>
		</section>
		<section class="sc6">
			<div class="container">
				<div class="title">
					<p>
						Cam kết của chúng tôi
					</p>
					<h2>
						Cam kết về dịch vụ chăm sóc website chuyên nghiệp tại HomeNest
					</h2>
				</div>
				<div class="group_card">
					<div class="card fade-element fade-up delay-0">
						<div class="main_card">
							<div class="number">
								<span>1</span>
							</div>
							<h3>
								<a href="#">Vận hành ổn định 24/7</a>
							</h3>
							<p>
								HomeNest cam kết đảm bảo website của bạn luôn hoạt động mượt mà, ổn định trên mọi thiết bị, với đội ngũ kỹ thuật viên sẵn sàng hỗ trợ và xử lý sự cố nhanh chóng 24/7.
							</p>
						</div>
					</div>
					<div class="card fade-element fade-up delay-1">
						<div class="main_card">
							<div class="number">
								<span>2</span>
							</div>
							<h3>
								<a href="#">Bảo mật tối ưu</a>
							</h3>
							<p>
								Chúng tôi tăng cường các giải pháp bảo mật, đồng thời thực hiện sao lưu dữ liệu định kỳ nhằm bảo vệ website khỏi các rủi ro tấn công mạng.
							</p>
						</div>
					</div>
					<div class="card fade-element fade-up delay-2">
						<div class="main_card">
							<div class="number">
								<span>3</span>
							</div>
							<h3>
								<a href="#">Tối ưu nội dung liên tục</a>
							</h3>
							<p>
								HomeNest liên tục cập nhật nội dung chuẩn SEO, tối ưu tốc độ tải trang và đồng bộ các nền tảng mạng xã hội, giúp webiste duy trì thứ hạng cao trên công cụ tìm kiếm.
							</p>
						</div>
					</div>
				</div>
				<div class="group_button fade-element fade-up delay-0">
					<div class="btn button1">
						<a href="#" class="text-gradient" style="display: inline-flex;  align-items:center">Tìm hiểu thêm <i class="homenest-icon-arrow-right"></i></a>
					</div>
					<div class="btn button2">
						<a href="#" style="display: inline-flex;  align-items:center">Xem chi tiết gói dịch vụ <i class="homenest-icon-google_fullCOLOR"></i></a>
					</div>
				</div>
			</div>
		</section>
		<section class="container sc7">
			<div class="group_content fade-element fade-up delay-0">
				<div class="main_content">
					<p class="title_p text-gradient">
						Các gói chăm sóc website
					</p>
					<h2 class="text-gradient">
						Các gói dịch vụ nổi bật của HomeNest
					</h2>
				</div>
			</div>
			<div class="group_card">
				<div class="card fade-element fade-up delay-0">
					<div class="main_card">
						<h3>
							Basic Plan
						</h3>
						<p>
							Powerful & Awesome Elements
						</p>
						<h4>
							$28<sub>/month</sub>
						</h4>
						<a href="#">Purchase Now <i class="homenest-icon-arrow-right"></i></a>
						<ul>
							<li>
								<i class="homenest-icon-tick"></i>
								<p>1000 creadits = 10,000 words</p>
							</li>
							<li>
								<i class="homenest-icon-tick"></i>
								<p>Access to all tools</p>
							</li>
							<li>
								<i class="homenest-icon-tick"></i>
								<p>5+ language supports</p>
							</li>
							<li>
								<i class="homenest-icon-tick"></i>
								<p>API access</p>
							</li>
							<li>
								<i class="homenest-icon-tick"></i>
								<p>20,000 Monthly Word Limit</p>
							</li>
							<li>
								<i class="homenest-icon-tick"></i>
								<p>Newest Features</p>
							</li>
							<li>
								<i class="homenest-icon-tick"></i>
								<p>Advance Editor Tool</p>
							</li>
						</ul>
					</div>
				</div>
				<div class="card fade-element fade-up delay-1">
					<div class="main_card">
						<h3>
							Pro Plan
						</h3>
						<p>
							Powerful & Awesome Elements
						</p>
						<h4>
							$99<sub>/month</sub>
						</h4>
						<a href="#">Purchase Now 
<i class="homenest-icon-arrow-right"></i></a>
						<ul>
							<li>
								<i class="homenest-icon-tick"></i>
								<p>5000 creadits = 10,000 words</p>
							</li>
							<li>
								<i class="homenest-icon-tick"></i>
								<p>Access to all tools</p>
							</li>
							<li>
								<i class="homenest-icon-tick"></i>
								<p>32+ language supports</p>
							</li>
							<li>
								<i class="homenest-icon-tick"></i>
								<p>API access with GPT4</p>
							</li>
							<li>
								<i class="homenest-icon-tick"></i>
								<p>Unlimited Words</p>
							</li>
							<li>
								<i class="homenest-icon-tick"></i>
								<p>Newest Features</p>
							</li>
							<li>
								<i class="homenest-icon-tick"></i>
								<p>Advance Editor Tool</p>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</section>

		<section class="homenest__quy-trinh-cham-soc-website">
			<div class="homenest__quy-trinh-cham-soc-website__container">
				<div class="homenest__quy-trinh-cham-soc-website__wrapper">
					<h2 class="homenest__quy-trinh-cham-soc-website__title text-gradient">
						Quy trình chăm sóc website <br> tại HomeNest
					</h2>
					<p class="homenest__quy-trinh-cham-soc-website__desc">
						Tại HomeNest, chúng tôi hiểu rằng website là gương mặt đại diện quan trọng của thương hiệu. Chúng tôi đảm bảo mang đến cho bạn một giải pháp với quy trình chuyên nghiệp, giúp cho website của bạn hoạt động một cách ổn định và hiệu quả.
					</p>
					<ul class="homenest__quy-trinh-cham-soc-website__contain">

					</ul>
				</div>
			</div>
		</section>

		<section class="container sc8">
			<div class="swiper mySwiper">
				<div class="swiper-wrapper">
					<div class="swiper-slide">
						<h2 class="text-gradient">
							HomeNest đã giúp website của chúng tôi hoạt động ổn định và tối ưu hơn rất nhiều.
						</h2>
						<div class="block_info">
							<img src="/wp-content/uploads/2025/07/standard-1.webp" alt="Homenest" title="Homenest">
							<div class="info">
								<h4 class="text-gradient">
									Trần Thị Thu Vân
								</h4>
								<span>Marketing Lead</span>
							</div>
						</div>
					</div>
					<div class="swiper-slide">
						<h2 class="text-gradient">
							Rất ấn tượng với sự tận tâm và chuyên nghiệp của đội ngũ HomeNest
						</h2>
						<div class="block_info">
							<img src="/wp-content/uploads/2025/07/standard-2.webp" alt="Homenest" title="Homenest">
							<div class="info">
								<h4 class="text-gradient">
									Nguyễn Thành Luân
								</h4>
								<span>CEO</span>
							</div>
						</div>
					</div>
				</div>
				<div class="swiper-button-next-ab">
					<img src="/wp-content/uploads/2025/07/arrow-right.svg" alt="Homenest" title="Homenest">
				</div>
				<div class="swiper-button-prev-ab">
					<img src="/wp-content/uploads/2025/07/arrow-left.svg" alt="Homenest" title="Homenest">
				</div>
			</div>
		</section>
		<section class="container sc9">
			<div class="main_content fade-element fade-up delay-0">
				<p class="title_p text-gradient">
					Về dự án
				</p>
				<h2 class="text-gradient">
					Hơn 1000+ khách hàng đã và đang hài lòng về dịch vụ chăm sóc website của chúng tôi.
				</h2>
			</div>
			<div class="group_button">
				<div class="btn button1 fade-element fade-up delay-0">
					<a href="/case-studies/" class="text-gradient" style="display: inline-flex;  align-items:center">Tìm hiểu thêm <i class="homenest-icon-arrow-right"></i></a>
				</div>
				<div class="btn button2 fade-element fade-up delay-1">
					<a href="/about-us/" style="display: inline-flex;  align-items:center">Về chúng tôi <i class="homenest-icon-google_fullCOLOR"></i></a>
				</div>
			</div>
			<p class="last_p">
				Nỗ lực không ngừng để mang lại 100% sự hài lòng từ khách hàng
			</p>
		</section>
		<section class="container sc10">
			<div class="title">
				Hơn 1500+ khách hàng đã và đang tin tưởng sử dụng dịch vụ của chúng tôi
			</div>
			<div class="logo-marquee">
				<div class="logo-track" id="logo-track">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-1.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-2.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-3.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-4.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-5.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-6.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-7.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-8.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-9.webp" 
alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-10.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-11.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-12.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-13.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-14.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-15.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-16.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-17.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-18.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-19.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-20.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-21.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-22.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-23.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-24.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-25.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-26.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-27.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-28.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-29.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-30.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-31.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-32.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-33.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-34.webp" 
alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-35.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-36.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-37.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-38.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-39.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-40.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-41.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-42.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-43.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-44.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-45.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-46.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-47.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-48.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-49.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-50.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-51.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-52.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-53.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-54.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-55.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-56.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-57.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-58.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-59.webp" 
alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-60.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-61.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-62.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-63.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-64.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-65.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-66.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/05/Logo_website-67.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/06/Logo_website-68.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/06/Logo_website-69.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/06/Logo_website-70.webp" alt="Homenest" title="Homenest">
					<img loading="lazy" src="/wp-content/uploads/2025/06/Logo_website-71.webp" alt="Homenest" title="Homenest">
				</div>
			</div>
		</section>
	</div>
	<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
	<script>
        // ==============================
        // Dữ liệu Quy trình chăm sóc Website (Internal)
        // ==============================
        const quyTrinhContain = [
     
        {
                heading: "Phân tích và lập kế hoạch",
                content: "Xác định mục tiêu, nhu cầu và đối tượng khách hàng của website. Lên kế hoạch chi tiết về nội dung, kỹ thuật, bảo mật và các chỉ số đánh giá hiệu quả (KPI).",
                linkImg: "/wp-content/uploads/2025/07/761d2291534b7cd6cf9fc1eaccf9f8b6-scaled-1.webp",
            },
            {
                heading: "Quản trị và cập nhật nội dung",
                content: "Đăng tải, chỉnh sửa nội dung mới chuẩn SEO, cập nhật hình ảnh, banner, sản phẩm/dịch vụ. Đảm bảo nội dung luôn hấp dẫn, phù hợp xu hướng và tăng trải nghiệm người dùng.",
                linkImg: "/wp-content/uploads/2025/07/761d2291534b7cd6cf9fc1eaccf9f8b6-scaled-1.webp",
            },
            {
                heading: "Bảo trì kỹ thuật và tối ưu hiệu suất",
                content: "Kiểm tra, sửa lỗi kỹ thuật, cập nhật hệ thống, plugin và theme. Tối ưu tốc độ tải trang, dọn dẹp dữ liệu không cần thiết, đảm bảo website hoạt động mượt mà trên mọi thiết bị.",
                linkImg: "/wp-content/uploads/2025/07/761d2291534b7cd6cf9fc1eaccf9f8b6-scaled-1.webp",
            },
            {
                heading: "Tăng cường bảo mật và sao lưu dữ liệu",
           
             content: "Cài đặt và cập nhật các giải pháp bảo mật, quét mã độc định kỳ. Sao lưu dữ liệu thường xuyên để phòng tránh mất mát và hỗ trợ phục hồi nhanh khi có sự cố.",
                linkImg: "/wp-content/uploads/2025/07/761d2291534b7cd6cf9fc1eaccf9f8b6-scaled-1.webp",
            },
            {
                heading: "Theo dõi, phân tích và báo cáo",
                content: "Sử dụng công cụ như Google Analytics, Google Search Console để theo dõi lưu lượng, hành vi người dùng và thứ hạng từ khóa. Báo cáo định kỳ, đánh giá hiệu quả và đề xuất cải tiến phù hợp.",
                linkImg: "/wp-content/uploads/2025/07/761d2291534b7cd6cf9fc1eaccf9f8b6-scaled-1.webp",
            },
        ];
    </script>

</body>

<?php get_footer(); ?>