<?php
/**
 * Template Name: Google Ads
 * Template Post Type: service
 */
get_header();
?>

<!-- Main content -->
<section class="homenest__google-ads__wrapper">
	<div class="homenest__google-ads__content">
		<h2 class="homenest__google-ads__title">
			<span class="gradient-text-1">QUẢNG CÁO GOOGLE ADS</span>
		</h2>
		<h2 class="homenest__google-ads__subtitle">CHUYÊN NGHIỆP TẠI HOMENEST</h2>

		<p class="homenest__google-ads__description">
			<a href="#">HomeNest</a> cung cấp dịch vụ quảng cáo Google Ads chuyên nghiệp, giúp doanh nghiệp tiếp cận
			nhanh chóng và hiệu quả đến khách hàng tiềm năng. Với chiến lược tối ưu từ khóa và ngân sách, HomeNest
			đảm bảo chiến dịch quảng cáo của bạn đạt hiệu quả tối đa, tăng cường khả năng hiển thị và tỷ lệ chuyển đổi.
		</p>

		<ul class="homenest__google-ads__features-list">
			<li>
				<img src="/wp-content/uploads/2025/06/homenest_li.svg" alt="icon" class="li-icon" />
				Tăng cường mức độ nhận diện thương hiệu
			</li>
			<li>
				<img src="/wp-content/uploads/2025/06/homenest_li.svg" alt="icon" class="li-icon" />
				Nâng cao tỷ lệ chuyển đổi khách hàng
			</li>
			<li>
				<img src="/wp-content/uploads/2025/06/homenest_li.svg" alt="icon" class="li-icon" />
				Thúc đẩy và phát huy các lợi thế cạnh tranh
			</li>
			<li>
				<img src="/wp-content/uploads/2025/06/homenest_li.svg" alt="icon" class="li-icon" />
				Thu thập dữ liệu khách hàng mục tiêu
			</li>
		</ul>

		<div class="homenest__google-ads__cta-button1">
			<button class="homenest__google-ads__cta-button">Đăng ký nhận báo giá</button>
		</div>
	</div>

	<div class="homenest__google-ads__image">
		<div class="homenest__google-ads__image-layout">
			<img src="/wp-content/uploads/2025/06/homenest_client.webp" alt="Nhân viên HomeNest đang làm việc" class="homenest__google-ads__main-image" loading="lazy">
			<img src="/wp-content/uploads/2025/06/homenest_chip.webp" alt="Hình minh họa AI của HomeNest" class="homenest__google-ads__overlay-image" loading="lazy">
		</div>
	</div>
</section>

<section class="section-container">
	<div class="left-background">
		<img src="/wp-content/uploads/2025/06/homenest_background3.webp" alt="Hình nền hình khối trang trí" loading="lazy" />
	</div>
	<section class="google-ads-section">
		<div class="text-content">
			<h2><span class="gradient-text">GOOGLE</span> <span class="gradient-text">ADS</span> <strong>LÀ GÌ?</strong></h2>
			<p>
				Google Ads là nền tảng quảng cáo trực tuyến của Google, cho phép doanh nghiệp hiển thị quảng cáo trên kết quả tìm kiếm của Google và trên các trang web trong mạng lưới Google. Các quảng cáo này xuất hiện dưới dạng liên kết văn bản, hình ảnh hoặc video, nhằm tiếp cận đối tượng tiềm năng dựa trên từ khóa tìm kiếm, sở thích hoặc vị trí địa lý. Google Ads giúp doanh nghiệp tăng khả năng tiếp cận khách hàng, tăng tỷ lệ nhấp chuột và doanh thu bằng cách tối ưu hóa chi phí cho từng lần nhấp (CPC) hoặc nghìn lần hiển thị (CPM).
			</p>
		</div>
		<div class="slider">
			<div class="slides">
				<img src="/wp-content/uploads/2025/06/homenest_slide1.webp" alt="Quảng cáo Google Ads trên giao diện tìm kiếm 1" loading="lazy" />
				<img src="/wp-content/uploads/2025/06/homenest_slide2.webp" alt="Quảng cáo Google Ads trên giao diện tìm kiếm 2" loading="lazy" />
				<img src="/wp-content/uploads/2025/06/homenest_slide3.webp" alt="Quảng cáo Google Ads trên giao diện tìm kiếm 3" loading="lazy" />
				<img src="/wp-content/uploads/2025/06/homenest_slide4.webp" alt="Quảng cáo Google Ads trên giao diện tìm kiếm 4" loading="lazy" />
				<img src="/wp-content/uploads/2025/06/homenest_slide5.webp" alt="Quảng cáo Google Ads trên giao diện tìm kiếm 5" loading="lazy" />
				<img src="/wp-content/uploads/2025/06/homenest_slide1.webp" alt="Quảng cáo Google Ads trên giao diện tìm kiếm 6" loading="lazy" />
				<img src="/wp-content/uploads/2025/06/homenest_slide2.webp" alt="Quảng cáo Google Ads trên giao diện tìm kiếm 7" loading="lazy" />
				<img src="/wp-content/uploads/2025/06/homenest_slide3.webp" alt="Quảng cáo Google Ads trên giao diện tìm kiếm 8" loading="lazy" />
			</div>
			<button class="prev"><span class="sr-only">Previous</span>&#10094;</button>
			<button class="next"><span class="sr-only">Next</span>&#10095;</button>
		</div>
	</section>
</section>

<section class="ads-benefit-section">
	<h2 class="section-title">
		VÌ SAO NÊN SỬ DỤNG <span class="gradient-text">DỊCH VỤ GOOGLE <br> ADS</span>
		<span class="gradient-text">CHO DOANH NGHIỆP CỦA BẠN?</span>
	</h2>

	<div class="benefit-grid">
		<div class="benefit-item item-1">
			<img src="/wp-content/uploads/2025/06/homenest_business-1.svg" alt="Biểu tượng tiếp cận khách hàng" class="icon" loading="lazy" />
			<h3>Tiếp cận khách hàng</h3>
			<p>Google Ads nhắm mục tiêu chi tiết theo từ khóa, địa điểm và sở thích, tối ưu hóa hiệu quả tiếp cận.</p>
		</div>
		<div class="benefit-item item-2">
			<img src="/wp-content/uploads/2025/06/homenest_business-1.svg" alt="Biểu tượng tăng doanh thu" class="icon" loading="lazy" />
			<h3>Tăng doanh thu</h3>
			<p>Google Ads giúp tăng tỷ lệ chuyển đổi, từ đó cải thiện doanh thu cho doanh nghiệp.</p>
		</div>
		<div class="benefit-item item-3">
			<img src="/wp-content/uploads/2025/06/homenest_business-1.svg" alt="Biểu tượng tối ưu chi phí" class="icon" loading="lazy" />
			<h3>Tối ưu chi phí</h3>
			<p>Google Ads cho phép điều chỉnh ngân sách linh hoạt, đảm bảo hiệu quả với chi phí hợp lý.</p>
		</div>
		<div class="benefit-item item-4">
			<img src="/wp-content/uploads/2025/06/homenest_business-1.svg" alt="Biểu tượng mở rộng thị trường" class="icon" loading="lazy" />
			<h3>Mở rộng thị trường</h3>
			<p>Google Ads giúp doanh nghiệp tiếp cận khách hàng toàn cầu, mở rộng phạm vi kinh doanh.</p>
		</div>
	</div>
</section>

<section class="stats-section" id="stats">
	<div class="stats-heading">
		<h1 class="black">GOOGLE ADS</h1>
		<h1 class="gradient-text-1">VÀ NHỮNG CON SỐ <span>ẤN TƯỢNG</span></h1>
	</div>
	<div class="stat stat-1">
		<div class="tlcl">
			<h2 class="counter" data-target="66">0</h2>
			<p class="label">Người dùng</p>
		</div>
		<p class="content">
			Có xu hướng nhấp vào <a href="#" class="highlight-link">quảng cáo Google</a> khi tìm kiếm thông tin sản phẩm hoặc dịch vụ.
		</p>
	</div>
	<div class="stat stat-2">
		<div class="tlcl">
			<h2 class="counter" data-target="75">0</h2>
			<p class="label">Doanh nghiệp</p>			
		</div>
		<p class="content">Báo cáo rằng Google Ads giúp họ tăng doanh thu và cải thiện kết quả kinh doanh rõ rệt.</p>
	</div>
	<div class="stat stat-3">
		<div class="tlcl">
			<h2 class="counter" data-target="90">0</h2>
			<p class="label">Người dùng <span class="highlight">Internet</span></p>
		</div>
		<p class="content">Nhìn thấy quảng cáo Google, mở rộng khả năng tiếp cận đối tượng khách hàng.</p>
	</div>
	<div class="stat-image">
		<img src="/wp-content/uploads/2025/06/homenest_adverti-gg.gif" alt="Hình ảnh minh họa quảng cáo Google Ads" loading="lazy">
	</div>
</section>

<section>
	<div class="section-title_services">
		<h2>LÝ DO NÊN CHỌN DỊCH VỤ
			<br>
			<span class="gradient-text-1">QUẢNG CÁO GOOGLE ADS CỦA HOMENEST</span>
		</h2>
	</div>
	<div class="grid-container">
		<div class="grid-item">
			<img src="/wp-content/uploads/2025/06/homenest_service1.webp" alt="Hình minh họa chiến lược tối ưu" loading="lazy">
			<h4>Chiến lược tối ưu - chuyên sâu</h4>
			<p>HomeNest xây dựng chiến lược quảng cáo tùy chỉnh, phù hợp với từng ngành nghề và mục tiêu kinh doanh, đảm bảo chiến dịch tiếp cận đúng đối tượng và tăng tỷ lệ chuyển đổi.</p>
		</div>
		<div class="grid-item">
			<img src="/wp-content/uploads/2025/06/homenest_service2.webp" alt="Hình minh họa đội ngũ chuyên gia" loading="lazy">
			<h4>Đội ngũ giàu kinh nghiệm</h4>
			<p>Đội ngũ chuyên viên của HomeNest có nhiều năm kinh nghiệm trong việc quản lý và tối ưu chiến dịch Google Ads, giúp bạn đạt được kết quả tốt nhất với chi phí hợp lý.</p>
		</div>
		<div class="grid-item">
			<img src="/wp-content/uploads/2025/06/homenest_service3.webp" alt="Hình minh họa báo cáo minh bạch" loading="lazy">
			<h4>Báo cáo chi tiết và minh bạch</h4>
			<p>HomeNest cung cấp báo cáo đầy đủ, dễ hiểu về hiệu suất quảng cáo, giúp bạn nắm bắt tiến độ và điều chỉnh chiến lược kịp thời để tối đa hóa hiệu quả đầu tư.</p>
		</div>
		<div class="grid-item">
			<img src="/wp-content/uploads/2025/06/homenest_service4.webp" alt="Hình minh họa hỗ trợ khách hàng" loading="lazy">
			<h4>Hỗ trợ liên tục và tư vấn tận tâm</h4>
			<p>HomeNest luôn đồng hành và hỗ trợ khách hàng xuyên suốt chiến dịch, tư vấn tận tình nhằm đảm bảo chiến dịch vận hành hiệu quả và đúng mục tiêu.</p>
		</div>
	</div>
</section>

<section class="section-title_services">
	<div class="section-title-budget">
		<h2 class="title">
			<span class="black">BẢNG GIÁ</span>
			<span class="gradient-text-1">QUẢNG CÁO GOOGLE ADS</span>
		</h2>
	</div>
</section>

<section class="pricing-slider swiper">
	<div class="slider-container swiper-wrapper">
		<div class="card basic swiper-slide">
			<div class="card-header">
				<p>BASIC</p>
			</div>
			<div class="card-body">
				<p class="desc"><strong>Gói Basic</strong> Tập trung vào các kỹ thuật SEO Onpage, nâng cao trải nghiệm người dùng và tạo sự nhận diện cho thương hiệu.</p>
				<ul class="features">
					<li>Phí Dịch Vụ 20%</li>
					<li>Từ khóa: Không giới hạn</li>
					<li>Cài đặt tài khoản</li>
					<li>Tài khoản thực hiện ngân sách lớn</li>
					<li>Tối ưu quảng cáo</li>
					<li>Cài Google Analytics</li>
					<li class="extra hidden">Theo dõi quảng cáo hàng ngày</li>
					<li class="extra hidden">Đảm bảo vị trí top</li>
					<li class="extra hidden">Tạo chiến dịch Tiếp Thị Lại Remarketing</li>
					<li class="extra hidden">Hỗ trợ thiết kế banner</li>
					<li class="extra hidden">Quyền truy cập tài khoản quảng cáo</li>
					<li class="extra hidden">Hỗ trợ trực tuyến</li>
					<li class="toggle-btn">Xem thêm</li>
				</ul>
				<p class="consult-note">*Liên hệ ngay để được tư vấn miễn phí</p>
				<div class="card-bottom">
					<a class="call-button" href="tel:0901234567">
						<i class="homenest-icon-phone"></i>
					</a>
					<p class="price" data-text="Tư vấn ngay">
						<span>10Tr – 50Tr</span>
					</p>
				</div>
			</div>
		</div>

		<div class="card golden swiper-slide">
			<div class="card-header ">
				<p>GOLDEN</p>
			</div>
			<div class="card-body">
				<p class="desc"><strong>Gói Golden</strong> Tối ưu hóa trải nghiệm người dùng và thúc đẩy quảng bá thương hiệu, đồng thời hỗ trợ trong việc phát triển kinh doanh.</p>
				<ul class="features">
					<li>Phí Dịch Vụ 18%</li>
					<li>Từ khóa: Không giới hạn</li>
					<li>Cài đặt tài khoản</li>
					<li>Tài khoản thực hiện ngân sách lớn</li>
					<li>Tối ưu quảng cáo</li>
					<li>Cài Google Analytics</li>
					<li class="extra hidden">Theo dõi quảng cáo hàng ngày</li>
					<li class="extra hidden">Đảm bảo vị trí top</li>
					<li class="extra hidden">Tạo chiến dịch Tiếp Thị Lại Remarketing</li>
					<li class="extra hidden">Hỗ trợ thiết kế banner</li>
					<li class="extra hidden">Quyền truy cập tài khoản quảng cáo</li>
					<li class="extra hidden">Hỗ trợ trực tuyến</li>
					<li class="toggle-btn">Xem thêm</li>
				</ul>
				<p class="consult-note">*Liên hệ ngay để được tư vấn miễn phí</p>
				<div class="card-bottom">
					<a class="call-button" href="tel:0901234567">
						<i class="homenest-icon-phone"></i>
					</a>
					<p class="price" data-text="Tư vấn ngay">
						<span>51Tr – 100Tr</span>
					</p>
				</div>
			</div>
		</div>

		<div class="card diamond swiper-slide">
			<div class="card-header">
				<p>DIAMOND</p>
			</div>
			<div class="card-body">
				<p class="desc"><strong>Gói Diamond</strong> SEO tăng mạnh đồng thời cải thiện thứ hạng từ khóa, tăng lượng truy cập và tối ưu hóa tỷ lệ chuyển đổi.</p>
				<ul class="features">
					<li>Phí Dịch Vụ 15%</li>
					<li>Từ khóa: Không giới hạn</li>
					<li>Cài đặt tài khoản</li>
					<li>Tài khoản thực hiện ngân sách lớn</li>
					<li>Tối ưu quảng cáo</li>
					<li>Cài Google Analytics</li>
					<li class="extra hidden">Theo dõi quảng cáo hàng ngày</li>
					<li class="extra hidden">Đảm bảo vị trí top</li>
					<li class="extra hidden">Tạo chiến dịch Tiếp Thị Lại Remarketing</li>
					<li class="extra hidden">Hỗ trợ thiết kế banner</li>
					<li class="extra hidden">Quyền truy cập tài khoản quảng cáo</li>
					<li class="extra hidden">Hỗ trợ trực tuyến</li>
					<li class="toggle-btn" role="button">Xem thêm</li>
				</ul>
				<p class="consult-note">*Liên hệ ngay để được tư vấn miễn phí</p>
				<div class="card-bottom">
					<a class="call-button" href="tel:0901234567">
						<i class="homenest-icon-phone"></i>
					</a>
					<p class="price" data-text="Tư vấn ngay">
						<span>101Tr – 300Tr</span>
					</p>
				</div>
			</div>
		</div>

		<div class="card platinum swiper-slide">
			<div class="card-header">
				<p>PLATINUM</p>
			</div>
			<div class="card-body">
				<p class="desc"><strong>Gói Platinum</strong> Thống trị thị trường trong lĩnh vực ngành, chiếm lĩnh toàn bộ không gian tìm kiếm tự nhiên trên Google.</p>
				<ul class="features">
					<li>Phí Dịch Vụ 13%</li>
					<li>Từ khóa: Không giới hạn</li>
					<li>Cài đặt tài khoản</li>
					<li>Tài khoản thực hiện ngân sách lớn</li>
					<li>Tối ưu quảng cáo</li>
					<li>Cài Google Analytics</li>
					<li class="extra hidden">Theo dõi quảng cáo hàng ngày</li>
					<li class="extra hidden">Đảm bảo vị trí top</li>
					<li class="extra hidden">Tạo chiến dịch Tiếp Thị Lại Remarketing</li>
					<li class="extra hidden">Hỗ trợ thiết kế banner</li>
					<li class="extra hidden">Quyền truy cập tài khoản quảng cáo</li>
					<li class="extra hidden">Hỗ trợ trực tuyến</li>
					<li class="toggle-btn">Xem thêm</li>
				</ul>
				<p class="consult-note">*Liên hệ ngay để được tư vấn miễn phí</p>
				<div class="card-bottom">
					<a class="call-button" href="tel:0901234567">
						<i class="homenest-icon-phone"></i>
					</a>
					<p class="price" data-text="Tư vấn ngay">
						<span>301Tr – 1 Tỷ</span>
					</p>
				</div>
			</div>
		</div>

		<div class="card platinum-plus hidden swiper-slide">
			<div class="card-header">
				<p>PLATINUM+</p>
			</div>
			<div class="card-body">
				<p class="desc"><strong>Gói Platinum+</strong> Thống trị thị trường trong lĩnh vực ngành, chiếm lĩnh toàn bộ không gian tìm kiếm tự nhiên trên Google.</p>
				<ul class="features">
					<li>Phí Dịch Vụ 10%</li>
					<li>Từ khóa: Không giới hạn</li>
					<li>Cài đặt tài khoản</li>
					<li>Tài khoản thực hiện ngân sách lớn</li>
					<li>Tối ưu quảng cáo</li>
					<li>Cài Google Analytics</li>
					<li class="extra hidden">Theo dõi quảng cáo hàng ngày</li>
					<li class="extra hidden">Đảm bảo vị trí top</li>
					<li class="extra hidden">Tạo chiến dịch Tiếp Thị Lại Remarketing</li>
					<li class="extra hidden">Hỗ trợ thiết kế banner</li>
					<li class="extra hidden">Quyền truy cập tài khoản quảng cáo</li>
					<li class="extra hidden">Hỗ trợ trực tuyến</li>
					<li class="toggle-btn">Xem thêm</li>
				</ul>
				<p class="consult-note">*Liên hệ ngay để được tư vấn miễn phí</p>
				<div class="card-bottom">
					<a class="call-button" href="tel:0901234567">
						<i class="homenest-icon-phone"></i>
					</a>
					<p class="price" data-text="Tư vấn ngay">
						<span>Trên 1 Tỷ</span>
					</p>
				</div>
			</div>
		</div>
	</div>
	<div class="swiper-button-prev"></div>
	<div class="swiper-button-next"></div>
</section>

<section class="main-layout">
	<div class="left-panel">
		<div class="social-icons">
			<a href="#"><i class="fab fa-facebook-f"></i></a>
			<a href="#"><i class="fab fa-instagram"></i></a>
			<a href="#"><i class="homenest-icon-tiktok"></i></a>
			<a href="#"><i class="fab fa-youtube"></i></a>
			<a href="#"><i class="fab fa-linkedin-in"></i></a>
		</div>
		<div class="top-image">
			<img src="/wp-content/uploads/2025/06/homenest_frame3.webp" alt="Hình minh họa bàn tay robot" loading="lazy">
		</div>
	</div>

	<div class="right-panel">
		<div class="header-section">
			<h1 class="brand">HOMENEST <span class="tag">Website</span></h1>
			<h2 class="title">QUY TRÌNH <br><span class="gradient-text-1">THIẾT KẾ WEBSITE THEO YÊU CẦU</span></h2>
			<div class="bg-elements"></div>
		</div>

		<div class="process-wrapper">
			<div class="process-section">
				<div class="step" data-step="1">
					<div class="step-number">.01</div>
					<div class="step-content">
						<h3>Tư vấn & Báo giá</h3>
						<p>Tư vấn chi tiết về những mong muốn và ý tưởng của khách hàng, đưa ra tính năng và gói dịch vụ phù hợp với ngân sách và lên báo giá chi tiết.</p>
					</div>
				</div>

				<div class="step-1" data-step="2">
					<div class="step-number">.02</div>
					<div class="step-content">
						<h3>Lập kế hoạch chi tiết</h3>
						<p>Sau khi tiếp nhận yêu cầu của khách hàng, bộ phận UI/UX và Dev sẽ thảo luận để đưa ra kế hoạch tối ưu nhất dành cho khách hàng.</p>
					</div>
				</div>

				<div class="step" data-step="3">
					<div class="step-number">.03</div>
					<div class="step-content">
						<h3>Thiết kế và lập trình</h3>
						<p>Bộ phận UI/UX Design sau khi có kế hoạch sẽ tiến hành lên demo và gửi khách hàng bản Figma. Khách hàng điều chỉnh trước khi lập trình.</p>
					</div>
				</div>

				<div class="step-1" data-step="4">
					<div class="step-number">.04</div>
					<div class="step-content">
						<h3>Thử nghiệm và điều chỉnh</h3>
						<p>Khách hàng thử nghiệm website của họ sau khi lập trình và tiến hành điều chỉnh nếu có vấn đề phát sinh.</p>
					</div>
				</div>

				<div class="step" data-step="5">
					<div class="step-number">.05</div>
					<div class="step-content">
						<h3>Hướng dẫn quản trị</h3>
						<p>Trao đổi và hướng dẫn khách hàng tự quản lý website của họ một cách chuyên nghiệp và chính xác.</p>
					</div>
				</div>

				<div class="step-1" data-step="6">
					<div class="step-number">.06</div>
					<div class="step-content">
						<h3>Bàn giao và bảo hành</h3>
						<p>Sau khi hoàn thành các bước thử nghiệm và đào tạo, tiến hành bàn giao và bảo hành cho khách trong những trường hợp cụ thể về kỹ thuật.</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<div class="homenest__professional_website_faq">
	<div class="homenest__professional_website_title-wrapper">
		<h2 class="homenest__professional_website_title">CÂU HỎI THƯỜNG GẶP</h2>
	</div>
	<div id="homenest__professional_website_faq-container"></div>
</div>


<?php
// Đăng ký và nhúng file JavaScript (nếu bạn tách riêng JS)
function homenest_enqueue_scripts() {
	wp_enqueue_script('homenest-scripts', get_template_directory_uri() . '/js/scripts.js', array(), '1.0', true);
}
add_action('wp_enqueue_scripts', 'homenest_enqueue_scripts');

// Đăng ký và nhúng Swiper JS
function homenest_enqueue_swiper() {
	wp_enqueue_script('swiper', 'https://unpkg.com/swiper/swiper-bundle.min.js', array(), '7.4.1', true);
}
add_action('wp_enqueue_scripts', 'homenest_enqueue_swiper');

wp_footer();
get_footer();
?>