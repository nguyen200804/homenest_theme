<?php
/**
 * Template Name: SEO từ khóa
 * Template Post Type: service
 */
get_header(); ?>

<body>

	<!-- <main class="service-wrapper container"> -->
	<main class="service-wrapper">
		<!-- 	
<article class="service-detail service-seo-tong-the">
<header class="service-header">
<h1 class="service-title"><?php the_title(); ?></h1>

<?php if (has_post_thumbnail()) : ?>
<div class="service-thumbnail">
<?php the_post_thumbnail('large', ['class' => 'img-responsive']); ?>
</div>
<?php endif; ?>
</header>

<section class="service-content">
<?php the_content(); ?>
</section>

<?php
// Lấy custom field ví dụ: giá dịch vụ
$gia = get_post_meta(get_the_ID(), 'gia_dich_vu', true);
$thoi_gian = get_post_meta(get_the_ID(), 'thoi_gian_thuc_hien', true);
?>

<?php if ($gia || $thoi_gian) : ?>
<section class="service-meta">
<ul>
<?php if ($gia) : ?>
<li><strong>Giá dịch vụ:</strong> <?php echo esc_html($gia); ?></li>
<?php endif; ?>
<?php if ($thoi_gian) : ?>
<li><strong>Thời gian thực hiện:</strong> <?php echo esc_html($thoi_gian); ?></li>
<?php endif; ?>
</ul>
</section>
<?php endif; ?>

<footer class="service-footer">
<a class="btn-back" href="<?php echo home_url('/services'); ?>">&larr; Quay lại danh sách dịch vụ</a>
</footer>
</article>
-->

		<section class="homenest__single-services__about">
			<div class="container">
				<div class="col1">
					<h1 class="text-gradient">Thiết Kế Logo Chuyên Nghiệp - Dấu ấn vững bền, chinh phục niềm tin.</h1>
				</div>
				<div class="col2">
					<p><span class="text-gradient">Logo không chỉ đơn thuần là một hình ảnh</span>, mà còn là bản sắc thương hiệu, thể hiện giá trị cốt lõi và tầm nhìn của doanh nghiệp. <span class="text-gradient">Một logo chuyên nghiệp</span> giúp doanh nghiệp định vị vững chắc trên thị trường, tạo dấu ấn riêng biệt trong tâm trí khách hàng.</p>
					<a href="#"><span class="text-gradient">Liên hệ ngay để được tư vấn miễn phí</span><i class="fa-solid fa-arrow-right"></i></a>
				</div>
			</div>
		</section>

		<section class="homenest__single-services__banner">
			<div class="container">
				<div class="col1">
					<video width="100%" height="100%" autoplay loop muted>
						<source src="/wp-content/uploads/2025/06/homnest1.mp4" type="video/mp4 " >
					</video>
				</div>
				<div class="col2">
					<div class="row-1">
						<h5>Nghiên cứu thị trường và mục tiêu của thương hiệu</h5>
						<div class="line">

						</div>
						<p>
							Thực hiện nghiên cứu thị trường, và lắng nghe mong muốn, cũng như mục tiêu của thương hiệu, tổng hợp đưa ra những giải pháp giá trị cho logo thương hiệu
						</p>
					</div>
					<div class="row-2">
						<div class="icon">
							<i class="fa-light fa-bolt"></i>
						</div>
						<div class="content">
							<div class="number">
								100%
							</div>
							<p class="text">
								Mang lại sự hài lòng cho khách hàng
							</p>
						</div>
					</div>
				</div>
				<div class="col3">
					<div class="row-1">
						<img src="/wp-content/uploads/2025/05/Group-18430-min-e1747630312542.webp">
						<p class="text">
							Không chỉ là vẻ đẹp thương hiệu, mà còn hơn cả một câu chuyện
						</p>
					</div>
					<div class="row-2">
						<p class="text">
							Xây dựng chiến lược, câu chuyện xoay quoanh logo thương hiệu
						</p>
					</div>
				</div>
			</div>
		</section>





		<section class="homenest__single-services__adv"> 
			<div class="homenest__single-services__adv__container">
				<div class="homenest__single-services__adv__heading-wrapper"> 
					<h2 class="homenest__single-services__adv__title">Lợi ích khi sử dụng <br><span class="text-gradient">dịch vụ SEO từ khóa</span></h2>
				</div>

				<div class="homenest__single-services__adv__benefits"> 
					<div class="homenest__single-services__adv__benefit-item"> 
						<div class="homenest__single-services__adv__icon">
							<svg width="30px" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
								<rect width="48" height="48" fill="white" fill-opacity="0.01"/>
								<rect x="4" y="18" width="13" height="24" stroke="#ffffff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
								<rect x="17" y="6" width="13" height="36" stroke="#ffffff" stroke-width="4" stroke-linejoin="round"/>
								<rect x="30" y="26" width="13" height="16" stroke="#ffffff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
							</svg>
						</div> 
						<h3 class="homenest__single-services__adv__benefit-title">Tăng thứ hạng Google</h3>
						<p class="homenest__single-services__adv__benefit-desc">Giúp website xuất hiện trên top tìm kiếm, tiếp cận khách hàng tiềm năng hiệu quả hơn.</p>
					</div>
					<div class="homenest__single-services__adv__benefit-item"> 
						<div class="homenest__single-services__adv__icon">
							<svg width="30px" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
								<rect width="48" height="48" fill="white" fill-opacity="0.01"/>
								<path d="M24 2V46" stroke="#ffffff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
								<path d="M35 6C35 6 24.9706 6 20 6C15.0294 6 11 10.0294 11 15C11 19.9706 15.0294 24 20 24" stroke="#ffffff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
								<path d="M13 42C13 42 23.0294 42 28 42C32.9706 42 37 37.9706 37 33C37 28.0294 32.9706 24 28 24H20" stroke="#ffffff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
							</svg>
						</div> 
						<h3 class="homenest__single-services__adv__benefit-title">Giảm chi phí quảng cáo</h3>
						<p class="homenest__single-services__adv__benefit-desc">Tăng lượng truy cập tự nhiên, hạn chế phụ thuộc vào quảng cáo trả phí tốn kém.</p>
					</div>
					<div class="homenest__single-services__adv__benefit-item"> 
						<div class="homenest__single-services__adv__icon">
							<svg fill="#ffffff" width="30px" viewBox="0 0 1920 1920" xmlns="http://www.w3.org/2000/svg">
								<path d="m960 15 266.667 241.92 359.893-13.867 48.747 356.907L1920 820.547l-192 304.64 76.267 352.106-342.934 109.867-167.893 318.613L960 1769.56l-333.44 136.213-167.893-318.613-342.934-109.867L192 1125.187 0 820.547 284.693 599.96l48.747-356.907 359.893 13.867L960 15Zm0 144L764.907 335.96l-32.214 29.227-43.52-1.6-263.253-10.134-35.627 260.907-5.866 43.2-34.454 26.56-208.106 161.387L282.24 1068.44l23.253 36.693-9.28 42.667-55.68 257.387 250.774 80.426 41.493 13.334 20.373 38.506 122.667 232.96 243.84-99.52L960 1654.36l40.32 16.533 243.84 99.52 122.773-232.96 20.267-38.506 41.493-13.334 250.774-80.426-55.68-257.387-9.28-42.667 23.253-36.693 140.48-222.933-208.213-161.387-34.454-26.56-5.866-43.2-35.734-260.907-263.04 10.134-43.626 1.6-32.214-29.227L960 159Zm341.056 613.483 64.533 85.013-561.6 426.24-255.04-255.04 75.414-75.413 189.226 189.226 487.467-370.026Z" fill-rule="evenodd"/>
							</svg>
						</div> 
						<h3 class="homenest__single-services__adv__benefit-title">Xây dựng thương hiệu uy tín</h3>
						<p class="homenest__single-services__adv__benefit-desc">Website xuất hiện ổn định trên Google giúp nâng cao độ tin cậy và sức cạnh tranh.</p>
					</div>
					<div class="homenest__single-services__adv__benefit-item"> 
						<div class="homenest__single-services__adv__icon">
							<svg width="30px" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
								<g clip-path="url(#clip0)">
									<path d="M42 20V39C42 40.6569 40.6569 42 39 42H9C7.34315 42 6 40.6569 6 39V9C6 7.34315 7.34315 6 9 6H30" stroke="#ffffff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
									<path d="M16 20L26 28L41 7" stroke="#ffffff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
								</g>
								<defs>
									<clipPath id="clip0">
										<rect width="48" height="48" fill="white"/>
									</clipPath>
								</defs>
							</svg>
						</div> 
						<h3 class="homenest__single-services__adv__benefit-title">Cải thiện trải nghiệm</h3>
						<p class="homenest__single-services__adv__benefit-desc">Tối ưu tốc độ, nội dung và giao diện giúp giữ chân khách hàng và tăng tỷ lệ chuyển đổi.</p>
					</div>
				</div>

				<div class="homenest__single-services__adv__image-wrapper"> 
					<img src="/wp-content/uploads/2025/06/f3d2775843416f1262a5069db3f81ec5.webp" class="homenest__single-services__adv__image" alt="..." /> 
				</div>
			</div>
		</section>





		<section class="homenest__single-services__seo-tu-khoa"> 
			<div class="homenest__single-services__seo-tu-khoa__container">
				<div class="homenest__single-services__seo-tu-khoa__intro"> 
					<div class="homenest__single-services__seo-tu-khoa__intro-left"> 
						<h2 class="homenest__single-services__seo-tu-khoa__heading">SEO từ khóa HomeNest <span class="text-gradient">Chạm đúng nhu cầu, dẫn đầu</span> thị trường.</h2> 

					</div>
					<div class="homenest__single-services__seo-tu-khoa__intro-right"> 
						<p class="homenest__single-services__seo-tu-khoa__description">Không SEO từ khóa, website khó lên top Google, mất khách hàng và giảm truy cập. Đối thủ tối ưu SEO sẽ chiếm ưu thế, còn bạn phải phụ thuộc quảng cáo tốn kém. SEO từ khóa giúp thương hiệu vươn xa, tiếp cận khách hàng và phát triển bền vững. Đầu tư SEO ngay hôm nay để giữ vững chỗ đứng trên thị trường số!</p> 
						<a class="homenest__single-services__seo-tu-khoa__button">Tư vấn ngay</a> 
					</div>
				</div>

				<div class="homenest__single-services__seo-tu-khoa__body">
					<div class="homenest__single-services__seo-tu-khoa__stats">
						<div class="homenest__single-services__seo-tu-khoa__stat-item">
							<span class="homenest__single-services__seo-tu-khoa__stat-number">+300%</span>
							<span class="homenest__single-services__seo-tu-khoa__stat-label">Mức độ tăng trưởng website</span>
						</div>
						<div class="homenest__single-services__seo-tu-khoa__stat-item">
							<span class="homenest__single-services__seo-tu-khoa__stat-number">+2.000%</span>
							<span class="homenest__single-services__seo-tu-khoa__stat-label">Lượng traffic tăng trưởng mỗi năm</span>
						</div>
						<div class="homenest__single-services__seo-tu-khoa__stat-item">
							<span class="homenest__single-services__seo-tu-khoa__stat-number">6.000+</span>
							<span class="homenest__single-services__seo-tu-khoa__stat-label">Contact đổ về trong tháng</span>
						</div>
						<div class="homenest__single-services__seo-tu-khoa__stat-item">
							<span class="homenest__single-services__seo-tu-khoa__stat-number">12.000+</span>
							<span class="homenest__single-services__seo-tu-khoa__stat-label">Khách hàng trong và ngoài nước</span>
						</div>
					</div>
					<div class="homenest__single-services__seo-tu-khoa__image-block">
						<img src="/wp-content/uploads/2025/06/2dfef9043361b0ea61b4049c4f69a208-scaled-1.webp" class="homenest__single-services__seo-tu-khoa__image" /> 
					</div>
				</div>
			</div>
		</section>






		<section class="homenest__single-services__project">
			<div class="container">
				<h2><span class="text-gradient">Project</span> - Mẫu Thiết Kế <span class="text-gradient">Logo Chuyên Nghiệp</span> Đã Thực Hiện</h2>
				<p>HomeNest cung cấp giải pháp thiết kế thương hiệu chuyên nghiệp, giúp doanh nghiệp xây dựng nhận diện nhất quán và khác biệt. Với tư duy chiến lược và kinh nghiệm đa ngành, HomeNest đã thực hiện thành công nhiều dự án branding trong lĩnh vực bất động sản, F&B, thời trang và công nghệ, mang lại giá trị bền vững và lợi thế cạnh tranh.</p>
			</div>
			<div class="homenest__single-services__seo-tu-khoa__swiper-project">
				<?php
				$args = array(
					'post_type'      => 'case_study',
					'posts_per_page' => -1,
					'post_status'    => 'publish',
					'tax_query'      => array(
						array(
							'taxonomy' => 'linh-vuc',
							'field'    => 'slug',
							'terms'    => 'seo-tu-khoa',
						),
					),
				);

				$posts = get_posts($args);

				if ($posts) {
					echo '<div class="homenest__single-services__seo-tu-khoa__project-grid">';
					foreach ($posts as $post) {
						setup_postdata($post);

						$logo_du_an        = get_field('logo_du_an', $post->ID);
						$result_project_1  = get_field('result_project_1', $post->ID);
						$result_project_2  = get_field('result_project_2', $post->ID);
						$result_project_3  = get_field('result_project_3', $post->ID);

						echo '<div class="homenest__single-services__seo-tu-khoa__project-item">';

						// Ảnh đại diện
						echo '<div class="homenest__single-services__seo-tu-khoa__project-featured-image">';
						echo '<a href="' . get_permalink($post) . '">';
						if (has_post_thumbnail($post)) {
							echo get_the_post_thumbnail($post->ID, 'large');
						} else {
							echo '<img src="/wp-content/uploads/2025/05/elementor-placeholder-image.webp" alt="No Featured Image" />';
						}
						echo '</a>';
						echo '</div>';

						// Thông tin dự án
						if ($logo_du_an || $result_project_1 || $result_project_2 || $result_project_3) {
							echo '<div class="homenest__single-services__seo-tu-khoa__project-info">';

							if ($logo_du_an) {
								echo '<div class="logo">';
								echo '<a href="' . get_permalink($post) . '">';
								echo '<img src="' . esc_url($logo_du_an['url']) . '" alt="' . esc_attr($logo_du_an['alt'] ?: get_the_title($post)) . '" />';
								echo '</a>';
								echo '</div>';
							}

							foreach ([$result_project_1, $result_project_2, $result_project_3] as $i => $result) {
								if (!empty($result['con_so_dat_duoc']) && !empty($result['mo_ta_con_so'])) {
									echo '<div class="homenest__single-services__seo-tu-khoa__project-result' . ($i + 1) . '">';
									echo '<p><strong class="text-gradient">' . esc_html($result['con_so_dat_duoc']) . '</strong></p>';
									echo '<p>' . esc_html($result['mo_ta_con_so']) . '</p>';
									echo '</div>';
								}
							}

							echo '</div>'; // .project-info
						}

						echo '</div>'; // .project-item
					}
					echo '</div>'; // .grid

					wp_reset_postdata();
				} else {
					echo '<p>Không có case study nào thuộc lĩnh vực SEO từ khóa.</p>';
				}
				?>

				<a href="#" class="homenest__single-services__seo-tu-khoa__btn-see">Xem thêm</a>
			</div>
			
		</section>


		<section class="homenest__quy-trinh-cham-soc-website">
			<div class="homenest__quy-trinh-cham-soc-website__container">
				<div class="homenest__quy-trinh-cham-soc-website__wrapper">
					<h2 class="homenest__quy-trinh-cham-soc-website__title text-gradient">
						Quy trình chăm sóc website <br> tại HomeNest
					</h2>
					<p class="homenest__quy-trinh-cham-soc-website__desc">
						Tại HomeNest, chúng tôi hiểu rằng website là gương mặt đại diện quan trọng của thương hiệu. Chúng tôi đảm bảo mang đến cho bạn một giải pháp với quy trình chuyên nghiệp, giúp cho website của bạn hoạt động một cách ổn định và hiệu quả.
					</p>
					<ul class="homenest__quy-trinh-cham-soc-website__contain">

					</ul>
				</div>
			</div>
		</section>
		
		
		
		
<!-- 		<section class="homenest__professional_website_hn-pricing-section">
			<h2 class="homenest__professional_website_hn-pricing-title"> Bảng giá <span
																						class="homenest__professional_website_heading-highlight">Thiết kế website</span>
				chuyên nghiệp</h2>
			<div class="homenest__professional_website_pricing-section">
				<button class="homenest__professional_website_scroll-btn left" onclick="scrollCards(-1)">
					<svg xmlns="http://www.w3.org/2000/svg" width="31" height="24" viewBox="0 0 31 24" fill="none">
						<path d="M26 12H6" stroke="#0900FF" stroke-width="2" stroke-linecap="round"
							  stroke-linejoin="round"></path>
						<path d="M12.5938 19L5.8125 12L12.5938 5" stroke="#0900FF" stroke-width="2"
							  stroke-linecap="round" stroke-linejoin="round"></path>
					</svg>
				</button>

				
				<div class="homenest__professional_website_hn-pricing-cards-wrapper">
					<div class="homenest__professional_website_hn-pricing-cards">
					</div>
					<button class="homenest__professional_website_scroll-btn right" onclick="scrollCards(1)">
						<svg xmlns="http://www.w3.org/2000/svg" width="31" height="24" viewBox="0 0 31 24" fill="none">
							<path d="M5 12L25 12" stroke="#0900FF" stroke-width="2" stroke-linecap="round"
								  stroke-linejoin="round"></path>
							<path d="M18.4063 5L25.1875 12L18.4062 19" stroke="#0900FF" stroke-width="2"
								  stroke-linecap="round" stroke-linejoin="round"></path>
						</svg>
					</button>
				</div>
			</div>
		</section> 
-->
		
		


		<section class="homenest__single-services__price">
			<div class="container">
				<h2>
					<span class="text-gradient">Bảng giá thiết kế logo</span> chuyên nghiệp Homenest Media
				</h2>
				<div class="package-container">
					<div class="package-item basic" style="--bg-title: url('/wp-content/uploads/2025/06/homnest-dich-vu-thiet-ke-23-min.webp'); --color-package: #2db5b1;">
						<h4 class="package-title">Basic</h4>
						<p class="package-description"><span>Gói Basic</span> xây dựng nhận diện thương hiệu cơ bản, chuyên nghiệp, chi phí tối ưu.</p>
						<!-- 			Nhập 8 mục đầu		 -->
						<div class="package-features-list _1">
							<div>Thiết kế logo chuyên nghiệp: 2 mẫu chọn 1</div>
							<div>Thiết kế Namecard</div>
							<div>Thiết kế thẻ nhân viên</div>
							<div>Đồng phục (Áo thun, Sơmi)</div>
							<div>Thiết kế phong bì thư (A4,A5)</div>
							<div>Thời gian thực hiện: 3 ~ 5 ngày</div>
							<div>Chỉnh sửa không giới hạn</div>
							<div>Bàn giao: File gốc (AI, Vector), File in ấn chất lượng cao, File PDF, File ảnh PNG, JPG</div>
						</div>
						<!-- 			Nhập từ mục 9 trở lên		 -->

						<button class="btn-see-more text-gradient">Xem thêm</button>
						<p class="contact-note">
							Liên hệ ngay để được tư vấn miễn phí
						</p>
						<div class="contact-btn-and-price">
							<a class="contact-button">
								<svg 
									 xmlns="http://www.w3.org/2000/svg"
									 width="24"
									 height="24"
									 viewBox="0 0 24 24"
									 fill="none"
									 stroke="#fff"
									 stroke-width="2"
									 stroke-linecap="round"
									 stroke-linejoin="round"
									 >
									<path d="M14.05 6A5 5 0 0118 10m-3.95-8a9 9 0 018 7.94m0 7v3a2 2 0 01-2 2h-.19a19.79 19.79 0 01-8.63-3.07 19.52 19.52 0 01-6-6 19.82 19.82 0 01-3.11-8.69A2 2 0 013.93 2h3.18a2 2 0 012 1.72 13 13 0 00.7 2.81 2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 13 13 0 002.81.7A2 2 0 0122 16.92z" />
								</svg>
							</a>
							<p class="contact-price" data-text="Tư vấn ngay">
								<span>5.000.000</span>
							</p>
						</div>
					</div>
					<div class="package-item golden"  style="--bg-title: url('/wp-content/uploads/2025/06/homenest-dich-vu-thiet-ke-24-min.webp'); --color-package: #fd7401;">
						<h4 class="package-title">Golden</h4>
						<p class="package-description"><span>Gói Golden</span> nâng tầm thương hiệu, đồng nhất, ấn tượng, chuyên nghiệp hơn.</p>
						<!-- 			Nhập 8 mục đầu		 -->
						<div class="package-features-list _1">
							<div>Thiết kế logo chuyên nghiệp: 3 mẫu chọn 1</div>
							<div>Thiết kế Namecard</div>
							<div>Thiết kế thẻ nhân viên</div>
							<div>Đồng phục (Áo thun, sơmi, áo khoác)</div>
							<div>Thiết kế phong bì thư (A4,A5)</div>
							<div>Thời gian thực hiện: 5 ~ 10 ngày</div>
							<div>Chỉnh sửa không giới hạn</div>
							<div>Brand guidelines logo</div>
							<div class="hide-list">
								<div>Thiết kế kẹp Folder (Kẹp file)</div>
								<div>Thiết kế Letter Header</div>
								<div>Thiết kế profile công ty (10 trang)</div>
								<div>Thiết kế bảng hiệu công ty</div>
								<div>Bàn giao: File gốc (AI, Vector), File in ấn chất lượng cao, File PDF, File ảnh PNG, JPG</div>
								<div>Ưu đãi 10% khi thiết kế website tại Homenest</div>
							</div>

						</div>
						<button class="btn-see-more text-gradient">Xem thêm</button>
						<p class="contact-note">
							Liên hệ ngay để được tư vấn miễn phí
						</p>
						<div class="contact-btn-and-price">
							<a class="contact-button">
								<svg 
									 xmlns="http://www.w3.org/2000/svg"
									 width="24"
									 height="24"
									 viewBox="0 0 24 24"
									 fill="none"
									 stroke="#fff"
									 stroke-width="2"
									 stroke-linecap="round"
									 stroke-linejoin="round"
									 >
									<path d="M14.05 6A5 5 0 0118 10m-3.95-8a9 9 0 018 7.94m0 7v3a2 2 0 01-2 2h-.19a19.79 19.79 0 01-8.63-3.07 19.52 19.52 0 01-6-6 19.82 19.82 0 01-3.11-8.69A2 2 0 013.93 2h3.18a2 2 0 012 1.72 13 13 0 00.7 2.81 2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 13 13 0 002.81.7A2 2 0 0122 16.92z" />
								</svg>
							</a>
							<p class="contact-price" data-text="Tư vấn ngay">
								<span>10.000.000</span>
							</p>
						</div>
					</div>
					<div class="package-item diamond" style="--bg-title: url('/wp-content/uploads/2025/06/homenest-dich-vu-thiet-ke-25-min.webp'); --color-package: #020c6a;">
						<h4 class="package-title">Diamond</h4>
						<p class="package-description"><span>Gói Diamond</span> khẳng định vị thế, nhận diện mạnh mẽ, đồng bộ, dẫn đầu thị trường.</p>
						<div class="package-features-list _1">
							<div>Thiết kế logo chuyên nghiệp: 5 mẫu chọn 1</div>
							<div>Thiết kế Namecard</div>
							<div>Thiết kế thẻ nhân viên</div>
							<div>Thiết kế phong bì thư (A4,A5)</div>
							<div>Đồng phục (Áo thun, sơmi, áo khoác)</div>
							<div>Thời gian thực hiện: 10 ~ 15 ngày</div>
							<div>Chỉnh sửa không giới hạn</div>
							<div>Brand guidelines logo</div>
							<div class="hide-list">
								<div>Thiết kế kẹp Folder (Kẹp file)</div>
								<div>Thiết kế Letter Header</div>
								<div>Thiết kế profile công ty (15 trang)</div>
								<div>Thiết kế bảng hiệu công ty</div>
								<div>Thiết kế tờ rơi</div>
								<div>Thiết kế Backdrop</div>
								<div>Thiết kế tiêu đề thư</div>
								<div>Bàn giao: File gốc (AI, Vector), File in ấn chất lượng cao, File PDF, File ảnh PNG, JPG</div>
								<div>Ưu đãi 15% dịch vụ khác tại Homenest</div>
							</div>


						</div>
						<button class="btn-see-more text-gradient">Xem thêm</button>
						<p class="contact-note">
							Liên hệ ngay để được tư vấn miễn phí
						</p>
						<div class="contact-btn-and-price">
							<a class="contact-button">
								<svg 
									 xmlns="http://www.w3.org/2000/svg"
									 width="24"
									 height="24"
									 viewBox="0 0 24 24"
									 fill="none"
									 stroke="#fff"
									 stroke-width="2"
									 stroke-linecap="round"
									 stroke-linejoin="round"
									 >
									<path d="M14.05 6A5 5 0 0118 10m-3.95-8a9 9 0 018 7.94m0 7v3a2 2 0 01-2 2h-.19a19.79 19.79 0 01-8.63-3.07 19.52 19.52 0 01-6-6 19.82 19.82 0 01-3.11-8.69A2 2 0 013.93 2h3.18a2 2 0 012 1.72 13 13 0 00.7 2.81 2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 13 13 0 002.81.7A2 2 0 0122 16.92z" />
								</svg>
							</a>
							<p class="contact-price" data-text="Tư vấn ngay">
								<span>15.000.000</span>
							</p>
						</div>
					</div>
					<div class="package-item platinum" style="--bg-title: url('/wp-content/uploads/2025/06/homenest-dich-vu-thiet-ke-26-min.webp'); --color-package: #972295;">
						<h4 class="package-title">Platinum</h4>
						<p class="package-description"><span>Gói Platinum</span> độc quyền, sang trọng, linh hoạt, phản ánh giá trị doanh nghiệp.</p>
						<div class="package-features-list ">
							<div>Thiết kế logo chuyên nghiệp: Linh hoạt điều chỉnh</div>
							<div>Thiết kế Namecard</div>
							<div>Thiết kế thẻ nhân viên</div>
							<div>Thiết kế phong bì thư</div>
							<div>Thời gian thực hiện:</div>
							<div>Chỉnh sửa không giới hạn</div>
							<div>Brand guidelines logo</div>
							<div>Thiết kế kẹp Folder (Kẹp file)</div>
							<div class="hide-list">
								<div>Thiết kế Letter Header</div>
								<div>Gói dịch vụ linh hoạt – Xây dựng theo từng nhu cầu riêng của bạn</div>
								<div>Bàn giao: File gốc (AI, Vector), File in ấn chất lượng cao, File PDF, File ảnh PNG, JPG</div>
							</div>


						</div>
						<button class="btn-see-more text-gradient">Xem thêm</button>
						<p class="contact-note">
							Liên hệ ngay để được tư vấn miễn phí
						</p>
						<div class="contact-btn-and-price">
							<a class="contact-button">
								<svg 
									 xmlns="http://www.w3.org/2000/svg"
									 width="24"
									 height="24"
									 viewBox="0 0 24 24"
									 fill="none"
									 stroke="#fff"
									 stroke-width="2"
									 stroke-linecap="round"
									 stroke-linejoin="round"
									 >
									<path d="M14.05 6A5 5 0 0118 10m-3.95-8a9 9 0 018 7.94m0 7v3a2 2 0 01-2 2h-.19a19.79 19.79 0 01-8.63-3.07 19.52 19.52 0 01-6-6 19.82 19.82 0 01-3.11-8.69A2 2 0 013.93 2h3.18a2 2 0 012 1.72 13 13 0 00.7 2.81 2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 13 13 0 002.81.7A2 2 0 0122 16.92z" />
								</svg>
							</a>
							<p class="contact-price" data-text="Tư vấn ngay">
								<span>Linh hoạt</span>
							</p>
						</div>
					</div>
				</div>
			</div>
		</section>




		<div class="homenest__single-service__seo-tu-khoa__faq">
			<div class="homenest__single-service__seo-tu-khoa__faq-container">
				<div class="homenest__single-service__seo-tu-khoa__faq-title-wrapper">
					<h2 class="homenest__single-service__seo-tu-khoa__faq-title text-gradient">CÂU HỎI THƯỜNG GẶP</h2>
				</div>
				<div id="homenest__single-service__seo-tu-khoa__faq-container"></div>
			</div>
		</div>





		<section class="homenest__single-services__reviews">
			<div class="boxed">
				<p>HomeNest Media</p>
				<h2>Khách hàng nói gì về <span class="text-gradient">HomeNest</span></h2>
				<div>
					<div class="col1">
						<div class="elementor">
							<div class="testimonial-carousell">
								<div class="container">
									<div class="scroll-container">
										<div class="testimonial-circle-container" id="circleContainer">
											<!-- Changed from .circle-container -->
											<section class="section">
												<div class="content">
													<div class="quote-icon">
														<svg fill="#000000" viewBox="0 0 64 64" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" xmlns:serif="http://www.serif.com/" style="fill-rule: evenodd; clip-rule: evenodd; stroke-linejoin: round; stroke-miterlimit: 2">
															<path
																  id="quote-1"
																  d="M27.194,12l0,8.025c-2.537,0.14 -4.458,0.603 -5.761,1.39c-1.304,0.787 -2.22,2.063 -2.749,3.829c-0.528,1.766 -0.793,4.292 -0.793,7.579l9.303,0l0,19.145l-19.081,0l0,-18.201c0,-7.518 1.612,-13.025 4.836,-16.522c3.225,-3.497 7.973,-5.245 14.245,-5.245Zm28.806,0l0,8.025c-2.537,0.14 -4.457,0.586 -5.761,1.338c-1.304,0.751 -2.247,2.028 -2.828,3.829c-0.581,1.8 -0.872,4.344 -0.872,7.631l9.461,0l0,19.145l-19.186,0l0,-18.201c0,-7.518 1.603,-13.025 4.809,-16.522c3.207,-3.497 7.999,-5.245 14.377,-5.245Z"
																  />
														</svg>
													</div>
													<img src="/wp-content/uploads/2025/03/4-1-e1742551885654.webp" alt="John Doe" class="avatar" />
													<div class="user-info">
														<div class="user-header">
															<h3>Chị Lan</h3>
															<span class="job-title">Chủ thương hiệu thời trang</span>
														</div>
														<p class="testimonial">"Quy trình làm việc bài bản, chuyên nghiệp, giúp tôi hiểu rõ hơn về xây dựng thương hiệu."</p>
													</div>
												</div>
											</section>

											<section class="section">
												<div class="content">
													<div class="quote-icon">
														<svg fill="#000000" viewBox="0 0 64 64" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" xmlns:serif="http://www.serif.com/" style="fill-rule: evenodd; clip-rule: evenodd; stroke-linejoin: round; stroke-miterlimit: 2">
															<path
																  id="quote-1"
																  d="M27.194,12l0,8.025c-2.537,0.14 -4.458,0.603 -5.761,1.39c-1.304,0.787 -2.22,2.063 -2.749,3.829c-0.528,1.766 -0.793,4.292 -0.793,7.579l9.303,0l0,19.145l-19.081,0l0,-18.201c0,-7.518 1.612,-13.025 4.836,-16.522c3.225,-3.497 7.973,-5.245 14.245,-5.245Zm28.806,0l0,8.025c-2.537,0.14 -4.457,0.586 -5.761,1.338c-1.304,0.751 -2.247,2.028 -2.828,3.829c-0.581,1.8 -0.872,4.344 -0.872,7.631l9.461,0l0,19.145l-19.186,0l0,-18.201c0,-7.518 1.603,-13.025 4.809,-16.522c3.207,-3.497 7.999,-5.245 14.377,-5.245Z"
																  />
														</svg>
													</div>
													<img src="/wp-content/uploads/2025/03/3-2-scaled-e1742551979244.webp" alt="Jane Smith" class="avatar" />
													<div class="user-info">
														<div class="user-header">
															<h3>Chị My</h3>
															<span class="job-title">Chủ thương hiệu mỹ phẩm hữu cơ</span>
														</div>
														<p class="testimonial">"Logo không chỉ đẹp mà còn có ý nghĩa sâu sắc, giúp thương hiệu tôi nổi bật hơn." </p>
													</div>
												</div>
											</section>

											<section class="section">
												<div class="content">
													<div class="quote-icon">
														<svg fill="#000000" viewBox="0 0 64 64" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" xmlns:serif="http://www.serif.com/" style="fill-rule: evenodd; clip-rule: evenodd; stroke-linejoin: round; stroke-miterlimit: 2">
															<path
																  id="quote-1"
																  d="M27.194,12l0,8.025c-2.537,0.14 -4.458,0.603 -5.761,1.39c-1.304,0.787 -2.22,2.063 -2.749,3.829c-0.528,1.766 -0.793,4.292 -0.793,7.579l9.303,0l0,19.145l-19.081,0l0,-18.201c0,-7.518 1.612,-13.025 4.836,-16.522c3.225,-3.497 7.973,-5.245 14.245,-5.245Zm28.806,0l0,8.025c-2.537,0.14 -4.457,0.586 -5.761,1.338c-1.304,0.751 -2.247,2.028 -2.828,3.829c-0.581,1.8 -0.872,4.344 -0.872,7.631l9.461,0l0,19.145l-19.186,0l0,-18.201c0,-7.518 1.603,-13.025 4.809,-16.522c3.207,-3.497 7.999,-5.245 14.377,-5.245Z"
																  />
														</svg>
													</div>
													<img src="/wp-content/uploads/2025/03/2-2-e1742551684809.webp" class="avatar" />
													<div class="user-info">
														<div class="user-header">
															<h3>Anh Quang</h3>
															<span class="job-title">Founder Cửa hàng Nội thất</span>
														</div>
														<p class="testimonial">"Thiết kế không chỉ đẹp mà còn dễ sử dụng trên mọi nền tảng. Tôi cực kỳ hài lòng!"</p>
													</div>
												</div>
											</section>

											<section class="section">
												<div class="content">
													<div class="quote-icon">
														<svg fill="#000000" viewBox="0 0 64 64" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" xmlns:serif="http://www.serif.com/" style="fill-rule: evenodd; clip-rule: evenodd; stroke-linejoin: round; stroke-miterlimit: 2">
															<path
																  id="quote-1"
																  d="M27.194,12l0,8.025c-2.537,0.14 -4.458,0.603 -5.761,1.39c-1.304,0.787 -2.22,2.063 -2.749,3.829c-0.528,1.766 -0.793,4.292 -0.793,7.579l9.303,0l0,19.145l-19.081,0l0,-18.201c0,-7.518 1.612,-13.025 4.836,-16.522c3.225,-3.497 7.973,-5.245 14.245,-5.245Zm28.806,0l0,8.025c-2.537,0.14 -4.457,0.586 -5.761,1.338c-1.304,0.751 -2.247,2.028 -2.828,3.829c-0.581,1.8 -0.872,4.344 -0.872,7.631l9.461,0l0,19.145l-19.186,0l0,-18.201c0,-7.518 1.603,-13.025 4.809,-16.522c3.207,-3.497 7.999,-5.245 14.377,-5.245Z"
																  />
														</svg>
													</div>
													<img src="/wp-content/uploads/2025/03/1-2-e1742551402855.webp" class="avatar" />
													<div class="user-info">
														<div class="user-header">
															<h3>Anh Huy</h3>
															<span class="job-title">CEO Startup Công Nghệ</span>
														</div>
														<p class="testimonial">"HomeNest lắng nghe ý tưởng, thiết kế logo sáng tạo, chuyên nghiệp, đúng tinh thần thương hiệu chúng tôi"</p>
													</div>
												</div>
											</section>
										</div>
									</div>
									<div class="scroll-indicator" id="scrollIndicator"></div>
								</div>
							</div>
						</div>
					</div>
					<div class="col2">
						<img src="/wp-content/uploads/2025/05/Group-97-e1748580009420.webp" alt="">
					</div>
				</div>
			</div>
		</section>



		<section  class="homenest__single-services__brands">
			<div class="fullwidth">
				<div class="col1">
					<img src="/wp-content/uploads/2025/07/Logo_hn.webp">
				</div>
				<div class="col2">
					<h2><span class="text-gradient">Thương hiệu đồng hành</span> cùng <br>HomeNest.Media</h2>
					<div class="marquee--contain">
						<div class="marquee-item left">
							<div>
								<img src="/wp-content/uploads/2025/06/Logo_website-26-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-19-1.webp">
								<img src="/wp-content/uploads/2025/06/Logo_website-6-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-11-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-18-1.webp">
								<img src="/wp-content/uploads/2025/06/Logo_website-12-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-31-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-65-1.webp">
								<img src="/wp-content/uploads/2025/06/Logo_website-30-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-60-1.webp">
								<img src="/wp-content/uploads/2025/06/Logo_website-34-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-59-1.webp">
								<img src="/wp-content/uploads/2025/06/Logo_website-42-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-52-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-23-1.webp">
								<img src="/wp-content/uploads/2025/06/Logo_website-49-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-50-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-67-1.webp">
								<img src="/wp-content/uploads/2025/06/Logo_website-47-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-37-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-35-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-25-1.webp">
							</div>
						</div>
						<div class="marquee-item left">
							<div>
								<img src="/wp-content/uploads/2025/06/Logo_website-62-1.webp">
								<img src="/wp-content/uploads/2025/06/Logo_website-10-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-16-1.webp">
								<img src="/wp-content/uploads/2025/06/Logo_website-9-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-7-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-15-1.webp">
								<img src="/wp-content/uploads/2025/06/Logo_website-5-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-21-1.webp">
								<img src="/wp-content/uploads/2025/06/Logo_website-4-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-2-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-22-1.webp">
								<img src="/wp-content/uploads/2025/06/Logo_website-39-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-58-1.webp">
								<img src="/wp-content/uploads/2025/06/Logo_website-43-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-41-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-24-1.webp">
								<img src="/wp-content/uploads/2025/06/Logo_website-38-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-1-1.webp">
								<img src="/wp-content/uploads/2025/06/Logo_website-55-1.webp">
								<img src="/wp-content/uploads/2025/06/Logo_website-48-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-63-1.webp">
								<img src="/wp-content/uploads/2025/06/Logo_website-45-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-36-1.webp" class="rectangle">
							</div>
						</div>
						<div class="marquee-item left">
							<div>
								<img src="/wp-content/uploads/2025/06/Logo_website-53-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-17-1.webp">
								<img src="/wp-content/uploads/2025/06/Logo_website-8-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-14-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-13-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-61-1.webp">
								<img src="/wp-content/uploads/2025/06/Logo_website-27-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-3-1.webp">
								<img src="/wp-content/uploads/2025/06/Logo_website-40-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-32-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-66-1.webp">
								<img src="/wp-content/uploads/2025/06/Logo_website-34-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-57-1.webp">
								<img src="/wp-content/uploads/2025/06/Logo_website-29-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-64-1.webp">
								<img src="/wp-content/uploads/2025/06/Logo_website-28-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-51-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-46-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-56-1.webp">
								<img src="/wp-content/uploads/2025/06/Logo_website-44-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-54-1.webp" class="rectangle">
								<img src="/wp-content/uploads/2025/06/Logo_website-20-1.webp">
							</div>
						</div>
					</div>
				</div>
			</div>

		</section>

		<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>


	</main>

</body>
<?php get_footer(); ?>
