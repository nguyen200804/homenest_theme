<?php
/**
 * Template Name: Thiết kế app
 * Template Post Type: service
 */
get_header();
?>

<main class="service-wrapper">
	<section class="homenest_nexux_hero-banner">
		<div class="homenest_nexux_container">
			<div class="row-section10">
				<div class="col-xxl-12">
					<div class="homenest_nexux_heading mb-43">
						<span class="homenest_nexux_bloom"></span>
						<div class="relative z-5">
							<div class="homenest_nexux_sub-title center">
								<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-left.svg"
									 alt="subtitle">
								<p>HomeNest</p>
								<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-right.svg"
									 alt="subtitle">
							</div>
							<h1 class="homenest_nexux_title text-center wow fadeInUp animated">
								Giải pháp <br>
								Thiết kế app chuyên nghiệp
							</h1>
							<p class="homenest_nexux_text text-center letter-spacing-1 wow fadeInUp animated">
								<span class="homenest_nexux_ani-tada"></span>
								Để lại gmail để được nhận thông tin dịch vụ và tư vấn chi tiết
							</p>
						</div>
					</div>
					<div class="homenest_nexux_form-outer wow fadeInUp animated">
						<div class="homenest_nexux_form-wrap" id="subscribe-form">
							<form action="#" method="post" class="homenest_nexux_form">
								<div id="homenest_nexux_subscribe-content">
									<fieldset>
										<p>
											<input type="email" name="email-form" class="homenest_nexux_input-email"
												   placeholder="Your Email Address" required />
										</p>
									</fieldset>
									<p>
										<button type="submit" class="homenest_nexux_btn">
											<span class="homenest_nexux_overlay s1"></span>
											<span class="homenest_nexux_overlay s2"></span>
											<span class="homenest_nexux_btn-text"><span>Submit</span></span>
										</button>
									</p>
								</div>
							</form>
						</div>
						<div id="homenest_nexux_subscribe-msg" class="mb-20"></div>
					</div>
					<div class="homenest_nexux_banner wow fadeInUp animated">
						<img src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/banner.png" alt="">
					</div>
				</div>
			</div>
		</div>
		<div class="homenest_nexux_img-item item-1">
			<img src="" alt="">
		</div>
	</section>
	<section class="homenest_nexux_section2_container">
		<div class="homenest_nexux_section2_content">
			<div class="homenest_nexux_sub-title center">
				<span class="homenest_nexux_bloom2"></span>
				<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-left.svg" alt="subtitle">
				<p>Về chúng tôi</p>
				<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-right.svg" alt="subtitle">
			</div>
			<h2 id="revealText">
				<span 
class="line">Dịch vụ thiết kế app tại HomeNest</span><br>
				<span class="line">cung cấp giải pháp tối ưu, thiết kế theo yêu cầu,</span><br>
				<span class="line">bảo mật cao, giúp doanh nghiệp nâng tầm</span><br>
				<span class="line">thương hiệu trên nền tảng số.</span><br>
</h2>

			<div class="homenest_nexux_section2_button_wrapper">
				<button class="homenest_nexux_section2_button">Tìm hiểu thêm ⟶</button>
			</div>
			<div class="homenest_nexux_section2_features_subtext">
				<div class="homenest_nexux_section2_features">
					<span>➕ Cá nhân hóa</span>
					<span>✍️ Tích hợp linh hoạt</span>
					<span>✅ Tối ưu chi phí</span>
					<span>⚡ Tốc độ nhanh chóng</span>
					<span>📈 Cải thiện doanh số</span>
					<span>🧠 Hiệu quả quảng bá cao</span>
					<span>🎨 Giao diện thân thiện</span>
				</div>

				<div class="homenest_nexux_section2_subtext">
					<img decoding="async" class="wow fadeInUp  animated" data-wow-delay="0"
						 src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/access-net.svg" alt=""
						 style="visibility: visible;
animation-name: fadeInUp;">
					<img decoding="async" class="wow fade-up-diagonal animated brighter-image" data-wow-delay="0.1s"
						 src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/mouse-point.svg" alt=""
						 style="visibility: visible; animation-delay: 0.1s;
animation-name: fadeUpDiagonal;">
					<img decoding="async" class="wow fade-up-diagonal animated" data-wow-delay="0.2s"
						 src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/u-will-access.png" alt=""
						 style="visibility: visible; animation-delay: 0.2s; animation-name: fadeUpDiagonal;
width: 80px;">
				</div>
			</div>
		</div>
	</section>
	<section class="homenest_nexux_hero-banner_section3">
		<div class="homenest_nexux_container">
			<div class="row">
				<div class="col-xxl-12">
					<div class="homenest_nexux_heading mb-43">
						<span class="homenest_nexux_bloom"></span>
						<div class="relative z-5">
							<div class="homenest_nexux_sub-title center">
								<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-left.svg"
									 alt="subtitle">
								<p>Dự án</p>
								<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-right.svg"
									 alt="subtitle">
							</div>
							<h2 class="homenest_nexux_title text-center wow fadeInUp animated">
								Các dự án <br>
								Thiết kế app nổi bật
							</h2>
							<p class="homenest_nexux_text text-center letter-spacing-1 wow fadeInUp animated">
								<span class="homenest_nexux_ani-tada"></span>
								Tham khảo các dự án app nổi bật được thiết kế tại HomeNest
							</p>
						</div>
					</div>
					<div class="homenest_nexux_form-outer wow fadeInUp animated">
						<div id="homenest_nexux_subscribe-msg" class="mb-20"></div>
					</div>
					<div class="swiper-container slider-mobile-app">
						<div class="swiper-wrapper">
							<div class="swiper-slide">
								<div class="image">
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/app-1.png"
										 alt="Billing">
								</div>
							</div>
							<div class="swiper-slide">
								<div class="image">
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/app-2.png"
										 alt="AI Driven">
								</div>
							</div>
							<div class="swiper-slide">
								<div class="image">
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/app-3.png"
										 alt="Talk with Bot">
								</div>
							</div>
							<div class="swiper-slide">
								<div class="image">
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/app-4.png"
										 alt="Help Options">
								</div>
							</div>
							<div class="swiper-slide">
								<div class="image">
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/app-5.png"
										 alt="Spending">
								</div>
							</div>
							<div class="swiper-slide">
								<div class="image">
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/app-1.png"
										 
alt="Billing">
								</div>
							</div>
							<div class="swiper-slide">
								<div class="image">
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/app-2.png"
										 alt="AI Driven">
								</div>
							</div>
							<div class="swiper-slide">
								<div class="image">
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/app-3.png"
										 alt="Talk with Bot">
								</div>
							</div>
							<div class="swiper-slide">
								<div class="image">
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/app-4.png"
										 alt="Help Options">
								</div>
							</div>
							<div class="swiper-slide">
								<div class="image">
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/app-5.png"
										 alt="Spending">
								</div>
							</div>
							<div class="swiper-slide">
								<div class="image">
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/app-1.png"
										 alt="Billing">
								</div>
							</div>
							<div class="swiper-slide">
								<div class="image">
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/app-2.png"
										 alt="AI Driven">
								</div>
							</div>
							<div class="swiper-slide">
								<div class="image">
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/app-3.png"
										 alt="Talk with Bot">
								</div>
							</div>
							<div class="swiper-slide">
								<div class="image">
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/app-4.png"
										 alt="Help Options">
								</div>
							</div>
							<div class="swiper-slide">
								<div class="image">
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/app-5.png"
										 alt="Spending">
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="homenest_nexux_img-item item-1">
			<div class="homenest_nexux_section2_button_wrapper">
				<button class="homenest_nexux_section2_button">Tìm hiểu thêm ⟶</button>
			</div>
		</div>
	</section>
	<section class="homenest_nexux_hero-banner_section3">
		<div class="homenest_nexux_container">
			<div class="row">
				<div class="col-xxl-12">
					<div class="homenest_nexux_heading mb-43">
						<span class="homenest_nexux_bloom"></span>
						<div class="relative z-5">
							<div class="homenest_nexux_sub-title center">
								<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-left.svg"
									 alt="subtitle">
								<p>Lợi ích</p>
								<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-right.svg"
									 alt="subtitle">
							</div>
							<h2 class="homenest_nexux_title text-center wow fadeInUp animated">
								Lợi ích mà thiết kế app <br>
								Mang lại cho doanh nghiệp
							</h2>
							<p class="homenest_nexux_text text-center 
letter-spacing-1 wow fadeInUp animated">
								<span class="homenest_nexux_ani-tada"></span>
								Những giải pháp mà thiết kế app tại HomeNest Software mang lại cho doanh nghiệp
							</p>
						</div>
					</div>
					<div class="homenest_nexux_form-outer wow fadeInUp animated">
						<div id="homenest_nexux_subscribe-msg" class="mb-20"></div>
					</div>
				</div>
			</div>
		</div>
		<section class="homenest_nexux_section4_wrapper">
			<div class="homenest_nexux_section4_grid">

				<div class="homenest_nexux_section4_card">
					<div class="section4_icon_text_wrapper">
						<div class="section4_icon">
							<div class="icon style-circle">
								<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/bicon.svg" alt="">
							</div>
						</div>
						<div class="section4_text">
							<h3>Tiếp cận người dùng dễ dàng</h3>
							<p>Nhờ sự phổ biến của điện thoại thông minh, thiết kế app giúp doanh nghiệp mở rộng thị trường và tiếp cận hiệu quả hơn với nhiều khách hàng tiềm năng</p>
						</div>
					</div>
					<div class="homenest_nexux_section4_chart">
						<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/reseach.png" alt="">
					</div>
				</div>

				<div class="homenest_nexux_section4_card">
					<div class="section4_icon_text_wrapper">
						<div class="section4_icon">
							<div class="icon style-circle">
								<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/stack.svg" alt="">
							</div>
						</div>
						<div class="section4_text">
							<h3>Tăng nhận diện thương hiệu</h3>
							<p>Thiết kế app 
là giải pháp mạnh mẽ giúp nâng tầm nhận diện thương hiệu, duy trì tiếp thị và tăng chất lượng gắn kết với khách hàng</p>
						</div>
					</div>
					<div class="homenest_nexux_section4_chat">
						<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/powed.png" alt="">
					</div>
				</div>

				<div class="homenest_nexux_section4_card homenest_nexux_section4_fullwidth">
					<div class="section4_icon_text_wrapper section4_icon_text_column">
						<div class="section4_icon">
							<div class="icon style-circle">
								<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/fan.svg" alt="">
							</div>
						</div>
						<div class="section4_text_3">
							<h3>Giải pháp tiếp cận hàng triệu khách hàng hiệu quả</h3>
							<p>Thiết kế app tại HomeNest giúp bạn tiếp cận hàng triệu khách hàng và nâng cao nhận diện thương hiệu một cách hiệu quả</p>
						</div>
					</div>
					<div class="homenest_nexux_section4_dashboard">
						<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/dashboard.png" alt="">
					</div>
				</div>

			</div>

		</section>

		<div class="homenest_nexux_section4_cta">
			<div class="homenest_nexux_section4_text">
				<p>Click để nhận và trải nghiệm ngay demo app tại HomeNest Software</p>
			</div>
			<div class="homenest_nexux_section4_button">
				<a href="#" class="homenest_nexux_section4_demo_btn">Nhận Demo</a>
			</div>
		</div>
	</section>
	<section class="homenest_nexux_hero-banner_section3">
		<div class="homenest_nexux_container">
			<div class="row">
				<div class="col-xxl-12">
					<div class="homenest_nexux_heading mb-43">
						<span class="homenest_nexux_bloom"></span>
						<div 
class="relative z-5">
							<div class="homenest_nexux_sub-title center">
								<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-left.svg"
									 alt="subtitle">
								<p>Tại sao nên chọn chúng tôi?</p>
								<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-right.svg"
									 alt="subtitle">
							</div>
							<h2 class="homenest_nexux_title text-center wow fadeInUp animated">
								Thiết kế app chuyên nghiệp
							</h2>
							<p class="homenest_nexux_text text-center letter-spacing-1 wow fadeInUp animated">
								<span class="homenest_nexux_ani-tada"></span>
								Những điều làm nên sự khác biệt<br>
								Từ dịch vụ thiết kế app tại HomeNest Software
							</p>
						</div>
					</div>
					<div class="homenest_nexux_form-outer wow fadeInUp animated">
						<div id="homenest_nexux_subscribe-msg" class="mb-20"></div>
					</div>
				</div>
			</div>
		</div>
		<div class="homenest_nexus_section5_grid">

			<div class="homenest_nexus_section5_card">
				<h3>Độ tin cậy cao</h3>
				<p>Cam kết hoàn thành dự án đúng tiến độ, đảm bảo chất lượng và sự hài lòng cho khách hàng ngay từ khâu tu8w vấn đến triển khai</p>
			</div>

			<div class="homenest_nexus_section5_card">
				<h3>Đội ngũ giảu kinh nghiệm</h3>
				<p>Sở hữu đội ngũ kỹ sư nhiều năm làm việc trong lĩnh vực phát triển 
ứng dụng, giúp mang lại giải pháp tối ưu từng nhu cầu doanh nghiệp</p>
			</div>

			<div class="homenest_nexus_section5_card">
				<h3>Phát triển đa nền tảng</h3>
				<p>Các ứng dụng được phát triển linh hoạt trên iOS, Android và Web, giúp mở rộng tối đa tệp khách hàng tiềm năng.</p>
			</div>

			<div class="homenest_nexus_section5_card">
				<h3>Cam kết minh bạch</h3>
				<p>Mọi quy trình làm việc đều được cập nhật minh bạch, đảm bảo khách hàng có thể kiểm soát hiệu quả mọi khía cạnh của dự án</p>
			</div>

			<div class="homenest_nexus_section5_card">
				<h3>Tối ưu chi phí</h3>
				<p>Giúp tối ưu ngân sách vận hành và bảo trì, mang đến các gói dịch vụ phù hợp mà vẫn đảm bảo hiệu quả cao</p>
			</div>

			<div class="homenest_nexus_section5_card">
				<h3>Tính 
bảo mật cao</h3>
				<p>Hệ thống bảo mật được tích hợp nhiều lớp, đảm bảo an toàn dữ liệu khách hàng và ngăn ngừa mọi nguy cơ rò rỉ thông tin</p>
			</div>
</div>

	</section>
	<section class="homenest_nexux_hero-banner_section3">
		<div class="homenest_nexux_container">
			<div class="row">
				<div class="col-xxl-12">
					<div class="homenest_nexux_heading mb-43">
						<span class="homenest_nexux_bloom"></span>
						<div class="relative z-5">
							<div class="homenest_nexux_sub-title center">
								<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-left.svg"
									 alt="subtitle">
								<p>Subscription</p>
								<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-right.svg"
									 alt="subtitle">
							</div>
							<h2 class="homenest_nexux_title text-center wow fadeInUp animated">
								Get your Package
							</h2>
							<p class="homenest_nexux_text text-center letter-spacing-1 wow fadeInUp animated">
								<span class="homenest_nexux_ani-tada"></span>
								Pick your Plan and Start Unpleas yout Creativty from now
							</p>
						</div>
					</div>
					<div class="homenest_nexux_form-outer wow fadeInUp animated">
						<div id="homenest_nexux_subscribe-msg" class="mb-20"></div>
					</div>
				</div>
			</div>
		</div>
		<section class="homenest_nexux_section6_pricing">
			<div class="homenest_nexux_section6_card basic">
				<div class="homenest_nexux_section6_icon">
					<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/diamond-basic.svg"
						 alt="">
				</div>
				<h3 class="homenest_nexux_section6_title">Basic</h3>
				<p class="homenest_nexux_section6_desc">
					Harnessing the power of artificial intelligence to revolutionize industries and enhance human experiences.
</p>
				<span class="line"></span>
				<ul class="homenest_nexux_section6_features">
					<li><i class="fa fa-check" style="color: white;"></i> 30+ Features</li>
					<li><i class="fa fa-check" style="color: white;"></i> Priority Support</li>
					<li><i class="fa fa-check" style="color: white;"></i> 4 Team Members</li>
					<li><i class="fa fa-check" style="color: white;"></i> Premium Features</li>
					<li><i class="fa fa-check" style="color: white;"></i> Data Insights</li>
				</ul>
				<div class="homenest_nexux_section6_price">$39.99 <span>/per month</span></div>
				<button class="homenest_nexux_section6_btn">Get Started →</button>
			</div>

			<div class="homenest_nexux_section6_card standard featured">
				<div class="homenest_nexux_section6_icon">
					<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/diamond-standard.svg"
						 alt="">
				</div>
				<h3 class="homenest_nexux_section6_title">Standard</h3>
				<p class="homenest_nexux_section6_desc">
					Harnessing the power of artificial intelligence to revolutionize industries and enhance human experiences.
</p>
				<span class="line"></span>
				<ul class="homenest_nexux_section6_features">
					<li><i class="fa fa-check" style="color: white;"></i> 30+ Features</li>
					<li><i class="fa fa-check" style="color: white;"></i> Priority Support</li>
					<li><i class="fa fa-check" style="color: white;"></i> 4 Team Members</li>
					<li><i class="fa fa-check" style="color: white;"></i> Premium Features</li>
					<li><i class="fa fa-check" style="color: white;"></i> Data Insights</li>
				</ul>
				<div class="homenest_nexux_section6_price">$69.99 <span>/per month</span></div>
				<button class="homenest_nexux_section6_btn featured">Get Started →</button>
			</div>

			<div class="homenest_nexux_section6_card enterprise">
				<div class="homenest_nexux_section6_icon">
					<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/diamond-enterprise.svg"
						 alt="">
				</div>
				<h3 class="homenest_nexux_section6_title">Enterprise</h3>
				<p class="homenest_nexux_section6_desc">
					Harnessing the power of artificial intelligence to revolutionize industries and enhance human experiences.
</p>
				<span class="line"></span>
				<ul class="homenest_nexux_section6_features">
					<li><i class="fa fa-check" style="color: white;"></i> 30+ Features</li>
					<li><i class="fa fa-check" style="color: white;"></i> Priority Support</li>
					<li><i class="fa fa-check" style="color: white;"></i> 4 Team Members</li>
					<li><i class="fa fa-check" style="color: white;"></i> Premium Features</li>
					<li><i class="fa fa-check" style="color: white;"></i> Data Insights</li>
				</ul>
				<div class="homenest_nexux_section6_price">$89.99 <span>/per month</span></div>
				<button class="homenest_nexux_section6_btn">Contact Us →</button>
			</div>
		</section>


	</section>
	<section class="homenest_nexux_hero-banner_section3">
		<div class="homenest_nexux_container">
			<div class="row">
				<div class="col-xxl-12">
					<div class="homenest_nexux_heading mb-43">
						<span class="homenest_nexux_bloom"></span>
						<div class="relative z-5">
							<div class="homenest_nexux_sub-title center">
								<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-left.svg"
									 alt="subtitle">
								<p>Các câu hỏi thường gặp</p>
								<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-right.svg"
									 alt="subtitle">
							</div>
							<h2 class="homenest_nexux_title text-center wow fadeInUp animated">
								Bạn hỏi <br>
								HomeNest trả lời
							</h2>
							<p class="homenest_nexux_text text-center letter-spacing-1 wow fadeInUp animated">
								<span class="homenest_nexux_ani-tada"></span>
								Những câu hỏi phổ biến về dịch vụ thiết kế app chuyên nghiệp tại HomeNest
							</p>
						</div>
					</div>
					<div class="homenest_nexux_form-outer wow fadeInUp animated">
						<div id="homenest_nexux_subscribe-msg" class="mb-20"></div>
					</div>
				</div>
			</div>
		</div>
		<div class="homenest_nexux_section7_faq_wrapper">
			<div class="homenest_nexux_section7_faq_item">
				<div class="homenest_nexux_section7_faq_question">
					HomeNest 
có hỗ trợ tư vấn khi khách hàng chưa có ý tưởng cụ thể không?
					<span class="homenest_nexux_section7_faq_icon">+</span>
				</div>
				<div class="homenest_nexux_section7_faq_answer">
					Có.
HomeNest luôn đồng hành cùng khách hàng từ giai đoạn lên ý tưởng, phân tích nhu cầu đến tư vấn chức năng, thiết kế giao diện và lập kế hoạch phát triển ứng dụng phù hợp từng mô hình kinh doanh thực tế.
</div>
			</div>

			<div class="homenest_nexux_section7_faq_item">
				<div class="homenest_nexux_section7_faq_question">
					App thiết kế tại HomeNest có hoạt động trên cả iOS và Android không?
<span class="homenest_nexux_section7_faq_icon">+</span>
				</div>
				<div class="homenest_nexux_section7_faq_answer">
					Có. HomeNest cung cấp các giải pháp đa nền tảng (cross-platform), giúp ứng dụng chạy mượt mà trên cả iOS lẫn Android, tiết kiệm chi phí phát triển.
</div>
			</div>

			<div class="homenest_nexux_section7_faq_item active">
				<div class="homenest_nexux_section7_faq_question">
					Thời gian hoàn thành một dự án App là bao lâu?
<span class="homenest_nexux_section7_faq_icon">+</span>
				</div>
				<div class="homenest_nexux_section7_faq_answer">
					Tùy theo mức độ phức tạp, dự án đơn giản hoàn thiện trong khoảng 3–6 tuần.
Những app tích hợp nhiều tính năng (thanh toán, định vị, đặt lịch...) có thể kéo dài 2–3 tháng hoặc hơn.
HomeNest sẽ đưa ra mốc thời gian cụ thể trong quá trình tư vấn.
</div>
			</div>

			<div class="homenest_nexux_section7_faq_item">
				<div class="homenest_nexux_section7_faq_question">
					Sau khi bàn giao app, HomeNest có trợ bảo hành và nâng cấp không
					<span class="homenest_nexux_section7_faq_icon">+</span>
				</div>
				<div class="homenest_nexux_section7_faq_answer">
					Có.
Tất cả dự án đều kèm theo gói bảo hành từ 3–12 tháng tùy quy mô, kèm dịch vụ bảo trì dài hạn và nâng cấp tính năng định kỳ theo nhu cầu khách hàng.
</div>
			</div>

			<div class="homenest_nexux_section7_faq_item">
				<div class="homenest_nexux_section7_faq_question">
					App có tích hợp được với hệ thống  quản lý hay phần mềm khác không ?
<span class="homenest_nexux_section7_faq_icon">+</span>
				</div>
				<div class="homenest_nexux_section7_faq_answer">
					Hoàn toàn được. App có thể kết nối với CRM, ERP, POS, phần mềm kế toán, hệ thống booking, cổng thanh toán, email/SMS marketing… giúp đồng bộ dữ liệu, nâng cao hiệu quả vận hành.
</div>
			</div>

			<div class="homenest_nexux_section7_faq_item">
				<div class="homenest_nexux_section7_faq_question">
					HomeNest có giải pháp tối ưu chi phí cho startup hoặc doanh nghiệp nhỏ không ?
<span class="homenest_nexux_section7_faq_icon">+</span>
				</div>
				<div class="homenest_nexux_section7_faq_answer">
					Có. HomeNest cung cấp nhiều gói giải pháp linh hoạt, cho phép chia dự án thành từng giai đoạn (bản thử nghiệm MVP, mở rộng về sau…) để tiết kiệm chi phí đầu tư ban đầu mà vẫn đảm bảo mở rộng khi cần thiết.
</div>
			</div>

			<div class="homenest_nexux_section7_faq_item">
				<div class="homenest_nexux_section7_faq_question">
					HomeNest hỗ trợ khách hàng như thế nào sau khi kết thúc dự án ?
<span class="homenest_nexux_section7_faq_icon">+</span>
				</div>
				<div class="homenest_nexux_section7_faq_answer">
					Đội ngũ kỹ thuật của HomeNest luôn đồng hành lâu dài, hỗ trợ kỹ thuật, bảo trì, nâng cấp và cung cấp tư vấn giải pháp mới khi doanh nghiệp cần mở rộng hoặc cập nhật app.
</div>
			</div>
		</div>


	</section>
	
	
	
	
	<section class="homenest_nexux_section9_wrapper">

		
		<div class="homenest__procedure-section__container">
			<div class="homenest__procedure-section__wrapper">
				<h2 class="homenest__procedure-section__title">
					Quy trình thiết kế <br>App tại HomeNest Software
				</h2>
				<p class="homenest__procedure-section__desc">
					Tham khảo quy trình thiết kế app chuyên nghiệp tại HomeNest.
</p>
				<ul class="homenest__procedure-section__contain">

				</ul>
			</div>
		</div>
	</section>
	<section class="homenest_nexux_section10_s-indicator p-mod">
		<div class="homenest_nexux_section10_container">
			<div class="row">
				<div class="col-xxl-6"
					 style="display: flex; flex-direction: column;justify-content: center; align-items: center;">
					<div class="col-xxl-12">
						<div class="homenest_nexux_heading mb-43">
							<span class="homenest_nexux_bloom"></span>
							<div class="relative z-5">
								<div class="homenest_nexux_sub-title center">
									<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-left.svg"
										 alt="subtitle">
									<p>Các con số ấn tượng</p>
									<img src="https://wpriverthemes.com/nexux/wp-content/themes/nexux/icons/sub-title-right.svg"
										 alt="subtitle">
								</div>
								<h2 class="homenest_nexux_title_section8 text-center wow fadeInUp animated">
									HomeNest và giá trị <br>
									Đã mang lại cho khách hàng
								</h2>
								<p class="homenest_nexux_text text-center letter-spacing-1 wow fadeInUp animated">
									<span class="homenest_nexux_ani-tada"></span>
									Những con số ấn tượng mà dịch vụ thiết kế app của HomeNest đã mang lại
								</p>
							</div>
						</div>
						<div class="homenest_nexux_form-outer wow fadeInUp animated">
							<div id="homenest_nexux_subscribe-msg" class="mb-20"></div>
						</div>
					</div>

					<span class="homenest_nexux_section10_line"></span>

					<div class="homenest_nexux_section10_bot-wrap wow fadeInUp animated" data-wow-delay="0s"
						 style="visibility: visible;
animation-delay: 0s; animation-name: fadeInUp;">
						<div class="homenest_nexux_section10_rating-wrap">
							<ul class="homenest_nexux_section10_avatar-list">
								<li>
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/rate-1.jpg"
										 alt="">
								</li>
								<li>
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/rate-2.jpg"
										 alt="">
								</li>
								<li>
									<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/rate-3.png"
										 alt="">
								</li>
							</ul>
							<div class="homenest_nexux_section10_rating">
								<div class="homenest_nexux_section10_vote">
									<p>4.9/5</p>
									<div class="homenest_nexux_section10_vote-wrap">
										<span class="homenest_nexux_section8_stars">★★★★★</span>
									</div>
								</div>
								<p>99% Khách hàng hài lòng</p>
							</div>
						</div>
					</div>
				</div>

				<div class="col-xxl-6">
					<div class="homenest_nexux_section10_counter-group relative z-5">
						<div class="homenest_nexux_section10_wg-counter">
							<div class="homenest_nexux_section10_counter">
								<span class="number" data-speed="2500" data-to="10" data-inviewport="yes">10</span>
								<span></span><span>+</span>
							</div>
							<p class="homenest_nexux_section10_sub-counter">Năm kinh nghiệm</p>
						</div>

						<div class="homenest_nexux_section10_wg-counter">
							<div class="homenest_nexux_section10_counter style-2">
								<span class="number" data-speed="2500" data-to="15" data-inviewport="yes">15</span>
								<span></span><span>+</span>
							</div>
							<p class="homenest_nexux_section10_sub-counter">Quốc gia</p>
						</div>

						<div class="homenest_nexux_section10_wg-counter">
							<div class="homenest_nexux_section10_counter style-3">
								<span class="number" data-speed="2500" data-to="250" data-inviewport="yes">250</span>
								<span></span><span>+</span>
							</div>
							<p class="homenest_nexux_section10_sub-counter">Đối tác toàn cầu</p>
						</div>

						<div class="homenest_nexux_section10_wg-counter">
							<div class="homenest_nexux_section10_counter style-4">
								<span class="number" data-speed="2500" data-to="1000" data-inviewport="yes">1000</span>
								<span>+</span>
							</div>
							<p class="homenest_nexux_section10_sub-counter">Dự án đã hoàn thành</p>
						</div>
					</div>
				</div>
			</div>
		</div>

		<span class="homenest_nexux_section10_bloom item-1"></span>
		<div class="homenest_nexux_section10_s-img-item item-1">
			<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/net-10.png" alt="">
		</div>
		<div class="homenest_nexux_section10_s-img-item item-2">
			<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2024/12/net-9.png" alt="">
		</div>
	</section>
	<div class="homenest_nexux_section11_s-partner s1">
		<div class="homenest_nexux_section11_tf-container">
			<div class="row">
				<div class="col-xxl-12">
					<p class="homenest_nexux_section11_title">
						Trusted by 500+ Brands &amp;
Companies
					</p>
					<div class="homenest_nexux_section11_partner-group">
						<div class="homenest_nexux_section11_wg-partner wow fadeInLeft animated" data-wow-delay="0s">
							<a href="#">
								<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2025/04/client1.svg"
									 alt="">
							</a>
						</div>
						<div class="homenest_nexux_section11_wg-partner wow fadeInLeft animated" data-wow-delay="0.1s">
							<a href="#">
								<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2025/04/client2.svg"
									 alt="">
							</a>
						</div>
						<div class="homenest_nexux_section11_wg-partner wow fadeInLeft animated" data-wow-delay="0.2s">
							<a href="#">
								<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2025/04/client3.svg"
									 alt="">
							</a>
						</div>
						<div class="homenest_nexux_section11_wg-partner wow fadeInLeft animated" data-wow-delay="0.3s">
							<a href="#">
								<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2025/04/client4.svg"
									 alt="">
							</a>
						</div>
						<div class="homenest_nexux_section11_wg-partner wow fadeInLeft animated" data-wow-delay="0.5s">
							<a href="#">
								<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2025/04/client5.svg"
									 alt="">
							</a>
						</div>
						<div class="homenest_nexux_section11_wg-partner wow fadeInLeft animated" data-wow-delay="0.5s">
							<a href="#">
								<img decoding="async" src="https://wpriverthemes.com/nexux/wp-content/uploads/2025/04/client1.svg"
									 alt="">
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>




<script>
        // ==============================
        // Các quy trình dịch vụ nói chung (Internal)
        // ==============================
        const cacQuyTrinh = 
[
            {
                heading: "Tiếp nhận yêu cầu và tư vấn giải pháp",
                content: "HomeNest lắng nghe, thu thập đầy đủ thông tin về chức năng, giao diện, mục tiêu sử dụng… của khách hàng. Đội ngũ chuyên môn sẽ khảo sát, phân tích lĩnh vực, nghiên cứu người dùng nhằm tư vấn giải pháp phù hợp nhất và định hướng phát triển app.",
                linkImg: "/wp-content/uploads/2025/08/761d2291534b7cd6cf9fc1eaccf9f8b6-scaled-1.webp",
            },
            {
                heading: "Ký kết hợp đồng, lên kế hoạch chi tiết",
      
                content: "Khi đã thống nhất ý tưởng và chi phí, hai bên ký kết hợp đồng và HomeNest tiến hành lập kế hoạch phát triển chi tiết, phân bổ nhiệm vụ từng giai đoạn nhằm đảm bảo tiến độ dự án.",
                linkImg: "/wp-content/uploads/2025/08/761d2291534b7cd6cf9fc1eaccf9f8b6-scaled-1.webp",
            },
            {
         
                heading: "Thiết kế UI/UX & lập trình chức năng",
                content: "Đội ngũ thiết kế xây dựng giao diện (UI/UX) hiện đại, thân thiện, đồng thời các lập trình viên phát triển tính năng, đảm bảo app vận hành tốt trên đa nền tảng như iOS và Android.",
                linkImg: "/wp-content/uploads/2025/08/761d2291534b7cd6cf9fc1eaccf9f8b6-scaled-1.webp",
            },
   
          {
                heading: "Kiểm thử & hoàn thiện",
                content: "Ứng dụng được kiểm tra nghiêm ngặt về hiệu năng, bảo mật, và trải nghiệm người dùng.Những lỗi phát hiện sẽ được xử lý nhanh chóng;HomeNest sẵn sàng chỉnh sửa, tối ưu hóa theo phản hồi từ khách hàng.",
                linkImg: "/wp-content/uploads/2025/08/761d2291534b7cd6cf9fc1eaccf9f8b6-scaled-1.webp",
            },
            {
                heading: "Bàn giao & hỗ trợ vận hành",
                content: "Sau khi hoàn thiện, HomeNest bàn giao đầy đủ mã nguồn, hướng dẫn sử dụng và chuẩn bị sẵn sàng đội ngũ hỗ trợ kỹ thuật, bảo trì định kỳ, đồng hành cùng doanh nghiệp trong quá trình vận hành app.",
                linkImg: "/wp-content/uploads/2025/08/761d2291534b7cd6cf9fc1eaccf9f8b6-scaled-1.webp",
            },
        ];
    </script>





<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>



</main>

<?php get_footer(); ?>