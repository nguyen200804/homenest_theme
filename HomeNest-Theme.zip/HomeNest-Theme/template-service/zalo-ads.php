<?php
/**
 * Template Name: Zalo Ads
 * Template Post Type: service
 */
get_header(); ?>

<body>
    <div class="wp-all">
        <div class="wp-post">

            <div class="wp-post-1st">
                <div class="wp-post-1st-left">
                    <div class="wp-post-1st-left-header">
                        <div class="header-the-first-post">
                            <h2 class="header2-title">Quảng cáo <span class="highlight">Zalo ads đỉnh cao</span><br>
                                đồng
                                hành
                                cùng homenest</h2>
                        </div>
                        <div class="content-the-first-post">
                            <p>HomeNest tự hào mang đến dịch vụ quảng cáo Zalo Ads đỉnh cao, đồng hành cùng bạn
                                trong
                                việc
                                tiếp
                                cận đúng đối tượng khách hàng tiềm năng một cách nhanh chóng và hiệu quả. Chúng tôi
                                tận
                                dụng
                                tối
                                đa nền tảng Zalo mạnh mẽ để xây dựng chiến lược quảng cáo phù hợp, mang đến hiệu quả
                                vượt
                                trội
                                và gia tăng tỉ lệ chuyển đổi. Với
                                <a href="https://homenest.com.vn/" title="HomeNest"
                                    style="text-decoration: none;">HomeNest</a>, bạn hoàn toàn có thể tin
                                tưởng
                                vào giải pháp tối ưu và kết quả bền vững cho chiến dịch quảng cáo của mình.
                            </p>
                        </div>
                        <div class="elementor-icon-list-items">
                            <ul>
                                <li class="elementor-icon-list-item">
                                    <span class="elementor-icon-list-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                            viewBox="0 0 24 24">
                                            <path d="M10 3.85352H3V10.8535H10V3.85352Z" stroke="#1A85F8"
                                                stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                fill="white"></path>
                                            <path d="M21 3.85352H14V10.8535H21V3.85352Z" stroke="#1A85F8"
                                                stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                fill="white"></path>
                                            <path d="M21 14.8535H14V21.8535H21V14.8535Z" stroke="#1A85F8"
                                                stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                fill="white"></path>
                                            <path d="M10 14.8535H3V21.8535H10V14.8535Z" stroke="#1A85F8"
                                                stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                fill="white"></path>
                                        </svg>

                                    </span>
                                    <span class="elementor-icon-list-text">HomeNest – Quảng cáo Zalo hiệu quả, dẫn
                                        đầu
                                        xu
                                        hướng.</span>
                                </li>
                                <li class="elementor-icon-list-item">
                                    <span class="elementor-icon-list-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                            viewBox="0 0 24 24">
                                            <path d="M10 3.85352H3V10.8535H10V3.85352Z" stroke="#1A85F8"
                                                stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                fill="white"></path>
                                            <path d="M21 3.85352H14V10.8535H21V3.85352Z" stroke="#1A85F8"
                                                stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                fill="white"></path>
                                            <path d="M21 14.8535H14V21.8535H21V14.8535Z" stroke="#1A85F8"
                                                stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                fill="white"></path>
                                            <path d="M10 14.8535H3V21.8535H10V14.8535Z" stroke="#1A85F8"
                                                stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                fill="white"></path>
                                        </svg>

                                    </span>
                                    <span class="elementor-icon-list-text">Tăng tốc chiến dịch với Zalo Ads từ
                                        HomeNest.</span>
                                </li>
                                <li class="elementor-icon-list-item">
                                    <span class="elementor-icon-list-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                            viewBox="0 0 24 24">
                                            <path d="M10 3.85352H3V10.8535H10V3.85352Z" stroke="#1A85F8"
                                                stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                fill="white"></path>
                                            <path d="M21 3.85352H14V10.8535H21V3.85352Z" stroke="#1A85F8"
                                                stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                fill="white"></path>
                                            <path d="M21 14.8535H14V21.8535H21V14.8535Z" stroke="#1A85F8"
                                                stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                fill="white"></path>
                                            <path d="M10 14.8535H3V21.8535H10V14.8535Z" stroke="#1A85F8"
                                                stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                fill="white"></path>
                                        </svg>

                                    </span>
                                    <span class="elementor-icon-list-text">Đưa thương hiệu bạn chạm đến mọi khách
                                        hàng
                                        Zalo.</span>
                                </li>
                                <li class="elementor-icon-list-item">
                                    <span class="elementor-icon-list-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                            viewBox="0 0 24 24">
                                            <path d="M10 3.85352H3V10.8535H10V3.85352Z" stroke="#1A85F8"
                                                stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                fill="white"></path>
                                            <path d="M21 3.85352H14V10.8535H21V3.85352Z" stroke="#1A85F8"
                                                stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                fill="white"></path>
                                            <path d="M21 14.8535H14V21.8535H21V14.8535Z" stroke="#1A85F8"
                                                stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                fill="white"></path>
                                            <path d="M10 14.8535H3V21.8535H10V14.8535Z" stroke="#1A85F8"
                                                stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                fill="white"></path>
                                        </svg>

                                    </span>
                                    <span class="elementor-icon-list-text">Zalo Ads tối ưu, kết quả vượt
                                        trội.</span>
                                </li>
                            </ul>
                        </div>
                        <a class="elementor-button" href="#">
                            <span class="elementor-button-content-wrapper">
                                <span class="elementor-button-text">Đăng ký nhận báo giá</span>
                            </span>
                        </a>

                    </div>
                </div>
                <div class="wp-post-1st-right"> <img src="/wp-content/uploads/2025/06/zalo-ads.webp" width="622"
                        height="767" alt="" loading="lazy"></div>
            </div>
            <div class="wp-post-2st"><img src="https://homenest.com.vn/dich-vu/quang-cao-zalo-ads/" alt=""></div>
            <div class="img-overlay-1-1">
                <img src="/wp-content/uploads/2025/05/Vector-1-1.webp" alt="">
            </div>
            <div class="img-overlay-1-2"> <img src="/wp-content/uploads/2025/05/Vector-1.webp" alt="">
            </div>
            <div class="img-overlay-1-3"> <img src=/wp-content/uploads/2025/05/Vector1.webp alt="">
            </div>
        </div>
        <div class="wp-post-2nd">
            <div class="img-wrapper">
                <img src="https://homenest.com.vn/wp-content/uploads/2024/11/703c0e300b2556a0379d5f7e742ce90a.webp"
                    width="100%" height="480" alt="">

            </div>
        </div>
        <!-- wrapper 3 -->
        <div class="wp-post-container"
            style="margin-top: 80px;margin-right: 0px; display: flex; justify-content: center; background: linear-gradient(180deg, #ffffff 0%, #e0f7fa 50%, #ffffff 100%);">
            <div class="overlay__img_1">
                <img src="https://homenest.com.vn/wp-content/uploads/2024/11/Vector1-1-1.svg" alt=""
                    style="filter: blur(220px);">
            </div>
            <div class="overlay__img_2">
                <img src="https://homenest.com.vn/wp-content/uploads/2024/11/Vector-5.svg" width="300" height="300"
                    style="filter: blur(200px);" alt="">
            </div>
            <div class="overlay__img_3">
                <img src="https://homenest.com.vn/wp-content/uploads/2024/11/Vector-5.svg" width="457" height="514.25"
                    alt="">
            </div>
            <div class="overlay__img_4">
                <img src="https://homenest.com.vn/wp-content/uploads/2024/11/Vector1-4.svg" width="300" height="300"
                    style="filter: blur(100px);" alt="">
            </div>
            <div class="wp-post-content" style="margin-left: 0px;">
                <div class="wp-post-3">
                    <div class="wp-post-3-header">
                        <h2 class="title">Vì sao doanh nghiệp
                            <br>
                            <span class="highlight" style="margin-left: 0;">Nên sử dụng Zalo ads ?</span>
                        </h2>
                    </div>
                    <div class="wp-post-3-gird-list">

                        <div class="wp-post-3-gird">
                            <div class="wp-post-3-content">
                                <div class="wp-post-3-description">
                                    <h3><span>Tiếp cân khác hàng tìm năng</span></h3>
                                </div>
                                <p>Zalo có hàng chục triệu người dùng tại Việt Nam, giúp doanh nghiệp dễ dàng
                                    tiếp
                                    cận
                                    đúng
                                    đối
                                    tượng.</p>
                            </div>
                        </div>

                        <div class="wp-post-3-gird">
                            <div class="wp-post-3-content">
                                <div class="wp-post-3-description">
                                    <h3><span>Tỉ lệ tương tác cao</span></h3>
                                </div>

                                <p>
                                    Nền tảng Zalo có mức độ tin cậy cao, giúp quảng cáo đạt tỷ lệ tương tác tốt. </p>
                            </div>
                        </div>
                        <div class="wp-post-3-gird">
                            <div class="wp-post-3-content">
                                <div class="wp-post-3-description">
                                    <h3><span>Chi phí cạnh tranh</span></h3>
                                </div>

                                <p>
                                    Quảng cáo Zalo có chi phí hợp lý, tối ưu hóa ngân sách hiệu quả. </p>
                            </div>
                        </div>
                        <div class="wp-post-3-gird">
                            <div class="wp-post-3-content">
                                <div class="wp-post-3-description">
                                    <h3><span>Nhắm mục tiêu chính xác</span></h3>
                                </div>

                                <p>
                                    Công cụ Zalo Ads cho phép nhắm đúng đối tượng theo vị trí, sở thích và hành vi. </p>
                            </div>
                        </div>
                    </div>

                    <div class="img-wrapper-3">
                        <img src="https://homenest.com.vn/wp-content/uploads/2024/11/Group-1203-1.png" alt="">
                    </div>
                </div>
            </div>

        </div>
        <!-- wrapper 4 -->
        <div class="wp-post-container" style="margin-bottom: 100px; padding: 0 128px;">
            <div class="wp-post-4" style="margin-top: 130px;">
                <div class="post_4_overlay_img">
                    <img src="https://homenest.com.vn/wp-content/uploads/2024/11/Group-1221.png" width="180"
                        height="160" alt="">
                </div>
                <div class="wp-post-4-header">
                    <h2 class="title">các gói dịch vụ <span class="highlight">zalo ads</span></h2>

                </div>
                <div class="swiper mySwiper">
                    <div class="swiper-wrapper">

                        <!-- basic -->
                        <div class="swiper-slide">
                            <div class="pricing-card">
                                <div class="pricing-header-image-basic">
                                    <h3>BASIC</h3>
                                </div>
                                <div class="pricing-header">
                                    <p> <span
                                            style=" font-size: 16px; font-weight: 500; color: rgb(45, 181, 177); margin-bottom: 8px;">Gói
                                            Basic</span>
                                        tại HomeNest mang đến website chuyên nghiệp và chỉnh chu</p>
                                </div>

                                <ul class="pricing-features">
                                    <!-- 5 mục hiển thị sẵn -->
                                    <li>
                                        <span class="svg-placeholder-basic"></span>
                                        <p>Giao diện đa dạng có sẵn theo các mẫu</p>
                                    </li>
                                    <li>
                                        <span class="svg-placeholder-basic"></span>
                                        <p>Đầy đủ chức năng cơ bản</p>
                                    </li>
                                    <li>
                                        <span class="svg-placeholder-basic"></span>
                                        <p>Thiết kế chuẩn SEO</p>
                                    </li>
                                    <li>
                                        <span class="svg-placeholder-basic"></span>
                                        <p>Công cụ hỗ trợ SEO Google</p>
                                    </li>
                                    <li>
                                        <span class="svg-placeholder-basic"></span>
                                        <p>Hướng dẫn quản trị website</p>
                                    </li>

                                    <!-- Các mục ẩn (ẩn mặc định qua class) -->
                                    <li class="more-feature-item basic-more">
                                        <span class="svg-placeholder-basic"></span>
                                        <p>Hỗ trợ live chat, fanpage, Google map...</p>
                                    </li>
                                    <li class="more-feature-item basic-more">
                                        <span class="svg-placeholder-basic"></span>
                                        <p>Miễn phí bảo mật SSL năm đầu</p>
                                    </li>
                                    <li class="more-feature-item basic-more">
                                        <span class="svg-placeholder-basic"></span>
                                        <p>Bàn giao mã nguồn (Source code) và tên miền hosting sau khi hoàn thiện
                                        </p>
                                    </li>
                                    <li class="more-feature-item basic-more">
                                        <span class="svg-placeholder-basic"></span>
                                        <p>Thời gian hoàn thiện trong 5 ngày làm việc</p>
                                    </li>

                                    <!-- BASIC -->
                                    <li class="click-more-li-basic" data-bottom-open="10px" data-bottom-close="0">
                                        <a href="javascript:void(0);" onclick="toggleMore('.basic-more', this)"
                                            style="display: flex; text-decoration: none; align-items: center; justify-content: flex-start;">
                                            <span class="svg-placeholder-basic"></span>
                                            <p class="card-link-read-more toggle-text"
                                                style="color: orange; font-weight: 300; margin: 0 0 0 8px;">
                                                Xem thêm
                                            </p>
                                        </a>
                                    </li>

                                </ul>
                                <p class="free-contact">*Liên hệ ngay để được tư vấn miễn phí</p>

                                <div class="pricing-footer">
                                    <a href="#" class="cta-button"><img
                                            src="/wp-content/uploads/2025/06/phone-call.webp" alt=""></a>

                                    <div class="price"
                                        style="color:rgb(45, 181, 177);font-size: 20px; font-style: normal; font-weight: 700;">
                                        <div class="button-price-before"> 5–10 Triệu
                                        </div>
                                        <div class="button-price-after">Tư vấn ngay</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- golden -->
                        <div class="swiper-slide">
                            <div class="pricing-card">
                                <div class="pricing-header-image-golden">
                                    <h3>GOLDEN</h3>
                                </div>
                                <div class="pricing-header">
                                    <p> <span
                                            style=" font-size: 16px; font-weight: 500; color: rgb(253, 116, 1); margin-bottom: 8px;">Gói
                                            Golden</span>
                                        tại HomeNest mang đến website cao cấp với thiết kế tinh xảo</p>
                                </div>

                                <ul class="pricing-features">
                                    <!-- Các mục hiển thị sẵn -->
                                    <li><span class="svg-placeholder-golden"></span>
                                        <p>Giao diện theo mẫu hoặc theo yêu cầu</p>
                                    </li>
                                    <li><span class="svg-placeholder-golden"></span>
                                        <p>Chức năng nâng cao</p>
                                    </li>
                                    <li><span class="svg-placeholder-golden"></span>
                                        <p>Website song ngữ</p>
                                    </li>
                                    <li><span class="svg-placeholder-golden"></span>
                                        <p>Thiết kế chuẩn SEO</p>
                                    </li>
                                    <li><span class="svg-placeholder-golden"></span>
                                        <p>Công cụ hỗ trợ SEO Google</p>
                                    </li>

                                    <!-- Các mục ẩn ban đầu (có class để JS xử lý) -->
                                    <li class="more-feature-item golden-more">
                                        <span class="svg-placeholder-golden"></span>
                                        <p>Thiết kế Figma: 1</p>
                                    </li>
                                    <li class="more-feature-item golden-more">
                                        <span class="svg-placeholder-golden"></span>
                                        <p>Giao diện chuẩn UI/UX</p>
                                    </li>
                                    <li class="more-feature-item golden-more">
                                        <span class="svg-placeholder-golden"></span>
                                        <p>Hướng dẫn quản trị website</p>
                                    </li>
                                    <li class="more-feature-item golden-more">
                                        <span class="svg-placeholder-golden"></span>
                                        <p>Bàn giao mã nguồn (Source code) và tên miền hosting sau khi hoàn thiện
                                        </p>
                                    </li>
                                    <li class="more-feature-item golden-more">
                                        <span class="svg-placeholder-golden"></span>
                                        <p>Hỗ trợ live chat, fanpage, Google map...</p>
                                    </li>
                                    <li class="more-feature-item golden-more">
                                        <span class="svg-placeholder-golden"></span>
                                        <p>Miễn phí bảo mật SSL năm đầu</p>
                                    </li>
                                    <li class="more-feature-item golden-more">
                                        <span class="svg-placeholder-golden"></span>
                                        <p>Miễn phí tên miền .com hoặc .net năm đầu tiên</p>
                                    </li>
                                    <li class="more-feature-item golden-more">
                                        <span class="svg-placeholder-golden"></span>
                                        <p>Thời gian hoàn thiện trong 15 - 20 ngày</p>
                                    </li>

                                    <!-- GOLDEN -->
                                    <li class="click-more-li-golden" data-bottom-open="50px" data-bottom-close="0">
                                        <a href="javascript:void(0);" onclick="toggleMore('.golden-more', this)"
                                            style="display: flex; text-decoration: none; align-items: center; justify-content: flex-start;">
                                            <span class="svg-placeholder-golden"></span>
                                            <p class="card-link-read-more toggle-text"
                                                style="color: orange; font-weight: 300; margin: 0 0 0 8px;">
                                                Xem thêm
                                            </p>
                                        </a>
                                    </li>


                                </ul>
                                <p class="free-contact">*Liên hệ ngay để được tư vấn miễn phí</p>

                                <div class="pricing-footer">
                                    <a href="#" class="cta-button"><img
                                            src="/wp-content/uploads/2025/06/phone-call.webp" alt=""></a>

                                    <div class="price"
                                        style="color:rgb(253, 116, 1);font-size: 20px; font-style: normal; font-weight: 700;">
                                        <div class="button-price-before"> 11 – 20 Triệu
                                        </div>
                                        <div class="button-price-after">Tư vấn ngay</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- diamond -->
                        <div class="swiper-slide">
                            <div class="pricing-card">
                                <div class="pricing-header-image-diamond">
                                    <h3>DIAMOND</h3>
                                </div>
                                <div class="pricing-header">
                                    <p> <span
                                            style=" font-size: 16px; font-weight: 500; color: #1a237e; margin-bottom: 8px;">Gói
                                            Diamond</span>
                                        tại HomeNest cung cấp website đỉnh cao và hoàn hảo</p>
                                </div>
                                <ul class="pricing-features">
                                    <li><span class="svg-placeholder-diamond"></span>Giao diện độc quyền theo thương
                                        hiệu
                                    </li>
                                    <li><span class="svg-placeholder-diamond"></span>Chức năng theo nhu cầu</li>
                                    <li><span class="svg-placeholder-diamond"></span>Website đa ngôn ngữ</li>
                                    <li><span class="svg-placeholder-diamond"></span>Thiết kế chuẩn SEO</li>
                                    <li><span class="svg-placeholder-diamond"></span>Công cụ hỗ trợ SEO Google</li>

                                    <!-- Các mục ẩn ban đầu (có class để JS xử lý) -->
                                    <li class="more-feature-item diamond-more"><span
                                            class="svg-placeholder-diamond"></span>Thiết kế Figma: 2</li>
                                    <li class="more-feature-item diamond-more"><span
                                            class="svg-placeholder-diamond"></span>Giao diện chuẩn UI/UX</li>
                                    <li class="more-feature-item diamond-more"><span
                                            class="svg-placeholder-diamond"></span>Tối ưu SEO</li>
                                    <li class="more-feature-item diamond-more"><span
                                            class="svg-placeholder-diamond"></span>Hướng dẫn viết bài chuẩn SEO</li>
                                    <li class="more-feature-item diamond-more"><span
                                            class="svg-placeholder-diamond"></span>Content chuẩn SEO: 5 bài</li>
                                    <li class="more-feature-item diamond-more"><span
                                            class="svg-placeholder-diamond"></span>Hướng dẫn đi internal link và
                                        external
                                        link</li>
                                    <li class="more-feature-item diamond-more"><span
                                            class="svg-placeholder-diamond"></span>Hướng dẫn quản trị website</li>
                                    <li class="more-feature-item diamond-more"><span
                                            class="svg-placeholder-diamond"></span>Bàn giao mã nguồn (Source code)
                                        và
                                        tên
                                        miền hosting sau khi hoàn thiện</li>
                                    <li class="more-feature-item diamond-more"><span
                                            class="svg-placeholder-diamond"></span>Miễn phí gói hosting năm đầu</li>
                                    <li class="more-feature-item diamond-more"><span
                                            class="svg-placeholder-diamond"></span>Nút Live chat, Call now Fanpage,
                                        Google map tương tác trực tiếp</li>
                                    <li class="more-feature-item diamond-more"><span
                                            class="svg-placeholder-diamond"></span>Miễn phí bảo mật SSL năm đầu</li>
                                    <li class="more-feature-item diamond-more"><span
                                            class="svg-placeholder-diamond"></span>Miễn phí tên miền .com hoặc .net
                                        năm
                                        đầu tiên</li>
                                    <!-- DIAMOND -->
                                    <li class="click-more-li-diamond" data-bottom-open="50px" data-bottom-close="0">
                                        <a href="javascript:void(0);" onclick="toggleMore('.diamond-more', this)"
                                            style="display: flex; text-decoration: none; align-items: center; justify-content: flex-start;">
                                            <span class="svg-placeholder-diamond"></span>
                                            <p class="card-link-read-more toggle-text"
                                                style="color: orange; font-weight: 300; margin: 0 0 0 8px;">
                                                Xem thêm
                                            </p>
                                        </a>
                                    </li>
                                </ul>
                                <p class="free-contact">*Liên hệ ngay để được tư vấn miễn phí</p>

                                <div class="pricing-footer">
                                    <a href="#" class="cta-button"><img
                                            src="/wp-content/uploads/2025/06/phone-call.webp" alt=""></a>

                                    <div class="price"
                                        style="color: rgb(2, 12, 106);font-size: 20px; font-style: normal; font-weight: 700;">
                                        <div class="button-price-before"> 21 – 50 Triệu
                                        </div>
                                        <div class="button-price-after">
                                            Tư vấn ngay
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- platinum -->
                        <div class="swiper-slide">
                            <div class="pricing-card">
                                <div class="pricing-header-image-platinum">
                                    <h3>PLATINUM</h3>
                                </div>
                                <div class="pricing-header">

                                    <p> <span
                                            style="color: rgb(151, 34, 149); font-size: 16px; font-weight: 500; font-style: normal;">Gói
                                            Platinum</span> tại HomeNest cung cấp website tối ưu với thiết kế sang
                                        trọng
                                    </p>
                                </div>

                                <ul class="pricing-features">
                                    <li><span class="svg-placeholder-platinum"></span>Giao diện độc quyền theo
                                        thương
                                        hiệu</li>
                                    <li><span class="svg-placeholder-platinum"></span>Chức năng theo nhu cầu</li>
                                    <li><span class="svg-placeholder-platinum"></span>Website đa ngôn ngữ</li>
                                    <li><span class="svg-placeholder-platinum"></span>Thiết kế chuẩn SEO</li>
                                    <li><span class="svg-placeholder-platinum"></span>Công cụ hỗ trợ SEO Google</li>
                                    <!-- Các mục ẩn ban đầu -->
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Thiết kế Figma: 3</li>
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Giao diện chuẩn UI/UX</li>
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Tối ưu SEO</li>
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Hướng dẫn viết bài chuẩn SEO
                                    </li>
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Content chuẩn SEO: 10 bài</li>
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Hướng dẫn đi internal link và
                                        external link</li>
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Hướng dẫn quản trị website</li>
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Bàn giao mã nguồn (Source code)
                                        và
                                        tên miền hosting sau khi hoàn thiện</li>
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Miễn phí gói hosting năm đầu
                                    </li>
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Nút Live chat, Call now Fanpage,
                                        Google map tương tác trực tiếp</li>
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Miễn phí bảo mật SSL năm đầu
                                    </li>
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Miễn phí tên miền .com hoặc .net
                                        năm
                                        đầu tiên</li>
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Xử lý dữ liệu lớn</li>
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Hướng dẫn quảng cáo Facebook Ads
                                        hoặc Google Ads</li>
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Website thương mại điện tử và hệ
                                        thống</li>
                                    <!-- Nút xem thêm -->
                                    <li class="click-more-li-platinum" data-bottom-open="50px" data-bottom-close="0">
                                        <a href="javascript:void(0);" onclick="toggleMore('.platinum-more', this)"
                                            style="display: flex; text-decoration: none; align-items: center; justify-content: flex-start;">

                                            <span class="svg-placeholder-platinum">
                                                <!-- SVG code giữ nguyên -->
                                            </span>

                                            <p class="card-link-read-more toggle-text"
                                                style="color: orange; font-weight: 300; margin: 0 0 0 8px;">
                                                Xem thêm
                                            </p>
                                        </a>
                                    </li>
                                </ul>
                                <p class="free-contact">*Liên hệ ngay để được tư vấn miễn phí</p>

                                <div class="pricing-footer">

                                    <a href="#" class="cta-button"><img
                                            src="/wp-content/uploads/2025/06/phone-call.webp" alt=""></a>
                                    <div class="price"
                                        style="color: rgb(151, 34, 149);font-size: 20px; font-weight: 700; font-style: normal;">
                                        <div class="button-price-before"> Từ 51 Triệu</div>
                                        <div class="button-price-after">Tư vấn ngay</div>

                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- basic -->
                        <div class="swiper-slide">
                            <div class="pricing-card">
                                <div class="pricing-header-image-basic">
                                    <h3>BASIC</h3>
                                </div>
                                <div class="pricing-header">
                                    <p> <span
                                            style=" font-size: 16px; font-weight: 500; color: rgb(45, 181, 177); margin-bottom: 8px;">Gói
                                            Basic</span>
                                        tại HomeNest mang đến website chuyên nghiệp và chỉnh chu</p>
                                </div>

                                <ul class="pricing-features">
                                    <!-- 5 mục hiển thị sẵn -->
                                    <li>
                                        <span class="svg-placeholder-basic"></span>
                                        <p>Giao diện đa dạng có sẵn theo các mẫu</p>
                                    </li>
                                    <li>
                                        <span class="svg-placeholder-basic"></span>
                                        <p>Đầy đủ chức năng cơ bản</p>
                                    </li>
                                    <li>
                                        <span class="svg-placeholder-basic"></span>
                                        <p>Thiết kế chuẩn SEO</p>
                                    </li>
                                    <li>
                                        <span class="svg-placeholder-basic"></span>
                                        <p>Công cụ hỗ trợ SEO Google</p>
                                    </li>
                                    <li>
                                        <span class="svg-placeholder-basic"></span>
                                        <p>Hướng dẫn quản trị website</p>
                                    </li>

                                    <!-- Các mục ẩn (ẩn mặc định qua class) -->
                                    <li class="more-feature-item basic-more">
                                        <span class="svg-placeholder-basic"></span>
                                        <p>Hỗ trợ live chat, fanpage, Google map...</p>
                                    </li>
                                    <li class="more-feature-item basic-more">
                                        <span class="svg-placeholder-basic"></span>
                                        <p>Miễn phí bảo mật SSL năm đầu</p>
                                    </li>
                                    <li class="more-feature-item basic-more">
                                        <span class="svg-placeholder-basic"></span>
                                        <p>Bàn giao mã nguồn (Source code) và tên miền hosting sau khi hoàn thiện
                                        </p>
                                    </li>
                                    <li class="more-feature-item basic-more">
                                        <span class="svg-placeholder-basic"></span>
                                        <p>Thời gian hoàn thiện trong 5 ngày làm việc</p>
                                    </li>

                                    <!-- BASIC -->
                                    <li class="click-more-li-basic" data-bottom-open="10px" data-bottom-close="0">
                                        <a href="javascript:void(0);" onclick="toggleMore('.basic-more', this)"
                                            style="display: flex; text-decoration: none; align-items: center; justify-content: flex-start;">
                                            <span class="svg-placeholder-basic"></span>
                                            <p class="card-link-read-more toggle-text"
                                                style="color: orange; font-weight: 300; margin: 0 0 0 8px;">
                                                Xem thêm
                                            </p>
                                        </a>
                                    </li>

                                </ul>

                                <p class="free-contact">*Liên hệ ngay để được tư vấn miễn phí</p>

                                <div class="pricing-footer">
                                    <a href="#" class="cta-button"><img
                                            src="/wp-content/uploads/2025/06/phone-call.webp" alt=""></a>

                                    <div class="price"
                                        style="color:rgb(45, 181, 177);font-size: 20px; font-style: normal; font-weight: 700;">
                                        <div class="button-price-before"> 5–10 Triệu
                                        </div>
                                        <div class="button-price-after">Tư vấn ngay</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- golden -->
                        <div class="swiper-slide">
                            <div class="pricing-card">
                                <div class="pricing-header-image-golden">
                                    <h3>GOLDEN</h3>
                                </div>
                                <div class="pricing-header">
                                    <p> <span
                                            style=" font-size: 16px; font-weight: 500; color: rgb(253, 116, 1); margin-bottom: 8px;">Gói
                                            Golden</span>
                                        tại HomeNest mang đến website cao cấp với thiết kế tinh xảo</p>
                                </div>

                                <ul class="pricing-features">
                                    <!-- Các mục hiển thị sẵn -->
                                    <li><span class="svg-placeholder-golden"></span>
                                        <p>Giao diện theo mẫu hoặc theo yêu cầu</p>
                                    </li>
                                    <li><span class="svg-placeholder-golden"></span>
                                        <p>Chức năng nâng cao</p>
                                    </li>
                                    <li><span class="svg-placeholder-golden"></span>
                                        <p>Website song ngữ</p>
                                    </li>
                                    <li><span class="svg-placeholder-golden"></span>
                                        <p>Thiết kế chuẩn SEO</p>
                                    </li>
                                    <li><span class="svg-placeholder-golden"></span>
                                        <p>Công cụ hỗ trợ SEO Google</p>
                                    </li>

                                    <!-- Các mục ẩn ban đầu (có class để JS xử lý) -->
                                    <li class="more-feature-item golden-more">
                                        <span class="svg-placeholder-golden"></span>
                                        <p>Thiết kế Figma: 1</p>
                                    </li>
                                    <li class="more-feature-item golden-more">
                                        <span class="svg-placeholder-golden"></span>
                                        <p>Giao diện chuẩn UI/UX</p>
                                    </li>
                                    <li class="more-feature-item golden-more">
                                        <span class="svg-placeholder-golden"></span>
                                        <p>Hướng dẫn quản trị website</p>
                                    </li>
                                    <li class="more-feature-item golden-more">
                                        <span class="svg-placeholder-golden"></span>
                                        <p>Bàn giao mã nguồn (Source code) và tên miền hosting sau khi hoàn thiện
                                        </p>
                                    </li>
                                    <li class="more-feature-item golden-more">
                                        <span class="svg-placeholder-golden"></span>
                                        <p>Hỗ trợ live chat, fanpage, Google map...</p>
                                    </li>
                                    <li class="more-feature-item golden-more">
                                        <span class="svg-placeholder-golden"></span>
                                        <p>Miễn phí bảo mật SSL năm đầu</p>
                                    </li>
                                    <li class="more-feature-item golden-more">
                                        <span class="svg-placeholder-golden"></span>
                                        <p>Miễn phí tên miền .com hoặc .net năm đầu tiên</p>
                                    </li>
                                    <li class="more-feature-item golden-more">
                                        <span class="svg-placeholder-golden"></span>
                                        <p>Thời gian hoàn thiện trong 15 - 20 ngày</p>
                                    </li>

                                    <!-- GOLDEN -->
                                    <li class="click-more-li-golden" data-bottom-open="50px" data-bottom-close="0">
                                        <a href="javascript:void(0);" onclick="toggleMore('.golden-more', this)"
                                            style="display: flex; text-decoration: none; align-items: center; justify-content: flex-start;">
                                            <span class="svg-placeholder-golden"></span>
                                            <p class="card-link-read-more toggle-text"
                                                style="color: orange; font-weight: 300; margin: 0 0 0 8px;">
                                                Xem thêm
                                            </p>
                                        </a>
                                    </li>


                                </ul>
                                <p class="free-contact">*Liên hệ ngay để được tư vấn miễn phí</p>

                                <div class="pricing-footer">
                                    <a href="#" class="cta-button"><img
                                            src="/wp-content/uploads/2025/06/phone-call.webp" alt=""></a>

                                    <div class="price"
                                        style="color:rgb(253, 116, 1);font-size: 20px; font-style: normal; font-weight: 700;">
                                        <div class="button-price-before"> 11 – 20 Triệu
                                        </div>
                                        <div class="button-price-after">Tư vấn ngay</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- diamond -->
                        <div class="swiper-slide">
                            <div class="pricing-card">
                                <div class="pricing-header-image-diamond">
                                    <h3>DIAMOND</h3>
                                </div>
                                <div class="pricing-header">
                                    <p> <span
                                            style=" font-size: 16px; font-weight: 500; color: #1a237e; margin-bottom: 8px;">Gói
                                            Diamond</span>
                                        tại HomeNest cung cấp website đỉnh cao và hoàn hảo nhất</p>
                                </div>
                                <ul class="pricing-features">
                                    <li><span class="svg-placeholder-diamond"></span>Giao diện độc quyền theo thương
                                        hiệu
                                    </li>
                                    <li><span class="svg-placeholder-diamond"></span>Chức năng theo nhu cầu</li>
                                    <li><span class="svg-placeholder-diamond"></span>Website đa ngôn ngữ</li>
                                    <li><span class="svg-placeholder-diamond"></span>Thiết kế chuẩn SEO</li>
                                    <li><span class="svg-placeholder-diamond"></span>Công cụ hỗ trợ SEO Google</li>

                                    <!-- Các mục ẩn ban đầu (có class để JS xử lý) -->
                                    <li class="more-feature-item diamond-more"><span
                                            class="svg-placeholder-diamond"></span>Thiết kế Figma: 2</li>
                                    <li class="more-feature-item diamond-more"><span
                                            class="svg-placeholder-diamond"></span>Giao diện chuẩn UI/UX</li>
                                    <li class="more-feature-item diamond-more"><span
                                            class="svg-placeholder-diamond"></span>Tối ưu SEO</li>
                                    <li class="more-feature-item diamond-more"><span
                                            class="svg-placeholder-diamond"></span>Hướng dẫn viết bài chuẩn SEO</li>
                                    <li class="more-feature-item diamond-more"><span
                                            class="svg-placeholder-diamond"></span>Content chuẩn SEO: 5 bài</li>
                                    <li class="more-feature-item diamond-more"><span
                                            class="svg-placeholder-diamond"></span>Hướng dẫn đi internal link và
                                        external
                                        link</li>
                                    <li class="more-feature-item diamond-more"><span
                                            class="svg-placeholder-diamond"></span>Hướng dẫn quản trị website</li>
                                    <li class="more-feature-item diamond-more"><span
                                            class="svg-placeholder-diamond"></span>Bàn giao mã nguồn (Source code)
                                        và
                                        tên
                                        miền hosting sau khi hoàn thiện</li>
                                    <li class="more-feature-item diamond-more"><span
                                            class="svg-placeholder-diamond"></span>Miễn phí gói hosting năm đầu</li>
                                    <li class="more-feature-item diamond-more"><span
                                            class="svg-placeholder-diamond"></span>Nút Live chat, Call now Fanpage,
                                        Google map tương tác trực tiếp</li>
                                    <li class="more-feature-item diamond-more"><span
                                            class="svg-placeholder-diamond"></span>Miễn phí bảo mật SSL năm đầu</li>
                                    <li class="more-feature-item diamond-more"><span
                                            class="svg-placeholder-diamond"></span>Miễn phí tên miền .com hoặc .net
                                        năm
                                        đầu tiên</li>
                                    <!-- DIAMOND -->
                                    <li class="click-more-li-diamond" data-bottom-open="50px" data-bottom-close="0">
                                        <a href="javascript:void(0);" onclick="toggleMore('.diamond-more', this)"
                                            style="display: flex; text-decoration: none; align-items: center; justify-content: flex-start;">
                                            <span class="svg-placeholder-diamond"></span>
                                            <p class="card-link-read-more toggle-text"
                                                style="color: orange; font-weight: 300; margin: 0 0 0 8px;">
                                                Xem thêm
                                            </p>
                                        </a>
                                    </li>
                                </ul>
                                <p class="free-contact">*Liên hệ ngay để được tư vấn miễn phí</p>

                                <div class="pricing-footer">
                                    <a href="#" class="cta-button"><img
                                            src="/wp-content/uploads/2025/06/phone-call.webp" alt=""></a>

                                    <div class="price"
                                        style="color: rgb(2, 12, 106);font-size: 20px; font-style: normal; font-weight: 700;">
                                        <div class="button-price-before"> 21 – 50 Triệu
                                        </div>
                                        <div class="button-price-after">
                                            Tư vấn ngay
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- platinum -->
                        <div class="swiper-slide">
                            <div class="pricing-card">
                                <div class="pricing-header-image-platinum">
                                    <h3>PLATINUM</h3>
                                </div>
                                <div class="pricing-header">

                                    <p> <span
                                            style="color: rgb(151, 34, 149); font-size: 16px; font-weight: 500; font-style: normal;">Gói
                                            Platinum</span> tại HomeNest cung cấp website tối ưu với thiết kế sang
                                        trọng
                                    </p>
                                </div>

                                <ul class="pricing-features">
                                    <li><span class="svg-placeholder-platinum"></span>Giao diện độc quyền theo
                                        thương
                                        hiệu</li>
                                    <li><span class="svg-placeholder-platinum"></span>Chức năng theo nhu cầu</li>
                                    <li><span class="svg-placeholder-platinum"></span>Website đa ngôn ngữ</li>
                                    <li><span class="svg-placeholder-platinum"></span>Thiết kế chuẩn SEO</li>
                                    <li><span class="svg-placeholder-platinum"></span>Công cụ hỗ trợ SEO Google</li>
                                    <!-- Các mục ẩn ban đầu -->
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Thiết kế Figma: 3</li>
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Giao diện chuẩn UI/UX</li>
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Tối ưu SEO</li>
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Hướng dẫn viết bài chuẩn SEO
                                    </li>
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Content chuẩn SEO: 10 bài</li>
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Hướng dẫn đi internal link và
                                        external link</li>
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Hướng dẫn quản trị website</li>
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Bàn giao mã nguồn (Source code)
                                        và
                                        tên miền hosting sau khi hoàn thiện</li>
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Miễn phí gói hosting năm đầu
                                    </li>
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Nút Live chat, Call now Fanpage,
                                        Google map tương tác trực tiếp</li>
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Miễn phí bảo mật SSL năm đầu
                                    </li>
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Miễn phí tên miền .com hoặc .net
                                        năm
                                        đầu tiên</li>
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Xử lý dữ liệu lớn</li>
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Hướng dẫn quảng cáo Facebook Ads
                                        hoặc Google Ads</li>
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Website thương mại điện tử và hệ
                                        thống</li>
                                    <li class="more-feature-item platinum-more"><span
                                            class="svg-placeholder-platinum"></span>Thu hồi</li>
                                    <!-- Nút xem thêm -->
                                    <li class="click-more-li-platinum" data-bottom-open="50px" data-bottom-close="0">
                                        <a href="javascript:void(0);" onclick="toggleMore('.platinum-more', this)"
                                            style="display: flex; text-decoration: none; align-items: center; justify-content: flex-start;">

                                            <span class="svg-placeholder-platinum">
                                                <!-- SVG code giữ nguyên -->
                                            </span>

                                            <p class="card-link-read-more toggle-text"
                                                style="color: orange; font-weight: 300; margin: 0 0 0 8px;">
                                                Xem thêm
                                            </p>
                                        </a>
                                    </li>
                                </ul>
                                <p class="free-contact">*Liên hệ ngay để được tư vấn miễn phí</p>


                                <div class="pricing-footer">

                                    <a href="#" class="cta-button"><img
                                            src="/wp-content/uploads/2025/06/phone-call.webp" alt=""></a>
                                    <div class="price"
                                        style="color: rgb(151, 34, 149);font-size: 20px; font-weight: 700; font-style: normal;">
                                        <div class="button-price-before"> Từ 51 Triệu</div>
                                        <div class="button-price-after">Tư vấn ngay</div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper_button_prev__icon">
                        <img src="/wp-content/uploads/2025/06/blue_circle_arrow_left.svg" alt="blue_circle_arrow_left"
                            width="26" height="26">
                    </div>
                    <div class="swiper_button_next__icon">
                        <img src="/wp-content/uploads/2025/06/blue_circle_arrow_right.svg" alt="blue_circle_arrow_right"
                            width="26" height="26">

                    </div>

                </div>

            </div>
        </div>
        <!-- wrapper 5 -->
        <div class="wp-post-container-5">
            <div class="wp-post-5">
                <div class="wp-post-header-img">
                    <img src="https://homenest.com.vn/wp-content/uploads/2024/11/Group-1221.png" width="470.625"
                        height="411.30" alt="">
                </div>
                <div class="wp-post-header">
                    <h2 class="title_5">Tại sao chọn Homenest <br><span class="highlight">Cho dịch vụ Zalo ads
                            ?</span>
                    </h2>

                </div>
                <div class="wp-post-content-5">
                    <div class="wp-post-5-gird-list">
                        <div class="wp-post-5-gird">

                            <div class="wp-post-5-description">
                                <h3><span>Chiến lược tối ưu hóa cao</span></h3>
                            </div>

                            <p>HomeNest cung cấp chiến lược quảng cáo Zalo Ads được thiết kế đặc biệt để tối ưu
                                hóa
                                hiệu
                                quả chiến dịch, giúp bạn tiếp cận khách hàng mục tiêu nhanh chóng và hiệu quả.
                            </p>
                        </div>
                        <div class="wp-post-5-gird">

                            <div class="wp-post-5-description">
                                <h3><span>Kinh nghiệm dày dặn</span></h3>
                            </div>

                            <p>Với đội ngũ chuyên gia có kinh nghiệm, HomeNest đảm bảo quảng cáo của bạn đạt
                                được tỉ
                                lệ
                                chuyển đổi cao, tối đa hóa ngân sách và hiệu quả.</p>
                        </div>
                        <div class="wp-post-5-gird">

                            <div>
                                <div class="wp-post-5-description">
                                    <h3><span>Công cụng theo dỗi và báo cáo chi tiết</span></h3>
                                </div>
                                <p>HomeNest cung cấp các công cụ phân tích và báo cáo chi tiết giúp bạn theo dõi
                                    tiến độ
                                    chiến dịch và điều chỉnh kịp thời để đạt được kết quả tốt nhất. </p>
                            </div>
                        </div>
                        <div class="wp-post-5-gird">

                            <div class="wp-post-5-description">
                                <h3><span>Dịch vụ hỗ trợ tậm tâm</span></h3>
                            </div>

                            <p>Chúng tôi luôn đồng hành cùng khách hàng, cung cấp dịch vụ chăm sóc tận tình, từ
                                việc
                                xây
                                dựng chiến lược đến triển khai và theo dõi kết quả.</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- wrapper 6 -->
        <div class="wp-post-container-6">
            <div class="img-overlay-post-6__st1">
                <img src="https://homenest.com.vn/wp-content/uploads/2024/11/Group-1203-1.png" alt="">

            </div>
            <div class="img-overlay-post-6__st2">
                <img src="https://homenest.com.vn/wp-content/uploads/2024/11/Frame.png" alt="">
            </div>
            <div class="img-overlay-post-6__st3">
                <img src="https://homenest.com.vn/wp-content/uploads/2024/11/Group-1219-471x1024.png" alt="">
            </div>

            <div class="wp-post-content-6">
                <div class="wp-6-img-left">
                    <div class="overlay__1"></div>
                    <div class="overlay__2"></div>
                    <div class="overlay__3"></div>
                    <div class="overlay__4"></div>

                    <div class="elementor-social-icons-wrapper elementor-grid">
                        <span class="elementor-grid-item">
                            <a class="elementor-icon elementor-social-icon elementor-social-icon-Quy trình thực hiện elementor-repeater-item-a9f5489"
                                target="_blank">
                                <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 40 40"
                                    fill="none">
                                    <rect x="0.5" y="0.5" width="39" height="39" rx="7.5" stroke="#898384"></rect>
                                    <path
                                        d="M21.4602 28.5V21.0621H23.9137L24.3805 17.9822H21.4602V15.9903C21.4602 15.1498 21.87 14.3266 23.1736 14.3266H24.5V11.7072C24.5 11.7072 23.2932 11.5 22.1433 11.5C19.741 11.5 18.1698 12.9738 18.1698 15.6392V17.9822H15.5V21.0621H18.1755V28.5H21.4602Z"
                                        fill="#898384"></path>
                                </svg> </a>
                        </span>
                        <span class="elementor-grid-item">
                            <a class="elementor-icon elementor-social-icon elementor-social-icon-Quy trình thực hiện elementor-repeater-item-40e5f18"
                                target="_blank">
                                <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 40 40"
                                    fill="none">
                                    <rect x="0.5" y="0.5" width="39" height="39" rx="7.5" stroke="#898384"></rect>
                                    <path
                                        d="M24.1934 14.9082C23.6811 14.9082 23.2666 15.3227 23.2666 15.835C23.2666 16.3473 23.6811 16.7618 24.1934 16.7618C24.7057 16.7618 25.1202 16.3473 25.1202 15.835C25.1259 15.3227 24.7057 14.9082 24.1934 14.9082Z"
                                        fill="#898384"></path>
                                    <path
                                        d="M20.0659 16.0996C17.913 16.0996 16.1631 17.8495 16.1631 20.0024C16.1631 22.1553 17.913 23.9052 20.0659 23.9052C22.2188 23.9052 23.9687 22.1553 23.9687 20.0024C23.9687 17.8495 22.2188 16.0996 20.0659 16.0996ZM20.0659 22.5007C18.6901 22.5007 17.5676 21.3782 17.5676 20.0024C17.5676 18.6267 18.6901 17.5042 20.0659 17.5042C21.4417 17.5042 22.5642 18.6267 22.5642 20.0024C22.5642 21.3782 21.4417 22.5007 20.0659 22.5007Z"
                                        fill="#898384"></path>
                                    <path
                                        d="M23.1629 27.9234H16.8367C14.2118 27.9234 12.0762 25.7878 12.0762 23.1629V16.8367C12.0762 14.2118 14.2118 12.0762 16.8367 12.0762H23.1629C25.7878 12.0762 27.9234 14.2118 27.9234 16.8367V23.1629C27.9234 25.7878 25.7878 27.9234 23.1629 27.9234ZM16.8367 13.5671C15.0349 13.5671 13.5671 15.0349 13.5671 16.8367V23.1629C13.5671 24.9647 15.0349 26.4325 16.8367 26.4325H23.1629C24.9647 26.4325 26.4325 24.9647 26.4325 23.1629V16.8367C26.4325 15.0349 24.9647 13.5671 23.1629 13.5671H16.8367Z"
                                        fill="#898384"></path>
                                </svg> </a>
                        </span>
                        <span class="elementor-grid-item">
                            <a class="elementor-icon elementor-social-icon elementor-social-icon-Quy trình thực hiện elementor-repeater-item-04bf73d"
                                target="_blank">
                                <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 40 40"
                                    fill="none">
                                    <rect x="0.5" y="0.5" width="39" height="39" rx="7.5" stroke="#898384"></rect>
                                    <path
                                        d="M27.5 18.2828C27.3544 18.2943 27.2143 18.3058 27.0687 18.3058C25.4892 18.3058 24.0161 17.489 23.1535 16.1314V23.5292C23.1535 26.5494 20.7674 29 17.8267 29C14.8861 29 12.5 26.5494 12.5 23.5292C12.5 20.5091 14.8861 18.0585 17.8267 18.0585C17.9388 18.0585 18.0452 18.07 18.1572 18.0757V20.768C18.0452 20.7565 17.9388 20.7335 17.8267 20.7335C16.3256 20.7335 15.1102 21.9818 15.1102 23.5235C15.1102 25.0652 16.3256 26.3135 17.8267 26.3135C19.3279 26.3135 20.6553 25.0997 20.6553 23.558L20.6833 11H23.1927C23.4279 13.3126 25.2427 15.1189 27.5 15.2857V18.2828Z"
                                        fill="#898384"></path>
                                </svg> </a>
                        </span>
                        <span class="elementor-grid-item">
                            <a class="elementor-icon elementor-social-icon elementor-social-icon-Quy trình thực hiện elementor-repeater-item-41bf95f"
                                target="_blank">
                                <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 40 40"
                                    fill="none">
                                    <rect x="0.5" y="0.5" width="39" height="39" rx="7.5" stroke="#898384"></rect>
                                    <path
                                        d="M28.5 17.7634C28.5 15.6845 26.8296 14 24.7682 14H15.2318C13.1704 14 11.5 15.6845 11.5 17.7634V22.2366C11.5 24.3155 13.1704 26 15.2318 26H24.7682C26.8296 26 28.5 24.3155 28.5 22.2366V17.7634ZM22.8911 20.338L18.6173 22.4732C18.4497 22.5634 17.8799 22.4394 17.8799 22.2479V17.8704C17.8799 17.6732 18.4553 17.5549 18.6229 17.6507L22.7179 19.8986C22.8855 19.9944 23.0643 20.2423 22.8911 20.338Z"
                                        fill="#898384"></path>
                                </svg> </a>
                        </span>
                        <span class="elementor-grid-item">
                            <a class="elementor-icon elementor-social-icon elementor-social-icon-Quy trình thực hiện elementor-repeater-item-40c2756"
                                target="_blank">
                                <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 40 40"
                                    fill="none">
                                    <rect x="0.5" y="0.5" width="39" height="39" rx="7.5" stroke="#898384"></rect>
                                    <path
                                        d="M12.3816 17.3608H15.6512V27.8546H12.3816V17.3608ZM14.0164 12.1455C15.0641 12.1455 15.9103 12.9917 15.9103 14.0336C15.9103 15.0755 15.0641 15.9274 14.0164 15.9274C12.9688 15.9274 12.1226 15.0813 12.1226 14.0336C12.1226 12.9917 12.9688 12.1455 14.0164 12.1455Z"
                                        fill="#898384"></path>
                                    <path
                                        d="M17.7007 17.3605H20.8321V18.7938H20.8724C21.3099 17.9707 22.3749 17.0957 23.9636 17.0957C27.2678 17.0957 27.8779 19.2659 27.8779 22.098V27.8543H24.6198V22.7484C24.6198 21.5281 24.5968 19.9624 22.9217 19.9624C21.2236 19.9624 20.9645 21.2863 20.9645 22.6563V27.8486H17.7064V17.3605H17.7007Z"
                                        fill="#898384"></path>
                                </svg> </a>
                        </span>
                    </div>
                </div>
                <div class="wp-post-content-6-left">
                    <div class="wp-post-connet-wight-80">
                        <div class="wp-post-6-content-header">
                            <div class="tpye-website">
                                <p>Website</p>
                            </div>
                            <h2 class="heading_stroke">homenest</h2>
                        </div>
                        <div class="wp-post-6-content-header-body">
                            <h2 class="title-6">quy trình thực hiện<br><span class="highlight">thiết kế website
                                    chuyên
                                    nghiệp</span></h2>
                        </div>
                        <div class="column-wrapper-list">
                            <!-- 1 -->
                            <div class="column-wrapper ">
                                <div class="elementor-icon-box-icon">
                                    <span class="elementor-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="130" height="130"
                                            viewBox="0 0 185 114" fill="none">
                                            <defs>
                                                <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="0%">
                                                    <stop offset="0%" stop-color="#020c6a" />
                                                    <stop offset="50%" stop-color="#1a85f8" />
                                                    <stop offset="100%" stop-color="#66e5fb" />
                                                </linearGradient>
                                            </defs>

                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                d="M157.512 110.9H183.384V3.10009H143.036V25.7381H157.512V110.9ZM156.512 26.7381V111.9H184.384V2.1001H142.036V26.7381H156.512Z"
                                                fill="url(#grad1)"></path>
                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                d="M47.123 98.2285C39.985 88.5073 36.2261 74.45 36.2261 56.9999C36.2261 39.5497 39.985 25.4924 47.123 15.7713C54.2904 6.01017 64.7999 0.713867 78.0361 0.713867C91.1974 0.713867 101.668 6.01183 108.815 15.7723C115.933 25.493 119.692 39.5496 119.692 56.9999C119.692 74.4501 115.933 88.5067 108.815 98.2274C101.668 107.988 91.1974 113.286 78.0361 113.286C64.7999 113.286 54.2904 107.99 47.123 98.2285ZM68.063 79.2471C70.5783 84.5386 74.0395 87.2619 78.0361 87.2619C81.8687 87.2619 85.2951 84.5516 87.8167 79.2471C90.3302 73.9594 91.8201 66.3051 91.8201 56.9999C91.8201 47.6946 90.3302 40.0404 87.8167 34.7527C85.2951 29.4481 81.8687 26.7379 78.0361 26.7379C74.0395 26.7379 70.5783 29.4612 68.063 34.7527C65.5506 40.0379 64.0981 47.6906 64.0981 56.9999C64.0981 66.3091 65.5506 73.9618 68.063 79.2471ZM37.2261 56.9999C37.2261 91.6499 52.1641 112.286 78.0361 112.286C103.754 112.286 118.692 91.6499 118.692 56.9999C118.692 22.3499 103.754 1.71387 78.0361 1.71387C52.1641 1.71387 37.2261 22.3499 37.2261 56.9999ZM78.0361 88.2619C68.9501 88.2619 63.0981 75.7879 63.0981 56.9999C63.0981 38.2119 68.9501 25.7379 78.0361 25.7379C86.8141 25.7379 92.8201 38.2119 92.8201 56.9999C92.8201 75.7879 86.8141 88.2619 78.0361 88.2619Z"
                                                fill="url(#grad1)"></path>
                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                d="M1 98.5799C1 105.972 7.314 112.286 14.86 112.286C22.406 112.286 28.72 105.972 28.72 98.5799C28.72 90.8799 22.406 84.5659 14.86 84.5659C7.314 84.5659 1 90.8799 1 98.5799ZM14.86 113.286C6.76895 113.286 0 106.531 0 98.5799C0 90.3348 6.75456 83.5659 14.86 83.5659C22.9654 83.5659 29.72 90.3348 29.72 98.5799C29.72 106.531 22.951 113.286 14.86 113.286Z"
                                                fill="url(#grad1)"></path>
                                        </svg>
                                    </span>
                                </div>
                                <div class="elementor-icon-box-title">
                                    <h3 style="padding-bottom: 10px;">Tư vấn & Báo giá</h3>
                                    <p>
                                        Tư vấn chi tiết về những mong muốn và ý tưởng của khách hàng, đưa ra tính
                                        năng
                                        và
                                        gói
                                        dịch vụ phù hợp với ngân sách và lên báo giá chi tiết </p>
                                </div>
                            </div>
                            <!-- 2 -->
                            <div class="column-wrapper column-wrapper-chan">
                                <div class="elementor-icon-box-icon">
                                    <span class="elementor-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="130" height="130"
                                            viewBox="0 0 206 114" fill="none">
                                            <defs>
                                                <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="0%">
                                                    <stop offset="0%" stop-color="#020c6a" />
                                                    <stop offset="50%" stop-color="#1a85f8" />
                                                    <stop offset="100%" stop-color="#66e5fb" />
                                                </linearGradient>
                                            </defs>

                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                d="M130.486 91.0955L131.855 89.6599C153.26 67.2111 164.412 55.5156 170.228 48.3062C173.182 44.645 174.698 42.2139 175.491 40.176C176.272 38.1697 176.378 36.4818 176.378 34.2079C176.378 28.5278 171.983 24.5819 165.982 24.5819C163.053 24.5819 160.396 25.5789 158.473 27.5198C156.554 29.4561 155.278 32.4201 155.278 36.5179V37.5179H128.484V36.5179C128.484 23.842 133.262 14.8473 140.403 9.04213C147.514 3.26221 156.879 0.713867 165.982 0.713867C176.78 0.713867 186.072 3.64811 192.683 9.10461C199.315 14.5779 203.172 22.5275 203.172 32.3599C203.172 40.8638 201.54 47.2963 196.054 55.4962C190.823 63.3144 182.067 72.7704 167.898 87.2619H205.02V111.9H130.486V91.0955ZM165.52 88.2619C165.849 87.9259 166.176 87.5926 166.5 87.2619C195.994 57.1264 202.172 48.8113 202.172 32.3599C202.172 13.2639 187.234 1.71387 165.982 1.71387C148.36 1.71387 129.989 11.4544 129.494 35.5179C129.488 35.8485 129.484 36.1818 129.484 36.5179H154.278C154.278 27.8939 159.668 23.5819 165.982 23.5819C172.45 23.5819 177.378 27.8939 177.378 34.2079C177.378 43.366 175.714 45.1113 132.651 90.2741L131.486 91.4959V110.9H204.02V88.2619H165.52Z"
                                                fill="url(#grad1)" />

                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                d="M47.123 98.2285C39.985 88.5073 36.2261 74.45 36.2261 56.9999C36.2261 39.5497 39.985 25.4924 47.123 15.7713C54.2904 6.01017 64.7999 0.713867 78.0361 0.713867C91.1974 0.713867 101.668 6.01183 108.815 15.7723C115.933 25.493 119.692 39.5496 119.692 56.9999C119.692 74.4501 115.933 88.5067 108.815 98.2274C101.668 107.988 91.1974 113.286 78.0361 113.286C64.7999 113.286 54.2904 107.99 47.123 98.2285ZM68.063 79.2471C70.5783 84.5386 74.0395 87.2619 78.0361 87.2619C81.8687 87.2619 85.2951 84.5516 87.8167 79.2471C90.3302 73.9594 91.8201 66.3051 91.8201 56.9999C91.8201 47.6946 90.3302 40.0404 87.8167 34.7527C85.2951 29.4481 81.8687 26.7379 78.0361 26.7379C74.0395 26.7379 70.5783 29.4612 68.063 34.7527C65.5506 40.0379 64.0981 47.6906 64.0981 56.9999C64.0981 66.3091 65.5506 73.9618 68.063 79.2471ZM37.2261 56.9999C37.2261 91.6499 52.1641 112.286 78.0361 112.286C103.754 112.286 118.692 91.6499 118.692 56.9999C118.692 22.3499 103.754 1.71387 78.0361 1.71387C52.1641 1.71387 37.2261 22.3499 37.2261 56.9999ZM78.0361 88.2619C68.9501 88.2619 63.0981 75.7879 63.0981 56.9999C63.0981 38.2119 68.9501 25.7379 78.0361 25.7379C86.8141 25.7379 92.8201 38.2119 92.8201 56.9999C92.8201 75.7879 86.8141 88.2619 78.0361 88.2619Z"
                                                fill="url(#grad1)" />

                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                d="M1 98.5799C1 105.972 7.314 112.286 14.86 112.286C22.406 112.286 28.72 105.972 28.72 98.5799C28.72 90.8799 22.406 84.5659 14.86 84.5659C7.314 84.5659 1 90.8799 1 98.5799ZM14.86 113.286C6.76895 113.286 0 106.531 0 98.5799C0 90.3348 6.75456 83.5659 14.86 83.5659C22.9654 83.5659 29.72 90.3348 29.72 98.5799C29.72 106.531 22.951 113.286 14.86 113.286Z"
                                                fill="url(#grad1)" />
                                        </svg>
                                    </span>
                                </div>
                                <div class="elementor-icon-box-title">
                                    <h3 style="padding-bottom: 10px;"> Lập kế hoạch chi tiết </h3>
                                    <p>
                                        Sau khi tiếp nhận yêu cầu của khách hàng, bộ phận UI/UX và Dev sẽ thảo luận
                                        để
                                        đưa
                                        ra kế
                                        hoạch tối ưu nhất dành cho khách hàng </p>
                                </div>
                            </div>
                            <!-- 3 -->
                            <div class="column-wrapper">
                                <div class="elementor-icon-box-icon">
                                    <span class="elementor-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="130" height="130"
                                            viewBox="0 0 208 114" fill="none">
                                            <defs>
                                                <linearGradient id="gradientStroke" x1="0%" y1="0%" x2="100%" y2="0%">
                                                    <stop offset="0%" stop-color="#020c6a" />
                                                    <stop offset="50%" stop-color="#1a85f8" />
                                                    <stop offset="100%" stop-color="#66e5fb" />
                                                </linearGradient>
                                            </defs>

                                            <path fill="none" stroke="url(#gradientStroke)" stroke-width="1"
                                                fill-rule="evenodd" clip-rule="evenodd"
                                                d="M126.636 76.4819H154.354V77.4819C154.354 80.95 155.714 83.3348 157.883 84.8887C160.098 86.4763 163.255 87.2619 166.906 87.2619C170.887 87.2619 174.177 86.1566 176.456 84.1933C178.717 82.2454 180.074 79.3758 180.074 75.6339C180.074 72.0645 178.732 69.4376 176.508 67.6788C174.253 65.8957 170.992 64.9299 167.06 64.9299H156.828L156.659 42.6019H165.366C168.48 42.6019 171.126 41.6609 172.977 40.0874C174.814 38.5246 175.916 36.3001 175.916 33.5919C175.916 28.5636 171.869 25.0439 166.29 25.0439C160.806 25.0439 156.644 28.3135 156.51 33.1576L156.483 34.1299H129.408V33.1299C129.408 22.7665 133.374 14.6289 139.845 9.09654C146.298 3.57991 155.168 0.713867 164.904 0.713867C185.554 0.713867 201.17 12.8142 201.17 29.5879C201.17 37.5373 198.06 44.5352 192.488 49.4759C201.626 55.2503 207.484 64.5263 207.484 76.5579C207.484 97.7035 189.67 113.286 166.136 113.286C155.58 113.286 145.71 110.511 138.459 104.611C131.178 98.6867 126.636 89.6899 126.636 77.4819V76.4819ZM191.689 50.1559C191.389 49.9694 191.084 49.7867 190.776 49.6079C191.055 49.3865 191.328 49.1601 191.595 48.9289C197.089 44.1745 200.17 37.3714 200.17 29.5879C200.17 13.5719 185.232 1.71387 164.904 1.71387C146.126 1.71387 130.922 12.5847 130.421 32.1299C130.412 32.4607 130.408 32.7941 130.408 33.1299H155.51C155.664 27.5859 160.438 24.0439 166.29 24.0439C172.296 24.0439 176.916 27.8939 176.916 33.5919C176.916 39.5979 171.988 43.6019 165.366 43.6019H157.666L157.82 63.9299H167.06C175.222 63.9299 181.074 67.9339 181.074 75.6339C181.074 83.6419 175.222 88.2619 166.906 88.2619C159.36 88.2619 153.354 85.0279 153.354 77.4819H127.636C127.636 77.8178 127.64 78.1511 127.647 78.4819C128.135 101.657 145.639 112.286 166.136 112.286C189.236 112.286 206.484 97.0399 206.484 76.5579C206.484 64.7843 200.715 55.7511 191.689 50.1559Z" />

                                            <path fill="none" stroke="url(#gradientStroke)" stroke-width="1"
                                                fill-rule="evenodd" clip-rule="evenodd"
                                                d="M47.123 98.2285C39.985 88.5073 36.2261 74.45 36.2261 56.9999C36.2261 39.5497 39.985 25.4924 47.123 15.7713C54.2904 6.01017 64.7999 0.713867 78.0361 0.713867C91.1974 0.713867 101.668 6.01183 108.815 15.7723C115.933 25.493 119.692 39.5496 119.692 56.9999C119.692 74.4501 115.933 88.5067 108.815 98.2274C101.668 107.988 91.1974 113.286 78.0361 113.286C64.7999 113.286 54.2904 107.99 47.123 98.2285ZM68.063 79.2471C70.5783 84.5386 74.0395 87.2619 78.0361 87.2619C81.8687 87.2619 85.2951 84.5516 87.8167 79.2471C90.3302 73.9594 91.8201 66.3051 91.8201 56.9999C91.8201 47.6946 90.3302 40.0404 87.8167 34.7527C85.2951 29.4481 81.8687 26.7379 78.0361 26.7379C74.0395 26.7379 70.5783 29.4612 68.063 34.7527C65.5506 40.0379 64.0981 47.6906 64.0981 56.9999C64.0981 66.3091 65.5506 73.9618 68.063 79.2471ZM37.2261 56.9999C37.2261 91.6499 52.1641 112.286 78.0361 112.286C103.754 112.286 118.692 91.6499 118.692 56.9999C118.692 22.3499 103.754 1.71387 78.0361 1.71387C52.1641 1.71387 37.2261 22.3499 37.2261 56.9999ZM78.0361 88.2619C68.9501 88.2619 63.0981 75.7879 63.0981 56.9999C63.0981 38.2119 68.9501 25.7379 78.0361 25.7379C86.8141 25.7379 92.8201 38.2119 92.8201 56.9999C92.8201 75.7879 86.8141 88.2619 78.0361 88.2619Z" />

                                            <path fill="none" stroke="url(#gradientStroke)" stroke-width="1"
                                                fill-rule="evenodd" clip-rule="evenodd"
                                                d="M1 98.5799C1 105.972 7.314 112.286 14.86 112.286C22.406 112.286 28.72 105.972 28.72 98.5799C28.72 90.8799 22.406 84.5659 14.86 84.5659C7.314 84.5659 1 90.8799 1 98.5799ZM14.86 113.286C6.76895 113.286 0 106.531 0 98.5799C0 90.3348 6.75456 83.5659 14.86 83.5659C22.9654 83.5659 29.72 90.3348 29.72 98.5799C29.72 106.531 22.951 113.286 14.86 113.286Z" />
                                        </svg>
                                    </span>
                                </div>
                                <div class="elementor-icon-box-title">
                                    <h3 style="padding-bottom: 10px;">Thiết kế và lập trình</h3>
                                    <p>

                                        Bộ phận UI/UX Design sau khi có kế hoạch sẽ tiến hành lên demo và gửi khách
                                        hàng
                                        bản
                                        Figma. Khách hàng điều chỉnh trước khi lập trình </p>
                                </div>
                            </div>
                            <!-- 4 -->
                            <div class="column-wrapper column-wrapper-chan">
                                <div class="elementor-icon-box-icon">
                                    <span class="elementor-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="130" height="130"
                                            viewBox="0 0 210 114" fill="none">
                                            <defs>
                                                <linearGradient id="gradient-stroke" x1="0%" y1="0%" x2="100%" y2="0%">
                                                    <stop offset="0%" stop-color="#020c6a" />
                                                    <stop offset="50%" stop-color="#1a85f8" />
                                                    <stop offset="100%" stop-color="#66e5fb" />
                                                </linearGradient>
                                            </defs>

                                            <path fill="none" stroke="url(#gradient-stroke)" stroke-width="1"
                                                fill-rule="evenodd" clip-rule="evenodd"
                                                d="M174.606 110.9H200.478V88.2621H208.794V65.6241H200.478V3.10009H167.676L123.94 71.9381V88.2621H174.606V110.9ZM173.606 89.2621V111.9H201.478V89.2621H209.794V64.6241H201.478V2.1001H167.127L122.94 71.6473V89.2621H173.606ZM153.2 65.6241L174.606 27.7401V65.6241H153.2ZM154.914 64.6241H173.606V31.5427L154.914 64.6241Z" />

                                            <path fill="none" stroke="url(#gradient-stroke)" stroke-width="1"
                                                fill-rule="evenodd" clip-rule="evenodd"
                                                d="M47.123 98.2285C39.985 88.5073 36.2261 74.45 36.2261 56.9999C36.2261 39.5497 39.985 25.4924 47.123 15.7713C54.2904 6.01017 64.7999 0.713867 78.0361 0.713867C91.1974 0.713867 101.668 6.01183 108.815 15.7723C115.933 25.493 119.692 39.5496 119.692 56.9999C119.692 74.4501 115.933 88.5067 108.815 98.2274C101.668 107.988 91.1974 113.286 78.0361 113.286C64.7999 113.286 54.2904 107.99 47.123 98.2285ZM68.063 79.2471C70.5783 84.5386 74.0395 87.2619 78.0361 87.2619C81.8687 87.2619 85.2951 84.5516 87.8167 79.2471C90.3302 73.9594 91.8201 66.3051 91.8201 56.9999C91.8201 47.6946 90.3302 40.0404 87.8167 34.7527C85.2951 29.4481 81.8687 26.7379 78.0361 26.7379C74.0395 26.7379 70.5783 29.4612 68.063 34.7527C65.5506 40.0379 64.0981 47.6906 64.0981 56.9999C64.0981 66.3091 65.5506 73.9618 68.063 79.2471ZM37.2261 56.9999C37.2261 91.6499 52.1641 112.286 78.0361 112.286C103.754 112.286 118.692 91.6499 118.692 56.9999C118.692 22.3499 103.754 1.71387 78.0361 1.71387C52.1641 1.71387 37.2261 22.3499 37.2261 56.9999ZM78.0361 88.2619C68.9501 88.2619 63.0981 75.7879 63.0981 56.9999C63.0981 38.2119 68.9501 25.7379 78.0361 25.7379C86.8141 25.7379 92.8201 38.2119 92.8201 56.9999C92.8201 75.7879 86.8141 88.2619 78.0361 88.2619Z" />

                                            <path fill="none" stroke="url(#gradient-stroke)" stroke-width="1"
                                                fill-rule="evenodd" clip-rule="evenodd"
                                                d="M1 98.5799C1 105.972 7.314 112.286 14.86 112.286C22.406 112.286 28.72 105.972 28.72 98.5799C28.72 90.8799 22.406 84.5659 14.86 84.5659C7.314 84.5659 1 90.8799 1 98.5799ZM14.86 113.286C6.76895 113.286 0 106.531 0 98.5799C0 90.3348 6.75456 83.5659 14.86 83.5659C22.9654 83.5659 29.72 90.3348 29.72 98.5799C29.72 106.531 22.951 113.286 14.86 113.286Z" />
                                        </svg>
                                    </span>
                                </div>
                                <div class="elementor-icon-box-title">
                                    <h3 style="padding-bottom: 10px;">Thử nghiệm và điểu chỉnh</h3>
                                    <p>
                                        Khách hàng thử nghiệm website của họ sau khi lập trình và tiến hành điều
                                        chỉnh
                                        nếu
                                        có
                                        vấn đề phát sinh </p>
                                </div>
                            </div>
                            <!-- 5 -->
                            <div class="column-wrapper">
                                <div class="elementor-icon-box-icon">
                                    <span class="elementor-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="130" height="130"
                                            viewBox="0 0 208 114" fill="none">
                                            <defs>
                                                <linearGradient id="strokeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                                                    <stop offset="0%" stop-color="#020c6a" />
                                                    <stop offset="50%" stop-color="#1a85f8" />
                                                    <stop offset="100%" stop-color="#66e5fb" />
                                                </linearGradient>
                                            </defs>

                                            <path fill="none" stroke="url(#strokeGradient)" stroke-width="1"
                                                d="M127.188 78.4821C127.759 99.4509 146.293 112.286 167.214 112.286C189.082 112.286 206.946 96.7321 206.946 71.4761C206.946 49.1461 192.932 35.7481 174.76 35.7481C165.772 35.7481 159.986 37.9254 155.883 40.5279C155.487 40.7792 155.106 41.0345 154.74 41.2921L157.358 25.7381H203.712V3.10009H138.724L127.328 66.5481H154.124C155.972 60.5421 160.9 56.8461 167.368 56.8461C175.838 56.8461 181.536 63.0061 181.536 72.2461C181.536 81.6401 175.838 87.8001 167.368 87.8001C160.746 87.8001 155.664 83.7961 153.97 77.4821H127.174C127.174 77.8175 127.179 78.1508 127.188 78.4821Z" />

                                            <path fill="none" stroke="url(#strokeGradient)" stroke-width="1"
                                                d="M158.204 26.7381H204.712V2.1001H137.888L126.133 67.5481H154.863L155.08 66.8422C156.798 61.2571 161.338 57.8461 167.368 57.8461C171.349 57.8461 174.615 59.2869 176.893 61.7587C179.177 64.2377 180.536 67.831 180.536 72.2461C180.536 76.7422 179.175 80.3741 176.891 82.8708C174.614 85.3596 171.348 86.8001 167.368 86.8001C161.207 86.8001 156.515 83.108 154.936 77.223L154.737 76.4821H126.174V77.4821C126.174 99.7741 145.609 113.286 167.214 113.286C178.387 113.286 188.578 109.31 195.98 102.067C203.388 94.8179 207.946 84.3503 207.946 71.4761C207.946 60.0992 204.373 50.9084 198.396 44.5533C192.418 38.1961 184.1 34.7481 174.76 34.7481C166.113 34.7481 160.312 36.7286 156.103 39.2202L158.204 26.7381Z" />

                                            <path fill="none" stroke="url(#strokeGradient)" stroke-width="1"
                                                d="M47.123 98.2285C39.985 88.5073 36.2261 74.45 36.2261 56.9999C36.2261 39.5497 39.985 25.4924 47.123 15.7713C54.2904 6.01017 64.7999 0.713867 78.0361 0.713867C91.1974 0.713867 101.668 6.01183 108.815 15.7723C115.933 25.493 119.692 39.5496 119.692 56.9999C119.692 74.4501 115.933 88.5067 108.815 98.2274C101.668 107.988 91.1974 113.286 78.0361 113.286C64.7999 113.286 54.2904 107.99 47.123 98.2285ZM68.063 79.2471C70.5783 84.5386 74.0395 87.2619 78.0361 87.2619C81.8687 87.2619 85.2951 84.5516 87.8167 79.2471C90.3302 73.9594 91.8201 66.3051 91.8201 56.9999C91.8201 47.6946 90.3302 40.0404 87.8167 34.7527C85.2951 29.4481 81.8687 26.7379 78.0361 26.7379C74.0395 26.7379 70.5783 29.4612 68.063 34.7527C65.5506 40.0379 64.0981 47.6906 64.0981 56.9999C64.0981 66.3091 65.5506 73.9618 68.063 79.2471ZM37.2261 56.9999C37.2261 91.6499 52.1641 112.286 78.0361 112.286C103.754 112.286 118.692 91.6499 118.692 56.9999C118.692 22.3499 103.754 1.71387 78.0361 1.71387C52.1641 1.71387 37.2261 22.3499 37.2261 56.9999ZM78.0361 88.2619C68.9501 88.2619 63.0981 75.7879 63.0981 56.9999C63.0981 38.2119 68.9501 25.7379 78.0361 25.7379C86.8141 25.7379 92.8201 38.2119 92.8201 56.9999C92.8201 75.7879 86.8141 88.2619 78.0361 88.2619Z" />

                                            <path fill="none" stroke="url(#strokeGradient)" stroke-width="1"
                                                d="M1 98.5799C1 105.972 7.314 112.286 14.86 112.286C22.406 112.286 28.72 105.972 28.72 98.5799C28.72 90.8799 22.406 84.5659 14.86 84.5659C7.314 84.5659 1 90.8799 1 98.5799ZM14.86 113.286C6.76895 113.286 0 106.531 0 98.5799C0 90.3348 6.75456 83.5659 14.86 83.5659C22.9654 83.5659 29.72 90.3348 29.72 98.5799C29.72 106.531 22.951 113.286 14.86 113.286Z" />
                                        </svg>
                                    </span>
                                </div>
                                <div class="elementor-icon-box-title">
                                    <h3 style="padding-bottom: 10px;">Hướng dẫn quản trị</h3>
                                    <p>Trao đổi và hướng dẫn khách hàng tự quản lí website của họ một các chuyên
                                        nghiệp
                                        và
                                        chính
                                        xác</p>
                                </div>
                            </div>
                            <!-- 6 -->

                            <div class="column-wrapper column-wrapper-chan">
                                <div class="elementor-icon-box-icon">
                                    <span class="elementor-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="130" height="130"
                                            viewBox="0 0 210 114" fill="none">
                                            <defs>
                                                <linearGradient id="strokeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                                                    <stop offset="0%" stop-color="#020c6a" />
                                                    <stop offset="50%" stop-color="#1a85f8" />
                                                    <stop offset="100%" stop-color="#66e5fb" />
                                                </linearGradient>
                                            </defs>

                                            <path fill="none" stroke="url(#strokeGradient)" stroke-width="1"
                                                d="M126.558 77.1741C126.558 97.3481 144.884 112.286 167.214 112.286C189.236 112.286 208.332 97.5021 208.332 74.2481C208.332 55.3061 195.088 38.8281 172.45 38.8281H170.448L197.398 3.10009H168.292L142.42 39.5981C132.41 53.7661 126.558 63.3141 126.558 77.1741ZM172.455 37.8281L199.405 2.1001H167.775L141.604 39.0198L141.603 39.0211C131.594 53.1885 125.558 62.968 125.558 77.1741C125.558 98.048 144.492 113.286 167.214 113.286C189.661 113.286 209.332 98.1734 209.332 74.2481C209.332 64.5458 205.939 55.4374 199.607 48.7474C193.266 42.0489 184.028 37.8293 172.455 37.8281ZM167.522 90.1101C158.128 90.1101 152.43 82.8721 152.43 74.2481C152.43 65.6241 158.282 58.5401 167.522 58.5401C176.608 58.5401 182.614 65.6241 182.614 74.2481C182.614 83.0261 176.454 90.1101 167.522 90.1101ZM157.197 84.7441C159.6 87.4146 163.1 89.1101 167.522 89.1101C175.831 89.1101 181.614 82.5474 181.614 74.2481C181.614 66.1023 175.984 59.5401 167.522 59.5401C158.912 59.5401 153.43 66.0951 153.43 74.2481C153.43 78.3436 154.783 82.0618 157.197 84.7441Z" />

                                            <path fill="none" stroke="url(#strokeGradient)" stroke-width="1"
                                                d="M47.123 98.2285C39.985 88.5073 36.2261 74.45 36.2261 56.9999C36.2261 39.5497 39.985 25.4924 47.123 15.7713C54.2904 6.01017 64.7999 0.713867 78.0361 0.713867C91.1974 0.713867 101.668 6.01183 108.815 15.7723C115.933 25.493 119.692 39.5496 119.692 56.9999C119.692 74.4501 115.933 88.5067 108.815 98.2274C101.668 107.988 91.1974 113.286 78.0361 113.286C64.7999 113.286 54.2904 107.99 47.123 98.2285ZM68.063 79.2471C70.5783 84.5386 74.0395 87.2619 78.0361 87.2619C81.8687 87.2619 85.2951 84.5516 87.8167 79.2471C90.3302 73.9594 91.8201 66.3051 91.8201 56.9999C91.8201 47.6946 90.3302 40.0404 87.8167 34.7527C85.2951 29.4481 81.8687 26.7379 78.0361 26.7379C74.0395 26.7379 70.5783 29.4612 68.063 34.7527C65.5506 40.0379 64.0981 47.6906 64.0981 56.9999C64.0981 66.3091 65.5506 73.9618 68.063 79.2471ZM37.2261 56.9999C37.2261 91.6499 52.1641 112.286 78.0361 112.286C103.754 112.286 118.692 91.6499 118.692 56.9999C118.692 22.3499 103.754 1.71387 78.0361 1.71387C52.1641 1.71387 37.2261 22.3499 37.2261 56.9999ZM78.0361 88.2619C68.9501 88.2619 63.0981 75.7879 63.0981 56.9999C63.0981 38.2119 68.9501 25.7379 78.0361 25.7379C86.8141 25.7379 92.8201 38.2119 92.8201 56.9999C92.8201 75.7879 86.8141 88.2619 78.0361 88.2619Z" />

                                            <path fill="none" stroke="url(#strokeGradient)" stroke-width="1"
                                                d="M1 98.5799C1 105.972 7.314 112.286 14.86 112.286C22.406 112.286 28.72 105.972 28.72 98.5799C28.72 90.8799 22.406 84.5659 14.86 84.5659C7.314 84.5659 1 90.8799 1 98.5799ZM14.86 113.286C6.76895 113.286 0 106.531 0 98.5799C0 90.3348 6.75456 83.5659 14.86 83.5659C22.9654 83.5659 29.72 90.3348 29.72 98.5799C29.72 106.531 22.951 113.286 14.86 113.286Z" />
                                        </svg>
                                    </span>
                                </div>
                                <div class="elementor-icon-box-title">
                                    <h3 style="padding-bottom: 10px;">Bàn giao và bảo hành</h3>
                                    <p>Sau khi hoàn thành các bước thử nghiệm và đào tạo, tiến hàng bàn giao và bảo
                                        hành
                                        cho
                                        khách trong những trường hợp cụ thể về kĩ thuật</p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- hình reponsiry -->
        <div class="wp-post-container-0">

        </div>
        <!-- wrapper some always question to ask-->
        <div class="homenest__professional_website_faq">
            <div class="homenest__professional_website_title-wrapper">
                <h2 class="homenest__professional_website_title">CÂU HỎI THƯỜNG GẶP</h2>
            </div>
            <div id="homenest__professional_website_faq-container"></div>
        </div>
    </div>
</body>
<?php get_footer(); ?>