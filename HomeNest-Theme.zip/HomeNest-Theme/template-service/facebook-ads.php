<?php
/**
 * Template Name: Facebook Ads
 * Template Post Type: service
 */
get_header(); ?>
<style>

	
.homenest-fb {
  font-family: "Homenest", sans-serif;
  margin: 0 auto;
  padding: 0;
  width: 100%;
  margin-top: 50px;
  
} 
  *,
  *::before,
  *::after {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }
  
.homenest-fb #slider {
  display: flex;
  transition: transform 0.5s ease;
  will-change: transform;
}
.homenest-fb p {
  line-height: 1.8;
}
.homenest-fb  li,a{
    list-style: none;
    text-decoration: none;
}
.homenest-fb .link-a {
  cursor: pointer;
  color: #0066ff;
}
.homenest-fb  summary{
  display: flex;
}
.homenest-fb  summary .stt{
  right: 10px;
}
.homenest-fb .container {
  width: 100%;
  margin: 0 auto; 
  padding: 0;
  max-width: 1700px;
  display: flex;
  justify-content: center;
  align-items: center;
  
}
.homenest-fb .row-1{
  font-size: 45px;
  background: linear-gradient(92.16deg, #0417bd 0%, #1A85F8 26.7%, #66E5FB 80%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}
.homenest-fb h2{
    font-size: 45px;
    
}
.homenest-fb .container-adss, 
.homenest-fb .container-fanpage,
.homenest-fb  .container-fanpage
{
    display: flex;
    justify-content: center;
    align-items: center;
}
.homenest-fb .container-adss{
  background-color: #f0f2f4;
}
.homenest-fb .container-adss .container-adss-left{
  margin-top: 50px;
}

.homenest-fb .container .container-hero{
  display: flex;
  margin: 20px auto;
  gap: 50px;
  flex-wrap: wrap;
  overflow: hidden;
  margin-bottom: 60px;
}
.homenest-fb .container .container-hero .container-left,
.homenest-fb .container .container-hero .container-right {
  flex: 1;
  min-width: 0;
}
.homenest-fb .container .container-hero .container-left{
  padding: 0 50px;
}
.homenest-fb .container .container-hero .container-left h2{
background: linear-gradient(92.16deg, #0417bd 0%, #1A85F8 66.7%, #66E5FB 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}
.homenest-fb .container .container-hero .container-left p{
  font-size: 18px;
  margin: 30px 0;
}
.homenest-fb .container .container-hero .container-left ul {
  list-style: none;
  padding-left: 0;
}
.homenest-fb .container .container-hero .container-left ul li {
  display: flex;
  align-items: center;
  margin-bottom: 15px;
  font-size: 18px;
  font-weight: 500;

}
.homenest-fb .container .container-hero .container-left ul li svg {
  margin-right: 10px;
  flex-shrink: 0;
}
.homenest-fb .container .container-hero .container-left a{
   margin: 30px 0;
   padding: 30px 20px;
}
.homenest-fb .container .container-hero .container-left a .button {
  width: 300px;
  height: 35px;
  padding: 28px 20px;
  background: linear-gradient(92.16deg, #0417bd 0%, #1A85F8 56.7%, #66E5FB 100%);
  color: #fff;
  border-radius: 50px;
  text-decoration: none;
  font-weight: bold;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 18px;
}
.homenest-fb .container .container-hero .container-left a .button:hover  {
  background: linear-gradient(92.16deg, #0414a2 0%, #1164bd 56.7%, #388390 100%);
  color: #cacaca;
}
.homenest-fb .container .container-hero .container-right {
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  align-items: flex-end;
  background-image: url('https://homenest.com.vn/wp-content/uploads/2024/11/cbff8409d0d4d38686b23bf86cd8b4a0.webp');
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  border-radius: 20px;
  height: 600px;
  padding: 0 50px;
  margin-right: 40px;
}
.homenest-fb .container .container-hero .container-right img {
  margin-right: 10px;
  margin-bottom: 20px;
  height: auto;
  max-width: 28%;
  display: block;
}
.homenest-fb .container .container-hero .container-right img:last-child {
  margin-right: 0;
}


.homenest-fb  .container-slideshow {
  display: flex;
  justify-content: center; 
  align-items: center;
  height: 100%;
  background-color: #fff;
  position: relative;
  overflow: hidden;
  padding-bottom: 150px;
}

.homenest-fb  .container-slideshow .slideshow-left {
  z-index: 1;
  opacity: 0.5;
  pointer-events: none;
  position: absolute;
  left: 0;
}
.homenest-fb  .container-slideshow .slideshow-right {
  z-index: 1;
  opacity: 0.5;
  pointer-events: none;
  position: absolute;
  right: 0;

}
/* .homenest-fb  .container-fanpage .slideshow-left img {
  position: absolute;
    height: 650px;
} */
.homenest-fb  .container-slideshow .slideshow-left img,
.homenest-fb  .container-slideshow .slideshow-right img {
  height: 650px;
  object-fit: contain;
}

.homenest-fb .mySwiper {
  position: relative;
  width: 90%;
  /* z-index: 10; */
  box-sizing: border-box;
}
.homenest-fb .container-slideshow .swiper{
  padding: 0 20px;
}
.homenest-fb .center-center {
  display: flex;
  justify-content: left;
  align-items: center;
  flex-wrap: wrap;
  margin-bottom: -10px;
}
.homenest-fb .slideshow-center-h2 .row-1,
.homenest-fb .slideshow-center-h2 {
  font-size: 50px;
  font-weight: bold;
  color: #333;
  margin-right: 20px;
  text-align: left;
  display: flex;
  gap: 10px;
}
.homenest-fb .slideshow-center-h2 {
  margin-top: 30px;
}

.homenest-fb  .center-center img {
  width: 150px;
}

.homenest-fb  .swiper-slide {
  background: #f0f2f4;
  border-radius: 12px;
  padding: 20px;
  box-sizing: border-box;
}
.homenest-fb .container-slideshow .mySwiper .swiper-wrapper .swiper-slide ul{
    padding-left: 0;
  }
  .homenest-fb .container-slideshow .mySwiper .swiper-wrapper .swiper-slide ul li{
    display: flex;
    align-items: center;
    gap: 5px;
}

.homenest-fb  .plan h3 {
  margin-bottom: 20px;
  font-size: 24px;
  color: #fff;
  padding: 10px;
  border-radius: 8px;
}
.homenest-fb .slide-btn {
  position: absolute;
  top: 60%;
  transform: translateY(-50%);
  background-color: transparent;
  border: none;
  color: white;
  font-size: 24px;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  cursor: pointer;
  z-index: 10;
}
.homenest-fb .prev {
  left: -10px;
  top: 60%;
}

.homenest-fb .next {
  right: -10px;
    top: 60%;
}

.homenest-fb  .swiper-wrapper .basic h3 {
  background-image: url('https://homenest.com.vn/wp-content/uploads/2025/01/image-5.png');
   background-size: cover;
  background-position: center;
}

.homenest-fb  .swiper-wrapper .golden h3 {
  background-image: url('https://homenest.com.vn/wp-content/uploads/2025/01/image-1-1.png');
   background-size: cover;
  background-position: center;
}

.homenest-fb .swiper-wrapper .diamond h3 {
  background-image: url('https://homenest.com.vn/wp-content/uploads/2025/01/image-2-1.png');
   background-size: cover;
  background-position: center;
}

.homenest-fb  .swiper-wrapper .platinum h3 {
  background-image: url('https://homenest.com.vn/wp-content/uploads/2025/01/image-3-1.png');
   background-size: cover;
  background-position: center;
}
.homenest-fb .swiper-wrapper .basic .button-price .button-price-before, 
.homenest-fb .swiper-wrapper .basic .button-price .button-price-after {
  color: #2db5b1;
}

.homenest-fb .swiper-wrapper .golden .button-price .button-price-before, 
.homenest-fb .swiper-wrapper .golden .button-price .button-price-after {
  color: #ff9800;
}

.homenest-fb .swiper-wrapper .diamond .button-price .button-price-before, 
.homenest-fb .swiper-wrapper .diamond .button-price .button-price-after {
  color: #020c6a;
}

.homenest-fb .swiper-wrapper .platinum .button-price .button-price-before, 
.homenest-fb .swiper-wrapper .platinum .button-price .button-price-after  {
  color: #972295;
}
.homenest-fb  .swiper-wrapper .basic li svg {
  color: #2db5b1;
}

.homenest-fb .swiper-wrapper .golden li svg {
  color: #ff9800;
}

.homenest-fb  .swiper-wrapper .diamond li svg {
  color: #020c6a;
}

.homenest-fb .swiper-wrapper .platinum li svg {
  color: #972295;
}
.homenest-fb .plan {
  border-radius: 12px;
  position: relative;
  background: #f0f2f4;
  border: 2px solid #ddd;
}
.homenest-fb  .plan p{
  font-size: 16px;
  margin: 10px 0;
}
.homenest-fb  .plan ul li {
  padding: 10px 0;

}
.homenest-fb  .plan .sale{
  font-size: 16px;
}
.homenest-fb  .plan hr {
  border: none;
  border-top: 1px solid #ffffff;
  margin: 20px 0;
}

.homenest-fb .plan h3 {
  position: relative;
  margin-bottom: 40px;
  left: -30px;
  width: 200px;
  height: 60px;
  color: #fff;
  padding: 5px 30px;
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 10px;
  z-index: 2;
  font-size: 20px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}
.homenest-fb .plan h2 {
  font-size: 30px;
  margin-bottom: 20px;
}

.homenest-fb  .swiper-wrapper .button {
  display: flex;
  width: 100%;
  max-width: 300px;
  box-sizing: border-box;
  align-items: center;
  gap: 12px;
  position: relative;
  cursor: pointer;
  background: transparent;
  border: none;
  padding: 0;
  margin: 30px 10px;
}
.homenest-fb  .button-img {
  width: 100px;
  height: 45px;
  padding: 10px 34px;
  border-radius: 10px;
  object-fit: contain;
  justify-content: center;
  align-items: center;
  display: flex;
  background: linear-gradient(to right, #e64b48, #2463ff, #ff7a1a, #5bb9ff, #ff2831);
    background-size: 500% 100%;
    animation: moveGradient 3s linear infinite alternate;
}

@keyframes moveGradient {
  0% {
    background-position: 0% 50%;
  }
  100% {
    background-position: 100% 50%;
  }
}
.homenest-fb  .button-img img {
  width: 20px;
  height: 20px;
  object-fit: contain;
  display: block;
  
}
.homenest-fb  .button-price {
  position: relative;
  min-width: 200px;
  margin-top: 10px  ;
  height: 40px;
  overflow: hidden;
}

.homenest-fb  .button-price-before,
.homenest-fb  .button-price-after {
  position: absolute;
  left: 0;
  width: 100%;
  transition: all 0.6s cubic-bezier(.4,2,.6,1);
  text-align: left;
  background: none;
  display: block;
  font-size: 25px;
  font-weight: bold;

}

.homenest-fb  .button-price-before {
  top: 0;
  opacity: 1;
  transform: translateY(0) rotate(0deg);
  z-index: 2;
  transition: all 0.6s cubic-bezier(.4,2,.6,1);
}
.homenest-fb  .button:hover .button-price-before {
  transform: translateY(100%) rotate(90deg);
  opacity: 0;
}
.homenest-fb .button-price-after {
  top: 100%;
  opacity: 0;
  z-index: 1;
}

.homenest-fb .button:hover .button-price-after {
  top: 0;
  opacity: 1;
  transform: translateY(0);
}





 .homenest-fb .why-use-wrapper {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  margin: 20px 60px;
  background-color: #fff;
}
.homenest-fb  .reasons{
  margin-top: 50px;
  display: flex;
  gap: 20px;
}
 .homenest-fb .reason {
  padding: 10px;
  width: calc(100% / 4);
  border: 1px solid #ccc;
  border-radius: 12px;
}
.homenest-fb  .reason .reason-1 {
  margin: 0 5px;
  padding-top: 90px;
  padding-bottom: 30px;
  color: #fff;
}
.homenest-fb  .reason .reason-1 p{
  line-height: 1.8;
  font-size: 18px;
}
.homenest-fb  .reason-1 img {
  width: 50px;
  filter: brightness(0) invert(1);
}
.homenest-fb .reason .reason-1 h3
{
  font-size: 19px;
  font-weight: 900;
  margin-top: 15px;

}
.homenest-fb .rea-1, .homenest-fb .rea-2, .homenest-fb .rea-3, .homenest-fb .rea-4 {
  position: relative;
  overflow: hidden;
}

.homenest-fb .rea-1::before,
.homenest-fb .rea-2::before,
.homenest-fb .rea-3::before,
.homenest-fb .rea-4::before {
  content: '';
  position: absolute;
  inset: 0;
  background: rgba(0,0,0,0.35);
  z-index: 1;
  border-radius: 12px;
  pointer-events: none;
}

.homenest-fb .reason-1,
.homenest-fb .reason-1 * {
  position: relative;
  z-index: 2;
}
.homenest-fb .rea-1{
  background-image: url('https://homenest.com.vn/wp-content/uploads/2024/11/dcb023592bad2296448f21c49f08ad01.webp');
  background-size: cover;
  background-position: center;
}
.homenest-fb .rea-2{
  background-image: url('https://homenest.com.vn/wp-content/uploads/2024/11/d83ee65078eabbb75bb246f80501e08d.webp');
  background-size: cover;
  background-position: center;
}
.homenest-fb .rea-3{
  background-image: url('https://homenest.com.vn/wp-content/uploads/2024/11/4248173b4e7cf1db9137a1e95395d183.webp');
  background-size: cover;
  background-position: center;
}
.homenest-fb .rea-4{
  background-image: url('https://homenest.com.vn/wp-content/uploads/2024/11/2fd19cb8d602f3312937a5bc6ccc6bec.webp');
  background-size: cover;
  background-position: center;
}
.homenest-fb .reason h3{
  font-size: 19px;
  margin-top: 10px;
}
.homenest-fb .reason hr{
    border: 1px solid #ffffff;
  margin: 20px 0;
}
.homenest-fb  .container-fanpage {
  display: flex;
  position: relative;
  justify-content: center;
  align-items: center;
  width: 100%;
  margin: 50px 0;
  z-index: -1;
   background: linear-gradient(180deg, #ffffff 0%, #e0f7fa 50%, #ffffff 100%);
}
.homenest-fb .container-fanpage .container-fanpage-img {
 position: absolute;
 bottom: 0;
}
.homenest-fb .container-fanpage .container-fanpage-left {
  display: flex;
  flex-direction: row;
  max-width: 1500px;
  width: 90%;
  /* gap: 30px; */
  justify-content: center;
  align-items: flex-start;
  margin: 50px auto;
}

.homenest-fb .container-fanpage .container-fanpage-left h2 {
  margin: 0 40px 0 0;
  top: 0;
  width: 50%;
  max-width: 600px;
}
.homenest-fb .container-fanpage .container-fanpage-left h2 img {
  width: 400px;
  z-index: 1;
  margin: 30px 10px;
}
.homenest-fb  .container-fanpage .container-fanpage-left ul {
  display: grid;
  width: 850px;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
  padding: 0;
  margin: 16px 0;
  list-style: disc inside;
  
}

.homenest-fb  .container-fanpage .container-fanpage-left ul li {
  margin: 0;
  font-size: 17px;
  border-radius: 16px;
  box-shadow: 0 4px 24px 0 rgba(26, 133, 248, 0.10), 0 1.5px 8px 0 rgba(4, 23, 189, 0.08);
  padding: 30px 30px 30px 35px;
  transition: box-shadow 0.3s, transform 0.3s;
  position: relative;
}
.homenest-fb .container-fanpage-left ul li:hover {
  box-shadow: 0 8px 32px 0 rgba(26, 133, 248, 0.18), 0 3px 16px 0 rgba(4, 23, 189, 0.12);
  transform: translateY(-4px) scale(1.02);
}

.homenest-fb  .container-fanpage .container-fanpage-left ul li span {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 50px;
  height: 50px;
  border-radius: 8px;
  background: #D9EBFE;
  margin-right: 16px;
}

.homenest-fb  .container-fanpage .container-fanpage-left ul li span svg {
  width: 30px;
  height: 30px;
}
.homenest-fb .timeline details summary{
  gap: 5px;
  display: flex;
  align-items: center;
  text-align: center;
}

.homenest-fb  .container-fanpage .container-fanpage-left ul li h3{
  margin: 15px 0;
}
.homenest-fb  .container-fanpage .container-fanpage-right{
  height: 600px;
  width: 250px;
  right: 0;
    position: absolute;
    z-index: -1;

}
.homenest-fb  .container-fanpage .container-fanpage-right img{
  width: 100%;
 
}
.homenest-fb .details-body-group {
  position: relative;
  margin-left: 15px;
  padding-left: 15px;
}
.homenest-fb .timeline{
  margin-top: 50px;
}

.homenest-fb .container-adss .container-adss-right{
 margin-left: 50px;
}
.homenest-fb .container-adss .container-adss-right h2, 
.homenest-fb .container-adss .container-adss-right h2 .row-1
{
  font-size: 50px;
}
.homenest-fb .fa-solid{
  margin-right: 10px;
  color: #1a73e8;
  font-size: 24px;
}
.homenest-fb .details-body-group::before {
  content: '';
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  width: 2px;
  background-color: #1a73e8;
}
.homenest-fb .details-body-group li {
  position: relative;
  list-style: disc inside;
  line-height: 1.8;
  font-size: 17px;
  text-align: start !important;
}

.homenest-fb .details-body {
  padding: 0 20px;
  margin-bottom: 10px;
  color: #333;
  position: relative;
  display: flex;
}

.homenest-fb .container-faq  .homenest__professional_website_faq {
  width: 100%;
  padding: 80px 128px;
}
.homenest-fb .container-faq  .homenest__professional_website_faq p {
  justify-content: center;
  display: flex;
  font-size: 25px;
  margin-bottom: -70px;
  font-weight: 700;
}
.homenest-fb .container-faq .homenest__professional_website_title-wrapper {
  display: flex;
  justify-content: center;
  padding: 20px;
}
.homenest-fb .container-faq .homenest__professional_website_title-wrapper h2 {
  font-size: 55px;
  padding: 40px 0;
}
.homenest-fb .container-faq .homenest__professional_website_question {
  border-bottom: 1px solid #adadad;
  padding: 20px 0;
}

.homenest-fb .container-faq .homenest__professional_website_question:first-child {
  border-top: 1px solid #adadad;
}
.homenest-fb .container-faq .homenest__professional_website_question-header-number {
  display: grid;
  grid-template-columns: 250px 1.5fr 40px;
  align-items: center;
  height: 50px;
  padding: 10px 0;
  cursor: pointer;
  gap: 10px;
}
.homenest-fb .container-faq .homenest__professional_website_question-header {
  display: grid;
  grid-template-columns: 250px 1.5fr 40px;
  align-items: center;
  /* padding: 10px 0; */
  cursor: pointer;
  gap: 10px;
}
.homenest-fb .container-faq .homenest__professional_website_question-label{
  font-size: 16px;
  color: #1A85F8;
}
.homenest-fb .container-faq .homenest__professional_website_question-title {
  padding: 20px 0;
  text-align: left;
  font-size: 18px;
  color: #111111;
  font-weight: 600;
}
.homenest-fb .container-faq .homenest__professional_website_question-number span{
  font-weight: 600;
  font-size: 60px;
  white-space: nowrap;
  text-align: left;
  background: linear-gradient(92.16deg, #020C6A 0%, #1A85F8 56.7%, #66E5FB 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  color: transparent;
}


.homenest-fb .container-faq .homenest__professional_website_toggle-btn {
  width: 40px;
  height: 40px;
  border-radius: 8px;
  background-color: #dee0e2;
  border: 1px solid #ccc;
  cursor: pointer;

  display: flex;
  align-items: center;
  justify-content: center;

  font-size: 20px;
  font-weight: bold;
  color: #333;
  line-height: 1;

  transition: 
    background-color 0.3s ease,
    color 0.3s ease,
    transform 0.2s ease;
}

.homenest-fb .container-faq .homenest__professional_website_toggle-btn.open {
  background-color: #1A85F8;
  color: white;
}
.homenest-fb .container-faq .homenest__professional_website_answer-wrapper {
  display: grid;
  grid-template-columns: 250px 1.5fr 40px;
  gap: 10px;
  padding: 0;
  max-height: 0;
  overflow: hidden;
  opacity: 0;
  transition:
    max-height 0.6s ease,
    padding 0.4s ease,
    opacity 0.4s ease;
}

.homenest-fb .container-faq .homenest__professional_website_answer-wrapper.show {
  max-height: 1000px;
  padding: 10px 0;
  opacity: 1;
}


.homenest-fb .container-faq .homenest__professional_website_answer {
  display: flex;
  align-items: center;
  height: 100%;
  font-size: 19px;
  font-weight: 300;
}
.homenest-fb .container-faq .homenest__professional_website_homenest-header-section h1 {
  font-size: 40px;
}
.homenest-fb .container-faq .homenest__professional_website_homenest-header-section h2 {
  font-size: 40px;
}



    
.homenest-fb .details-body-group {
  height: 0;
  overflow: hidden;
  transition: height 0.5s ease;
}

.homenest-fb summary {
  cursor: pointer;
  list-style: none;
  font-weight: 700;
  padding: 10px 0;
  font-size: 18px;
}

.homenest-fb .container-process {
  display: flex;
  margin: 0 auto;
  justify-content: center;
  align-items: flex-start;
  position: relative;
  padding: 50px 0;
  min-height: 1500px;
  background-color: #fff;
  background-image: 
    url('https://homenest.com.vn/wp-content/uploads/2024/11/Group-1203-1.png'),
    url('https://homenest.com.vn/wp-content/uploads/2024/11/Group-1219-600x1303.png'),
    url('https://homenest.com.vn/wp-content/uploads/2024/11/Frame.png');
  background-repeat: no-repeat, no-repeat, no-repeat;
  background-position: top right, top right, top right;
  background-size: 300px, 300px, 300px;
}

.homenest-fb .container-process  .process-left {
  margin-left: 50px;
  position: sticky;
  top: 80px;
  max-height: 100vh;
  
}

.homenest-fb .container-process .process-bottom {
  position: sticky;
  display: flex;
  align-items: flex-start;
}

.homenest-fb .container-process .process-top {
  display: flex;
  flex-direction: column;
  gap: 10px;
  position: absolute;
  left: 5px;
  top: 20px;
  z-index: 2;
  padding: 10px;
  border-radius: 8px;
}
.homenest-fb .container-process .process-top a svg{
  width: 50px;
  height: 50px;
}

.homenest-fb .container-process .process-bottom img {
  width: 650px;
}

.homenest-fb .container-process .process-right {
  flex: 1;
}

.homenest-fb .blank-pro{
  width: 100%;
  height: 600px;
  position: relative;
  background-image: url('https://homenest.com.vn/wp-content/uploads/2024/11/f001283b6f1ffb524922cd3349de3833.webp');
  background-position: center;
  background-size: cover;
}
.homenest-fb .blank-pro::after {
  content: "";
  position: absolute;
  inset: 0;
  background: rgba(0, 0, 0, 0.6);
  z-index: 1;
  pointer-events: none;
}


.homenest-fb .container-process .process-right ol {
  overflow-y: auto;
  margin-left: 50px;
  scrollbar-width: none;
  -ms-overflow-style: none;
}
.homenest-fb .container-process .process-right .website-logo {
  width: auto;
  max-width: 750px;
  position: relative;
}
.homenest-fb .container-process .process-right .website-logo h4{
  font-size: 24px;
  margin: 0;
  position: absolute;
  top: 0;
  right: 0;
  text-align: right;
  display: block;
  width: auto;
}

.homenest-fb .container-process .process-right .website-logo h1{
  font-size: 115px;
 margin-left: 50px;
 font-weight: bold;
 margin-bottom: 10px;;
 color: #fff;
  position: relative;
  -webkit-text-stroke: 2px transparent;
  text-stroke: 2px transparent; 
  background: linear-gradient(92.16deg, #0314a4 0%, #1569c3 56.7%, #52bbcd 100%);
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-stroke-color: transparent;
  text-stroke-color: transparent;
}
.homenest-fb .process-item{
  justify-content: right;
}
.homenest-fb .container-process .process-right  h2{
  font-size: 50px;
 margin-left: 50px;
 padding-right: 20px;
 font-weight: 900;
 margin-bottom: 30px;
}
.homenest-fb .container-process .process-right h2 .row-1{
  font-size: 50px;
}
.homenest-fb .container-process .process-right ol li {
  display: flex;
  align-items: center;
  padding: 10px 30px;
}
.homenest-fb .container-process .process-right ol li svg  {   
   padding: 10px;
}
.homenest-fb .container-process .process-right ol li p  {   
   padding: 10px;
  font-size: 20px;
  max-width: 600px;
  line-height: 1.8;
}

.homenest-fb .container-contact  {
  background-image: url('https://homenest.com.vn/wp-content/uploads/2024/11/31984fc126aff5ec9df718f896793610-scaled.jpg');
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  width: 100%;
  height: 700px;
  padding: 60px;
  display: flex;
    justify-content: center;
    align-items: flex-start;
}
.homenest-fb .container-contact .contact-left{
  width: 430px;
  background-color: rgba(202, 207, 210, 0.8);
  margin: 0 20px;
  border-radius: 20px;
  color: #fff;
}
.homenest-fb .container-contact .contact-left ul{
  display: flex;
  align-items: center;
  margin: 20px;
 
}
.homenest-fb .container-contact .contact-left h1{
  font-size: 40px;
  margin: 30px 10px 10px 30px;
    padding: 0 10px;

}
.homenest-fb .container-contact .contact-left h2{
  font-size: 30px;
  margin: 30px 10px 10px 30px;
    padding: 0 10px;

}
.homenest-fb .container-contact .contact-left p{
  font-size: 23px;
  margin: 30px 10px 10px 30px;
    padding: 0 10px;

}
.homenest-fb .container-contact .contact-left p a{
  color: #1a73e8;
}
.homenest-fb .container-contact .contact-left ul li {
  width: 30px;
  height: 30px;
  margin: 10px;
}
.homenest-fb .container-contact .contact-left svg {
  fill: #fff;
  color: #fff;
}

.homenest-fb .container-contact .contact-left svg path {
  fill: #fff;
}
.homenest-fb .container-contact .contact-right{
    align-items: flex-start;
    top: 0;
  width: 430px;
  height: 70px;
  background-color: rgba(202, 207, 210, 0.8);
  margin: 0 20px;
  border-radius: 20px;
}
.homenest-fb .container-contact .contact-right hr {
  margin: 35px;
  border: none;
  border-top: 1px solid rgba(202, 207, 210, 0.8);
}

/* ------------------------------------------------------------- */
/* ------------------------ RESPONSIVE ------------------------- */
/* ------------------------------------------------------------- */
@media (min-width: 1500px){

.homenest-fb .container-process .process-left {
    margin-left: 150px;
}
}

@media (max-width: 1200px){

  .homenest-fb .blank-pro{
  width: 100%;
  height: 20px;
    
}
.homenest-fb .blank-pro::after {
  content: "";
  position: absolute;
  inset: 0;
  background: rgb(121, 121, 121);
  z-index: 1;
  pointer-events: none;
}

}
@media (min-width: 769px) and (max-width: 1024px) {
  
  .homenest-fb .container .container-hero {
    padding: 20px;
  }
   .homenest-fb .why-use-wrapper .container-reasons h2{
    margin: 0 40px;
  }
  
  .homenest-fb .container .container-hero .container-left,
  .homenest-fb .container .container-hero .container-right,
  .homenest-fb .container-contact .contact-left,
  .homenest-fb .container-contact .contact-right {
    width: 100%;
    padding: 20px;
  }

  .homenest-fb .reasons {
    flex-wrap: wrap;
    justify-content: center;
  }

  .homenest-fb .reason {
    width: 45%;
  }
.homenest-fb .container-process .process-right .website-logo h1{
  font-size: 90px;
 margin-left: 20px;
 font-weight: bold;
 margin-bottom: 10px;;
 color: #fff;
  position: relative;
  -webkit-text-stroke: 2px transparent;
  text-stroke: 2px transparent; 
  background: linear-gradient(92.16deg, #0314a4 0%, #1569c3 56.7%, #52bbcd 100%);
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-stroke-color: transparent;
  text-stroke-color: transparent;
}
  .homenest-fb .center-center {
    text-align: center;
    margin-left: 0;
  }
  
  .homenest-fb .container-slideshow .slideshow-right {
    display: none;
  }

  .homenest-fb  .mySwiper {
    width: 95%;
   
  }
  .homenest-fb .container-faq .faq-right details {
    width: 100%;
  }

   .homenest-fb  .container-adss {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 20px;
    padding: 20px;
  }

  .homenest-fb .container-adss .container-adss-left,
  .homenest-fb .container-adss .container-adss-right {
    width: 100%;
  }

  .homenest-fb .container-adss .container-adss-left img {
     width: 100%;
    max-width: 500px;
    height: auto;
    object-fit: contain;
    display: block;
    margin: 0 auto;
  }

  .homenest-fb .container-adss .container-adss-right h2 {
    font-size: 45px;
    text-align: center;
  }
  .homenest-fb .container-adss .container-adss-right h2 .row-1,
  .homenest-fb .container-process .process-right h2,.homenest-fb .container-process .process-right h2,
  .homenest-fb .container-faq .homenest__professional_website_title-wrapper h2,
  .homenest-fb .slideshow-center-h2 .row-1, .homenest-fb .slideshow-center-h2
 {
    font-size: 45px;
}


  .homenest-fb .timeline {
    padding: 10px 0;
  }

  .homenest-fb .faq-item summary {
    font-size: 16px;
  }

  .homenest-fb .details-body-group {
    padding-left: 20px;
    font-size: 15px;
  }

  .homenest-fb .link-a {
    color: #007bff;
    text-decoration: underline;
  }


  .homenest-fb  .container-fanpage {
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 20px;
    position: relative;
  }

 .homenest-fb  .slideshow-left,
  .homenest-fb  .container-fanpage .container-fanpage-right {
    position: absolute;
    top: 0;
    bottom: 0;
    width: 50%;
    z-index: 1;
    opacity: 1;
  }

  .homenest-fb .slideshow-left {
    left: 0;
    max-height: 700px;
  }

  .homenest-fb  .container-fanpage .container-fanpage-right {
    right: 0;
  }



  .homenest-fb  .container-fanpage .container-fanpage-left {
    width: 100%;
    max-width: 900px;
    z-index: 2;
    padding: 20px;
    border-radius: 12px;
  }


    .homenest-fb .container-fanpage .container-fanpage-left h2 img {
      width: 300px;
}

.homenest-fb .container-process .process-bottom img {
    width: 450px;
}

   .homenest-fb .container-process  {
    position: relative;
    display: flex;
    flex-direction: column;
  }

  .homenest-fb .container-process .process-left {
    position: relative;
    z-index: 1;
  }

  .homenest-fb .container-process .process-left img {
    width: 100%;
    height: auto;
    object-fit: cover;
    margin-bottom: 100px;
  }


  .homenest-fb .container-process .process-right {
    top: 0;
    left: 0;
    padding: 20px;
    width: 100%;
    background: transparent;
  }
.homenest-fb .container-process .process-right h1,
.homenest-fb .container-process .process-right h2,
.homenest-fb .container-process .process-right ol {
  margin-left: 20px;
}

  .homenest-fb .container-faq {
    margin-top: 115px;
    position: relative;
    display: flex;
    flex-direction: column;
    height: auto;
    min-width: 1000px;
  }

  .homenest-fb .container-faq .faq-left {
    position: absolute;
    z-index: 1;
  }
  .homenest-fb .container-faq .faq-right {
    max-width: 100%;
}


  .homenest-fb .container-faq .faq-left img {
    width: 80%;
    height: auto;
    object-fit: cover;
  }
  .homenest-fb .faq-rr{
    display: flex;
    position: relative;
  }
  .homenest-fb .faq-rr img{
    width: 250px;
    position: absolute;
    right: 0;
   
  }
  .homenest-fb .container-faq .faq-right {
    top: 0;
    left: 0;
    z-index: 2;
    width: 100%;
    padding: 20px;
    height: auto;
  }
  .homenest-fb{
    overflow: hidden;
  }
  .homenest-fb .container .container-hero {
    padding: 20px;
  }
.homenest-fb .blank-pro {
        width: 100%;
        height: 20px;
        margin: 0;

    }
    .homenest-fb .container-fanpage .container-fanpage-left h2 {

    width: 60%;
}
    
  .homenest-fb .container .container-hero .container-left,
 .homenest-fb .container .container-hero .container-right {
    width: 100%;
    padding: 20px;
  }

  .homenest-fb .reasons {
    flex-wrap: wrap;
    justify-content: center;
  }

  .homenest-fb .reason {
    width: 45%;
  }

  .homenest-fb .container-faq .faq-right details {
    margin: 30px;
    margin-right: 0;
    max-width: 1024px;
    width: 90%;
  }
 
  .homenest-fb .container .container-hero .container-right {
    height: auto;
    margin-right: 10px;
  }


  .homenest-fb .container-contact .contact-left,
  .homenest-fb .container-contact .contact-right {
    width: 100%;
    margin: 20px;
  }



  .homenest-fb .container-contact  {
    flex-direction: column;
    height: auto;
  }
 .homenest-fb .mySwiper {
    width: 95%;
   
  }
  .homenest-fb .center-center{
    display: flex;
    position: relative;
  }
      .homenest-fb .center-center img {
        width: 120px;
        position: absolute;
        z-index: -1;
        right: 0;
    }
     .homenest-fb .container-slideshow .swiper .center-center .slideshow-center-h2
  {
    margin-bottom: 30px;
    width: 100%;
    display: block;
  }

}
@media (max-width: 900px) {
  .homenest-fb .container-faq .faq-right {
        max-width: 88%;
    }
        .homenest-fb .container-fanpage .container-fanpage-left h2 img {
display: none;
}
  .homenest-fb .container-process .process-right .website-logo {
    max-width: 600px;
  }
   .homenest-fb .slideshow-center-h2{
       display: block;
  }
 

}

/*  Mobile (≤768px) */
  @media (max-width: 768px) {
    .homenest-fb{
      overflow: hidden;
      margin-top: -60px;
    }
  .homenest-fb .container .container-hero {
    display: block;
  
}

  .homenest-fb .container .container-hero .container-left,
  .homenest-fb .container .container-hero .container-right {
    width: 100%;
    padding: 20px;
  }
   
  .homenest-fb .container .container-hero .container-left h2{
    margin-left: 0;
    font-size: 40px;
  }
  .homenest-fb .container .container-hero .container-right {
    min-height: 250px;
    max-height: 350px;
    display: flex;
    justify-content: center;
    align-items: end;
    gap: 30px;
  }

  .homenest-fb .container .container-hero .container-right img {
    max-width: 60%;
    margin: 10px 0;
  }
.homenest-fb .why-use-wrapper {
  margin: 0;
}
  
.homenest-fb h2,
 .homenest-fb  .slideshow-center-h2 {
    font-size: 30px;
    text-align: left;
    margin-left: 30px;
    display: block;
  }
  .homenest-fb .slideshow-center-h2 .row-1, .homenest-fb .slideshow-center-h2 {
    font-size: 30px;
}
.homenest-fb .container-faq .homenest__professional_website_title-wrapper h2
 {
    font-size: 30px;
}
  .homenest-fb .row-1{
    font-size: 30px;
  }
  .homenest-fb .reason {
    width: 100%;
  }

 .homenest-fb  .reasons {
    flex-direction: column;
    gap: 15px;
    padding: 0 20px;
  }

 .homenest-fb  .mySwiper {
    width: 95%;
   
  }
    .homenest-fb  .container-fanpage .container-fanpage-left h2{
    text-align: left;
    margin-left: -90px;
    padding-left: 0;
    }
  .homenest-fb  .container-fanpage .container-fanpage-left ul {
    grid-template-columns: 1fr;
    width: 90%;
    padding: 0 20px;
    margin: 0 auto;
  }
  .homenest-fb  .container-fanpage .container-fanpage-left ul li{
    display: flex;
  flex-direction: column;
  align-items: start;
  justify-content: center;
  width: 100%;
  padding-right: 20px;
  /* margin: 16px 20px; */
  }
.homenest-fb  .container-fanpage .container-fanpage-left ul li p{
  justify-content: center;
  text-align: start;
}
  .homenest-fb .container-faq .faq-right details {
    max-width: 768px;

  }

  .homenest-fb .container-faq .faq-right summary {
    font-size: 20px;
  }

  .homenest-fb .container-faq .faq-right details p {
    font-size: 18px;
    padding: 10px 20px;
  }
  .homenest-fb .flex{
  display: flex;
  justify-content: center;
  align-items: center;
}
  .homenest-fb .container-contact .contact-left,
  .homenest-fb .container-contact .contact-right {
    width: 100%;
    margin: 10px 0;
  }

  .homenest-fb .container-contact  {
    flex-direction: column;
    height: auto;
    padding: 30px 10px;
  }
.homenest-fb .container-fanpage .container-fanpage-left{
  display: block;
}
.homenest-fb .container-fanpage .container-fanpage-left h2 {
  align-self: center;
  width: 100%;
  max-width: 600px;
  margin-left: 40px;
  margin-bottom: 30px;
}
  
  .homenest-fb .container-process .process-right{
    margin-top: 150px;
  }
  .homenest-fb .container-process .process-right .website-logo{
    width: 350px;
  }
  .homenest-fb .container-process .process-right .website-logo h1 {
    font-size: 50px;
    margin-left: 30px;
    text-align: left;
    margin-top: 30px;
  }
  .homenest-fb .container-process .process-right .website-logo h4{
    font-size: 14px;
  }
  .homenest-fb .container-process .process-right h2{
    font-size: 30px;
    text-align: left;
    margin-left: 30px;
  }
    .homenest-fb .container-process .process-right h2 .row-1
  {
    font-size: 30px;
    text-align: left;
    margin-left: 1px;
  }

  .homenest-fb .process-item {
    margin-left: 0;
    flex-direction: column;
  }

  .homenest-fb .container-process .process-right ol {
    margin-left: 0;
    padding: 0 20px;
    max-height: none;
  }

  .homenest-fb .container-adss {
    display: block;
    align-items: center;
    padding: 20px;
    gap: 20px;
  }

  .homenest-fb .container-adss .container-adss-left,
  .homenest-fb .container-adss .container-adss-right {
    width: 100%;
    text-align: center;
  }
  .homenest-fb .container-adss .container-adss-right {
    align-items: center;
    margin: 0 20px;
  }
  .homenest-fb .container-adss .container-adss-left img {
    width: 90%;
    height: auto;
    max-width: 400px;
  }

  .homenest-fb .container-adss .container-adss-right h2 {
    font-size: 30px;
    line-height: 1.4;
    margin-bottom: 20px;
  }

  .homenest-fb .container-adss .container-adss-right h2 .row-1 {
    font-size:30px;
    margin-top: 5px;
  }

  .homenest-fb .timeline {
        margin: 0 30px;

  }

  .homenest-fb .faq-item summary {
    font-size: 16px;
    padding: 10px 0;
  }

 .homenest-fb  .details-body-group {
    padding-left: 10px;
  }

  .homenest-fb .details-body-group li {
    font-size: 14px;
    margin-bottom: 10px;
    text-align: start !important;
  }
  .homenest-fb  .container-fanpage .container-fanpage-right,
  .homenest-fb .container-slideshow  .slideshow-left,
  .homenest-fb .slideshow-left{
    display: none;
  }

  .homenest-fb .container-process {
    display: block;
    width: 100%;
  }
  .homenest-fb .container-process .process-left{
    width: 100%;
    justify-content: center;
    text-align: center;
    height: auto;
    position: relative;
    margin-left: 20px;
  }
  .homenest-fb .container-process .process-top a {
    margin-left: 18px;
    margin-top: 10px;
}
  .homenest-fb .container-process .process-top{
    width: 50px;
    height: auto;
    margin: 0;
    gap: 5px;
    margin-top: -15px;
    margin-left: -15px;

  }
  .homenest-fb .container-process .process-bottom{
    width: 500px;
    margin: 0;
  
  }
  .homenest-fb .container-process .process-bottom img{
    width: 100%;
  }

  .homenest-fb .container-process .process-right ol li {
    display: block;
    justify-content: center;
      text-align: center;
      margin-left: 90px;
      max-width: 500px;
  }
    .homenest-fb .container-process .process-right ol li p {
      width: 100%;
      max-width: 500px;
      justify-content: center;
      text-align: center;
    }


.homenest-fb .center-center {
        position: relative;
        height: 150px;
        flex-wrap: wrap;
    }
.homenest-fb .center-center img{
  position: absolute;
  right: 0;
  z-index: -1;
}

.homenest-fb .container-faq {
    position: relative;
    display: block;
  }
  .homenest-fb .container-faq .faq-left {
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    z-index: 1;
    opacity: 1;
    pointer-events: none;
  }
  .homenest-fb .container-faq .faq-right {
    position: relative;
    z-index: 2;
    max-width: 100%;
    background: transparent ;
    min-height: 100%;
  }
  .homenest-fb .container-faq .faq-right details{
    margin: 10px 20px;
    width: 95%;
  }
  .homenest-fb .container-faq .faq-right details summary{
    margin: 5px 20px;
    font-size: 18px;
  }
  .homenest-fb .container-faq .faq-right details summary .stt{
    font-size: 18px;
  }
  .homenest-fb .faq-rr {
  position: relative;
  display: flex;

}

.homenest-fb .faq-rr h2 {
  position: relative;
  z-index: 11;
  background: transparent;
}

.homenest-fb .faq-rr img {
  position: absolute;
  top: 0;
  left: 0;
  z-index: -1;
  width: 100%;
  height: auto;
  pointer-events: none;
}
.homenest-fb .prev {
  left: -10px;
  top: 60%;
}

.homenest-fb .next {
  right: -10px;
    top: 60%;
}

  .homenest-fb .container-faq .homenest__professional_website_faq {
    padding: 40px 16px;
  }

  .homenest-fb .container-faq .homenest__professional_website_question-header {
    display: grid;
    grid-template-columns: minmax(50px, 60px) 1fr 32px;
    gap: 8px;
    align-items: flex-start;
  }

  .homenest-fb .container-faq .homenest__professional_website_question-number span {
    font-size: 28px;
    white-space: nowrap;
    line-height: 1;
    text-align: left;
  }

  .homenest-fb .container-faq .homenest__professional_website_question-label {
    font-size: 13px;
    color: #1A85F8;
  }

  .homenest-fb .container-faq .homenest__professional_website_question-title {
    font-size: 15px;
    font-weight: 600;
    color: #111;
    padding: 10px 0;
  }

  .homenest-fb .container-faq .homenest__professional_website_toggle-btn {
    width: 32px;
    height: 32px;
    font-size: 18px;
    border-radius: 6px;
  }

  .homenest-fb .container-faq .homenest__professional_website_answer-wrapper {
    grid-template-columns: 1fr;
    padding: 0;
    gap: 12px;
  }

  .homenest-fb .container-faq .homenest__professional_website_answer {
    font-size: 15px;
    line-height: 1.5;
    padding: 0 30px;
  }

   .homenest-fb .container-faq .homenest__professional_website_question-label{
    width: 100px;
   }
   
.homenest-fb .container-faq .homenest__professional_website_answer-wrapper.show {
    display: flex;

}
.homenest-fb .container-faq .homenest__professional_website_faq p {
    font-size: 18px;

}
.homenest-fb .container-process .process-top a svg {
    width: 30px;
    height: 30px;
}
.homenest-fb .container-faq .homenest__professional_website_question-header-number {
    grid-template-columns: 60px 1.5fr 40px;
}
}


@media (max-width: 480px) {
  .homenest-fb{
    max-width: 480px;
    width: 100%;
    margin-top: -40px;
    overflow: hidden;
  }
  .homenest-fb  .container-fanpage  .container-fanpage-left ul li {
              display: flex;
        flex-direction: column;
        align-items: start;
        justify-content: left;
        width: 100%;
        padding-right: 20px;
        /* margin: 16px 20px; */
    }
   .homenest-fb .container{
    margin: 0;
   }
   .homenest-fb .container .container-hero .container-left h2 {
        margin-left: 10px;
        font-size: 25px;
    }
  .homenest-fb .container .container-hero,
  .homenest-fb .container-adss,
  .homenest-fb .container-fanpage,
 .homenest-fb .container-contact ,
  .homenest-fb .container-process,
  .homenest-fb .container-faq {
    padding: 0;
    flex-direction: column;
    margin: 0;
  }
.homenest-fb .container-adss .container-adss-right h2, 
.homenest-fb .container-adss .container-adss-right h2 .row-1
{
  font-size: 25px;
}
  .homenest-fb .row-1,
  h2,
  .slideshow-center-h2,
  .homenest-fb .container-faq .faq-right .faq-rr h2,
  .homenest-fb .container-contact .contact-left h1 {
    font-size: 20px;
    text-align: left;
    margin: 0 10px;
    margin-top: 10px;

  }
  .homenest-fb .container-contact .contact-left h2 {
    font-size: 20px;
    text-align: left;
    margin: 10px;
  }

  .homenest-fb .container-process .process-right h2 .row-1 {
      font-size: 22px;
  }
  .homenest-fb .container .container-hero .container-left,
  .homenest-fb .container .container-hero .container-right,
  .homenest-fb .container-contact .contact-left,
  .homenest-fb .container-contact .contact-right {
    width: 100%;
    padding: 15px;
    margin: 0 auto;
  }

  .homenest-fb .container .container-hero .container-right {
    gap: 30px;
    top: 80%;
    height: auto;
    align-items: end;
    justify-content: center;
  }

.homenest-fb .container-adss {
    padding: 15px 0;
  }

  .homenest-fb .container-adss .container-adss-right h2 {
    font-size: 25px;
  }

  .homenest-fb .container-adss .container-adss-right .row-1 {
    font-size: 20px;
  }

  .homenest-fb .details-body-group li {
    font-size: 13px;
  }

  .homenest-fb .faq-item summary i {
    font-size: 16px;
    margin-right: 8px;
  }
  .homenest-fb .container .container-hero .container-right img {
    max-width: 40%;
    margin: 10px 0;
  }
  .homenest-fb  .container-fanpage .container-fanpage-left h2{
    font-size: 22px;
    margin-left: 0;
    }
    .homenest-fb h2,
 .homenest-fb  .slideshow-center-h2 {
    font-size: 22px;
    text-align: left;
    display: block;
  }

  .homenest-fb .container-process .process-right .website-logo{
    margin-left: -20px;
    margin-bottom: 20px;
  }

  .homenest-fb .container .container-hero .container-left p,
  .homenest-fb .container .container-hero .container-left ul li,
  .homenest-fb .container-faq .faq-right details p,
  .homenest-fb .plan p,
 .homenest-fb  .reason p,
  .homenest-fb .container-process .process-right ol li p,
  .homenest-fb .container-contact .contact-left p {
    font-size: 14px;
    margin: 20px 10px;
    line-height: 2;

  }
.homenest-fb .container .container-hero .container-left ul li svg {
    width: 18px;
}
 .homenest-fb  .button,
  .homenest-fb .plan a button {
    width: 100%;
    font-size: 16px;
    padding: 15px;
  }

  .homenest-fb .container-slideshow .slideshow-left img,
  .homenest-fb .container-slideshow .slideshow-right img {
    height: 180px;
  }

  .homenest-fb .container-slideshow {
    height: 100%;
    padding-bottom: 50px;
  }
  .homenest-fb .center-center{
    position: relative;
    height: 120px;
  }
  .homenest-fb .center-center img {
    width: 120px;
    position: absolute;
    z-index: -1;
    right: 0;
  }

  .homenest-fb .reasons {
    flex-direction: column;
    gap: 15px;
  }

  .homenest-fb .reason {
    width: 100%;
  }

  .homenest-fb  .container-fanpage .container-fanpage-left ul {
    grid-template-columns: 1fr;
    padding: 0;
  margin: 16px 20px;
  }
  .homenest-fb  .container-fanpage .container-fanpage-left ul li p{
  text-align: start;
}

  .homenest-fb .container-faq.faq-right {
    padding: 0 10px;
  }
.homenest-fb .container-faq .faq-right {
  margin-right: 20px;
  max-width: 100%;
}
  .homenest-fb .container-faq .faq-right details {
    width: 97%;
  }

  .homenest-fb .container-faq .faq-right summary {
    font-size: 16px;
  }


.homenest-fb .mySwiper {
    width: 95%;
   
}
 .homenest-fb .container-faq .faq-right details p {
    padding: 10px 15px;
  }

  .homenest-fb .container-contact  {
    padding: 20px 10px;
    height: auto;
    background-position: center;
    background-size: cover;
  }

  .homenest-fb .container-contact .contact-left,
  .homenest-fb .container-contact .contact-right {
    width: 100%;
    margin: 10px 0;
  }

  .homenest-fb .container-contact .contact-left ul {
    flex-wrap: wrap;
    justify-content: center;
  }

.homenest-fb .container-process   .process-right h2 {
    font-size: 22px;
    margin-left: 10px;
    margin-top: -20px;
    text-align: left;
  }

  .homenest-fb .process-item {
    margin-left: 0;
    flex-direction: column;
  }

 .homenest-fb .container-process  .process-right ol {
    padding: 0 15px;
    margin-left: -25px;
    max-height: none;
  }

.homenest-fb .container-process .process-bottom img {
  width: 400px;
  height: auto;
}
    .homenest-fb .container-process .process-top {
        margin: 0;
        margin-top: -15px;
        margin-left: -20px;
    }
.homenest-fb .container-process .process-top a {
        margin-top: 0;
    }
 .homenest-fb .container-process  .process-right ol li {
      margin-left: 0;
  }

  .homenest-fb .slideshow-center-h2,
  .homenest-fb .row-1,
  .homenest-fb .slideshow-center-h2 .row-1 {
    font-size: 22px;
    margin: 0 1px;
  }
.homenest-fb .container-faq .homenest__professional_website_title-wrapper h2
 {
    font-size: 22px;
    padding: 40px 0;
}
  .homenest-fb .slideshow-left{
    display: none;
  }
  


  .homenest-fb .container-faq .homenest__professional_website_faq {
    padding: 40px 16px;
  }

  .homenest-fb .container-faq .homenest__professional_website_question-header {
    display: grid;
    grid-template-columns: minmax(50px, 60px) 1fr 32px;
    gap: 8px;
    align-items: flex-start;
  }

  .homenest-fb .container-faq .homenest__professional_website_question-number span {
    font-size: 28px;
    white-space: nowrap;
    line-height: 1;
    text-align: left;
  }

  .homenest-fb .container-faq .homenest__professional_website_question-label {
    font-size: 13px;
    color: #1A85F8;
  }

  .homenest-fb .container-faq .homenest__professional_website_question-title {
    font-size: 15px;
    font-weight: 600;
    color: #111;
    padding: 10px 0;
  }

  .homenest-fb .container-faq .homenest__professional_website_toggle-btn {
    width: 32px;
    height: 32px;
    font-size: 18px;
    border-radius: 6px;
  }

  .homenest-fb .container-faq .homenest__professional_website_answer-wrapper {
    grid-template-columns: 1fr;
    padding: 0;
    gap: 12px;
  }

  .homenest-fb .container-faq .homenest__professional_website_answer {
    font-size: 15px;
    line-height: 1.5;
  }

   .homenest-fb .container-faq .homenest__professional_website_question-label{
    width: 100px;
   }
.homenest-fb .container-faq .homenest__professional_website_faq p {
    font-size: 17px;
    margin-bottom: -65px;

}


}




</style>

<body>
     <div class="homenest-fb">
      <div class="container">

  <!-- Hero Section -->
        <div class="container-hero">
          <div class="container-left">
            <h2 class="row-1">Quảng Cáo Facebook Ads <br> Chuyên Nghiệp Tại Homenest</h2>
            <p>HomeNest cung cấp dịch vụ quảng cáo Facebook Ads chuyên nghiệp, giúp doanh nghiệp tiếp cận chính xác đối tượng khách hàng với các chiến dịch được thiết kế và tối ưu hóa theo mục tiêu cụ thể. Với kinh nghiệm chuyên sâu, HomeNest cam kết mang lại hiệu quả cao và tối đa hóa lợi nhuận từ ngân sách quảng cáo của bạn.</p>
            <ul>
              <li>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none"><path d="M10 3.85352H3V10.8535H10V3.85352Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M21 3.85352H14V10.8535H21V3.85352Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M21 14.8535H14V21.8535H21V14.8535Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M10 14.8535H3V21.8535H10V14.8535Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                Đối tác chính thức của Facebook tại Việt Nam</li>
              <li><svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none"><path d="M10 3.85352H3V10.8535H10V3.85352Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M21 3.85352H14V10.8535H21V3.85352Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M21 14.8535H14V21.8535H21V14.8535Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M10 14.8535H3V21.8535H10V14.8535Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                Ngân sách tiết kiệm nhất</li>
              <li><svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none"><path d="M10 3.85352H3V10.8535H10V3.85352Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M21 3.85352H14V10.8535H21V3.85352Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M21 14.8535H14V21.8535H21V14.8535Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M10 14.8535H3V21.8535H10V14.8535Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                Triển khai nhanh chóng, toàn diện</li>
              <li><svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none"><path d="M10 3.85352H3V10.8535H10V3.85352Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M21 3.85352H14V10.8535H21V3.85352Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M21 14.8535H14V21.8535H21V14.8535Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M10 14.8535H3V21.8535H10V14.8535Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                Bùng nổ doanh số từ Facebook</li>
            </ul>
            <a href=""><div class="button">Đăng ký nhận báo giá</div></a>
        </div>
          <div class="container-right">
            <img src="https://homenest.com.vn/wp-content/uploads//2024/11/Frame-56306.svg"  alt="Homenest" title="Homenest">
            <img src="https://homenest.com.vn/wp-content/uploads//2024/11/Frame-56307.svg" alt="Homenest" title="Homenest">
          </div>
          </div>
        </div>

    <!-- Các hình thức quảng cáo Facebook -->

      <div class="container-adss">
        <div class="container-adss-left">
          <img src="https://homenest.com.vn/wp-content/uploads/2024/11/Group-1277.webp" alt="Homenest" title="Homenest">
        </div>
        <div class="container-adss-right">
            <h2>Cung cấp mọi loại hình
              <div class="row-1">
                quảng cáo facebook
              </div>
            </h2>
            <div class="timeline">
            <details class="faq-item" open>
              <summary><span>
                <svg width="25" height="25" fill="none" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                  <defs>
                    <linearGradient id="pointer-gradient-1" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stop-color="#0417bd"/>
                      <stop offset="66%" stop-color="#1A85F8"/>
                      <stop offset="100%" stop-color="#66E5FB"/>
                    </linearGradient>
                  </defs>
                  <path d="M10.86 11.995l2.525 6.08L11.17 19l-2.525-6.05L5 16.625V1.1l10.946 10.888-5.086.006z"
                        fill="url(#pointer-gradient-1)"/>
                </svg>
              </span> Click to Website</summary>
              <div class="details-body-group">
                  <li>
                  Tăng hiệu quả bán hàng trực tiếp trên website
                  </li>
                  <li>
                    Tăng lượng traffic của website và sự tương tác giữa Fanpage với website của bạn
                  </li>
                  <li>
                    Giảm các chi phí cho việc <a href="" class="link-a">SEO</a> web và chạy quảng cáo trên Website
                  </li>
                </div>
            </details>
            <details class="faq-item">
              <summary><svg width="25" height="25" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                <defs>
                  <linearGradient id="pointer-gradient-3" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stop-color="#0417bd"/>
                    <stop offset="66%" stop-color="#1A85F8"/>
                    <stop offset="100%" stop-color="#66E5FB"/>
                  </linearGradient>
                </defs>
                <path fill="url(#pointer-gradient-3)"
                  d="M256 32C114.6 32 0 125.1 0 240c0 49.6 21.4 95 57 130.7C44.5 421.1 2.7 466 2.2 466.5c-2.2 2.3-2.8 5.7-1.5 8.7S4.8 480 8 480c66.3 0 116-31.8 140.6-51.4 32.7 12.3 69 19.4 107.4 19.4 141.4 0 256-93.1 256-208S397.4 32 256 32zM128 272c-17.7 0-32-14.3-32-32s14.3-32 32-32 32 14.3 32 32-14.3 32-32 32zm128 0c-17.7 0-32-14.3-32-32s14.3-32 32-32 32 14.3 32 32-14.3 32-32 32zm128 0c-17.7 0-32-14.3-32-32s14.3-32 32-32 32 14.3 32 32-14.3 32-32 32z">
                </path>
              </svg>
              Facebook - Messenger</summary>
              <div class="details-body-group">
                  <li>
                  Tăng hiệu quả bán hàng trực tiếp trên website
                  </li>
                  <li>
                    Tăng lượng traffic của website và sự tương tác giữa Fanpage với website của bạn
                  </li>
                  <li>
                    Giảm các chi phí cho việc SEO web và chạy quảng cáo trên Website
                  </li>
                </div>
            </details>
            <details class="faq-item">
              <summary><span>
                        <svg width="25" height="25" viewBox="0 0 512 512" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                          <defs>
                            <linearGradient id="pointer-gradient-6" x1="0%" y1="0%" x2="100%" y2="0%">
                              <stop offset="0%" stop-color="#0417bd" />
                              <stop offset="66%" stop-color="#1A85F8" />
                              <stop offset="100%" stop-color="#66E5FB" />
                            </linearGradient>
                          </defs>
                          <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                            <g id="icon" fill="url(#pointer-gradient-6)" transform="translate(85.333333, 42.666667)">
                              <path d="M170.666667,170.666667 C217.794965,170.666667 256,132.461632 256,85.3333333 
                                      C256,38.2050347 217.794965,0 170.666667,0 
                                      C123.538368,0 85.3333333,38.2050347 85.3333333,85.3333333 
                                      C85.3333333,132.461632 123.538368,170.666667 170.666667,170.666667 Z 
                                      M213.333333,213.333333 L128,213.333333 
                                      C57.307552,213.333333 0,270.640885 0,341.333333 
                                      L0,426.666667 L341.333333,426.666667 
                                      L341.333333,341.333333 C341.333333,270.640885 284.025781,213.333333 213.333333,213.333333 Z" 
                              id="user"></path>
                            </g>
                          </g>
                        </svg></span>
                  Engagement</summary>
              <div class="details-body-group">
                  <li>
                  Tăng hiệu quả bán hàng trực tiếp trên website
                  </li>
                  <li>
                    Tăng lượng traffic của website và sự tương tác giữa Fanpage với website của bạn
                  </li>
                  <li>
                    Giảm các chi phí cho việc SEO web và chạy quảng cáo trên Website
                  </li>
                </div>
            </details>
            <details class="faq-item">
              <summary><span>
                          <svg width="25" height="25" viewBox="0 -64 640 640" xmlns="http://www.w3.org/2000/svg">
                          <defs>
                          <linearGradient id="pointer-gradient-5" x1="0%" y1="0%" x2="100%" y2="0%">
                            <stop offset="0%" stop-color="#0417bd"/>
                            <stop offset="66%" stop-color="#1A85F8"/>
                            <stop offset="100%" stop-color="#66E5FB"/>
                          </linearGradient>
                        </defs>
                          <path fill="url(#pointer-gradient-5)"
                            d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4zm323-128.4l-27.8-28.1c-4.6-4.7-12.1-4.7-16.8-.1l-104.8 104-45.5-45.8c-4.6-4.7-12.1-4.7-16.8-.1l-28.1 27.9c-4.7 4.6-4.7 12.1-.1 16.8l81.7 82.3c4.6 4.7 12.1 4.7 16.8.1l141.3-140.2c4.6-4.7 4.7-12.2.1-16.8z">
                          </path>
                  </svg>
                  </span> Lead Ads</summary>
              <div class="details-body-group">
                  <li>
                  Tăng hiệu quả bán hàng trực tiếp trên website
                  </li>
                  <li>
                    Tăng lượng traffic của website và sự tương tác giữa Fanpage với website của bạn
                  </li>
                  <li>
                    Giảm các chi phí cho việc SEO web và chạy quảng cáo trên Website
                  </li>
                </div>
            </details>
          </div>
        </div>
        
      </div>
    


    <!-- Quản trị Fanpage -->

        <div class="container-fanpage">
          
          <div class="container-fanpage-left">
            <h2>Homenest - Giúp quản trị
              <div class="row-1">
                fanpage chuyên nghiệp
              </div>
            <img src="https://homenest.com.vn/wp-content/uploads/2024/11/Group-1203-1.png" alt="Homenest" title="Homenest">
            </h2>
          
          <ul>
            <li>
              <div class="flex">
                <span>
                  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <defs>
                        <linearGradient id="pointer-gradient-7" x1="0%" y1="0%" x2="100%" y2="0%">
                          <stop offset="0%" stop-color="#0417bd"/>
                          <stop offset="66%" stop-color="#1A85F8"/>
                          <stop offset="100%" stop-color="#66E5FB"/>
                        </linearGradient>
                      </defs>
                      <path fill-rule="evenodd" clip-rule="evenodd"
                        d="M2 2H22V22H2V2ZM6.74486 8C6.33313 8 6 8.33603 6 8.74674C6 9.15744 6.33313 9.49347 6.74486 9.49347C7.1566 9.49347 7.49347 9.15744 7.49347 8.74674C7.49347 8.33603 7.1566 8 6.74486 8ZM9.03917 8H18V9.49347H9.03917V8ZM9.03917 10.9869H18V12.4804H9.03917V10.9869ZM18 13.9739H9.03917V15.4674H18V13.9739ZM6 11.7337C6 11.323 6.33313 10.9869 6.74486 10.9869C7.1566 10.9869 7.49347 11.323 7.49347 11.7337C7.49347 12.1444 7.1566 12.4804 6.74486 12.4804C6.33313 12.4804 6 12.1444 6 11.7337ZM6.74486 13.9739C6.33313 13.9739 6 14.3099 6 14.7206C6 15.1313 6.33313 15.4674 6.74486 15.4674C7.1566 15.4674 7.49347 15.1313 7.49347 14.7206C7.49347 14.3099 7.1566 13.9739 6.74486 13.9739Z"
                        fill="url(#pointer-gradient-7)"/>
                    </svg>

                </span>
                <h3>Lập kế hoạch Content Marketing</h3>
              </div>
              
              <p>Nghiên cứu sản phẩm, đưa ra các mục tiêu, phương án làm việc hiệu quả</p>
            </li>
            <li>
              <div class="flex">
                <span>
                  <svg viewBox="0 -32 576 576" xmlns="http://www.w3.org/2000/svg">
                  <defs>
                    <linearGradient id="pointer-gradient-4" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stop-color="#0417bd"/>
                      <stop offset="66%" stop-color="#1A85F8"/>
                      <stop offset="100%" stop-color="#66E5FB"/>
                    </linearGradient>
                  </defs>
                  <path fill="url(#pointer-gradient-4)"
                    d="M416 192c0-88.4-93.1-160-208-160S0 103.6 0 192c0 34.3 14.1 65.9 38 92-13.4 30.2-35.5 54.2-35.8 54.5-2.2 2.3-2.8 5.7-1.5 8.7S4.8 352 8 352c36.6 0 66.9-12.3 88.7-25 32.2 15.7 70.3 25 111.3 25 114.9 0 208-71.6 208-160zm122 220c23.9-26 38-57.7 38-92 0-66.9-53.5-124.2-129.3-148.1.9 6.6 1.3 13.3 1.3 20.1 0 105.9-107.7 192-240 192-10.8 0-21.3-.8-31.7-1.9C207.8 439.6 281.8 480 368 480c41 0 79.1-9.2 111.3-25 21.8 12.7 52.1 25 88.7 25 3.2 0 6.1-1.9 7.3-4.8 1.3-2.9.7-6.3-1.5-8.7-.3-.3-22.4-24.2-35.8-54.5z">
                  </path>
                </svg>

                </span>
                <h3>Set Up Chatbot Chuyên Nghiệp</h3>
              </div>
              <p>Dựa trên kiến thức nghiên cứu để chủ động thiết kế botchat</p>
            </li>
            <li>
              <div class="flex">
                <span>
                  <svg viewBox="0 0 36 36" version="1.1" preserveAspectRatio="xMidYMid meet"
                    xmlns="http://www.w3.org/2000/svg">
                  <defs>
                    <linearGradient id="pointer-gradient-10" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stop-color="#0417bd"/>
                      <stop offset="66%" stop-color="#1A85F8"/>
                      <stop offset="100%" stop-color="#66E5FB"/>
                    </linearGradient>
                  </defs>
                  <g>
                    <path d="M30.14,3h0a1,1,0,0,0-1-1h-22a1,1,0,0,0-1,1h0V4h24Z"
                          fill="url(#pointer-gradient-10)"></path>
                    <path d="M32.12,7V7a1,1,0,0,0-1-1h-26a1,1,0,0,0-1,1h0V8h28Z"
                          fill="url(#pointer-gradient-10)"></path>
                    <path d="M32.12,10H3.88A1.88,1.88,0,0,0,2,11.88V30.12A1.88,1.88,0,0,0,3.88,32H32.12A1.88,1.88,0,0,0,34,30.12V11.88A1.88,1.88,0,0,0,32.12,10ZM8.56,13.45a3,3,0,1,1-3,3A3,3,0,0,1,8.56,13.45ZM30,28h-24l7.46-7.47a.71.71,0,0,1,1,0l3.68,3.68L23.21,19a.71.71,0,0,1,1,0L30,24.79Z"
                          fill="url(#pointer-gradient-10)"></path>
                    <rect x="0" y="0" width="36" height="36" fill-opacity="0"></rect>
                  </g>
                </svg>

                </span>
                <h3>Thiết kế Hình ảnh Chuyên nghiệp</h3>
              </div>
              <p>Thiết kế hình ảnh sản phẩm chuyên nghiệp, thay đổi bộ mặt sản phẩm, tăng uy tín.</p>
            </li>
            <li>
              <div class="flex">
                <span><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <defs>
                      <linearGradient id="pointer-gradient-9" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stop-color="#0417bd"/>
                        <stop offset="66%" stop-color="#1A85F8"/>
                        <stop offset="100%" stop-color="#66E5FB"/>
                      </linearGradient>
                    </defs>
                    <path 
                      d="M21 16V7.2C21 6.0799 21 5.51984 20.782 5.09202C20.5903 4.71569 20.2843 4.40973 19.908 4.21799C19.4802 4 18.9201 4 17.8 4H6.2C5.07989 4 4.51984 4 4.09202 4.21799C3.71569 4.40973 3.40973 4.71569 3.21799 5.09202C3 5.51984 3 6.0799 3 7.2V16M4.66667 20H19.3333C19.9533 20 20.2633 20 20.5176 19.9319C21.2078 19.7469 21.7469 19.2078 21.9319 18.5176C22 18.2633 22 17.9533 22 17.3333C22 17.0233 22 16.8683 21.9659 16.7412C21.8735 16.3961 21.6039 16.1265 21.2588 16.0341C21.1317 16 20.9767 16 20.6667 16H3.33333C3.02334 16 2.86835 16 2.74118 16.0341C2.39609 16.1265 2.12654 16.3961 2.03407 16.7412C2 16.8683 2 17.0233 2 17.3333C2 17.9533 2 18.2633 2.06815 18.5176C2.25308 19.2078 2.79218 19.7469 3.48236 19.9319C3.73669 20 4.04669 20 4.66667 20Z"
                      stroke="url(#pointer-gradient-9)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  </svg>
                  </span>
                <h3>Seeding Tương tác Bài viết</h3>
              </div>
              <p>Digimat sẽ seeding tăng tương tác bài viết bằng account thật, tạo tương tác thật cho Fanpage.</p>
            </li>
          </ul>
        </div>
          <div class="container-fanpage-right">
            <img src="https://homenest.com.vn/wp-content/uploads/2024/11/Group-1203-1.png" alt="Homenest" title="Homenest">
          </div>
          
        </div>

      <!-- Lý do sử dụng Facebook Ads -->
    <div class="why-use-wrapper">
        <div class="container-reasons">
          <h2>Vì sao nên sử dụng facebook ads <div class="row-1">
              dành cho doanh nghiệp của bạn
            </div>
          </h2>
          <div class="reasons">
            <div class="reason  rea-1">
                <div class="reason-1">
                  <img src="https://h2.homenest.tech/wp-content/uploads/2025/06/homenest_business.svg" alt="Homenest" title="Homenest">
              <h3>Tiếp cận đối tượng mục tiêu</h3>
              <hr>
              <p><a href="" class="link-a">Facebook Ads</a> cho phép doanh nghiệp nhắm mục tiêu theo độ tuổi, giới tính, vị trí địa lý, sở thích và hành vi, giúp tối ưu hóa hiệu quả quảng cáo.</p>
                </div>
            </div>
            <div class="reason  rea-2">
                <div class="reason-1">
                <img src="https://h2.homenest.tech/wp-content/uploads/2025/06/homenest_business.svg" alt="Homenest" title="Homenest">

              <h3>Tăng tương tác và nhận diện</h3>
              <hr>
              <p>Quảng cáo trên Facebook giúp doanh nghiệp xây dựng hình ảnh thương hiệu và duy trì sự hiện diện trong tâm trí khách hàng thông qua nội dung thu hút và đa dạng.</p>
                </div>
              </div>
            <div class="reason rea-3">
                <div class="reason-1">   
                <img src="https://h2.homenest.tech/wp-content/uploads/2025/06/homenest_business.svg" alt="Homenest" title="Homenest">

                <h3>Chi phí linh hoạt và hiệu quả</h3>
                <hr>
                <p>Facebook Ads cho phép bạn kiểm soát chi phí quảng cáo bằng cách thiết lập ngân sách phù hợp, chỉ trả tiền cho những hành động cụ thể như lượt nhấp chuột, lượt xem hoặc lượt chuyển đổi.</p>
                  </div>
                </div>
              <div class="reason  rea-4">
                  <div class="reason-1">
                    <img src="https://h2.homenest.tech/wp-content/uploads/2025/06/homenest_business.svg" alt="Homenest" title="Homenest">

              <h3>Công cụ đo lường mạnh mẽ</h3>
              <hr>
              <p>Facebook cung cấp các công cụ phân tích chi tiết để bạn theo dõi hiệu suất chiến dịch, điều chỉnh kịp thời và tối ưu hóa lợi nhuận.</p>
                </div>
              </div>
          </div>
        </div>

      </div>

    <!-- Bảng giá  -->
      <div class="container-slideshow">
          <div class="slideshow-left">
        <img src="https://homenest.com.vn/wp-content/uploads/2024/11/Frame-2.png" alt="Homenest" title="Homenest">
      </div>
    <!-- Swiper -->
    
    <div class="swiper mySwiper">
      <div class="center-center">
                <h2 class="slideshow-center-h2">Bảng giá <div class="row-1">quảng cáo facebook ads</div>
                </h2>
                <img src="https://homenest.com.vn/wp-content/uploads/2024/11/Group-1203-1.png" alt="Homenest" title="Homenest">
            </div>
      <div class="swiper-wrapper">
        <!-- Plan BASIC -->
              <div class="swiper-slide plan basic">
                <h3 style="background-color: #2db5b1;">BASIC</h3>
                <p><span class="black_normal"><strong style="color:#2db5b1;">Gói Basic</strong> Tập trung vào nâng cao trải nghiệm người dùng và nhận diện thương hiệu.</span></p>
                <hr>
                <ul>
                  <li><svg fill="#2db5b1" width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg>
                            Thiết kế ảnh và viết 2 Content QC</li>
                  <li><svg fill="#2db5b1" width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg> Quản lý 4 chiến dịch Quảng cáo</li>
                  <li><svg fill="#2db5b1" width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg> Quản lý ngân sách &lt; 20.000.000đ</li>
                  <li><svg fill="#2db5b1" width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg> Theo dõi tối ưu quảng cáo</li>
                </ul>
                <hr>
                <p class="sale">10% Ngân sách quảng cáo</p>
                <p class="sale">*Liên hệ ngay để được tư vấn miễn phí</p>
                <div class="button">
                  <div class="button-img"><img src="https://homenest.media/wp-content/uploads/2025/02/Icon-Call-Homenest.media_.svg" alt="Homenest" title="Homenest"></div>
                  <div class="button-price">
                    <div class="button-price-before">4.000.000</div>
                    <div class="button-price-after">Tư vấn ngay</div>
                  </div>
                </div>
              </div>

              <!-- Plan GOLDEN -->
              <div class="swiper-slide plan golden">
                <h3 style="background-color: #ff9800;">GOLDEN</h3>
                <p><span class="black_normal"><strong style="color:#ff9800;">Gói Golden</strong> Tối ưu hóa trải nghiệm người dùng và thúc đẩy quảng bá thương hiệu.</span></p>
                <hr>
                <ul>
                  <li><svg fill="#ff9800"  width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg> Thiết kế ảnh và viết 5 Content QC</li>
                  <li><svg fill="#ff9800"  width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg> Quản lý 10 chiến dịch Quảng cáo</li>
                  <li><svg fill="#ff9800"  width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg> Quản lý ngân sách &lt; 60.000.000đ</li>
                  <li><svg fill="#ff9800"  width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg> Theo dõi tối ưu quảng cáo</li>
                </ul>
                <hr>
                <p class="sale">10% Ngân sách quảng cáo</p>
                <p class="sale">*Liên hệ ngay để được tư vấn miễn phí</p>
                <div class="button">
                  <div class="button-img"><img src="https://homenest.media/wp-content/uploads/2025/02/Icon-Call-Homenest.media_.svg" alt="Homenest" title="Homenest"></div>
                  <div class="button-price">
                    <div class="button-price-before">6.000.000</div>
                    <div class="button-price-after">Tư vấn ngay</div>
                  </div>
                </div>
              </div>

              <!-- Plan DIAMOND -->
              <div class="swiper-slide plan diamond">
                <h3 style="background-color: #020c6a;">DIAMOND</h3>
                <p><span class="black_normal"><strong style="color:#020c6a;">Gói Diamond</strong> SEO tăng mạnh, cải thiện thứ hạng từ khóa, tăng lượng truy cập và tối ưu tỷ lệ chuyển đổi.</span></p>
                <hr>
                <ul>
                  <li><svg fill="#020c6a"  width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg> Thiết kế ảnh và viết 11 Content QC</li>
                  <li><svg fill="#020c6a"  width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg> Quản lý 22 chiến dịch Quảng cáo</li>
                  <li><svg fill="#020c6a"  width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg> Quản lý ngân sách &lt; 200.000.000đ</li>
                  <li><svg fill="#020c6a"  width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg> Theo dõi tối ưu quảng cáo</li>
                </ul>
                <hr>
                <p class="sale">10% Ngân sách quảng cáo</p>
                <p class="sale">*Liên hệ ngay để được tư vấn miễn phí</p>
                <div class="button">
                  <div class="button-img"><img src="https://homenest.media/wp-content/uploads/2025/02/Icon-Call-Homenest.media_.svg" alt="Homenest" title="Homenest"></div>
                  <div class="button-price">
                    <div class="button-price-before">12.000.000</div>
                    <div class="button-price-after">Tư vấn ngay</div>
                  </div>
                </div>
              </div>

              <!-- Plan PLATINUM -->
              <div class="swiper-slide plan platinum">
                <h3 style="background-color: #972295;">PLATINUM</h3>
                <p><span class="black_normal"><strong style="color:#972295;">Gói Platinum</strong> Thống trị thị trường, chiếm lĩnh toàn bộ không gian tìm kiếm tự nhiên trên Google.</span></p>
                <hr>
                <ul>
                  <li><svg  fill="#972295"  width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg> Thiết kế ảnh và viết 11 Content QC</li>
                  <li><svg  fill="#972295" width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg> Quản lý 22 chiến dịch Quảng cáo</li>
                  <li><svg  fill="#972295" width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg> Quản lý ngân sách &lt; 200.000.000đ</li>
                  <li><svg  fill="#972295" width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg> Theo dõi tối ưu quảng cáo</li>
                </ul>
                <hr>
                <p class="sale">10% Ngân sách quảng cáo</p>
                <p class="sale">*Liên hệ ngay để được tư vấn miễn phí</p>
                <div class="button">
                  <div class="button-img"><img src="https://homenest.media/wp-content/uploads/2025/02/Icon-Call-Homenest.media_.svg" alt="Homenest" title="Homenest"></div>
                  <div class="button-price">
                    <div class="button-price-before">18.000.000</div>
                    <div class="button-price-after">Tư vấn ngay</div>
                  </div>
                </div>
              </div>
              <!-- Plan BASIC -->
              <div class="swiper-slide plan basic">
                <h3 style="background-color: #2db5b1;">BASIC</h3>
                <p><span class="black_normal"><strong style="color:#2db5b1;">Gói Basic</strong> Tập trung vào nâng cao trải nghiệm người dùng và nhận diện thương hiệu.</span></p>
                <hr>
                <ul>
                  <li><svg fill="#2db5b1" width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg>
                            Thiết kế ảnh và viết 2 Content QC</li>
                  <li><svg fill="#2db5b1" width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg> Quản lý 4 chiến dịch Quảng cáo</li>
                  <li><svg fill="#2db5b1" width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg> Quản lý ngân sách &lt; 20.000.000đ</li>
                  <li><svg fill="#2db5b1" width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg> Theo dõi tối ưu quảng cáo</li>
                </ul>
                <hr>
                <p class="sale">10% Ngân sách quảng cáo</p>
                <p class="sale">*Liên hệ ngay để được tư vấn miễn phí</p>
                <div class="button">
                  <div class="button-img"><img src="https://homenest.media/wp-content/uploads/2025/02/Icon-Call-Homenest.media_.svg" alt="Homenest" title="Homenest"></div>
                  <div class="button-price">
                    <div class="button-price-before">4.000.000</div>
                    <div class="button-price-after">Tư vấn ngay</div>
                  </div>
                </div>
              </div>

              <!-- Plan GOLDEN -->
              <div class="swiper-slide plan golden">
                <h3 style="background-color: #ff9800;">GOLDEN</h3>
                <p><span class="black_normal"><strong style="color:#ff9800;">Gói Golden</strong> Tối ưu hóa trải nghiệm người dùng và thúc đẩy quảng bá thương hiệu.</span></p>
                <hr>
                <ul>
                  <li><svg fill="#ff9800"  width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg> Thiết kế ảnh và viết 5 Content QC</li>
                  <li><svg fill="#ff9800"  width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg> Quản lý 10 chiến dịch Quảng cáo</li>
                  <li><svg fill="#ff9800"  width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg> Quản lý ngân sách &lt; 60.000.000đ</li>
                  <li><svg fill="#ff9800"  width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg> Theo dõi tối ưu quảng cáo</li>
                </ul>
                <hr>
                <p class="sale">10% Ngân sách quảng cáo</p>
                <p class="sale">*Liên hệ ngay để được tư vấn miễn phí</p>
                <div class="button">
                  <div class="button-img"><img src="https://homenest.media/wp-content/uploads/2025/02/Icon-Call-Homenest.media_.svg" alt="Homenest" title="Homenest"></div>
                  <div class="button-price">
                    <div class="button-price-before">6.000.000</div>
                    <div class="button-price-after">Tư vấn ngay</div>
                  </div>
                </div>
              </div>

              <!-- Plan DIAMOND -->
              <div class="swiper-slide plan diamond">
                <h3 style="background-color: #020c6a;">DIAMOND</h3>
                <p><span class="black_normal"><strong style="color:#020c6a;">Gói Diamond</strong> SEO tăng mạnh, cải thiện thứ hạng từ khóa, tăng lượng truy cập và tối ưu tỷ lệ chuyển đổi.</span></p>
                <hr>
                <ul>
                  <li><svg fill="#020c6a"  width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg> Thiết kế ảnh và viết 11 Content QC</li>
                  <li><svg fill="#020c6a"  width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg> Quản lý 22 chiến dịch Quảng cáo</li>
                  <li><svg fill="#020c6a"  width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg> Quản lý ngân sách &lt; 200.000.000đ</li>
                  <li><svg fill="#020c6a"  width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg> Theo dõi tối ưu quảng cáo</li>
                </ul>
                <hr>
                <p class="sale">10% Ngân sách quảng cáo</p>
                <p class="sale">*Liên hệ ngay để được tư vấn miễn phí</p>
                <div class="button">
                  <div class="button-img"><img src="https://homenest.media/wp-content/uploads/2025/02/Icon-Call-Homenest.media_.svg" alt="Homenest" title="Homenest"></div>
                  <div class="button-price">
                    <div class="button-price-before">12.000.000</div>
                    <div class="button-price-after">Tư vấn ngay</div>
                  </div>
                </div>
              </div>

              <!-- Plan PLATINUM -->
              <div class="swiper-slide plan platinum">
                <h3 style="background-color: #972295;">PLATINUM</h3>
                <p><span class="black_normal"><strong style="color:#972295;">Gói Platinum</strong> Thống trị thị trường, chiếm lĩnh toàn bộ không gian tìm kiếm tự nhiên trên Google.</span></p>
                <hr>
                <ul>
                  <li><svg  fill="#972295"  width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg> Thiết kế ảnh và viết 11 Content QC</li>
                  <li><svg  fill="#972295" width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg> Quản lý 22 chiến dịch Quảng cáo</li>
                  <li><svg  fill="#972295" width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg> Quản lý ngân sách &lt; 200.000.000đ</li>
                  <li><svg  fill="#972295" width="20" height="20" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin"
                     class="jam jam-microchip"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" 
                     stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier">
                      <path d="M6 3h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zm0 2a1 
                      1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6zm2 2h4a1 1 0 0 1 1 1v4a1 1 0
                       0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1 2v2h2V9H9zM6 0a1 1 0 0 1 1 1v2a1 1 0 1 1-2 0V1a1 1 0 0
                        1 1-1zM1 5h2a1 1 0 1 1 0 2H1a1 1 0 1 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 9h2a1 1 0 1 1 0 2H1a1
                         1 0 0 1 0-2zm16 0h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zM1 13h2a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2zm16 0h2a1 1 0 0
                          1 0 2h-2a1 1 0 0 1 0-2zM6 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zm8-16a1 1 0 0 1 1 1v2a1 1 0 0
                           1-2 0V1a1 1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM10 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V1a1
                            1 0 0 1 1-1zm0 16a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1z"></path></g></svg> Theo dõi tối ưu quảng cáo</li>
                </ul>
                <hr>
                <p class="sale">10% Ngân sách quảng cáo</p>
                <p class="sale">*Liên hệ ngay để được tư vấn miễn phí</p>
                <div class="button">
                  <div class="button-img"><img src="https://homenest.media/wp-content/uploads/2025/02/Icon-Call-Homenest.media_.svg" alt="Homenest" title="Homenest"></div>
                  <div class="button-price">
                    <div class="button-price-before">18.000.000</div>
                    <div class="button-price-after">Tư vấn ngay</div>
                  </div>
                </div>
              </div>
              
      </div>
      <button class="slide-btn prev">
        <span>
          <svg width="35" height="35" viewBox="0 0 24 24" fill="none">
            <defs>
              <linearGradient id="chevron-left-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stop-color="#0417bd"/>
                <stop offset="66%" stop-color="#1A85F8"/>
                <stop offset="100%" stop-color="#66E5FB"/>
              </linearGradient>
            </defs>
            <path d="M15 6L9 12L15 18" stroke="url(#chevron-left-gradient)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </span></button>

      <button class="slide-btn next">
        <span>
          <svg width="35" height="35" viewBox="0 0 24 24" fill="none">
            <defs>
              <linearGradient id="chevron-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stop-color="#0417bd"/>
                <stop offset="66%" stop-color="#1A85F8"/>
                <stop offset="100%" stop-color="#66E5FB"/>
              </linearGradient>
            </defs>
            <path d="M9 6L15 12L9 18" stroke="url(#chevron-gradient)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </span></button>
    </div>
    
      <div class="slideshow-right">
        <img src="https://homenest.com.vn/wp-content/uploads/2024/11/Frame.png" alt="Homenest" title="Homenest">
      </div>
  </div>

        <div class="blank-pro">
        </div>
    <!-- Quy trình -->

        <div class="container-process">
          <div class="process-left">
            <div class="process-top">
                <a href=""><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 40 40" fill="none"><rect x="0.5" y="0.5" width="39" height="39" rx="7.5" stroke="#898384"></rect><path d="M21.4602 28.5V21.0621H23.9137L24.3805 17.9822H21.4602V15.9903C21.4602 15.1498 21.87 14.3266 23.1736 14.3266H24.5V11.7072C24.5 11.7072 23.2932 11.5 22.1433 11.5C19.741 11.5 18.1698 12.9738 18.1698 15.6392V17.9822H15.5V21.0621H18.1755V28.5H21.4602Z" fill="#898384"></path></svg></a>
              <a href=""><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 40 40" fill="none"><rect x="0.5" y="0.5" width="39" height="39" rx="7.5" stroke="#898384"></rect><path d="M24.1934 14.9082C23.6811 14.9082 23.2666 15.3227 23.2666 15.835C23.2666 16.3473 23.6811 16.7618 24.1934 16.7618C24.7057 16.7618 25.1202 16.3473 25.1202 15.835C25.1259 15.3227 24.7057 14.9082 24.1934 14.9082Z" fill="#898384"></path><path d="M20.0659 16.0996C17.913 16.0996 16.1631 17.8495 16.1631 20.0024C16.1631 22.1553 17.913 23.9052 20.0659 23.9052C22.2188 23.9052 23.9687 22.1553 23.9687 20.0024C23.9687 17.8495 22.2188 16.0996 20.0659 16.0996ZM20.0659 22.5007C18.6901 22.5007 17.5676 21.3782 17.5676 20.0024C17.5676 18.6267 18.6901 17.5042 20.0659 17.5042C21.4417 17.5042 22.5642 18.6267 22.5642 20.0024C22.5642 21.3782 21.4417 22.5007 20.0659 22.5007Z" fill="#898384"></path><path d="M23.1629 27.9234H16.8367C14.2118 27.9234 12.0762 25.7878 12.0762 23.1629V16.8367C12.0762 14.2118 14.2118 12.0762 16.8367 12.0762H23.1629C25.7878 12.0762 27.9234 14.2118 27.9234 16.8367V23.1629C27.9234 25.7878 25.7878 27.9234 23.1629 27.9234ZM16.8367 13.5671C15.0349 13.5671 13.5671 15.0349 13.5671 16.8367V23.1629C13.5671 24.9647 15.0349 26.4325 16.8367 26.4325H23.1629C24.9647 26.4325 26.4325 24.9647 26.4325 23.1629V16.8367C26.4325 15.0349 24.9647 13.5671 23.1629 13.5671H16.8367Z" fill="#898384"></path></svg></a>
              <a href=""><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 40 40" fill="none"><rect x="0.5" y="0.5" width="39" height="39" rx="7.5" stroke="#898384"></rect><path d="M27.5 18.2828C27.3544 18.2943 27.2143 18.3058 27.0687 18.3058C25.4892 18.3058 24.0161 17.489 23.1535 16.1314V23.5292C23.1535 26.5494 20.7674 29 17.8267 29C14.8861 29 12.5 26.5494 12.5 23.5292C12.5 20.5091 14.8861 18.0585 17.8267 18.0585C17.9388 18.0585 18.0452 18.07 18.1572 18.0757V20.768C18.0452 20.7565 17.9388 20.7335 17.8267 20.7335C16.3256 20.7335 15.1102 21.9818 15.1102 23.5235C15.1102 25.0652 16.3256 26.3135 17.8267 26.3135C19.3279 26.3135 20.6553 25.0997 20.6553 23.558L20.6833 11H23.1927C23.4279 13.3126 25.2427 15.1189 27.5 15.2857V18.2828Z" fill="#898384"></path></svg></a>
              <a href=""><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 40 40" fill="none"><rect x="0.5" y="0.5" width="39" height="39" rx="7.5" stroke="#898384"></rect><path d="M28.5 17.7634C28.5 15.6845 26.8296 14 24.7682 14H15.2318C13.1704 14 11.5 15.6845 11.5 17.7634V22.2366C11.5 24.3155 13.1704 26 15.2318 26H24.7682C26.8296 26 28.5 24.3155 28.5 22.2366V17.7634ZM22.8911 20.338L18.6173 22.4732C18.4497 22.5634 17.8799 22.4394 17.8799 22.2479V17.8704C17.8799 17.6732 18.4553 17.5549 18.6229 17.6507L22.7179 19.8986C22.8855 19.9944 23.0643 20.2423 22.8911 20.338Z" fill="#898384"></path></svg></a>
              <a href=""><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 40 40" fill="none"><rect x="0.5" y="0.5" width="39" height="39" rx="7.5" stroke="#898384"></rect><path d="M12.3816 17.3608H15.6512V27.8546H12.3816V17.3608ZM14.0164 12.1455C15.0641 12.1455 15.9103 12.9917 15.9103 14.0336C15.9103 15.0755 15.0641 15.9274 14.0164 15.9274C12.9688 15.9274 12.1226 15.0813 12.1226 14.0336C12.1226 12.9917 12.9688 12.1455 14.0164 12.1455Z" fill="#898384"></path><path d="M17.7007 17.3605H20.8321V18.7938H20.8724C21.3099 17.9707 22.3749 17.0957 23.9636 17.0957C27.2678 17.0957 27.8779 19.2659 27.8779 22.098V27.8543H24.6198V22.7484C24.6198 21.5281 24.5968 19.9624 22.9217 19.9624C21.2236 19.9624 20.9645 21.2863 20.9645 22.6563V27.8486H17.7064V17.3605H17.7007Z" fill="#898384"></path></svg></a>
          
            </div>
            <div class="process-bottom">
              <img src="https://homenest.com.vn/wp-content/uploads/2024/11/Mask-group.png" alt="Homenest" title="Homenest">
            </div>
            </div>
          <div class="process-right">
            <div class="website-logo">
              <h4>Website</h4>
            <h1>HOMENEST</h1>
            </div>  
            
            <h2>Quy trình
                <div class="row-1">Thiết kế website theo yêu cầu</div>
              </h2>
              <ol>
                <li>
                  <!-- 1 -->
              <svg xmlns="http://www.w3.org/2000/svg" width="185" height="114" viewBox="0 0 185 114" fill="none">
                <defs>
                  <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="0%" gradientTransform="rotate(2.16)">
                    <stop offset="0%" stop-color="#0417bd" />
                    <stop offset="26.7%" stop-color="#1A85F8" />
                    <stop offset="80%" stop-color="#66E5FB" />
                  </linearGradient>
                </defs>

                <path fill-rule="evenodd" clip-rule="evenodd" d="M157.512 110.9H183.384V3.09961H143.036V25.7376H157.512V110.9ZM156.512 26.7376V111.9H184.384V2.09961H142.036V26.7376H156.512Z" fill="url(#grad)"></path>

                <path fill-rule="evenodd" clip-rule="evenodd" d="M47.123 98.2285C39.985 88.5073 36.2261 74.45 36.2261 56.9999C36.2261 39.5497 39.985 25.4924 47.123 15.7713C54.2904 6.01017 64.7999 0.713867 78.0361 0.713867C91.1974 0.713867 101.668 6.01183 108.815 15.7723C115.933 25.493 119.692 39.5496 119.692 56.9999C119.692 74.4501 115.933 88.5067 108.815 98.2274C101.668 107.988 91.1974 113.286 78.0361 113.286C64.7999 113.286 54.2904 107.99 47.123 98.2285ZM68.063 79.2471C70.5783 84.5386 74.0395 87.2619 78.0361 87.2619C81.8687 87.2619 85.2951 84.5516 87.8167 79.2471C90.3302 73.9594 91.8201 66.3051 91.8201 56.9999C91.8201 47.6946 90.3302 40.0404 87.8167 34.7527C85.2951 29.4481 81.8687 26.7379 78.0361 26.7379C74.0395 26.7379 70.5783 29.4612 68.063 34.7527C65.5506 40.0379 64.0981 47.6906 64.0981 56.9999C64.0981 66.3091 65.5506 73.9618 68.063 79.2471ZM37.2261 56.9999C37.2261 91.6499 52.1641 112.286 78.0361 112.286C103.754 112.286 118.692 91.6499 118.692 56.9999C118.692 22.3499 103.754 1.71387 78.0361 1.71387C52.1641 1.71387 37.2261 22.3499 37.2261 56.9999ZM78.0361 88.2619C68.9501 88.2619 63.0981 75.7879 63.0981 56.9999C63.0981 38.2119 68.9501 25.7379 78.0361 25.7379C86.8141 25.7379 92.8201 38.2119 92.8201 56.9999C92.8201 75.7879 86.8141 88.2619 78.0361 88.2619Z" fill="url(#grad)"></path>

                <path fill-rule="evenodd" clip-rule="evenodd" d="M1 98.5794C1 105.971 7.314 112.285 14.86 112.285C22.406 112.285 28.72 105.971 28.72 98.5794C28.72 90.8794 22.406 84.5654 14.86 84.5654C7.314 84.5654 1 90.8794 1 98.5794ZM14.86 113.285C6.76895 113.285 0 106.531 0 98.5794C0 90.3343 6.75456 83.5654 14.86 83.5654C22.9654 83.5654 29.72 90.3343 29.72 98.5794C29.72 106.531 22.951 113.285 14.86 113.285Z" fill="url(#grad)"></path>
              </svg>
                  <p><b>Tư vấn & Báo giá</b><br>
                  Tư vấn chi tiết về những mong muốn và ý tưởng của khách hàng, đưa ra tính năng và gói dịch vụ phù hợp với ngân sách và lên báo giá chi tiết
                  </p></li>
                <li class="process-item">
                  <!-- 2 -->
            <svg xmlns="http://www.w3.org/2000/svg" width="185" height="114"
                    viewBox="0 0 206 114" fill="none">
            <defs>
            <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stop-color="#020c6a" />
                <stop offset="50%" stop-color="#1a85f8" />
                <stop offset="100%" stop-color="#66e5fb" />
              </linearGradient>
            </defs>

         <path fill-rule="evenodd" clip-rule="evenodd"
          d="M130.486 91.0955L131.855 89.6599C153.26 67.2111 164.412 55.5156 170.228 48.3062C173.182 44.645 174.698 42.2139 175.491 40.176C176.272 38.1697 176.378 36.4818 176.378 34.2079C176.378 28.5278 171.983 24.5819 165.982 24.5819C163.053 24.5819 160.396 25.5789 158.473 27.5198C156.554 29.4561 155.278 32.4201 155.278 36.5179V37.5179H128.484V36.5179C128.484 23.842 133.262 14.8473 140.403 9.04213C147.514 3.26221 156.879 0.713867 165.982 0.713867C176.78 0.713867 186.072 3.64811 192.683 9.10461C199.315 14.5779 203.172 22.5275 203.172 32.3599C203.172 40.8638 201.54 47.2963 196.054 55.4962C190.823 63.3144 182.067 72.7704 167.898 87.2619H205.02V111.9H130.486V91.0955ZM165.52 88.2619C165.849 87.9259 166.176 87.5926 166.5 87.2619C195.994 57.1264 202.172 48.8113 202.172 32.3599C202.172 13.2639 187.234 1.71387 165.982 1.71387C148.36 1.71387 129.989 11.4544 129.494 35.5179C129.488 35.8485 129.484 36.1818 129.484 36.5179H154.278C154.278 27.8939 159.668 23.5819 165.982 23.5819C172.45 23.5819 177.378 27.8939 177.378 34.2079C177.378 43.366 175.714 45.1113 132.651 90.2741L131.486 91.4959V110.9H204.02V88.2619H165.52Z"
            fill="url(#grad1)" />

              <path fill-rule="evenodd" clip-rule="evenodd"
              d="M47.123 98.2285C39.985 88.5073 36.2261 74.45 36.2261 56.9999C36.2261 39.5497 39.985 25.4924 47.123 15.7713C54.2904 6.01017 64.7999 0.713867 78.0361 0.713867C91.1974 0.713867 101.668 6.01183 108.815 15.7723C115.933 25.493 119.692 39.5496 119.692 56.9999C119.692 74.4501 115.933 88.5067 108.815 98.2274C101.668 107.988 91.1974 113.286 78.0361 113.286C64.7999 113.286 54.2904 107.99 47.123 98.2285ZM68.063 79.2471C70.5783 84.5386 74.0395 87.2619 78.0361 87.2619C81.8687 87.2619 85.2951 84.5516 87.8167 79.2471C90.3302 73.9594 91.8201 66.3051 91.8201 56.9999C91.8201 47.6946 90.3302 40.0404 87.8167 34.7527C85.2951 29.4481 81.8687 26.7379 78.0361 26.7379C74.0395 26.7379 70.5783 29.4612 68.063 34.7527C65.5506 40.0379 64.0981 47.6906 64.0981 56.9999C64.0981 66.3091 65.5506 73.9618 68.063 79.2471ZM37.2261 56.9999C37.2261 91.6499 52.1641 112.286 78.0361 112.286C103.754 112.286 118.692 91.6499 118.692 56.9999C118.692 22.3499 103.754 1.71387 78.0361 1.71387C52.1641 1.71387 37.2261 22.3499 37.2261 56.9999ZM78.0361 88.2619C68.9501 88.2619 63.0981 75.7879 63.0981 56.9999C63.0981 38.2119 68.9501 25.7379 78.0361 25.7379C86.8141 25.7379 92.8201 38.2119 92.8201 56.9999C92.8201 75.7879 86.8141 88.2619 78.0361 88.2619Z"
                fill="url(#grad1)" />

                <path fill-rule="evenodd" clip-rule="evenodd"
                d="M1 98.5799C1 105.972 7.314 112.286 14.86 112.286C22.406 112.286 28.72 105.972 28.72 98.5799C28.72 90.8799 22.406 84.5659 14.86 84.5659C7.314 84.5659 1 90.8799 1 98.5799ZM14.86 113.286C6.76895 113.286 0 106.531 0 98.5799C0 90.3348 6.75456 83.5659 14.86 83.5659C22.9654 83.5659 29.72 90.3348 29.72 98.5799C29.72 106.531 22.951 113.286 14.86 113.286Z"
                fill="url(#grad1)" />
        </svg>

                  <p>
                    <b>Lập kế hoạch chi tiết</b><br>
                    Sau khi tiếp nhận yêu cầu của khách hàng, bộ phận <a href="" class="link-a">UI/UX</a> và Dev sẽ thảo luận để đưa ra kế hoạch tối ưu nhất dành cho khách hàng
                  </p>
                </li>
                <li>
                  <!-- 3 -->
<svg xmlns="http://www.w3.org/2000/svg" width="185" height="114"
                viewBox="0 0 208 114" fill="none">
                <defs>
              <linearGradient id="gradientStroke" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stop-color="#020c6a" />
            <stop offset="50%" stop-color="#1a85f8" />
              <stop offset="100%" stop-color="#66e5fb" />
                </linearGradient>
            </defs>

          <path fill="none" stroke="url(#gradientStroke)" stroke-width="1"
           fill-rule="evenodd" clip-rule="evenodd"
          d="M126.636 76.4819H154.354V77.4819C154.354 80.95 155.714 83.3348 157.883 84.8887C160.098 86.4763 163.255 87.2619 166.906 87.2619C170.887 87.2619 174.177 86.1566 176.456 84.1933C178.717 82.2454 180.074 79.3758 180.074 75.6339C180.074 72.0645 178.732 69.4376 176.508 67.6788C174.253 65.8957 170.992 64.9299 167.06 64.9299H156.828L156.659 42.6019H165.366C168.48 42.6019 171.126 41.6609 172.977 40.0874C174.814 38.5246 175.916 36.3001 175.916 33.5919C175.916 28.5636 171.869 25.0439 166.29 25.0439C160.806 25.0439 156.644 28.3135 156.51 33.1576L156.483 34.1299H129.408V33.1299C129.408 22.7665 133.374 14.6289 139.845 9.09654C146.298 3.57991 155.168 0.713867 164.904 0.713867C185.554 0.713867 201.17 12.8142 201.17 29.5879C201.17 37.5373 198.06 44.5352 192.488 49.4759C201.626 55.2503 207.484 64.5263 207.484 76.5579C207.484 97.7035 189.67 113.286 166.136 113.286C155.58 113.286 145.71 110.511 138.459 104.611C131.178 98.6867 126.636 89.6899 126.636 77.4819V76.4819ZM191.689 50.1559C191.389 49.9694 191.084 49.7867 190.776 49.6079C191.055 49.3865 191.328 49.1601 191.595 48.9289C197.089 44.1745 200.17 37.3714 200.17 29.5879C200.17 13.5719 185.232 1.71387 164.904 1.71387C146.126 1.71387 130.922 12.5847 130.421 32.1299C130.412 32.4607 130.408 32.7941 130.408 33.1299H155.51C155.664 27.5859 160.438 24.0439 166.29 24.0439C172.296 24.0439 176.916 27.8939 176.916 33.5919C176.916 39.5979 171.988 43.6019 165.366 43.6019H157.666L157.82 63.9299H167.06C175.222 63.9299 181.074 67.9339 181.074 75.6339C181.074 83.6419 175.222 88.2619 166.906 88.2619C159.36 88.2619 153.354 85.0279 153.354 77.4819H127.636C127.636 77.8178 127.64 78.1511 127.647 78.4819C128.135 101.657 145.639 112.286 166.136 112.286C189.236 112.286 206.484 97.0399 206.484 76.5579C206.484 64.7843 200.715 55.7511 191.689 50.1559Z" />

        <path fill="none" stroke="url(#gradientStroke)" stroke-width="1"
          fill-rule="evenodd" clip-rule="evenodd"d="M47.123 98.2285C39.985 88.5073 36.2261 74.45 36.2261 56.9999C36.2261 39.5497 39.985 25.4924 47.123 15.7713C54.2904 6.01017 64.7999 0.713867 78.0361 0.713867C91.1974 0.713867 101.668 6.01183 108.815 15.7723C115.933 25.493 119.692 39.5496 119.692 56.9999C119.692 74.4501 115.933 88.5067 108.815 98.2274C101.668 107.988 91.1974 113.286 78.0361 113.286C64.7999 113.286 54.2904 107.99 47.123 98.2285ZM68.063 79.2471C70.5783 84.5386 74.0395 87.2619 78.0361 87.2619C81.8687 87.2619 85.2951 84.5516 87.8167 79.2471C90.3302 73.9594 91.8201 66.3051 91.8201 56.9999C91.8201 47.6946 90.3302 40.0404 87.8167 34.7527C85.2951 29.4481 81.8687 26.7379 78.0361 26.7379C74.0395 26.7379 70.5783 29.4612 68.063 34.7527C65.5506 40.0379 64.0981 47.6906 64.0981 56.9999C64.0981 66.3091 65.5506 73.9618 68.063 79.2471ZM37.2261 56.9999C37.2261 91.6499 52.1641 112.286 78.0361 112.286C103.754 112.286 118.692 91.6499 118.692 56.9999C118.692 22.3499 103.754 1.71387 78.0361 1.71387C52.1641 1.71387 37.2261 22.3499 37.2261 56.9999ZM78.0361 88.2619C68.9501 88.2619 63.0981 75.7879 63.0981 56.9999C63.0981 38.2119 68.9501 25.7379 78.0361 25.7379C86.8141 25.7379 92.8201 38.2119 92.8201 56.9999C92.8201 75.7879 86.8141 88.2619 78.0361 88.2619Z" />

            <path fill="none" stroke="url(#gradientStroke)" stroke-width="1"
           fill-rule="evenodd" clip-rule="evenodd"
             d="M1 98.5799C1 105.972 7.314 112.286 14.86 112.286C22.406 112.286 28.72 105.972 28.72 98.5799C28.72 90.8799 22.406 84.5659 14.86 84.5659C7.314 84.5659 1 90.8799 1 98.5799ZM14.86 113.286C6.76895 113.286 0 106.531 0 98.5799C0 90.3348 6.75456 83.5659 14.86 83.5659C22.9654 83.5659 29.72 90.3348 29.72 98.5799C29.72 106.531 22.951 113.286 14.86 113.286Z" />
          </svg>                  <p>
                    <b>Thiết kế và lập trình</b><br>
                    Bộ phận UI/UX Design sau khi có kế hoạch sẽ tiến hành lên demo và gửi khách hàng bản Figma. Khách hàng điều chỉnh trước khi lập trình

                  </p>
                </li>
                <li class="process-item">
                  <!-- 4 -->
                <svg xmlns="http://www.w3.org/2000/svg" width="185" height="114"
                                            viewBox="0 0 210 114" fill="none">
                                            <defs>
                                                <linearGradient id="gradient-stroke" x1="0%" y1="0%" x2="100%" y2="0%">
                                                    <stop offset="0%" stop-color="#020c6a" />
                                                    <stop offset="50%" stop-color="#1a85f8" />
                                                    <stop offset="100%" stop-color="#66e5fb" />
                                                </linearGradient>
                                            </defs>

                                            <path fill="none" stroke="url(#gradient-stroke)" stroke-width="1"
                                                fill-rule="evenodd" clip-rule="evenodd"
                                                d="M174.606 110.9H200.478V88.2621H208.794V65.6241H200.478V3.10009H167.676L123.94 71.9381V88.2621H174.606V110.9ZM173.606 89.2621V111.9H201.478V89.2621H209.794V64.6241H201.478V2.1001H167.127L122.94 71.6473V89.2621H173.606ZM153.2 65.6241L174.606 27.7401V65.6241H153.2ZM154.914 64.6241H173.606V31.5427L154.914 64.6241Z" />

                                            <path fill="none" stroke="url(#gradient-stroke)" stroke-width="1"
                                                fill-rule="evenodd" clip-rule="evenodd"
                                                d="M47.123 98.2285C39.985 88.5073 36.2261 74.45 36.2261 56.9999C36.2261 39.5497 39.985 25.4924 47.123 15.7713C54.2904 6.01017 64.7999 0.713867 78.0361 0.713867C91.1974 0.713867 101.668 6.01183 108.815 15.7723C115.933 25.493 119.692 39.5496 119.692 56.9999C119.692 74.4501 115.933 88.5067 108.815 98.2274C101.668 107.988 91.1974 113.286 78.0361 113.286C64.7999 113.286 54.2904 107.99 47.123 98.2285ZM68.063 79.2471C70.5783 84.5386 74.0395 87.2619 78.0361 87.2619C81.8687 87.2619 85.2951 84.5516 87.8167 79.2471C90.3302 73.9594 91.8201 66.3051 91.8201 56.9999C91.8201 47.6946 90.3302 40.0404 87.8167 34.7527C85.2951 29.4481 81.8687 26.7379 78.0361 26.7379C74.0395 26.7379 70.5783 29.4612 68.063 34.7527C65.5506 40.0379 64.0981 47.6906 64.0981 56.9999C64.0981 66.3091 65.5506 73.9618 68.063 79.2471ZM37.2261 56.9999C37.2261 91.6499 52.1641 112.286 78.0361 112.286C103.754 112.286 118.692 91.6499 118.692 56.9999C118.692 22.3499 103.754 1.71387 78.0361 1.71387C52.1641 1.71387 37.2261 22.3499 37.2261 56.9999ZM78.0361 88.2619C68.9501 88.2619 63.0981 75.7879 63.0981 56.9999C63.0981 38.2119 68.9501 25.7379 78.0361 25.7379C86.8141 25.7379 92.8201 38.2119 92.8201 56.9999C92.8201 75.7879 86.8141 88.2619 78.0361 88.2619Z" />

                                            <path fill="none" stroke="url(#gradient-stroke)" stroke-width="1"
                                                fill-rule="evenodd" clip-rule="evenodd"d="M1 98.5799C1 105.972 7.314 112.286 14.86 112.286C22.406 112.286 28.72 105.972 28.72 98.5799C28.72 90.8799 22.406 84.5659 14.86 84.5659C7.314 84.5659 1 90.8799 1 98.5799ZM14.86 113.286C6.76895 113.286 0 106.531 0 98.5799C0 90.3348 6.75456 83.5659 14.86 83.5659C22.9654 83.5659 29.72 90.3348 29.72 98.5799C29.72 106.531 22.951 113.286 14.86 113.286Z" />
                                        </svg>                  <p>
                    <b>Thử nghiệm và điều chỉnh</b><br>
                    Khách hàng thử nghiệm website của họ sau khi lập trình và tiến hành điều chỉnh nếu có vấn đề phát sinh
                  </p>
                </li>
                <li>
                  <!-- 5 -->
              <svg xmlns="http://www.w3.org/2000/svg" width="185" height="114"
                                            viewBox="0 0 208 114" fill="none">
                                            <defs>
                                                <linearGradient id="strokeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                                                    <stop offset="0%" stop-color="#020c6a" />
                                                    <stop offset="50%" stop-color="#1a85f8" />
                                                    <stop offset="100%" stop-color="#66e5fb" />
                                                </linearGradient>
                                            </defs>

                                            <path fill="none" stroke="url(#strokeGradient)" stroke-width="1"
                                                d="M127.188 78.4821C127.759 99.4509 146.293 112.286 167.214 112.286C189.082 112.286 206.946 96.7321 206.946 71.4761C206.946 49.1461 192.932 35.7481 174.76 35.7481C165.772 35.7481 159.986 37.9254 155.883 40.5279C155.487 40.7792 155.106 41.0345 154.74 41.2921L157.358 25.7381H203.712V3.10009H138.724L127.328 66.5481H154.124C155.972 60.5421 160.9 56.8461 167.368 56.8461C175.838 56.8461 181.536 63.0061 181.536 72.2461C181.536 81.6401 175.838 87.8001 167.368 87.8001C160.746 87.8001 155.664 83.7961 153.97 77.4821H127.174C127.174 77.8175 127.179 78.1508 127.188 78.4821Z" />

                                            <path fill="none" stroke="url(#strokeGradient)" stroke-width="1"
                                                d="M158.204 26.7381H204.712V2.1001H137.888L126.133 67.5481H154.863L155.08 66.8422C156.798 61.2571 161.338 57.8461 167.368 57.8461C171.349 57.8461 174.615 59.2869 176.893 61.7587C179.177 64.2377 180.536 67.831 180.536 72.2461C180.536 76.7422 179.175 80.3741 176.891 82.8708C174.614 85.3596 171.348 86.8001 167.368 86.8001C161.207 86.8001 156.515 83.108 154.936 77.223L154.737 76.4821H126.174V77.4821C126.174 99.7741 145.609 113.286 167.214 113.286C178.387 113.286 188.578 109.31 195.98 102.067C203.388 94.8179 207.946 84.3503 207.946 71.4761C207.946 60.0992 204.373 50.9084 198.396 44.5533C192.418 38.1961 184.1 34.7481 174.76 34.7481C166.113 34.7481 160.312 36.7286 156.103 39.2202L158.204 26.7381Z" />

                                            <path fill="none" stroke="url(#strokeGradient)" stroke-width="1"d="M47.123 98.2285C39.985 88.5073 36.2261 74.45 36.2261 56.9999C36.2261 39.5497 39.985 25.4924 47.123 15.7713C54.2904 6.01017 64.7999 0.713867 78.0361 0.713867C91.1974 0.713867 101.668 6.01183 108.815 15.7723C115.933 25.493 119.692 39.5496 119.692 56.9999C119.692 74.4501 115.933 88.5067 108.815 98.2274C101.668 107.988 91.1974 113.286 78.0361 113.286C64.7999 113.286 54.2904 107.99 47.123 98.2285ZM68.063 79.2471C70.5783 84.5386 74.0395 87.2619 78.0361 87.2619C81.8687 87.2619 85.2951 84.5516 87.8167 79.2471C90.3302 73.9594 91.8201 66.3051 91.8201 56.9999C91.8201 47.6946 90.3302 40.0404 87.8167 34.7527C85.2951 29.4481 81.8687 26.7379 78.0361 26.7379C74.0395 26.7379 70.5783 29.4612 68.063 34.7527C65.5506 40.0379 64.0981 47.6906 64.0981 56.9999C64.0981 66.3091 65.5506 73.9618 68.063 79.2471ZM37.2261 56.9999C37.2261 91.6499 52.1641 112.286 78.0361 112.286C103.754 112.286 118.692 91.6499 118.692 56.9999C118.692 22.3499 103.754 1.71387 78.0361 1.71387C52.1641 1.71387 37.2261 22.3499 37.2261 56.9999ZM78.0361 88.2619C68.9501 88.2619 63.0981 75.7879 63.0981 56.9999C63.0981 38.2119 68.9501 25.7379 78.0361 25.7379C86.8141 25.7379 92.8201 38.2119 92.8201 56.9999C92.8201 75.7879 86.8141 88.2619 78.0361 88.2619Z" />

                                            <path fill="none" stroke="url(#strokeGradient)" stroke-width="1"
                                                d="M1 98.5799C1 105.972 7.314 112.286 14.86 112.286C22.406 112.286 28.72 105.972 28.72 98.5799C28.72 90.8799 22.406 84.5659 14.86 84.5659C7.314 84.5659 1 90.8799 1 98.5799ZM14.86 113.286C6.76895 113.286 0 106.531 0 98.5799C0 90.3348 6.75456 83.5659 14.86 83.5659C22.9654 83.5659 29.72 90.3348 29.72 98.5799C29.72 106.531 22.951 113.286 14.86 113.286Z" />
                        </svg>                  <p>
                    <b>Hướng dẫn quản trị</b><br>
                    Trao đổi và hướng dẫn khách hàng tự quản lí website của họ một các chuyên nghiệp và chính xác

                  </p>
                </li>
                <li class="process-item">
                  <!-- 6 -->
                  <svg xmlns="http://www.w3.org/2000/svg" width="185" height="114"
                                            viewBox="0 0 210 114" fill="none">
                                            <defs>
                                                <linearGradient id="strokeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                                                    <stop offset="0%" stop-color="#020c6a" />
                                                    <stop offset="50%" stop-color="#1a85f8" />
                                                    <stop offset="100%" stop-color="#66e5fb" />
                                                </linearGradient>
                                            </defs>

                                            <path fill="none" stroke="url(#strokeGradient)" stroke-width="1"
                                                d="M126.558 77.1741C126.558 97.3481 144.884 112.286 167.214 112.286C189.236 112.286 208.332 97.5021 208.332 74.2481C208.332 55.3061 195.088 38.8281 172.45 38.8281H170.448L197.398 3.10009H168.292L142.42 39.5981C132.41 53.7661 126.558 63.3141 126.558 77.1741ZM172.455 37.8281L199.405 2.1001H167.775L141.604 39.0198L141.603 39.0211C131.594 53.1885 125.558 62.968 125.558 77.1741C125.558 98.048 144.492 113.286 167.214 113.286C189.661 113.286 209.332 98.1734 209.332 74.2481C209.332 64.5458 205.939 55.4374 199.607 48.7474C193.266 42.0489 184.028 37.8293 172.455 37.8281ZM167.522 90.1101C158.128 90.1101 152.43 82.8721 152.43 74.2481C152.43 65.6241 158.282 58.5401 167.522 58.5401C176.608 58.5401 182.614 65.6241 182.614 74.2481C182.614 83.0261 176.454 90.1101 167.522 90.1101ZM157.197 84.7441C159.6 87.4146 163.1 89.1101 167.522 89.1101C175.831 89.1101 181.614 82.5474 181.614 74.2481C181.614 66.1023 175.984 59.5401 167.522 59.5401C158.912 59.5401 153.43 66.0951 153.43 74.2481C153.43 78.3436 154.783 82.0618 157.197 84.7441Z" />

                                            <path fill="none" stroke="url(#strokeGradient)" stroke-width="1"d="M47.123 98.2285C39.985 88.5073 36.2261 74.45 36.2261 56.9999C36.2261 39.5497 39.985 25.4924 47.123 15.7713C54.2904 6.01017 64.7999 0.713867 78.0361 0.713867C91.1974 0.713867 101.668 6.01183 108.815 15.7723C115.933 25.493 119.692 39.5496 119.692 56.9999C119.692 74.4501 115.933 88.5067 108.815 98.2274C101.668 107.988 91.1974 113.286 78.0361 113.286C64.7999 113.286 54.2904 107.99 47.123 98.2285ZM68.063 79.2471C70.5783 84.5386 74.0395 87.2619 78.0361 87.2619C81.8687 87.2619 85.2951 84.5516 87.8167 79.2471C90.3302 73.9594 91.8201 66.3051 91.8201 56.9999C91.8201 47.6946 90.3302 40.0404 87.8167 34.7527C85.2951 29.4481 81.8687 26.7379 78.0361 26.7379C74.0395 26.7379 70.5783 29.4612 68.063 34.7527C65.5506 40.0379 64.0981 47.6906 64.0981 56.9999C64.0981 66.3091 65.5506 73.9618 68.063 79.2471ZM37.2261 56.9999C37.2261 91.6499 52.1641 112.286 78.0361 112.286C103.754 112.286 118.692 91.6499 118.692 56.9999C118.692 22.3499 103.754 1.71387 78.0361 1.71387C52.1641 1.71387 37.2261 22.3499 37.2261 56.9999ZM78.0361 88.2619C68.9501 88.2619 63.0981 75.7879 63.0981 56.9999C63.0981 38.2119 68.9501 25.7379 78.0361 25.7379C86.8141 25.7379 92.8201 38.2119 92.8201 56.9999C92.8201 75.7879 86.8141 88.2619 78.0361 88.2619Z" />

                                            <path fill="none" stroke="url(#strokeGradient)" stroke-width="1"
                                                d="M1 98.5799C1 105.972 7.314 112.286 14.86 112.286C22.406 112.286 28.72 105.972 28.72 98.5799C28.72 90.8799 22.406 84.5659 14.86 84.5659C7.314 84.5659 1 90.8799 1 98.5799ZM14.86 113.286C6.76895 113.286 0 106.531 0 98.5799C0 90.3348 6.75456 83.5659 14.86 83.5659C22.9654 83.5659 29.72 90.3348 29.72 98.5799C29.72 106.531 22.951 113.286 14.86 113.286Z" />
                    </svg>    <p>
                    <b>Bàn giao và bảo hành</b><br>
                    Sau khi hoàn thành các bước thử nghiệm và đào tạo, tiến hàng bàn giao và bảo hành cho khách trong những trường hợp cụ thể về kĩ thuật

                  </p>
                </li>
                
              </ol>
          </div>
          
        </div>


 
        <div class="container-faq">
          
          <div class="homenest__professional_website_faq">
            <p>FAQs</p>
            <div class="homenest__professional_website_title-wrapper">
              <h2 class="homenest__professional_website_title row-1">Các Câu Hỏi Thường Gặp</h2>
            </div>
            <div id="homenest__professional_website_faq-container"></div>
        </div>
        </div>


    <div class="container-contact">
      <div class="contact-left">
          <h1>HOME NEST</h1>
          <h2>Giải pháp website toàn diện</h2>
          <p><a href="">Home Nest</a> biến ý tưởng thành hiệu suất và thúc đẩy sự phát triển kinh doanh của bạn trên mọi khía cạnh số hóa.</p>
          <p>Hotline: 0889 - 994 - 289 <br>
          Email: admin@homenest.com.vn</p>
          <ul>
            <li><svg aria-hidden="true" class="e-font-icon-svg e-fab-facebook" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="M504 256C504 119 393 8 256 8S8 119 8 256c0 123.78 90.69 226.38 209.25 245V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.28c-30.8 0-40.41 19.12-40.41 38.73V256h68.78l-11 71.69h-57.78V501C413.31 482.38 504 379.78 504 256z"></path></svg></li>
            <li><svg aria-hidden="true" class="e-font-icon-svg e-fab-instagram" viewBox="0 0 448 512" xmlns="http://www.w3.org/2000/svg"><path d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"></path></svg></li>
            <li><svg aria-hidden="true" class="e-font-icon-svg e-fab-twitter" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z"></path></svg></li>
            <li><svg aria-hidden="true" class="e-font-icon-svg e-fab-youtube" viewBox="0 0 576 512" xmlns="http://www.w3.org/2000/svg"><path d="M549.655 124.083c-6.281-23.65-24.787-42.276-48.284-48.597C458.781 64 288 64 288 64S117.22 64 74.629 75.486c-23.497 6.322-42.003 24.947-48.284 48.597-11.412 42.867-11.412 132.305-11.412 132.305s0 89.438 11.412 132.305c6.281 23.65 24.787 41.5 48.284 47.821C117.22 448 288 448 288 448s170.78 0 213.371-11.486c23.497-6.321 42.003-24.171 48.284-47.821 11.412-42.867 11.412-132.305 11.412-132.305s0-89.438-11.412-132.305zm-317.51 213.508V175.185l142.739 81.205-142.739 81.201z"></path></svg></li>
          </ul>
      </div>
      <div class="contact-right">
        <hr>
      </div>
    </div>

  </div>


    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

    <!-- Initialize Swiper -->
    <script>
      var swiper = new Swiper(".mySwiper", {
        slidesPerView: 1,
        spaceBetween: 30,
        freeMode: true,
        loop: true,

          navigation: {
              nextEl: '.next',
              prevEl: '.prev',
              },
      breakpoints: {
          480: {
          slidesPerView: 1,
          },
          768: {
          slidesPerView: 2,
          },
          1024: {
          slidesPerView: 3,
          },
          1200: {
          slidesPerView: 4,
          }
      }
      });
    </script>
    <script>
      //  FAQ
   document.addEventListener("DOMContentLoaded", function () {
  const faqData = [
    {
      question: "Tại sao phải thiết kế website theo yêu cầu?",
      answer:
        "Thiết kế website theo yêu cầu giúp doanh nghiệp có giao diện, tính năng phù hợp với đặc thù hoạt động, tăng hiệu quả kinh doanh và nhận diện thương hiệu.",
    },
    {
      question: "Phí gia hạn web hàng năm là gì?",
      answer:
        "Phí gia hạn web hàng năm bao gồm chi phí duy trì tên miền, hosting và các dịch vụ kỹ thuật kèm theo để website hoạt động ổn định.",
    },
    {
      question: "Thiết kế website chuẩn SEO là gì?",
      answer:
        "Website chuẩn SEO giúp tối ưu công cụ tìm kiếm, dễ được Google index và cải thiện thứ hạng trên kết quả tìm kiếm.",
    },
    {
      question: "Hosting là gì và tại sao cần thiết?",
      answer:
        "Hosting là nơi lưu trữ toàn bộ dữ liệu website. Không có hosting thì website không thể hoạt động được trên internet.",
    },
    {
      question: "Tên miền là gì?",
      answer:
        "Tên miền là địa chỉ của website trên internet, ví dụ như www.tenmien.com. Nó giúp người dùng truy cập nhanh chóng vào website.",
    },
    {
      question: "Website có cần bảo mật SSL không?",
      answer:
        "Có. SSL giúp mã hóa dữ liệu giữa người dùng và máy chủ, tăng độ tin cậy và bảo vệ thông tin cá nhân, đặc biệt quan trọng với các website thương mại điện tử.",
    },
    {
      question: "Tôi có thể chỉnh sửa nội dung website không?",
      answer:
        "Có. Với hệ thống quản trị nội dung (CMS), bạn có thể dễ dàng cập nhật nội dung mà không cần kiến thức lập trình.",
    },
    {
      question: "Chi phí thiết kế website là bao nhiêu?",
      answer:
        "Chi phí tùy thuộc vào mức độ phức tạp và yêu cầu cụ thể. Bạn có thể liên hệ để được báo giá chi tiết.",
    },
    {
      question: "Thời gian thiết kế website mất bao lâu?",
      answer:
        "Thông thường từ 7-20 ngày làm việc tùy theo mức độ phức tạp và số lượng tính năng yêu cầu.",
    },
    {
      question: "Website có tương thích với điện thoại không?",
      answer:
        "Có. Website được thiết kế responsive, hiển thị tốt trên mọi thiết bị như điện thoại, máy tính bảng và laptop.",
    },
  ];

  const faqContainer = document.getElementById(
    "homenest__professional_website_faq-container"
  );

  faqData.forEach((item, index) => {
    const faqItem = document.createElement("div");
    faqItem.className = "homenest__professional_website_question";

    faqItem.innerHTML = `
      <div class="homenest__professional_website_question-header-number">
        <span class="homenest__professional_website_question-number"><span>${(
          index + 1
        )
          .toString()
          .padStart(2, "0")}
          </span></span>
        <span class="homenest__professional_website_question-label">QUESTION - ${(
          index + 1
        )
          .toString()
          .padStart(2, "0")}</span>
      </div>
      <div class="homenest__professional_website_question-header">
        <div style="width: 40px; height: 40px;"></div>
        <span class="homenest__professional_website_question-title">${
          item.question
        }</span>
        <button class="homenest__professional_website_toggle-btn">
          +
        </button>
      </div>
      <div class="homenest__professional_website_answer-wrapper">
        <div style="width: 40px; height: 40px;"></div>
        <div class="homenest__professional_website_answer">${item.answer}</div>
        <div style="width: 40px; height: 40px;"></div>
      </div>
    `;

    faqContainer.appendChild(faqItem);
  });

  document
    .querySelectorAll(".homenest__professional_website_question-header")
    .forEach((header) => {
      header.addEventListener("click", () => {
        const allAnswers = document.querySelectorAll(
          ".homenest__professional_website_answer-wrapper"
        );
        const allButtons = document.querySelectorAll(
          ".homenest__professional_website_toggle-btn"
        );

        const currentAnswer = header.nextElementSibling;
        const currentButton = header.querySelector(
          ".homenest__professional_website_toggle-btn"
        );

        // Close all other answers and reset their buttons
        allAnswers.forEach((answer) => {
          if (answer !== currentAnswer) answer.classList.remove("show");
        });

        allButtons.forEach((btn) => {
          if (btn !== currentButton) {
            btn.classList.remove("open");
            btn.textContent = "+";
          }
        });

        // Toggle current
        const isOpen = currentAnswer.classList.contains("show");
        currentAnswer.classList.toggle("show", !isOpen);
        currentButton.classList.toggle("open", !isOpen);
        currentButton.textContent = !isOpen ? "−" : "+";
      });
    });
});

 // CUNG CẤP MỌI LOẠI HÌNH QUẢNG CÁO FACEBOOK
document.addEventListener("DOMContentLoaded", () => {
  const items = document.querySelectorAll(".faq-item");

  items.forEach((item) => {
    const content = item.querySelector(".details-body-group");

    // Khởi tạo trạng thái cho content
    if (item.hasAttribute("open")) {
      content.style.height = content.scrollHeight + "px";
    } else {
      content.style.height = "0";
      content.style.overflow = "hidden";
    }

    item.addEventListener("toggle", () => {
      if (item.open) {
        // Đóng các mục khác
        items.forEach((el) => {
          if (el !== item) {
            el.removeAttribute("open");
            const elContent = el.querySelector(".details-body-group");
            elContent.style.height = "0";
            elContent.style.overflow = "hidden";
          }
        });

        // Mở mục hiện tại
        // Bắt đầu bằng height = 0 (để chắc chắn có transition)
        content.style.height = "0";
        content.style.overflow = "hidden";

        // Cho browser kịp render trước khi set height đúng
        requestAnimationFrame(() => {
          content.style.transition = "height 0.5s ease";
          content.style.height = content.scrollHeight + "px";
        });

        // Khi animation kết thúc, set height về auto để nội dung co dãn tự nhiên
        content.addEventListener(
          "transitionend",
          function handler(e) {
            if (e.propertyName === "height") {
              content.style.height = "auto";
              content.style.overflow = "visible";
              content.style.transition = "";
              content.removeEventListener("transitionend", handler);
            }
          }
        );
      } else {
        // Đóng mục: set height từ auto (hoặc chiều cao thực) về 0
        // Trước đó set height hiện tại để browser biết chiều cao bắt đầu là bao nhiêu
        content.style.height = content.scrollHeight + "px";

        // Cho browser kịp render trước khi chuyển về 0
        requestAnimationFrame(() => {
          content.style.transition = "height 0.5s ease";
          content.style.height = "0";
          content.style.overflow = "hidden";
        });

        // Khi kết thúc animation, giữ nguyên height = 0
        content.addEventListener(
          "transitionend",
          function handler(e) {
            if (e.propertyName === "height") {
              content.style.transition = "";
              content.removeEventListener("transitionend", handler);
            }
          }
        );
      }
    });
  });
});

    </script>
    
  </body>
<?php get_footer(); ?>
