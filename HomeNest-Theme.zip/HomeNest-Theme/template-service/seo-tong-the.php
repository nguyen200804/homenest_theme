<?php
/**
 * Template Name: SEO Tổng Thể
 * Template Post Type: service
 */
get_header(); ?>
<body>
    <div class="homenest_seo">

        <div class="homenest_seo_intro">
            <div class="homenest_seo_intro_title">
                <h1>HOMENEST<br>
                     DỊCH VỤ SEO TỔNG THỂ</h1>
            </div>
            <div class="homenest_seo_intro_p">
                <p>Dịch vụ SEO tổng thể tại Home Nest là sự kết hợp giữa việc tối ưu nội dung và kỹ thuật để tăng vị trí xếp hạng website trên Google.</p>
                <!-- <p><a href="">Home Nest</a> với đội ngũ chuyên gia SEO giàu kinh nghiệm không chỉ tối ưu thứ hạng trang web trên Google, Bing,… mà còn tập trung thu hút và giữ chân khách hàng, giúp nâng cao hiệu suất kinh doanh của bạn.</p> -->
                <ul>
                    <li>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none"><path d="M10 3.85352H3V10.8535H10V3.85352Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M21 3.85352H14V10.8535H21V3.85352Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M21 14.8535H14V21.8535H21V14.8535Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M10 14.8535H3V21.8535H10V14.8535Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                        Partner Google Premier</li>
                    <li><svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none"><path d="M10 3.85352H3V10.8535H10V3.85352Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M21 3.85352H14V10.8535H21V3.85352Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M21 14.8535H14V21.8535H21V14.8535Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M10 14.8535H3V21.8535H10V14.8535Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                        300+ dự án SEO hiệu quả với phương pháp SEO SPT độc quyền</li>
                    <li><svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none"><path d="M10 3.85352H3V10.8535H10V3.85352Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M21 3.85352H14V10.8535H21V3.85352Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M21 14.8535H14V21.8535H21V14.8535Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M10 14.8535H3V21.8535H10V14.8535Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                        10 năm kinh nghiệm đồng hành với khách hàng tại Việt Nam và quốc tế</li>
                    <li><svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none"><path d="M10 3.85352H3V10.8535H10V3.85352Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M21 3.85352H14V10.8535H21V3.85352Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M21 14.8535H14V21.8535H21V14.8535Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M10 14.8535H3V21.8535H10V14.8535Z" stroke="#1A85F8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                        Chuyên gia Tư vấn Chiến lược Marketing cho doanh nghiệp</li>
                </ul>
                <div class="homenest_intro_p_button">
                    <a href="">
                        Tư vấn miễn phí
                        <span class="icon-button-arrow left"></span>
                    </a>
                </div>
            </div>
        </div>

        <div class="homenest_seo_video">
            <div class="homenest_seo_video_left">
                <video src="https://homenest.media/wp-content/uploads/2024/11/homnest1.mp4"></video>
            </div>
            <div class="homenest_seo_video_right">
                <div class="homenest_seo_video_right_top">
                    <div class="homenest_video_right_60">
                        <h3>Nghiên cứu thị trường và mục tiêu của thương hiệu</h3>
                        <hr>
                        <p>Thực hiện nghiên cứu thị trường, và lắng nghe mong muốn, cũng như mục tiêu của thương hiệu, tổng hợp đưa ra những giải pháp giá trị cho logo thương hiệu</p>
                    </div>
                    <div class="homenest_video_right_40">
                        <span>
                            <svg viewBox="0 0 30 49" fill="none" xmlns="//www.w3.org/2000/svg"><path d="M25.4015 1H9.25846C8.81002 1 8.41641 1.29854 8.2955 1.73037L1.8555 24.7304C1.67695 25.368 2.15628 26 2.81846 26H9.75062C10.3913 26 10.8667 26.594 10.7263 27.219L6.46148 46.2171C6.22848 47.255 7.56217 47.8907 8.22175 47.0562L28.7196 21.1201C29.2378 20.4644 28.7708 19.5 27.9351 19.5H19.5985C18.8599 19.5 18.3762 18.7267 18.6993 18.0625L26.3007 2.43747C26.6238 1.77325 26.1401 1 25.4015 1Z" stroke="white" stroke-width="2"></path></svg>
                        </span>
                        <div class="homenest_video_right_30_right">
                            <h3>100%</h3>
                            <p>Mang lại sự hài lòng cho khách hàng</p>
                        </div>
                    </div>
                </div>
                <div class="homenest_seo_video_right_bottom">
                    <div class="homenest_video_right_50">
                        <p>Không chỉ là vẻ đẹp thương hiệu, mà còn hơn cả một câu chuyện</p>
                    </div>
                    <div class="homenest_video_right_501">
                        <img src="https://homenest.media/wp-content/uploads/2024/09/Layer_1.png" alt="">
                        <p>Xây dựng chiến lược, câu chuyện xoay quoanh logo thương hiệu</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="homenest_seo_paper">
            <div class="homenest_seo_paper_left">
                <h2>
                    Dịch vụ SEO tổng thể tại HomeNest
                    <div class="homenest_seo_color">
                        kết hợp tối ưu nội dung và kỹ thuật, <br> 
                    nâng tầm thứ hạng website của bạn
                    </div>
                     trên google một cáh bền vững.
                </h2>
            </div>
            <div class="homenest_seo_paper_right">
                <img src="https://homenest.com.vn/wp-content/uploads/2024/12/logo-HN-final-04.png" alt="">
            </div>
        </div>

        <div class="homenest_seo_warpaper">
            <div class="homenest_seo_warpaper_left">
                <img src="https://homenest.media/wp-content/uploads/2025/03/image-1.webp" alt="">
                <p>Với đội ngũ chuyên gia dày dạn kinh nghiệm, HomeNest không chỉ tập trung vào việc tối ưu hóa website theo các tiêu chí của công cụ tìm kiếm mà còn xây dựng chiến lược <a href="">SEO</a> toàn diện. Chúng tôi hiểu sâu sắc về tối ưu hóa nội dung, cấu trúc trang web, và các yếu tố kỹ thuật, giúp đưa website của bạn lên top các trang tìm kiếm. HomeNest tự hào là chuyên gia hàng đầu về SEO, thiết kế website và marketing. Với hơn 10 năm kinh nghiệm và đội ngũ tài năng, chúng tôi biến ý tưởng thành kết quả thực tế, thúc đẩy sự phát triển kỹ thuật số cho doanh nghiệp của bạn.</p>
                <span class="homenest_seo_warpaper_left_button">
                    <a href="#">
                        Tư vẫn ngay
                    </a>
                </span>
                
            </div>
            <div class="homenest_seo_warpaper_right">
                <img src="https://homenest.media/wp-content/uploads/2025/03/image-2.webp" alt="">
            </div>
        </div>

        <div class="homenest_seo_data">
            <div class="homenest_seo_data_margin">
                <div class="homenest_seo_data_top">
                    <h2>
                        Số liệu không chỉ là những con số, mà là <div class="homenest_seo_color">minh chứng cho sự thành công và tiềm lực</div> của chúng tôi.
                    </h2>
                </div>

                <div class="homenest_seo_data_center">
                    <div class="homenest_seo_counter">
                        <span class="homenest_seo_counter_font">+</span>
                        <span class="homenest_seo_counter_data homenest_seo_counter_font">300</span>
                        <span class="homenest_seo_counter_font">%</span>
                        <p>Mức độ tăng trưởng website</p>
                    </div>

                    <div class="homenest_seo_counter">
                        <span class="homenest_seo_counter_font">+</span>
                        <span class="homenest_seo_counter_data homenest_seo_counter_font">2000</span>
                        <span class="homenest_seo_counter_font">%</span>
                        <p>Lượng traffic tăng trưởng</p>
                    </div>

                    <div class="homenest_seo_counter">
                        <span class="homenest_seo_counter_data homenest_seo_counter_font">6000</span>
                        <span class="homenest_seo_counter_font">%</span>
                        <p>Contact đổ về trong tháng</p>
                    </div>

                    <div class="homenest_seo_counter">
                        <span class="homenest_seo_counter_data homenest_seo_counter_font">12000</span>
                        <span class="homenest_seo_counter_font">%</span>
                        <p>Khách hàng trong và ngoài nước</p>
                    </div>
                </div>

                <div class="homenest_seo_data_bottom">
                    <div class="homenest_seo_data_bottom_content data_bottom_content1">
                        <p>Tăng trưởng bứt phá - Doanh nghiệp vươn lên top Google, thu hút hàng ngàn khách hàng tiềm năng mỗi tháng.</p>
                    </div>
                    <div class="homenest_seo_data_bottom_content data_bottom_content2">
                        <p>Hiệu quả bền vững - Chiến lược SEO tối ưu giúp website duy trì thứ hạng cao, mang lại giá trị dài lâu.</p>
                    </div>
                    <div class="homenest_seo_data_bottom_content data_bottom_content3">
                        <p>Dẫn đầu thị trường - Thương hiệu của bạn không chỉ được tìm thấy mà còn tỏa sáng trong lĩnh vực kinh doanh.</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="homenest_seo_loop">
             <div class="homenest_seo_loop_top">
                <div class="homenest_seo_loop_top_left">
                    <img src="https://homenest.media/wp-content/uploads/2024/11/Group-1217-scaled.webp" alt="">
                </div>
                <div class="homenest_seo_loop_top_right">
                    <h2>"<span class="homenest_seo_color">Không chỉ dịch vụ - Homenest đồng hành</span> trên mọi lĩnh vực phát triển của bạn"</h2>
                    <div class="homenest_seo_loop_signature">
                        <img src="https://homenest.media/wp-content/uploads/2025/01/nTien-SignatureGenerator.svg" alt="">
                        <ul>
                            <li>
                                <svg width="26" height="30" viewBox="0 0 26 30" xmlns="http://www.w3.org/2000/svg">
                                <circle cx="6" cy="10" r="2.5" fill="black" />
                                <circle cx="6" cy="20" r="2.5" fill="black" />
                                <circle cx="16" cy="15" r="2.5" fill="black" />
                                <line x1="16" y1="15" x2="6" y2="10" stroke="black" stroke-width="1.5" />
                                <line x1="16" y1="15" x2="6" y2="20" stroke="black" stroke-width="1.5" />
                                </svg>
                                CO-FOUNDER
                            </li>
                        </ul>
                        
                    </div>
                    <hr>
                </div>
            </div>

            <div class="homenest_seo_loop_bottom">
                <div class="hn__marquee-slide">
                    <div class="hn__marquee-col1">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1418.webp" alt="">
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318725.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318712.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318717.webp" alt="">
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318724.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318718.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1423.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1459.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1422.webp" alt="">
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1422.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1425.webp" alt="">
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1453.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1434.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1444.webp" alt="">
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318729.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1441.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1442.webp" alt="">
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1461.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1439.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1429.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1427.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318728.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1418.webp" alt="">
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318725.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318712.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318717.webp" alt="">
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318724.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318718.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1423.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1459.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1422.webp" alt="">
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1422.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1425.webp" alt="">
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1453.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1434.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1444.webp" alt="">
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318729.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1441.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1442.webp" alt="">
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1461.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1439.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1429.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1427.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318728.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1418.webp" alt="">
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318725.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318712.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318717.webp" alt="">
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318724.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318718.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1423.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1459.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1422.webp" alt="">
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1422.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1425.webp" alt="">
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1453.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1434.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1444.webp" alt="">
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318729.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1441.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1442.webp" alt="">
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1461.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1439.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1429.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1427.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318728.webp" alt=""> 
                    </div>
                    <div class="hn__marquee-col2"> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1456.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318716.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318722.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318715.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318713.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318721.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318711.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318727.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318710.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318708.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318728.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1431.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1452.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1435.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1433.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318730.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1430.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1462.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1447.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1440.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1457.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1437.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1428.webp" alt="">
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1456.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318716.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318722.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318715.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318713.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318721.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318711.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318727.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318710.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318708.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318728.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1431.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1452.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1435.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1433.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318730.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1430.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1462.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1447.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1440.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1457.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1437.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1428.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1456.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318716.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318722.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318715.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318713.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318721.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318711.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318727.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318710.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318708.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318728.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1431.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1452.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1435.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1433.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318730.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1430.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1462.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1447.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1440.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1457.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1437.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1428.webp" alt=""> 
                    </div>
                    <div class="hn__marquee-col3"> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1445.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318723-1.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318714-2.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318720-1.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318719-1.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1455.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1419.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318709-1.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1432.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1424.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1460.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1426.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1450.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1421.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1458.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1420.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1443.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1438.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1449.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1436.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1446.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318726-1.webp" alt="">
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1445.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318723-1.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318714-2.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318720-1.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318719-1.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1455.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1419.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318709-1.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1432.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1424.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1460.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1426.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1450.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1421.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1458.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1420.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1443.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1438.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1449.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1436.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1446.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318726-1.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1445.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318723-1.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318714-2.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318720-1.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318719-1.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1455.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1419.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318709-1.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1432.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1424.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1460.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1426.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1450.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1421.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1458.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1420.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1443.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1438.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Group-1449.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1436.webp" alt=""> 
                        <img decoding="async" class="rectangle" src="https://homenest.media//wp-content/uploads/2025/03/Group-1446.webp" alt=""> 
                        <img decoding="async" class="square" src="https://homenest.media//wp-content/uploads/2025/03/Frame-427318726-1.webp" alt=""> 
                    </div> 
                </div>

            </div>
        </div>

        <div class="homenest_seo_process">
            <div class="homenest_seo_process_margin">
                <div class="homenest_seo_process_top">
                    <h2>
                        Quy trình <span class="homenest_seo_color">Tư vấn & Triển khai</span><br>Dịch vụ SEO Tổng thể
                    </h2>
                    <p>
                        Khách hàng của chúng tôi là những doanh nghiệp mong muốn nâng tầm thương hiệu và tối ưu hiệu quả kinh doanh. HomeNest đồng hành cùng họ, mang đến giải pháp số đột phá và bền vững.
                    </p>
                </div>

                <div class="homenest_seo_process_bottom">
                    <div class="homenest_seo_step homenest_seo_active" data-step="01">
                        <p class="homenest_seo_step_title">01.</p>
                        <span class="homenest_seo_vertical-text">Tiếp nhận thông tin khách hàng</span>
                        <div class="homenest_seo_step-content">
                            <div class="homenest_seo_step_content_title">
                                <p class="homenest_seo_step_number">01.</p>
                                <h3>Tiếp nhận thông tin khách hàng</h3>
                            </div>
                        <p>Khách hàng của chúng tôi là những doanh nghiệp mong muốn nâng tầm thương hiệu và tối ưu hiệu quả kinh doanh. HomeNest đồng hành cùng họ, mang đến giải pháp số đột phá và bền vững.</p>
                        </div>
                    </div>
                    <div class="homenest_seo_step" data-step="02">
                        <p class="homenest_seo_step_title">02.</p>
                        <span class="homenest_seo_vertical-text">Phân Tích Dự Án</span>
                        <div class="homenest_seo_step-content">
                            <div class="homenest_seo_step_content_title">
                                <p class="homenest_seo_step_number">02.</p>
                                <h3>Phân Tích Dự Án</h3>
                            </div>
                        <p>Khách hàng của chúng tôi là những doanh nghiệp mong muốn nâng tầm thương hiệu và tối ưu hiệu quả kinh doanh. HomeNest đồng hành cùng họ, mang đến giải pháp số đột phá và bền vững.</p>
                        </div>
                    </div>
                    <div class="homenest_seo_step" data-step="03">
                        <p class="homenest_seo_step_title">03.</p>
                        <span class="homenest_seo_vertical-text">Lên kế hoạch và phương án</span>
                        <div class="homenest_seo_step-content">
                        <div class="homenest_seo_step_content_title">
                            <p class="homenest_seo_step_number">03.</p>
                        <h3>Lên kế hoạch và phương án</h3>
                            </div>
                        <p>Khách hàng của chúng tôi là những doanh nghiệp mong muốn nâng tầm thương hiệu và tối ưu hiệu quả kinh doanh. HomeNest đồng hành cùng họ, mang đến giải pháp số đột phá và bền vững.</p>
                        </div>
                    </div>
                    <div class="homenest_seo_step" data-step="04">
                        <p class="homenest_seo_step_title">04.</p>
                        <span class="homenest_seo_vertical-text">Nghiên cứu và gom nhóm từ khóa</span>
                        <div class="homenest_seo_step-content">
                            <div class="homenest_seo_step_content_title">
                            <p class="homenest_seo_step_number">04.</p>
                        <h3>Nghiên cứu và gom nhóm từ khóa</h3>
                            </div>
                        <p>Khách hàng của chúng tôi là những doanh nghiệp mong muốn nâng tầm thương hiệu và tối ưu hiệu quả kinh doanh. HomeNest đồng hành cùng họ, mang đến giải pháp số đột phá và bền vững.</p>
                        </div>
                    </div>
                    <div class="homenest_seo_step" data-step="05">
                        <p class="homenest_seo_step_title">05.</p>
                        <span class="homenest_seo_vertical-text">Tối ưu website</span>
                        <div class="homenest_seo_step-content">
                            <div class="homenest_seo_step_content_title">
                            <p class="homenest_seo_step_number">05.</p>
                        <h3>Tối ưu website</h3>
                            </div>
                        <p>Khách hàng của chúng tôi là những doanh nghiệp mong muốn nâng tầm thương hiệu và tối ưu hiệu quả kinh doanh. HomeNest đồng hành cùng họ, mang đến giải pháp số đột phá và bền vững.</p>
                        </div>
                    </div>
                    <div class="homenest_seo_step" data-step="06">
                        <p class="homenest_seo_step_title">06.</p>
                        <span class="homenest_seo_vertical-text">Nghiệm thu dự án</span>
                        <div class="homenest_seo_step-content">
                            <div class="homenest_seo_step_content_title">
                                <p class="homenest_seo_step_number">06.</p>
                                <h3>Nghiệm thu dự án</h3>
                            </div>
                        <p>Khách hàng của chúng tôi là những doanh nghiệp mong muốn nâng tầm thương hiệu và tối ưu hiệu quả kinh doanh. HomeNest đồng hành cùng họ, mang đến giải pháp số đột phá và bền vững.</p>
                        </div>
                    </div>
                    <div class="homenest_seo_step" data-step="07">
                        <p class="homenest_seo_step_title">07.</p>
                        <span class="homenest_seo_vertical-text">Bảo hành dụ án</span>
                        <div class="homenest_seo_step-content">
                            <div class="homenest_seo_step_content_title">
                            <p class="homenest_seo_step_number">07.</p>
                        <h3>Bảo hành dụ án</h3>
                            </div>
                        <p>Khách hàng của chúng tôi là những doanh nghiệp mong muốn nâng tầm thương hiệu và tối ưu hiệu quả kinh doanh. HomeNest đồng hành cùng họ, mang đến giải pháp số đột phá và bền vững.</p>
                        </div>
                    </div>
                    <div class="homenest_seo_step" data-step="08">
                        <p class="homenest_seo_step_title">08.</p>
                        <span class="homenest_seo_vertical-text">Chăm sóc khách hàng</span>
                        <div class="homenest_seo_step-content">
                            <div class="homenest_seo_step_content_title">
                                <p class="homenest_seo_step_number">08.</p>
                                <h3>Chăm sóc khách hàng</h3>
                            </div>
                            
                        <p>Khách hàng của chúng tôi là những doanh nghiệp mong muốn nâng tầm thương hiệu và tối ưu hiệu quả kinh doanh. HomeNest đồng hành cùng họ, mang đến giải pháp số đột phá và bền vững.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="homenest_seo_slideshow">
            <h2><span class="homenest_seo_color">Bảng giá dịch vụ SEO tổng thể - </span> Homenest Media</h2>
            <div class="swiper mySwiper">

                <div class="swiper-wrapper">
                <!-- Plan BASIC -->
                        <div class="swiper-slide plan basic">
                        <h3 style="background-color: #2db5b1;">BASIC</h3>
                        <p><span class="black_normal" style="font-weight: 300;"><span style="color: #2db5b1; font-weight: bold;">Gói Basic</span> Tập trung vào các kỹ thuật SEO Onpage, nâng cao trải nghiệm người dùng và tạo sự nhận diện cho thương hiệu.</span></p>
                        <hr>
                        <ul>
                            <li>90 - 100% Top 10</li>
                            <li>Cam kết Top 10 các Keywords Top Volume Search</li>
                            <li>x2 - x5 Organic Traffic tổng thể</li>
                            <li>Chiến lược <a class="wpil_keyword_link" href="/cach-lam-content-marketing-hieu-qua-tiet-kiem/" title="Content Marketing" data-wpil-keyword-link="linked">Content Marketing</a> &amp; Thực thi​</li>
                            <li>Tối ưu tỷ lệ chuyển đổi cho Website</li>
                            <li>Nghiệm thu hàng tháng theo KPI</li>
                            <li>Chính sách hoàn phí &amp; Bảo hành kết quả</li>
                            <li>Combo đào tạo &amp; Chuyển giao Trainning nhân sự</li>
                        </ul>
                        <hr>
                        
                        <p class="sale">*Liên hệ ngay để được tư vấn miễn phí</p>
                        <div class="button">
                            <div class="button-img"><img src="https://homenest.media/wp-content/uploads/2025/02/Icon-Call-Homenest.media_.svg" alt=""></div>
                            <div class="button-price">
                            <div class="button-price-before">9.000.000</div>
                            <div class="button-price-after">Tư vấn ngay</div>
                            </div>
                        </div>
                        </div>

                        <!-- Plan GOLDEN -->
                        <div class="swiper-slide plan golden">
                        <h3 style="background-color: #ff9800;">GOLDEN</h3>
                        <p><span class="black_normal" style="font-weight: 300;"><span style="color: #fd7401; font-weight: bold;">Gói Golden </span>Tối ưu hóa trải nghiệm người dùng và thúc đẩy quảng bá thương hiệu, đồng thời hỗ trợ trong việc phát triển kinh doanh.</span></p>
                        <hr>
                            <ul>
                                <li>20 - 30% Top 5</li>
                                <li>50 - 80% Top 10</li>
                                <li>Cam kết Top 10 các Keywords Top Volume Search</li>
                                <li>x2 - x5 Organic Traffic tổng thể</li>
                                <li>Chiến lược <a class="wpil_keyword_link" href="/cach-lam-content-marketing-hieu-qua-tiet-kiem/" title="Content Marketing" data-wpil-keyword-link="linked">Content Marketing</a> &amp; Thực thi​</li>
                                <li>Tối ưu tỷ lệ chuyển đổi cho Website</li>
                                <li>Nghiệm thu hàng tháng theo KPI</li>
                                <li>Chính sách hoàn phí &amp; Bảo hành kết quả</li>
                                <li>Combo đào tạo &amp; Chuyển giao Trainning nhân sự</li>
                            </ul>
                        <hr>
                        
                        <p class="sale">*Liên hệ ngay để được tư vấn miễn phí</p>
                        <div class="button">
                            <div class="button-img"><img src="https://homenest.media/wp-content/uploads/2025/02/Icon-Call-Homenest.media_.svg" alt=""></div>
                            <div class="button-price">
                            <div class="button-price-before">19.000.000</div>
                            <div class="button-price-after">Tư vấn ngay</div>
                            </div>
                        </div>
                        </div>

                        <!-- Plan DIAMOND -->
                        <div class="swiper-slide plan diamond">
                        <h3 style="background-color: #020c6a;">DIAMOND</h3>
                        <p><span class="black_normal" style="font-weight: 300;"><span style="color: #020c6a; font-weight: bold;">Gói Diamond </span>SEO tăng mạnh đồng thời cải thiện thứ hạng từ khóa, tăng lượng truy cập và tối ưu hóa tỷ lệ chuyển đổi</span></p>                        <hr>
                        <ul>
                            <li>25 - 40% Top 5</li>
                            <li> 65 - 80% Top 10</li>
                            <li>Cam kết Top 10 các Keywords Top Volume Search</li>
                            <li>Organic Traffic Top 5 - 10 thị trường</li>
                            <li>Chiến lược Content Marketing &amp; Thực thi</li>
                            <li>Tối ưu tỷ lệ chuyển đổi Website</li>
                            <li>Nghiệm thu hàng tháng theo KPI</li>
                            <li>Chính sách hoàn phí &amp; Bảo hành kết quả</li>
                            <li>Combo Đào tạo &amp; Chuyển giao Trainning nhân sự</li>
                        </ul>
                        <hr>
                        
                        <p class="sale">*Liên hệ ngay để được tư vấn miễn phí</p>
                        <div class="button">
                            <div class="button-img"><img src="https://homenest.media/wp-content/uploads/2025/02/Icon-Call-Homenest.media_.svg" alt=""></div>
                            <div class="button-price">
                            <div class="button-price-before">39.000.000</div>
                            <div class="button-price-after">Tư vấn ngay</div>
                            </div>
                        </div>
                        </div>

                        <!-- Plan PLATINUM -->
                        <div class="swiper-slide plan platinum">
                            <h3 style="background-color: #972295;">PLATINUM</h3>
                            <p><span class="black_normal" style="font-weight: 300;"><span style="color: #972295; font-weight: bold;">Gói Platinum </span>Thống trị thị trường trong lĩnh vực ngành, chiếm lĩnh toàn bộ không gian tìm kiếm tự nhiên trên Google.</span></p>                        <hr>
                            <ul>
                                <li>15 - 50% Top 3</li>
                                <li>40 - 60% Top 5</li>
                                <li>70 - 85% Top 10</li>
                                <li>Cam kết Top 5 các Keywords Top Volume Search</li>
                                <li>Organic Traffic Top 1 - 3 thị trường</li>
                                <li>Chiến lược Content Marketing &amp; Thực thi</li>
                                <li>Tối ưu tỷ lệ chuyển đổi cho Website</li>
                                <li>Nghiệm thu hằng tháng theo KPI</li>
                                <li>Chính sách hoàn phí &amp; Bảo hành kết quả</li>
                                <li>Combo Đào tạo &amp; Chuyển giao Trainning nhân sự</li>
                            </ul>
                            <hr>
                            
                            <p class="sale">*Liên hệ ngay để được tư vấn miễn phí</p>
                            <div class="button">
                                <div class="button-img"><img src="https://homenest.media/wp-content/uploads/2025/02/Icon-Call-Homenest.media_.svg" alt=""></div>
                                <div class="button-price">
                                <div class="button-price-before">Linh hoạt</div>
                                <div class="button-price-after">Tư vấn ngay</div>
                                </div>
                            </div>
                        </div>

                </div>
               
            </div>
        </div>

        <div class="homenest_seo_why">
            <div class="homenest_seo_why_left">
                <img src="https://homenest.media/wp-content/uploads/2024/08/dich-vu-SEO-tong-the-2.webp" alt="">
            </div>
            <div class="homenest_seo_why_right">
                <span>/ How it works /</span>
                <h2 class="homenest_seo_color">Giá trị vượt trỗi từ dịch vụ SEO tổng thể</h2>
                <div class="homenest_seo_why_right_right">
                    <span>01</span>
                    <div class="homenest_seo_why_right_top">
                        <h3>Tăng Traffic tự nhiên</h3>
                        <p>Mạng nơ-ron nhân tạo (Neural Network) bao gồm các nút (neurons) được kết nối với nhau và được tổ chức thành các lớp (layers).</p>
                    </div>
                    
                </div>
                <hr>
                <div class="homenest_seo_why_right_right">
                    <span>02</span>
                    <div class="homenest_seo_why_right_top">
                        <h3>Giảm chi phí quảng cáo</h3>
                        <p>Mỗi nơ-ron thực hiện một hàm kích hoạt (activation function) trên tổng có trọng số của các đầu vào và tạo ra một đầu ra.</p>
                    </div>
                </div>
                <hr>
                <div class="homenest_seo_why_right_right">
                    <span>03</span>
                    <div class="homenest_seo_why_right_top">
                        <h3>Tăng tỉ lệ chuyển đổi khách hàng</h3>
                    <p>Các đầu vào được nhân với trọng số tương ứng, cộng lại, sau đó truyền qua hàm kích hoạt (activation function).</p>
                    </div>
                </div>
                <div class="homenest_seo_why_button">
                    <a href="#">
                        Tư vấn ngay
                    </a>
                </div>
            </div>
        </div>

        <div class="homenest_seo_faq_container">
            <section class="homenest_seo_faq">
                <div class="faq-header">
                    <p>/ faq /</p>
                    <h2>Câu hỏi thường gặp về dịch vụ SEO tổng thể</h2>
                </div>

                <div class="faq-item">
                    <div class="faq-title" onclick="toggleFAQ(this)">
                        <span class="faq-number">01</span>
                        <h3>SEO tổng thể là gì ?</h3>
                        <span class="arrow">
                            <svg width="10" height="10" viewBox="0 0 200 200" 
                            xmlns="http://www.w3.org/2000/svg">
                            <polygon points="200,0 200,200 0,200" fill="black" />
                            </svg>
                        </span>
                    </div>
                    <div class="faq-content">
                        <p>SEO tổng thể là chiến lược tối ưu hóa toàn diện website để tăng cường hiệu quả hiển thị trên công cụ tìm kiếm, bao gồm cả SEO on-page, off-page, và trải nghiệm người dùng (UX/UI). Nó không chỉ tập trung vào từ khóa mà còn cải thiện tổng thể chất lượng và hiệu suất của website.</p>
                    </div>
                </div>

                <div class="faq-item">
                <div class="faq-title" onclick="toggleFAQ(this)">
                    <span class="faq-number">02</span>
                    <h3>SEO tổng thể mang lại lợi ích gì ?</h3>
                    <span class="arrow"><svg width="10" height="10" viewBox="0 0 200 200" 
                            xmlns="http://www.w3.org/2000/svg">
                            <polygon points="200,0 200,200 0,200" fill="black" />
                            </svg></span>
                </div>
                <div class="faq-content">
                    <p>SEO tổng thể giúp website phát triển bền vững, tăng traffic tự nhiên, cải thiện trải nghiệm người dùng và tăng khả năng chuyển đổi.</p>
                </div>
                </div>

                <div class="faq-item">
                <div class="faq-title" onclick="toggleFAQ(this)">
                    <span class="faq-number">03</span>
                    <h3>Khác biệt giữa SEO tổng thể và SEO từ khóa là gì ?</h3>
                    <span class="arrow"><svg width="10" height="10" viewBox="0 0 200 200" 
                            xmlns="http://www.w3.org/2000/svg">
                            <polygon points="200,0 200,200 0,200" fill="black" />
                            </svg></span>
                </div>
                <div class="faq-content">
                    <p>SEO từ khóa tập trung vào việc tối ưu một số từ khóa cụ thể, trong khi SEO tổng thể chú trọng cải thiện toàn bộ website.</p>
                </div>
                </div>

                <div class="faq-item">
                <div class="faq-title" onclick="toggleFAQ(this)">
                    <span class="faq-number">04</span>
                    <h3>Tại sao SEO tổng thể quan trọng hơn trong thời đại hiện nay ?</h3>
                    <span class="arrow"><svg width="10" height="10" viewBox="0 0 200 200" 
                            xmlns="http://www.w3.org/2000/svg">
                            <polygon points="200,0 200,200 0,200" fill="black" />
                            </svg></span>
                </div>
                <div class="faq-content">
                    <p>SEO tổng thể đáp ứng nhu cầu ngày càng cao về trải nghiệm người dùng, tối ưu hiệu suất, và yêu cầu của thuật toán mới từ Google.</p>
                </div>
                </div>

                <div class="faq-item">
                <div class="faq-title" onclick="toggleFAQ(this)">
                    <span class="faq-number">05</span>
                    <h3>SEO tổng thể là gì ?</h3>
                    <span class="arrow"><svg width="10" height="10" viewBox="0 0 200 200" 
                            xmlns="http://www.w3.org/2000/svg">
                            <polygon points="200,0 200,200 0,200" fill="black" />
                            </svg></span>
                </div>
                <div class="faq-content">
                    <p>SEO tổng thể là chiến lược tối ưu hóa toàn diện website để tăng cường hiệu quả hiển thị trên công cụ tìm kiếm, bao gồm cả SEO on-page, off-page, và trải nghiệm người dùng (UX/UI). Nó không chỉ tập trung vào từ khóa mà còn cải thiện tổng thể chất lượng và hiệu suất của website.</p>
                </div>
                </div>

                <div class="faq-item">
                <div class="faq-title" onclick="toggleFAQ(this)">
                    <span class="faq-number">06</span>
                    <h3>SEO tổng thể mang lại lợi ích gì ?</h3>
                    <span class="arrow"><svg width="10" height="10" viewBox="0 0 200 200" 
                            xmlns="http://www.w3.org/2000/svg">
                            <polygon points="200,0 200,200 0,200" fill="black" />
                            </svg></span>
                </div>
                <div class="faq-content">
                    <p>SEO tổng thể giúp website phát triển bền vững, tăng traffic tự nhiên, cải thiện trải nghiệm người dùng và tăng khả năng chuyển đổi.</p>
                </div>
                </div>

                <div class="faq-item">
                <div class="faq-title" onclick="toggleFAQ(this)">
                    <span class="faq-number">07</span>
                    <h3>Khác biệt giữa SEO tổng thể và SEO từ khóa là gì ?</h3>
                    <span class="arrow"><svg width="10" height="10" viewBox="0 0 200 200" 
                            xmlns="http://www.w3.org/2000/svg">
                            <polygon points="200,0 200,200 0,200" fill="black" />
                            </svg></span>
                </div>
                <div class="faq-content">
                    <p>SEO từ khóa tập trung vào việc tối ưu một số từ khóa cụ thể, trong khi SEO tổng thể chú trọng cải thiện toàn bộ website.</p>
                </div>
                </div>

                <div class="faq-item">
                <div class="faq-title" onclick="toggleFAQ(this)">
                    <span class="faq-number">08</span>
                    <h3>Tại sao SEO tổng thể quan trọng hơn trong thời đại hiện nay ?</h3>
                    <span class="arrow"><svg width="10" height="10" viewBox="0 0 200 200" 
                            xmlns="http://www.w3.org/2000/svg">
                            <polygon points="200,0 200,200 0,200" fill="black" />
                            </svg></span>
                </div>
                <div class="faq-content">
                    <p>SEO tổng thể đáp ứng nhu cầu ngày càng cao về trải nghiệm người dùng, tối ưu hiệu suất, và yêu cầu của thuật toán mới từ Google.</p>
                </div>
                </div>

                <div class="faq-item">
                <div class="faq-title" onclick="toggleFAQ(this)">
                    <span class="faq-number">09</span>
                    <h3>Tại sao SEO tổng thể quan trọng hơn trong thời đại hiện nay ?</h3>
                    <span class="arrow"><svg width="10" height="10" viewBox="0 0 200 200" 
                            xmlns="http://www.w3.org/2000/svg">
                            <polygon points="200,0 200,200 0,200" fill="black" />
                            </svg></span>
                </div>
                <div class="faq-content">
                    <p>SEO tổng thể đáp ứng nhu cầu ngày càng cao về trải nghiệm người dùng, tối ưu hiệu suất, và yêu cầu của thuật toán mới từ Google.</p>
                </div>
                </div>
                
                <div class="faq-toggle-wrapper">
                    <button id="toggleMore" onclick="toggleMoreItems()">Xem tất cả FAQ</button>
                </div>
            
            </section>
        </div>

        <div class="homenest_seo_aboutus">
            <div class="homenest_seo_aboutus_left">
                <div class="swiper mySwiper_about">

                    <div class="swiper-wrapper">
                        <!-- 1 -->
                            <div class="swiper-slide">
                                <svg width="120" height="120" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg">
                                    <rect x="20" y="20" width="30" height="80" rx="15" ry="15" transform="rotate(45 20 20)" fill="white" />
                                    <rect x="60" y="40" width="25" height="60" rx="12" ry="12" transform="rotate(45 60 40)" fill="white" />
                                </svg>


                                <p class="status">Chúng tôi hiểu rằng xây dựng thương hiệu mạnh và chiến lược marketing hiệu quả là yếu tố quan trọng để phát triển công ty, giúp doanh nghiệp của bạn tăng doanh số và tạo ra lợi nhuận bền vững. Chúng tôi sẽ đồng hành cùng bạn trên hành trình này.</p>
                                <div class="homenest_seo_aboutus_author">
                                    <li class="author">- Nguyễn Ngọc Tiến, SEO</li>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <svg width="120" height="120" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg">
                                    <rect x="20" y="20" width="30" height="80" rx="15" ry="15" transform="rotate(45 20 20)" fill="white" />
                                    <rect x="60" y="40" width="25" height="60" rx="12" ry="12" transform="rotate(45 60 40)" fill="white" />
                                </svg>
                                <p class="status">Chúng tôi hiểu rằng xây dựng thương hiệu mạnh và chiến lược marketing hiệu quả là yếu tố quan trọng để phát triển công ty, giúp doanh nghiệp của bạn tăng doanh số và tạo ra lợi nhuận bền vững. Chúng tôi sẽ đồng hành cùng bạn trên hành trình này.</p>
                                <div class="homenest_seo_aboutus_author">
                                    <li class="author">- Nguyễn Ngọc Tiến, SEO</li>
                                </div>
                            </div>
                            
                            
                    </div>
                
                </div>
            </div>
            <div class="homenest_seo_aboutus_right"> 
                <div class="homenest_seo_about_right_bottom">
                    <span>/ testimonials /</span>
                    <h4>HomeNest.Media với bộ giải pháp All In One là sự lựa chọn hoàn hảo để tối ưu SEO doanh nghiệp của bạn.</h4>
                    <p><span class="homenest_seo_counter_data">250</span>+</p>
                    <div class="homenest_seo_about_title">
                        Khách hàng hài lòng
                    </div>
                </div>
                
            </div>
        </div>




    </div>
    <script src="media.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

    <!-- Initialize Swiper -->
    <script>
      var swiper = new Swiper(".mySwiper", {
        slidesPerView: 1,
        spaceBetween: 30,
        freeMode: true,
        loop: true,
          navigation: {
             nextEl: '.next',
            prevEl: '.prev',
             },
      breakpoints: {
          480: {
          slidesPerView: 1,
          },
          768: {
          slidesPerView: 2,
          },
          1024: {
          slidesPerView: 3,
          },
          1200: {
          slidesPerView: 4,
          }
      }
      });
      var swiper = new Swiper(".mySwiper_about", {
        slidesPerView: 1,
        spaceBetween: 30,
        freeMode: true,
        loop: true,
      breakpoints: {
          
          1200: {
          slidesPerView: 1,
          }
      }
      });
    </script>

</body>

<?php get_footer(); ?>
