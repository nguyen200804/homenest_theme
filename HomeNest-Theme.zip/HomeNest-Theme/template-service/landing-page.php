<?php
/**
 * Template Name: Landing Page
 * Template Post Type: service
 */
get_header(); ?>
<style>
	/* RESET CƠ BẢN */
	*,
	*::before,
	*::after {
		margin: 0;
		padding: 0;
		box-sizing: border-box;
	}


	html,
	body {
		height: 100%;
		width: 100%;


	}

	input,
	button,
	textarea,
	select {
		font: inherit;
		color: inherit;
		background: none;
		border: none;
		outline: none;
	}

	ul,
	ol {
		list-style: none;
	}

	a {
		color: inherit;
		text-decoration: none;
	}

	img,
	picture,
	video,
	canvas,
	svg {
		display: block;
		max-width: 100%;
		height: auto;
	}


	:root {
		--color-secondary: #1f1f1f;
		--color-text-desc: #666666;
		--bg-text-gradient: linear-gradient(to right, #020C6A, #1A85F8, #66E5FB);
	}

	.homenest-sw__landingpage__hl-title{
		background: linear-gradient(to right, #020C6A, #1A85F8, #66E5FB);
		-webkit-background-clip: text;
		-webkit-text-fill-color: transparent;
		display: inline-block;
	}


	.homnest-sw__landing-page__section1 {
		background-color: white;
		width: 100%;
	}


	.homnest-sw__landing-page__section1-wrapper {
		width: 100%;
		margin: 0 auto;
		display: flex;
		justify-content: flex-start;
		flex-wrap: wrap;
		gap: 1rem;
		padding: 100px 160px;
	}

	.homnest-sw__landing-page__section1-content{
		width: 100%;
		display: flex;
		flex-direction: row;
		gap: 48px;
	}
	.homnest-sw__landing-page__section1-title {
		width: 100%;
		height: 100%;
	}




	.homnest-sw__landing-page__section1-title h2 {
		font-size: 48px;
		font-weight: 800;
		line-height: 150%;
	}

	.homnest-sw__landing-page__section1-title p {
		font-size: 20px;
		font-weight: 400;
		line-height: 150%;
		text-align: justify;
		max-width: 100%;
	}

	.homnest-sw__landing-page__section1-title a{
		width: 298px;
		height: 62px;
		border-radius: 100px;
		background: var(--bg-text-gradient);
		text-align: center;
		display: flex;
		align-items: center;
		justify-content: center;
		color: white;
		font-weight: 700;
		font-size: 20px;
		line-height: 150%;
		transition: transform 0.3s ease;
	}

	.homnest-sw__landing-page__section1-title a:hover{
		transform: translateY(-5px);
	}



	.homnest-sw__landing-page__section1-title{
		display: flex;
		flex-direction: column;
		gap: 48px;
	}

	.homnest-sw__landing-page__section1-title .items{
		display: flex;
		flex-direction: row;
		gap: 25px;
	}

	.homnest-sw__landing-page__section1-title .items .item{
		min-width: 45%;
		min-height: 194px;
		display: flex;
		flex-direction: column;
		justify-content: center;
		padding: 25px;
		border-radius: 16px;
		gap: 16px;
		border: 1px solid #abf9ff;
	}

	.homnest-sw__landing-page__section1-title .items .item.item-1{
		background-image: url('http://homenest.software/wp-content/uploads/2025/06/ee66a71cc66e46b0ac7cb7bcbdd55056cf2b5145.webp');
		background-repeat: no-repeat;
		background-position: center;
		background-size: cover;
	}

	.homnest-sw__landing-page__section1-title .items .item.item-2{
		background-image: url('http://homenest.software/wp-content/uploads/2025/06/affda61766fc0cf35a0f088069674f82e8ba2f59.webp');
		background-repeat: no-repeat;
		background-position: center;
		background-size: cover;
	}

	.homnest-sw__landing-page__section1-title .items .item .item-num{
		font-size: 72px;
		font-weight: 900;
		line-height: 120%;
		color: transparent;
		background: linear-gradient(to right, #020C6A, #1A85F8, #66E5FB);
		-webkit-background-clip: text;
		background-clip: text;
	}
	.homnest-sw__landing-page__section1-title .items .item .item-text{
		font-size: 24px;
		font-weight: 600;
		line-height: 150%;

	}

	.homnest-sw__landing-page__section1-contact {
		width: 100%;
		height: 100%;
		position: relative;
		border-radius: 16px;
		margin-bottom: auto;
	}


	.homnest-sw__landing-page__section1-contact img{
		width: 100%;
		object-fit: cover;
	}
	.homnest-sw__landing-page__section1-contact .section1-btn-contact-wrapper{
	}

	.homnest-sw__landing-page__section1-contact .section1-btn-watch{
		width: 200px;
		height: 60px;
		border: 1px solid #020C6A;
		color: #020C6A;
		font-size: 18px;
		font-weight: 700;
		border-radius: 80px;
		padding: 10px 20px;
		position: absolute;
		left: 0;
		display: flex;
		align-items: center;
		justify-content: center;
		line-height: 1;
		transition: transform 0.3s ease;
	}
	.homnest-sw__landing-page__section1-contact .section1-btn-watch:hover{
		transform: translateY(-5px);			
	}

	.homnest-sw__landing-page__section1-contact .section1-btn-watch::before{
		content: '';
		width: 20px;
		height:   20px;
		background-image: url('http://homenest.software/wp-content/uploads/2025/06/play-button.webp');
		background-size: contain;
		background-repeat: no-repeat;
		margin-right: 10px;
		display: inline-block;
	}

	@media (max-width: 1440px){
		.homnest-sw__landing-page__section1-wrapper{
			padding: 100px 50px;
		}
	}

	@media (max-width: 1300px){
		.homnest-sw__landing-page__section1-title .items .item {
			min-width: 100%;
		}
	}

	@media (max-width: 1024px) {
		.homnest-sw__landing-page__section1-wrapper {
			padding: 60px 40px;
		}

		.homnest-sw__landing-page__section1-content {
			flex-direction: column;
			gap: 40px;
		}

		.homnest-sw__landing-page__section1-title h2 {
			font-size: 40px;
		}

		.homnest-sw__landing-page__section1-title p {
			font-size: 20px;
		}

		.homnest-sw__landing-page__section1-title .items {
			gap: 20px;
		}

		.homnest-sw__landing-page__section1-title .items .item {
			min-width: 280px;
			min-height: 160px;
			padding: 20px;
		}
	}

	/* Mobile styles */
	@media (max-width: 768px) {
		.homnest-sw__landing-page__section1-contact{
			display: none;
		}
		.homnest-sw__landing-page__section1-wrapper {
			padding: 0px 20px 40px 20px;
		}

		.homnest-sw__landing-page__section1-title {
			gap: 32px;
		}

		.homnest-sw__landing-page__section1-title h2 {
			font-size: 32px;
			text-align: center;
		}

		.homnest-sw__landing-page__section1-title p {
			font-size: 18px;
			text-align: justify;
		}

		.homnest-sw__landing-page__section1-title a {
			width: 100%;
			max-width: 300px;
			margin: 0 auto;
			font-size: 18px;
		}

		.homnest-sw__landing-page__section1-title .items {
			flex-direction: column;
			gap: 16px;
		}

		.homnest-sw__landing-page__section1-title .items .item {
			min-width: 100%;
			min-height: 140px;
			padding: 20px;
		}

		.homnest-sw__landing-page__section1-title .items .item .item-num {
			font-size: 48px;
		}

		.homnest-sw__landing-page__section1-title .items .item .item-text {
			font-size: 18px;
		}

		.homnest-sw__landing-page__section1-contact {
			height: 300px;
		}

		.homnest-sw__landing-page__section1-contact .section1-btn-watch {
			width: 160px;
			height: 50px;
			font-size: 16px;
			bottom: 15px;
			left: 15px;
		}

		.homnest-sw__landing-page__section1-contact .section1-btn-watch::before {
			width: 16px;
			height: 16px;
			margin-right: 8px;
		}
	}

	/* Small mobile styles */
	@media (max-width: 480px) {
		.homnest-sw__landing-page__section1-wrapper {
			padding: 0px 16px 30px 16px;
		}

		.homnest-sw__landing-page__section1-title h2 {
			font-size: 28px;
		}

		.homnest-sw__landing-page__section1-title p {
			font-size: 15px;
		}

		.homnest-sw__landing-page__section1-title a {
			font-size: 16px;
			height: 56px;
		}

		.homnest-sw__landing-page__section1-title .items .item {
			min-height: 120px;
			padding: 16px;
		}

		.homnest-sw__landing-page__section1-title .items .item .item-num {
			font-size: 40px;
		}

		.homnest-sw__landing-page__section1-title .items .item .item-text {
			font-size: 16px;
		}

		.homnest-sw__landing-page__section1-contact {
			display: none;
			height: 250px;
		}

		.homnest-sw__landing-page__section1-contact .section1-btn-watch {
			width: 140px;
			height: 45px;
			font-size: 14px;
			bottom: 12px;
			left: 12px;
		}
	}

	/* Very small screens */
	@media (max-width: 360px) {
		.homnest-sw__landing-page__section1-title h2 {
			font-size: 24px;
		}

		.homnest-sw__landing-page__section1-title .items .item .item-num {
			font-size: 36px;
		}
	}


	/************************************** SECTION 2 ********************************************/
	.homnest-sw__landing-page__section2 {
		background-color: #F0F2F4;
		width: 100%;
		background: url("http://h2.homenest.tech/wp-content/uploads/2025/06/1-3.webp"), url("http://h2.homenest.tech/wp-content/uploads/2025/06/1.svg"), url("http://h2.homenest.tech/wp-content/uploads/2025/06/Frame-1.webp"), url("http://h2.homenest.tech/wp-content/uploads/2025/06/Group-1224.webp");
		background-repeat: no-repeat, no-repeat, no-repeat, no-repeat;
		background-position: left top, right bottom, right bottom, left center;
	}


	.homnest-sw__landing-page__section2-wrapper {
		width: 100%;
		margin: 0 auto;
		display: flex;
		justify-content: flex-start;
		flex-wrap: wrap;
		gap: 1rem;
		padding: 90px 160px;
	}
	.homnest-sw__landing-page__section2-title{
		width: 100%;
	}

	.homnest-sw__landing-page__section2-title h2{
		width: 100%;
		text-align: center;
		font-size: 48px;
		font-weight: 800;
		line-height: 150%;
	}

	.homnest-sw__landing-page__section2-content{
		margin-top: 70px;
		width: 100%;

	}

	.homnest-sw__landing-page__section2-content .boxs{
		display: flex;
		flex-direction: row;
		gap: 35px;
	}

	.homnest-sw__landing-page__section2-content .boxs .box{
		border-radius: 10px;
		background: white;
		height: fit-content;
		flex: 1;
		max-width: none;
		-webkit-box-shadow: 1px 20px 30px -3px #c5cae9;
		box-shadow: 1px 20px 30px -3px #c5cae9;
	}

	.homnest-sw__landing-page__section2-content .boxs .box .box-content{
		padding: 20px;
		display: flex;
		flex-direction: column;
		gap: 10px;
	}

	.homnest-sw__landing-page__section2-content .boxs .box .box-content .box-content-title{
		display: flex;
		flex-direction: column;
		gap: 20px;
	}

	.homnest-sw__landing-page__section2-content .boxs .box .box-content img{
		width: 72px;
		height: 72px;
		color: #1A85F8;
	}
	.homnest-sw__landing-page__section2-content .boxs .box .box-content h3{
		font-size: 24px;
		font-weight: 900;
		line-height: 120%;
	}

	.homnest-sw__landing-page__section2-content .boxs .box .box-content p{
		font-size: 20px;
		font-weight: 300;
		line-height: 150%;
	}

	.homnest-sw__landing-page__section2-content .boxs .box.box2{
		margin-top: 30px;
	}
	.homnest-sw__landing-page__section2-content .boxs .box.box3{
		margin-top: 60px;
	}
	.homnest-sw__landing-page__section2-content .boxs .box.box4{
		margin-top: 90px;
	}

	.homnest-sw__landing-page__section2-content2 {
		padding: 200px 200px 100px 200px;
		display: flex;
		flex-direction: column;
	}

	.homnest-sw__landing-page__section2-content2--title{
		display: flex;
		flex-direction: row;
		gap: 100px;
	}
	.homnest-sw__landing-page__section2-content2--title img{
		width: 260px;
		height: 128px;
		border-radius: 100px;
	}

	.homnest-sw__landing-page__section2-content2--title h2{
		font-size: 48px;
		line-height: 150%;
		font-weight: 800;
	}

	.homnest-sw__landing-page__section2-content2-grids{
		display: grid;
		grid-template-columns: repeat(2, 1fr);
		grid-template-rows: repeat(2, 1fr);
		column-gap: 70px; 
		row-gap: 40px;  
		margin-top: 120px;
	}

	.homnest-sw__landing-page__section2-content2-grids .content2-grid h3{
		font-size: 24px;
		font-weight: 700;
		line-height: 150%;

	}

	.homnest-sw__landing-page__section2-content2-grids .content2-grid p{
		font-size: 20px;
		line-height: 150%;
		font-weight: 400;
		text-align: justify;
	}

	.homnest-sw__landing-page__section2-content2-grids .content2-grid .content2-grid-content{
		display: flex;
		flex-direction: column;
		gap: 10px;
	}

	/* =============== RESPONSIVE MEDIA QUERIES =============== */

	/* Large Desktop (1440px and up) */
	@media (min-width: 1440px) {
		.homnest-sw__landing-page__section2-wrapper {
			max-width: 100%;
			padding: 100px 180px;
		}

		.homnest-sw__landing-page__section2-content2 {
			padding: 180px 20px 80px 20px;
		}
	}

	/* Desktop (1024px - 1439px) */
	@media (max-width: 1439px) {
		.homnest-sw__landing-page__section2-wrapper {
			padding: 80px 50px;
		}
		.homnest-sw__landing-page__section2-content2--title h2{
			font-size: 35px;
		}

		.homnest-sw__landing-page__section2-content2 {
			padding: 180px 50px 80px 50px;
		}

		.homnest-sw__landing-page__section2-content2--title {
			gap: 70px;
		}

		.homnest-sw__landing-page__section2-content2--title img {
			width: 220px;
			height: 110px;
			object-fit:cover;
		}
	}

	/* Tablet Large (768px - 1023px) */
	@media (max-width: 1023px) {
		.homnest-sw__landing-page__section2-wrapper {
			padding: 60px 50px;
		}

		.homnest-sw__landing-page__section2-title h2 {
			font-size: 40px;
		}

		.homnest-sw__landing-page__section2-content {
			margin-top: 50px;
		}

		.homnest-sw__landing-page__section2-content .boxs {
			flex-direction: column;
			gap: 25px;
		}

		/* Reset staggered margins for mobile stack */
		.homnest-sw__landing-page__section2-content .boxs .box.box2,
		.homnest-sw__landing-page__section2-content .boxs .box.box3,
		.homnest-sw__landing-page__section2-content .boxs .box.box4 {
			margin-top: 0;
		}

		.homnest-sw__landing-page__section2-content2 {
			padding: 120px 50px 60px 50px;
		}

		.homnest-sw__landing-page__section2-content2--title {
			flex-direction: column;
			gap: 30px;
			align-items: center;
			text-align: center;
		}

		.homnest-sw__landing-page__section2-content2--title h2 {
			font-size: 36px;
		}

		.homnest-sw__landing-page__section2-content2--title img {
			width: 90%;
			height: 100px;
			object-fit:cover;
		}

		.homnest-sw__landing-page__section2-content2-grids {
			grid-template-columns: 1fr;
			column-gap: 0;
			row-gap: 30px;
			margin-top: 80px;
		}

		.homnest-sw__landing-page__section2-content .boxs .box .box-content h3 {
			font-size: 22px;
		}

		.homnest-sw__landing-page__section2-content .boxs .box .box-content p {
			font-size: 18px;
		}
	}

	/* Tablet Small (576px - 767px) */
	@media (max-width: 767px) {
		.homnest-sw__landing-page__section2-content .boxs .box .box-content .box-content-title{
			display: flex;
			flex-direction: row;
			align-items: center;
			gap: 10px;
		}
		.homnest-sw__landing-page__section2-wrapper {
			padding: 50px 30px;
		}

		.homnest-sw__landing-page__section2-title h2 {
			font-size: 32px;
		}

		.homnest-sw__landing-page__section2-content {
			margin-top: 40px;
		}

		.homnest-sw__landing-page__section2-content .boxs {
			gap: 20px;
		}

		.homnest-sw__landing-page__section2-content .boxs .box .box-content {
			padding: 15px;
			gap: 20px;
		}

		.homnest-sw__landing-page__section2-content .boxs .box .box-content img {
			width: 60px;
			height: 60px;
		}

		.homnest-sw__landing-page__section2-content .boxs .box .box-content h3 {
			font-size: 20px;
		}

		.homnest-sw__landing-page__section2-content .boxs .box .box-content p {
			font-size: 16px;
		}

		.homnest-sw__landing-page__section2-content2 {
			padding: 100px 30px 50px 30px;
		}

		.homnest-sw__landing-page__section2-content2--title h2 {
			font-size: 28px;
		}

		.homnest-sw__landing-page__section2-content2--title img {
			width: 90%;
			height: 90px;
		}

		.homnest-sw__landing-page__section2-content2-grids {
			margin-top: 60px;
			row-gap: 25px;
		}

		.homnest-sw__landing-page__section2-content2-grids .content2-grid h3 {
			font-size: 20px;
		}

		.homnest-sw__landing-page__section2-content2-grids .content2-grid p {
			font-size: 16px;
		}
	}

	/* Mobile (320px - 575px) */
	@media (max-width: 575px) {
		.homnest-sw__landing-page__section2-wrapper {
			padding: 40px 20px;
		}

		.homnest-sw__landing-page__section2-title h2 {
			font-size: 28px;
			line-height: 130%;
		}

		.homnest-sw__landing-page__section2-content {
			margin-top: 30px;
		}

		.homnest-sw__landing-page__section2-content .boxs {
			gap: 15px;
		}

		.homnest-sw__landing-page__section2-content .boxs .box .box-content {
			padding: 12px;
			gap: 15px;
		}

		.homnest-sw__landing-page__section2-content .boxs .box .box-content img {
			width: 50px;
			height: 50px;
		}

		.homnest-sw__landing-page__section2-content .boxs .box .box-content h3 {
			font-size: 18px;
		}

		.homnest-sw__landing-page__section2-content .boxs .box .box-content p {
			font-size: 16px;
			line-height: 140%;
		}

		.homnest-sw__landing-page__section2-content2 {
			padding: 80px 0 40px 0;
		}

		.homnest-sw__landing-page__section2-content2--title {
			gap: 20px;
		}

		.homnest-sw__landing-page__section2-content2--title h2 {
			font-size: 26px;
			line-height: 130%;
		}

		.homnest-sw__landing-page__section2-content2--title img {
			width: 90%;
			height: 75px;
			object-fit:cover;
		}

		.homnest-sw__landing-page__section2-content2-grids {
			margin-top: 40px;
			row-gap: 20px;
		}

		.homnest-sw__landing-page__section2-content2-grids .content2-grid h3 {
			font-size: 18px;
		}

		.homnest-sw__landing-page__section2-content2-grids .content2-grid p {
			font-size: 16px;
			line-height: 140%;
		}

		.homnest-sw__landing-page__section2-content2-grids .content2-grid .content2-grid-content {
			gap: 8px;
		}
	}

	/* Extra Small Mobile (max 374px) */
	@media (max-width: 374px) {
		.homnest-sw__landing-page__section2-wrapper {
			padding: 30px 15px;
		}

		.homnest-sw__landing-page__section2-title h2 {
			font-size: 24px;
		}

		.homnest-sw__landing-page__section2-content2 {
			padding: 60px 15px 30px 15px;
		}

		.homnest-sw__landing-page__section2-content2--title h2 {
			font-size: 20px;
		}

		.homnest-sw__landing-page__section2-content2--title img {
			width: 90%;
			height: 60px;
		}
	}

	/************************************** SECTION 3 ********************************************/
	.homnest-sw__landing-page__section3 {
		background-color: #F0F2F4;
		width: 100%;
	}


	.homnest-sw__landing-page__section3-wrapper {
		border-radius: 16px;
		height: 766px;
		width: 90%;
		margin: 0 auto;
		display: flex;
		justify-content: flex-start;
		flex-wrap: wrap;
		gap: 1rem;
		background-image: url('http://homenest.software/wp-content/uploads/2025/06/image-2-1720x600-1.webp');
		background-position: center;
		background-repeat: no-repeat;
		background-size: cover;
		position: relative;
		overflow: hidden; 
	}

	.homnest-sw__landing-page__section3-wrapper::before {
		content: "";
		position: absolute;
		inset: 0;
		background: linear-gradient(to right, rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0));
		z-index: 0;
		pointer-events: none;
	}


	.homnest-sw__landing-page__section3--content{
		width: 100%;
		display: flex;
		color: white;
		padding: 70px 100px;

	}

	.homnest-sw__landing-page__section3--content-title{
		width: 100%;
		flex: 1.3;
		display: flex;
		flex-direction: column;
		gap: 35px;
		justify-content: center;
		z-index: 1;

	}

	.homnest-sw__landing-page__section3--content-title h2{
		font-size: 48px;
		line-height: 150%;
		font-weight: 800;
	}

	.homnest-sw__landing-page__section3--content-title p{
		font-size: 20px;
		line-height: 150%;
		font-weight: 400;
		text-align: justify;
		width: 95%;
	}
	.homnest-sw__landing-page__section3--content-prices{
		flex: 1.5;
		display: flex;
		width: 100%;
		height: 100%;
		gap: 25px;
	}


	.homnest-sw__landing-page__section3--content-prices .prices-item{
		width: 100%;
		border-radius: 16px;
		flex: 1;
	}

	.homnest-sw__landing-page__section3--btn-contact{
		width: fit-content;
		padding: 16px 48px;
		background: var(--bg-text-gradient);
		border-radius: 100px;
		font-size: 20px;
		line-height: 150%;
		font-weight: 700;
		transition: transform 0.3s ease;
	}

	.homnest-sw__landing-page__section3--btn-contact:hover{
		transform: translateY(-5px);
	}


	.homnest-sw__landing-page__section3--content-prices .prices-item .prices-item-content{
		padding: 40px 30px;
		display: flex;
		flex-direction: column;
		width: 100%;
		height: 100%;
		background: rgba(255, 255, 255, 0.2);
		border-radius: 16px;
		box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
		backdrop-filter: blur(12.2px);
		-webkit-backdrop-filter: blur(12.2px);
		border: 1px solid rgba(255, 255, 255, 0.63);
		gap: 20px;
	}

	.homnest-sw__landing-page__section3--content-prices .prices-item .prices-item-content h3{
		font-size: 32px;
		font-weight: 900;
		line-height: 150%;
	}

	.homnest-sw__landing-page__section3--content-prices .prices-item .prices-item-content h4{
		font-size: 40px;
		font-weight: 900;
		line-height: 150%;
	}

	.homnest-sw__landing-page__section3--content-prices .prices-item .prices-item-content .btn-price-card{
		padding: 16px 48px;
		width: fit-content;
		font-size: 20px;
		border: 2px solid white;
		border-radius: 100px;
		transition: transform 0.3s ease;
	}

	.homnest-sw__landing-page__section3--content-prices .prices-item .prices-item-content .btn-price-card:hover{
		transform: translateY(-5px);
		color: #046dbd;
		background: white;

	}


	.homnest-sw__landing-page__section3--content-prices .prices-item ul{
		display: flex;
		flex-direction: column;
		justify-content: center;
		gap: 16px;
	}

	.homnest-sw__landing-page__section3--content-prices .prices-item ul li{
		font-size: 18px;
		font-weight: 400;
		line-height: 150%;
		position: relative;
		display: flex;
		align-items: center;
	}

	.homnest-sw__landing-page__section3--content-prices .prices-item ul li::before{
		content: '';
		width: 28px;
		height: 28px;
		background-image: url('http://homenest.software/wp-content/uploads/2025/06/Group-1218.webp');
		background-position: center;
		background-size: contain;
		background-repeat: no-repeat;
		display: inline-block;
		margin-right: 10px;
	}

	/* =============== RESPONSIVE MEDIA QUERIES =============== */

	/* Large Desktop (1440px and up) */
	@media (min-width: 1440px) {
		.homnest-sw__landing-page__section3-wrapper {
			width: 85%;
			height: 800px;
		}

		.homnest-sw__landing-page__section3--content {
			padding: 80px 120px;
		}
	}

	/* Desktop (1024px - 1439px) */
	@media (max-width: 1439px) {
		.homnest-sw__landing-page__section3-wrapper {
			height: 700px;
		}

		.homnest-sw__landing-page__section3--content {
			padding: 60px 40px;
		}

		.homnest-sw__landing-page__section3--content-title h2 {
			font-size: 35px;
		}

		.homnest-sw__landing-page__section3--content-title p {
			font-size: 17px;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item .prices-item-content h3 {
			font-size: 28px;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item .prices-item-content h4 {
			font-size: 36px;
		}

		.homnest-sw__landing-page__section3--content-title {
			justify-content: center;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item .prices-item-content {
			padding: 30px 20px;
			gap: 10px;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item ul li {
			font-size: 14px;
			font-weight: 400;
			line-height: 150%;
			position: relative;
			display: flex;
			align-items: center;
		}
		.homnest-sw__landing-page__section3--content-prices .prices-item .prices-item-content h4 {
			font-size: 24px;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item .prices-item-content .btn-price-card {
			padding: 16px 33px;
			width: fit-content;
			font-size: 15px;
			border: 1px solid white;
			border-radius: 100px;
			transition: transform 0.3s ease;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item .prices-item-content h3 {
			font-size: 24px;
		}
	}

	/* Tablet Large (768px - 1023px) */
	@media (max-width: 1023px) {
		.homnest-sw__landing-page__section3-wrapper {
			width: 95%;
			height: auto;
			min-height: 600px;
		}

		.homnest-sw__landing-page__section3--content {
			flex-direction: column;
			padding: 50px 40px;
			gap: 40px;
		}

		.homnest-sw__landing-page__section3--content-title {
			flex: none;
			text-align: left;
			gap: 25px;
		}

		.homnest-sw__landing-page__section3--content-title h2 {
			font-size: 36px;
		}

		.homnest-sw__landing-page__section3--content-title p {
			font-size: 16px;
			width: 100%;
			text-align: justify;
		}

		.homnest-sw__landing-page__section3--btn-contact {
			font-size: 18px;
			padding: 14px 40px;
		}

		.homnest-sw__landing-page__section3--content-prices {
			flex: 1;
			flex-direction: column;
			gap: 20px;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item .prices-item-content {
			padding: 30px 25px;
			gap: 15px;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item .prices-item-content h3 {
			font-size: 26px;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item .prices-item-content h4 {
			font-size: 32px;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item ul li {
			font-size: 16px;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item .prices-item-content .btn-price-card {
			font-size: 18px;
			padding: 12px 36px;
		}


	}

	/* Tablet Small (576px - 767px) */
	@media (max-width: 767px) {
		.homnest-sw__landing-page__section3-wrapper {
			width: 95%;
			border-radius: 12px;
		}

		.homnest-sw__landing-page__section3--content {
			padding: 40px 30px;
			gap: 30px;
		}

		.homnest-sw__landing-page__section3--content-title h2 {
			font-size: 30px;
			line-height: 130%;
		}

		.homnest-sw__landing-page__section3--content-title p {
			font-size: 18px;
			line-height: 140%;
		}

		.homnest-sw__landing-page__section3--btn-contact {
			font-size: 16px;
			padding: 12px 32px;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item .prices-item-content {
			padding: 25px 20px;
			border-radius: 12px;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item .prices-item-content h3 {
			font-size: 24px;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item .prices-item-content h4 {
			font-size: 28px;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item ul {
			gap: 12px;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item ul li {
			font-size: 15px;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item ul li::before {
			width: 24px;
			height: 24px;
			margin-right: 8px;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item .prices-item-content .btn-price-card {
			font-size: 16px;
			padding: 10px 28px;
		}
	}

	/* Mobile (320px - 575px) */
	@media (max-width: 575px) {
		.homnest-sw__landing-page__section3-wrapper {
			width: 98%;
			border-radius: 10px;
		}

		.homnest-sw__landing-page__section3--content {
			padding: 30px 20px;
			gap: 25px;
		}

		.homnest-sw__landing-page__section3--content-title {
			gap: 20px;
		}

		.homnest-sw__landing-page__section3--content-title h2 {
			font-size: 26px;
			line-height: 125%;
		}

		.homnest-sw__landing-page__section3--content-title p {
			font-size: 16px;
			line-height: 135%;
		}

		.homnest-sw__landing-page__section3--btn-contact {
			font-size: 15px;
			padding: 10px 24px;
		}

		.homnest-sw__landing-page__section3--content-prices {
			gap: 15px;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item .prices-item-content {
			padding: 20px 15px;
			gap: 12px;
			border-radius: 10px;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item .prices-item-content h3 {
			font-size: 22px;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item .prices-item-content h4 {
			font-size: 24px;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item ul {
			gap: 10px;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item ul li {
			font-size: 13px;
			line-height: 140%;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item ul li::before {
			width: 20px;
			height: 20px;
			margin-right: 6px;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item .prices-item-content .btn-price-card {
			font-size: 14px;
			padding: 8px 20px;
		}
	}

	/* Extra Small Mobile (max 374px) */
	@media (max-width: 374px) {
		.homnest-sw__landing-page__section3--content {
			padding: 25px 15px;
		}

		.homnest-sw__landing-page__section3--content-title h2 {
			font-size: 22px;
		}

		.homnest-sw__landing-page__section3--content-title p {
			font-size: 13px;
		}

		.homnest-sw__landing-page__section3--btn-contact {
			font-size: 14px;
			padding: 8px 20px;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item .prices-item-content {
			padding: 15px 12px;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item .prices-item-content h3 {
			font-size: 20px;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item .prices-item-content h4 {
			font-size: 22px;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item ul li {
			font-size: 12px;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item .prices-item-content .btn-price-card {
			font-size: 13px;
			padding: 6px 16px;
		}
	}

	/* Landscape Mobile Orientation */
	@media (max-height: 500px) and (orientation: landscape) {
		.homnest-sw__landing-page__section3-wrapper {
			height: auto;
			min-height: 400px;
		}

		.homnest-sw__landing-page__section3--content {
			flex-direction: row;
			padding: 30px 40px;
		}

		.homnest-sw__landing-page__section3--content-title {
			flex: 1;
		}

		.homnest-sw__landing-page__section3--content-prices {
			flex: 1.2;
			flex-direction: row;
			gap: 15px;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item .prices-item-content {
			padding: 15px 12px;
			gap: 8px;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item ul {
			gap: 6px;
		}

		.homnest-sw__landing-page__section3--content-prices .prices-item ul li {
			font-size: 12px;
		}
	}		


	/************************************** SECTION 4 ********************************************/
	.homnest-sw__landing-page__section4 {
		background-color: #F0F2F4;
		width: 100%;
	}


	.homnest-sw__landing-page__section4-wrapper {
		width: 100%;
		margin: 0 auto;
		display: flex;
		justify-content: flex-start;
		flex-wrap: wrap;
		gap: 1rem;
		padding: 90px 160px;
	}

	.homnest-sw__landing-page__section4-title{
		width: 100%;
	}


	.homnest-sw__landing-page__section4-title h2{
		font-size: 48px;
		font-weight: 800;
		line-height: 150%;
	}


	/* Section 9 */
	.section9 {

		background-position: right top;/* Hình 2 */
		margin-top: 100px;
		width: 100%;
		height: auto;
		padding: 50px 128px;
		background-color: #F0F2F4;

	}

	.section9__reason-content {
		margin-top: 70px;
		display: grid;
		grid-template-columns: 4fr 6fr;
		grid-template-rows: 1fr;
		grid-column-gap: 0px;
		grid-row-gap: 0px;
	}

	.section9__left {
		width: 90%;
		grid-area: 1 / 1 / 2 / 2;
	}

	.section9__left img {
		width: 100%;
	}

	.section9__right {
		grid-area: 1 / 2 / 2 / 3;
		min-width: 600px;
	}

	.section9__title {
		margin-top: 30px;
		min-width: 730px;

	}

	.section9__title h2,
	.section9__title span {
		font-size: 48px;
	}


	.swiper {
		width: 100%;
		max-width: 900px;
		margin: auto;
		overflow: hidden;
		position: relative;
	}

	.section9__card-grid {
		display: grid;
		grid-template-columns: 1fr 1fr;
		grid-gap: 20px;
		height: 100%;
		overflow: hidden;

	}

	.section9__card {
		border: 3px solid #ffffff;
		border-radius: 12px;
		padding: 20px;
		box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
		height: 100%;
		overflow: hidden;
		min-height: 250px;
	}

	.section9__card h3 {
		margin-top: 20px;
		font-size: 20px;
		font-weight: 600;
	}

	.section9__card p {
		margin-top: 20px;
		color: #444;
		font-size: 16px;
		line-height: 1.5;
	}



	.section9__icon-card {
		display: flex;
		align-items: flex-start;

	}

	.section9__icon-card svg {
		background-color: #D9ebfe;
		padding: 10px;
		width: 70px;
		height: 70px;
		border-radius: 13px;
		color: #47dcf7;
	}
	.section9__icon-card img {
		background-color: #D9ebfe;
		padding: 10px;
		width: 70px;
		height: 70px;
		border-radius: 13px;
		color: #47dcf7;
	}




	.section9__card-title h3,
	.section9__card-title span {
		margin-top: 20px;
		font-size: 1.5rem;
		text-align: left;
	}

	.section9__card-title p {
		margin-top: 20px;
		font-size: 1rem;
		text-align: left;
		line-height: 1.7;
	}

	.section9__project {
		text-align: center;
		margin-top: 90px;

	}

	.section9__project p {
		font-size: 1.2rem;
		margin-top: 20px;
		line-height: 1.8em;
		padding: 0 120px;
	}

	.section9__project p>span {
		font-size: 1.2rem;
		margin-top: 20px;
		line-height: 1.8em;

	}

	.swiper-button-next::after,
	.swiper-button-prev::after {
		/* display: none; */
	}

	.swiper-button-next,
	.swiper-button-prev {
		position: absolute;
		/* right: 0; */
		/* Sát bên phải */
		transform: none;
		/* left: auto; */
		width: 20px;     /* chiều rộng */
		height: 20px;    /* chiều cao */
		background-size: 10px 10px; /* điều chỉnh kích thước icon bên trong */

	}

	.swiper-button-prev {
		/* top: 10px; */
		/* Cách trên một chút */
	}

	.swiper-button-next {
		/* bottom: 10px; */
		/* Cách dưới một chút */
	}

	.swiper-button-next svg,
	.swiper-button-prev svg {

		fill: #555;
		/* màu của mũi tên */
		transition: fill 0.3s;
		width: 50px;
		height: 50px;

	}

	.swiper-button-next:hover svg,
	.swiper-button-prev:hover svg {
		fill: #000;
		/* màu khi hover */
	}

	.toggle-btn-du-an {
		display: inline;
		background: none;
		border: none;
		color: blue; /* Màu xanh giống trong ảnh */
		text-decoration: none;
		font-size: 1em;
		cursor: pointer;
		padding: 0;
		font-family: inherit;
	}

	.toggle-btn-du-an:hover {
		text-decoration: underline;
		background: none;
		border: none;
	}

	/* Section 9 Responsive Styles */

	/* Base styles (keep your existing styles) */
	.section9 {
		margin-top: 100px;
		width: 100%;
		height: auto;
		padding: 50px 128px;
		background-color: #F0F2F4;
	}
	.section9__reason-content {
		margin-top: 70px;
		display: grid;
		grid-template-columns: 4fr 6fr;
		grid-template-rows: 1fr;
		grid-column-gap: 0px;
		grid-row-gap: 0px;
	}
	.section9__left {
		width: 90%;
		grid-area: 1 / 1 / 2 / 2;
	}
	.section9__left img {
		width: 100%;
	}
	.section9__right {
		grid-area: 1 / 2 / 2 / 3;
		min-width: 600px;
	}
	.section9__title {
		margin-top: 30px;
		min-width: 730px;
	}
	.section9__title h2,
	.section9__title span {
		font-size: 48px;
		font-weight: 800;
		line-height: 150%;
	}
	.swiper {
		width: 100%;
		max-width: 900px;
		margin: auto;
		overflow: hidden;
		position: relative;
	}
	.section9__card-grid {
		display: grid;
		grid-template-columns: 1fr 1fr;
		grid-gap: 20px;
		height: 100%;
		overflow: hidden;
	}
	.section9__card {
		border: 1px solid #ffffff;
		border-radius: 12px;
		padding: 20px;
		box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
		height: 100%;
		overflow: hidden;
		min-height: 250px;
	}
	.section9__card h3 {
		margin-top: 20px;
		font-size: 22px;
		font-weight: 600;
	}
	.section9__card p {
		margin-top: 20px;
		color: #444;
		font-size: 16px;
		line-height: 1.5;
	}
	.section9__icon-card {
		display: flex;
		align-items: flex-start;
	}
	.section9__icon-card svg {
		background-color: #D9ebfe;
		padding: 10px;
		width: 70px;
		height: 70px;
		border-radius: 20px;
		color: #47dcf7;
	}
	.section9__icon-card img {
		background-color: #D9ebfe;
		padding: 10px;
		width: 70px;
		height: 70px;
		border-radius: 13px;
		color: #47dcf7;
	}
	.section9__card-title h3,
	.section9__card-title span {
		margin-top: 20px;
		font-size: 1.5rem;
		text-align: left;
	}
	.section9__card-title p {
		margin-top: 20px;
		font-size: 1rem;
		text-align: left;
		line-height: 1.7;
	}
	.section9__project {
		text-align: center;
		margin-top: 90px;
	}
	.section9__project p {
		font-size: 1.2rem;
		margin-top: 20px;
		line-height: 1.8em;
		padding: 0 120px;
	}
	.section9__project p>span {
		font-size: 1.2rem;
		margin-top: 20px;
		line-height: 1.8em;
	}
	.swiper-button-next,
	.swiper-button-prev {
		position: absolute;
		width: 20px;
		height: 20px;
		background-size: 10px 10px;
	}
	.swiper-button-next svg,
	.swiper-button-prev svg {
		fill: #555;
		transition: fill 0.3s;
		width: 50px;
		height: 50px;
	}
	.swiper-button-next:hover svg,
	.swiper-button-prev:hover svg {
		fill: #000;
	}

	.section9__card p{
		font-size: 1.2rem;
	}
	/* Responsive Styles */

	/* Large devices (desktops, less than 1400px) */
	@media (max-width: 1399.98px) {
		.section9 {
			padding: 50px 80px;
		}

		.section9__title {
			min-width: auto;
			max-width: 100%;
		}

		.section9__title h2,
		.section9__title span {
			font-size: 36px;
		}

		.section9__project p {
			padding: 0 80px;
		}

		.section9__right {
			min-width: 500px;
		}
		.section9__card p{
			font-size: 1.1rem;
		}
	}

	/* Medium devices (tablets, less than 1200px) */
	@media (max-width: 1199.98px) {
		.section9 {
			padding: 40px 60px;
		}

		.section9__reason-content {
			grid-template-columns: 1fr;
			grid-row-gap: 40px;
		}

		.section9__left {
			width: 70%;
			margin: 0 auto;
			grid-area: 1 / 1 / 2 / 2;
		}

		.section9__right {
			grid-area: 2 / 1 / 3 / 2;
			min-width: auto;
			width: 100%;
			overflow: hidden;
		}

		.section9__title h2,
		.section9__title span {
			font-size: 32px;
		}

		.section9__project p {
			padding: 0 60px;
		}
		.section9__card p{
			font-size: 1.1rem;
		}
	}

	/* Small devices (landscape phones, less than 992px) */
	@media (max-width: 991.98px) {
		.section9 {
			padding: 40px 40px;
			margin-top: 70px;
		}

		.section9__reason-content {
			margin-top: 50px;
		}

		.section9__left {
			width: 80%;
		}

		.section9__title h2,
		.section9__title span {
			font-size: 28px;
		}

		.section9__card h3 {
			font-size: 1.2rem;
		}

		.section9__project {
			margin-top: auto;
		}

		.section9__project p {
			padding: 0 30px;
			font-size: 1.1rem;
		}

		.section9__project p>span {
			font-size: 1.1rem;
		}
		.section9__card p{
			font-size: 1.1rem;
		}
	}

	/* Extra small devices (portrait phones, less than 768px) */
	@media (max-width: 767.98px) {
		.section9 {
			padding: 30px 20px;
			margin-top: 50px;
			overflow: hidden;
		}

		.section9__reason-content {
			margin-top: 40px;
		}

		.section9__left {
			width: 100%;
		}

		.section9__title {
			min-width: unset;
			width: 100%;
			padding: 0 10px;
			box-sizing: border-box;
		}

		.section9__title h2,
		.section9__title span {
			font-size: 35px;
			line-height: 1.3;
		}

		.section9__card-grid {
			grid-template-columns: 1fr;
			width: 100%;
		}

		.section9__card {
			min-height: auto;
			margin-bottom: 10px;
		}

		.section9__icon-card img,
		.section9__icon-card svg {
			width: 60px;
			height: 60px;
		}

		.section9__project {
			margin-top: auto;
		}

		.section9__card h3{
			font-size: 1.2rem;
		}

		.section9__project p {
			padding: 0 15px;
			font-size: 1rem;
		}
		.section9__project h2{
			font-size: 40px;
		}

		.section9__project p>span {
			font-size: 1rem;
			display: none;
		}

		/* Swiper adjustment for mobile to show cards vertically */
		.swiper {
			width: 100%;
			padding: 0;
			margin: 0;
			overflow: visible;
		}
	}

	/* Very small devices (small phones, less than 576px) */
	@media (max-width: 575.98px) {
		.section9 {
			padding: 25px 15px;
			margin-top: 40px;
		}

		.section9__reason-content {
			margin-top: 30px;
		}
		.section9__project h2{
			font-size: 40px;
		}

		.section9__title h2,
		.section9__title span {
			font-size: 26px;
		}

		.section9__card {
			padding: 15px;
			min-height: 240px;
		}
		.section9__card p{
			font-size: 1.1rem;
		}

		.section9__card h3 {
			font-size: 1.2rem;
			margin-top: 15px;
		}

		.section9__card p {
			margin-top: 15px;
			font-size: 14px;
		}

		.section9__icon-card img,
		.section9__icon-card svg {
			width: 50px;
			height: 50px;
			padding: 8px;
		}

		.section9__project {
			margin-top: 50px;
		}

		.section9__project p {
			line-height: 1.6em;
		}

		/* Navigation buttons for mobile */
		.swiper-button-next,
		.swiper-button-prev {
			top: auto;
			bottom: -40px;
			transform: scale(0.8);
		}

		.swiper-button-next {
			right: 20px;
		}

		.swiper-button-prev {
			left: 20px;
		}
	}

	/* Fix for toggle button on mobile */
	/* .toggle-btn-du-an {
	display: inline-block;
	margin-top: 15px;
	padding: 8px 20px;
	background-color: #0072CE;
	color: white;
	border: none;
	border-radius: 5px;
	cursor: pointer;
	font-size: 16px;
	transition: background-color 0.3s;
	} */



	@media (max-width: 767.98px) {
		.toggle-btn-du-an {
			display: block !important;
			margin: 15px auto 0;
		}

		.section9__project p>span {
			display: none;
		}

		.section9__project p>span.show {
			display: inline;
		}
		.section9__card p{
			font-size: 1.1rem;

		}
		.section9__project h2{
			font-size: 40px;
		}

	}

	/* Add specific fixes for Swiper in mobile view */
	@media (max-width: 767.98px) {
		.swiper {
			padding-bottom: 40px;
		}

		.swiper-button-next::after,
		.swiper-button-prev::after {
			font-size: 20px;
		}
		.section9__card p{
			font-size: 1.1rem;
		}
		.section9__project h2 span{
			font-size: 30px;
		}

	}
	/* End section 9 */

	/* Section 10 */
	.section10 {
		background-color: #F0F2F4;
	}

	:root {
		--gap: -70px;
	}

	.section10__slider {
		width: 100%;
		height: var(--height);
		overflow: hidden;
	}

	.section10__slider .section10__list {
		display: flex;
		width: 100%;
		min-width: calc(var(--width) * var(--quantity) + var(--gap) * (var(--quantity) - 1));
		position: relative;
		margin-top: 20px;
	}

	.section10__slider .section10__list .section10__item {
		width: var(--width);
		height: calc(var(--height) - 20px);
		position: absolute;
		left: 100%;
		animation: autoRun 200s linear infinite;
		transition: filter 0.5s;
		animation-delay: calc((200s / var(--quantity)) * (var(--position) - 1) - 200s) !important;
		border-radius: 5px;
		display: grid;
		grid-template-columns: repeat(3, 1fr);
		grid-template-rows: repeat(2, 1fr);
		gap: 10px;
		overflow: hidden;
		margin-right: var(--gap);
	}

	.section10__slider .section10__list .section10__item div {
		overflow: hidden;
	}

	.section10__slider .section10__list .section10__item img {
		width: 100%;
		height: 100%;
		object-fit: cover;
		display: block;
		border-radius: 5px;
	}

	@keyframes autoRun {
		from {
			left: calc(100% + var(--gap));
		}

		to {
			left: calc(var(--width) * -1 - var(--gap));
		}
	}

	.section10__div1,
	.section10__div2,
	.section10__div4,
	.section10__div5 {
		border-radius: 5px;
	}

	.section10__div1 {
		grid-column: span 2 / span 2;
	}

	.section10__div2 {
		grid-column-start: 3;
	}

	.section10__div4 {
		grid-row-start: 2;
	}

	.section10__div5 {
		grid-column: span 2 / span 2;
		grid-row-start: 2;
	}

	.section10__div1 img,
	.section10__div2 img,
	.section10__div4 img,
	.section10__div5 img {
		transition: transform 0.3s ease;
	}

	.section10__div1:hover img,
	.section10__div2:hover img,
	.section10__div4:hover img,
	.section10__div5:hover img {
		transform: scale(1.05);
	}

	.section10__item>a {
		text-decoration: none;
		display: contents;
	}

	.section10__btn {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		background-color: #F0F2F4;
		color: white;
		border: none;
		cursor: pointer;
		border-radius: 8px;
		font-weight: bold;
	}

	.section10__btn a {
		text-decoration: none;
		font-size: 1.5rem;
		padding-top: 20px;
		padding-bottom: 10px;
	}

	.arrow-container {
		margin-bottom: 40px;
		width: 40px;
		height: 40px;
		border: 1px solid #333;
		border-radius: 50%;
		display: flex;
		justify-content: center;
		align-items: center;
		position: relative;
		/* overflow: hidden; */
	}

	/* Mũi tên */
	.arrow {
		/* Điều chỉnh kích thước */
		width: 30px;
		height: 30px;
		color: #333;
		position: absolute;
		top: 20%;
		animation: drop 2s ease-in infinite;
	}
	.arrow img{

		height:100%;
		width:100%;
	}

	/* Keyframes cho hiệu ứng rơi + mờ */
	@keyframes drop {
		0% {
			top: 15%;
			opacity: 1;
			transform: scale(1);
		}

		70% {
			opacity: 0.6;
			transform: scale(1);
		}

		100% {
			top: 150%;
			opacity: 0;
			transform: scale(1);
		}

	}

	/* End section10 */

	/* Section 11 */

	.section11 {
		background-image:url('https://homenest.com.vn/wp-content/uploads/2024/11/Group-1203-1.png'),url('https://homenest.com.vn/wp-content/uploads/2024/11/Group-1219.png');
		background-repeat: no-repeat, no-repeat, no-repeat;
		background-position:-150px top, right center;
		padding: 170px 200px;
		width: 100%;
		height: 100%;

	}

	.section11 h2,
	.section11 h2 span {
		text-align: center;
		justify-content: center;
		align-items: center;
		font-size: 48px;
	}

	.section11__content {
		margin-top: 50px;
		margin-bottom: 50px;
	}

	.section11__question {
		cursor: pointer;
		display: flex;
		justify-content: space-between;
	}

	.section11__question-num,
	.section11__question-text,
	.section11__question-icon {
		font-size: 1.8rem;
	}

	.section11__question-num {
		width: 20%;
		font-weight: 600;
	}

	.section11__question-text {
		flex: 1;
		font-size: 1.8rem;
	}

	.section11__question-icon {
		width: 1%;
		text-align: right;
	}

	.sectio11__answer {
		display: none;
		margin-top: 50px;
		padding-left: 20%;
		padding-right: 10%;
		opacity: 0;
		max-height: 0;
		transition: opacity 0.5s ease, max-height 0.5s ease;
		/* Hiệu ứng chuyển dần */

	}

	.sectio11__answer p {
		font-size: 20px;
		line-height: 1.8;
		font-weight: 200;
	}

	.section11__question-icon {
		transition: transform 0.5s ease;
		/* Thêm chuyển động mượt mà khi xoay */
	}

	.section11__question-icon.rotated {
		transform: rotate(120deg);
	}

	/* Media Queries */
	@media (max-width: 992px) {
		.section11 {
			padding: 50px 4%;
		}
	}

	@media (max-width: 768px) {
		.section11__question-num {
			width: 15%;
		}

		.sectio11__answer {
			padding-left: 15%;
		}
		.section11 h2 span{
			font-size: 1.8rem;
		}

	}

	@media (max-width: 576px) {
		.section11 {
			padding: 40px 3%;
		}

		.section11__question {
			/*         padding: 8px 0; */
		}

		.section11__question-num {
			width: 10%;
			font-size: clamp(1.1rem, 4vw, 1.4rem);
		}

		.section11__question-text {
			width: 80%;
			font-size: clamp(1.1rem, 4vw, 1.4rem);
		}

		.section11__question-icon {
			width: 10%;
			font-size: clamp(1.1rem, 4vw, 1.4rem);
		}

		.sectio11__answer {
			padding-left: 10%;
			padding-right: 0;
		}

		.sectio11__answer p {
			font-size: clamp(14px, 4vw, 16px);
		}
		.section11 h2 span{
			font-size: 1.8rem;
		}
	}

	@media (max-width: 375px) {
		.section11 {
			padding: 30px 2%;
		}

		.section11__content {
			/*         margin: 20px 0; */
		}
		.section11 h2 span{
			font-size: 1.8rem;
		}
	}

	/*End section 11 */


	/*Section 8 */
	.section8 {
		margin-top: 100px;
		background-image: url('https://homenest.com.vn/wp-content/uploads/2024/11/Group-1203-1.png'), url('https://homenest.com.vn/wp-content/uploads/2024/11/Frame.png'), url('https://homenest.com.vn/wp-content/uploads/2024/11/Group-1219.png');
		background-repeat: no-repeat, no-repeat, no-repeat;
		background-position:
			right top,
			/* Hình 1 */
			right top,
			/* Hình 2 */
			right center;
		padding: 0 128px;
		display: grid;
		grid-template-columns: 4fr 6fr;
		grid-template-rows: 1fr;
		grid-column-gap: 30px;
		grid-row-gap: 0px;
		position: relative;

	}

	.section8__left {
		grid-area: 1 / 1 / 2 / 2;
		width: 100%;
		position: sticky; /* Make it sticky */
		top: 50px; /* Distance from top when sticky */
		align-self: flex-start; /* Important for sticky behavior */
		height: fit-content; /* Ensure it only takes the height it needs */
		gap: 50px;
	}

	.section8__left img {
		width: 100%;
		height: auto;
		border-radius: 10px;
	}

	.section8__left img:nth-of-type(2) {
		margin-top: 20px;
		width: 100%;
		height: 246px;
		object-fit: cover;
		border-radius: 10px;
	}

	.section8__right {

		grid-area: 1 / 2 / 2 / 3;
		padding-bottom: 50px;
	}

	.section8__brain-title {
		position: relative;
		margin-top: 50px;
	}

	.section8__brain-title__text {
		font-size: 8rem;
		font-weight: bold;
		text-transform: uppercase;
		color: white;
		/* Màu nền trắng giống background */
		letter-spacing: 3px;
		position: relative;
		font-family: Arial, sans-serif;
	}

	.section8__brain-title__text::before {
		content: 'HOMENEST';
		position: absolute;
		left: 0;
		top: 0;
		width: 100%;
		height: 100%;
		background: linear-gradient(92.16deg, #2F3FCF 0%, #1A85F8 56.7%, #66E5FB 100%);
		/* Gradient từ xanh đậm sang xanh nhạt */
		-webkit-background-clip: text;
		background-clip: text;
		color: transparent;
		-webkit-text-stroke: 2px;
		z-index: -1;
	}

	.section8__wrap-title {
		position: relative;
		width: 100%;
	}

	.section8__main-title {
		margin-top: 35px;
		color: #616060;
	}

	.section8__main-title h2, .section8__main-title span{
		font-size: 48px;
		font-weight: 800;
	}



	.section8__sub-title {
		position: absolute;
		top: -5px;
		right: 220px;
		font-size: 22px;
		font-weight: bold;
		color: #000;
		z-index: 2;
	}

	.section8__content {
		display: flex;
		flex-direction: column;
	}

	.step {
		display: flex;
		align-items: flex-start;
		margin-top: 50px;
	}


	.content-step {
		margin-left: 1rem;
		width: 50%;
	}

	.content-step h4 {
		font-size: 24px;
	}

	.content-step p {
		font-size: 20px;
		margin-top: 0.5rem;
		line-height: 150%;
	}

	.content-step--mgleft {
		padding-left: 30%;
	}
	.step-icon{
		display: flex;
		align-items: center;
		justify-content: center;
	}

	.step-icon span{
		font-size: 150px;
		font-weight: 800;
		line-height: 1;
		color: transparent;
		-webkit-text-stroke-width: 1px;
		-webkit-text-stroke-color: #47dcf7;
	}
	@media (min-width: 1025px) and (max-width:1440px) {
		.section8__brain-title__text {
			font-size: 50px;
		}

		.section8__main-title h2, .section8__main-title span{
			font-size: 28px;
		}

		.step-icon span {
			font-size: 100px;
		}
		.content-step p{
			font-size: 16px;
		}

		.content-step {
			margin-left: 1rem;
			width: 70%;	
		}

		.section8 {
			padding: 0 50px;
		}
		.content-step h4 {
			font-size: 20px;
		}
	}

	/* Responsive cho màn hình nhỏ hơn 1024px (tablet) */
	@media (max-width: 1024px) {


		.section8 {
			padding: 0 50px;
			grid-template-columns: 1fr;
			/* Chuyển sang bố cục 1 cột */
			grid-template-rows: auto auto;
			/* Tự động điều chỉnh hàng */
		}

		.section8__left {
			position: static;
			grid-area: 1 / 1 / 2 / 2;
			width: 100%;
			/* Hình ảnh chiếm toàn bộ chiều rộng */
			margin-bottom: 20px;
		}

		.section8__right {
			grid-area: 2 / 1 / 3 / 2;
		}

		.section8__brain-title__text {
			font-size: 5rem;
			/* Giảm kích thước chữ */
		}

		.section8__main-title h2,
		.section8__main-title span {
			font-size: 35px;
			/* Giảm kích thước chữ */
		}

		.section8__sub-title {
			right: 150px;
			/* Điều chỉnh vị trí sub-title */
			font-size: 18px;
		}

		.content-step--mgleft {
			/*         margin-left: 20%; */
			/* Giảm margin cho các bước */
		}


	}

	/* Responsive cho màn hình nhỏ hơn 768px (mobile) */
	@media (max-width: 768px) {
		.section8 {
			padding: 0 20px;
			background-size: 50%, 50%, 50%;
			/* Giảm kích thước background */
			background-position: center top;
		}
		.section8__left {
			position: static;
			top: auto;
		}


		.section8__left img {
			border-radius: 5px;
			/* Giảm border-radius cho phù hợp */
		}

		.section8__brain-title__text::before {
			-webkit-text-stroke: 1px;
			/* Giảm độ dày stroke */
		}

		.section8__brain-title__text {
			font-size: 3.5rem;
		}

		.section8__main-title h2,
		.section8__main-title span {
			font-size: 1.9rem;
		}

		.section8__sub-title {
			right: 20px;
			font-size: 14px;
		}

		.step {
			/* flex-direction: column;  */
			align-items: center;
			margin-top: 30px;
		}

		.step-icon {
			margin-top: 25px;
			flex-shrink: 0;

		}

		.step-iconlist span {
			font-size: 50px;

		}




		.content-step {
			margin-left: 20px;
			/* Xóa margin-left */
			width: 100%;

		}

		.content-step--mgleft {
			padding-left: 0;
			/* Xóa margin-left */
		}

		.content-step h4 {
			font-size: 1.2rem;
		}

		.content-step p {
			font-size: 1rem;
		}
		.step-icon span {
			font-size: 50px;
		}
	}

	/* Responsive cho màn hình rất nhỏ (dưới 480px) */
	@media (max-width: 480px) {
		.section8 {
			padding: 0 10px;
			background-position: center right;
		}

		.section8__brain-title__text {
			font-size: 3.5rem;
		}

		.section8__main-title h2,
		.section8__main-title span {
			font-size: 1.9rem;
		}

		.section8__sub-title {
			right: 20px;
			font-size: 14px;
		}

		.step-icon span {
			font-size:50;
			/* Giảm kích thước SVG hơn nữa */
		}

		.content-step h4 {
			font-size: 1.2rem;
		}

		.content-step p {
			font-size: 1rem;

		}

		.step {
			display: flex;
			align-items: flex-start;
		}

		.step-icon {
			flex-shrink: 0;
		}


	}

	/* End section 8 */
</style>
<body>

	<section class="homnest-sw__landing-page__section1">
		<div class="homnest-sw__landing-page__section1-wrapper">
			<div class="homnest-sw__landing-page__section1-content">
				<div class="homnest-sw__landing-page__section1-title">
					<h2>
						DỊCH VỤ <br />
						<span class="homenest-sw__landingpage__hl-title">
							THIẾT KẾ LANDING PAGE
						</span>
					</h2>
					<p>
						Dịch vụ thiết kế Landing Page của HomeNest tạo ra các trang đích
						hấp dẫn và tối ưu hóa chuyển đổi, giúp doanh nghiệp thu hút khách
						hàng hiệu quả. Với giao diện bắt mắt và nội dung rõ ràng, các
						landing page được tùy chỉnh theo nhu cầu cụ thể, nâng cao hiệu quả
						marketing trực tuyến.
					</p>

					<a href="">Đăng kí nhận báo giá</a>

					<div class="items">
						<div class="item item-1">
							<div class="item-num">
								<img src="http://homenest.software/wp-content/uploads/2025/06/250.webp" alt="">
							</div>
							<div class="item-text">Landing Page được cung cấp</div>
						</div>
						<div class="item item-2">
							<div class="item-num">
								<img src="http://homenest.software/wp-content/uploads/2025/06/99-2.webp" alt="">
							</div>
							<div class="item-text">Khách hàng hài lòng</div>
						</div>
					</div>
				</div>
				<div class="homnest-sw__landing-page__section1-contact">
					<img
						 src="http://homenest.software/wp-content/uploads/2025/06/Mask-group-3.webp"
						 alt=""
						 />
					<div class="section1-btn-watch-wrapper">
						<a class="section1-btn-watch" href="#">Xem video</a>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="homnest-sw__landing-page__section2">
		<div class="homnest-sw__landing-page__section2-wrapper">
			<div class="homnest-sw__landing-page__section2-title">
				<h2>
					VÌ SAO DOANH NGHIỆP <br>
					<span class="homenest-sw__landingpage__hl-title">NÊN THIẾT KẾ LANDING PAGE ?</span>
				</h2>
			</div>

			<div class="homnest-sw__landing-page__section2-content">

				<div class="boxs">
					<div class="box box1">
						<div class="box-content">
							<div class=box-content-title>
								<img class="box-img" src="http://homenest.software/wp-content/uploads/2025/06/Mask-group-3-1.webp" alt="">
								<h3 class="box-title">
									Tăng tỉ lệ chuyển đổi
								</h3>
							</div>
							<hr>
							<p class="box-desc">Landing Page được tối ưu hóa để chuyển đổi khách truy cập thành khách hàng, giúp gia tăng doanh số.</p>
						</div>
					</div>

					<div class="box box2">
						<div class="box-content">
							<div class=box-content-title>
								<img class="box-img" src="http://homenest.software/wp-content/uploads/2025/06/Mask-group-3-1.webp" alt="">
								<h3 class="box-title">
									Truyền tải thông điệp rõ ràng
								</h3>
							</div>
							<hr>
							<p class="box-desc">Landing Page cho phép bạn tập trung vào một sản phẩm hoặc dịch vụ cụ thể, giúp khách hàng dễ dàng hiểu giá trị mà bạn cung cấp.</p>
						</div>
					</div>

					<div class="box box3">
						<div class="box-content">
							<div class=box-content-title>
								<img class="box-img" src="http://homenest.software/wp-content/uploads/2025/06/Mask-group-3-1.webp" alt="">
								<h3 class="box-title">
									Tiếp cận mục tiêu rõ ràng
								</h3>
							</div>
							<hr>
							<p class="box-desc">Thiết kế Landing Page phù hợp với nhu cầu của đối tượng mục tiêu, giúp thu hút đúng khách hàng.</p>
						</div>
					</div>

					<div class="box box4">
						<div class="box-content">
							<div class=box-content-title>
								<img class="box-img" src="http://homenest.software/wp-content/uploads/2025/06/Mask-group-3-1.webp" alt="">
								<h3 class="box-title">
									Thu thập dữ liệu khách hàng
								</h3>
							</div>
							<hr>
							<p class="box-desc">Landing Page thường có biểu mẫu để thu thập thông tin từ khách hàng, tạo cơ hội xây dựng danh sách khách hàng tiềm năng.</p>
						</div>
					</div>

				</div>

				<div class="homnest-sw__landing-page__section2-content2">
					<div class="homnest-sw__landing-page__section2-content2--title">
						<h2>
							KHI NÀO DOANH NGHIỆP <br>NÊN 
							<span class="homenest-sw__landingpage__hl-title">THIẾT KẾ LANDING PAGE ?</span>
						</h2>
						<img src="http://homenest.software/wp-content/uploads/2025/06/492330aafa2151403cfbfff9a3be7d827e83ca86.webp" alt="">
					</div>

					<div class="homnest-sw__landing-page__section2-content2-grids">
						<div class="content2-grid">
							<div class="content2-grid-content">
								<h3>
									Ra mắt sản phẩm hoặc dịch vụ mới
								</h3>
								<p>
									Landing Page giúp thu hút sự chú ý và tạo ấn tượng mạnh mẽ khi giới thiệu sản phẩm/dịch vụ mới. Đây là nơi truyền tải rõ ràng thông tin về tính năng, lợi ích, giá cả, từ đó giúp khách hàng hiểu sản phẩm và dễ dàng đưa ra quyết định mua hàng.
								</p>
							</div>
						</div>

						<div class="content2-grid">
							<div class="content2-grid-content">
								<h3>
									Chạy chiến dịch quảng cáo hoặc khuyến mãi
								</h3>
								<p>
									Khi triển khai các chiến dịch marketing có thời hạn, Landing Page là công cụ lý tưởng để tập trung chuyển đổi. Nó giúp khách hàng dễ dàng tiếp cận nội dung ưu đãi và thực hiện hành động như đăng ký, mua hàng hoặc nhận mã giảm giá.
								</p>
							</div>
						</div>

						<div class="content2-grid">
							<div class="content2-grid-content">
								<h3>
									Tăng tỷ lệ chuyển đổi từ traffic có sẵn
								</h3>
								<p>
									Nếu doanh nghiệp đang có lượng truy cập từ website, mạng xã hội hay email marketing, một Landing Page tối ưu sẽ giúp chuyển đổi khách truy cập thành khách hàng tiềm năng hoặc người mua thực sự.
								</p>
							</div>
						</div>

						<div class="content2-grid">
							<div class="content2-grid-content">
								<h3>
									Thu thập thông tin khách hàng tiềm năng
								</h3>
								<p>
									Landing Page có thể tích hợp form đăng ký, tải tài liệu, nhận tư vấn… giúp doanh nghiệp thu thập dữ liệu khách hàng phục vụ cho các chiến dịch chăm sóc và bán hàng sau này.
								</p>
							</div>
						</div>

					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="homnest-sw__landing-page__section3">
		<div class="homnest-sw__landing-page__section3-wrapper">
			<div class="homnest-sw__landing-page__section3--content">
				<div class="homnest-sw__landing-page__section3--content-title">
					<h2>
						CÁC GÓI THIẾT KẾ <br>
						LANDING PAGE TẠI HOMENEST
					</h2>
					<p>
						HomeNest cung cấp hai gói thiết kế Landing Page: Gói cơ bản và Gói nâng cao. Gói cơ bản phù hợp cho các doanh nghiệp nhỏ, tập trung vào thiết kế đơn giản và hiệu quả, tối ưu hóa cho quảng cáo và thu hút khách hàng. Gói nâng cao cung cấp nhiều tính năng hơn, bao gồm tích hợp công cụ phân tích, thiết kế tùy chỉnh và tối ưu hóa SEO, giúp tăng cường trải nghiệm người dùng và hiệu quả tiếp thị.
					</p>

					<a class="homnest-sw__landing-page__section3--btn-contact" href="#">
						Tư vấn ngay: 0898 994 298
					</a>
				</div>
				<div class="homnest-sw__landing-page__section3--content-prices">
					<div class="prices-item">
						<div class="prices-item-content">
							<h3>
								BASIC
							</h3>
							<hr >
							<ul>
								<li>Đầy đủ Module Website</li>
								<li>Live chat Messenger/Zalo</li>
								<li>Đa ngôn ngữ</li>
								<li>Tương thích phiên bản mobile</li>
								<li>Bàn giao toàn bộ source code</li>
								<li>Bảo mật SSL miễn phí</li>
								<li>Cài đặt Google Analytic</li>
							</ul>

							<h4>
								5 - 10 Triệu
							</h4>

							<a class="btn-price-card" href="">Tư vấn báo giá</a>
						</div>
					</div>
					<div class="prices-item">
						<div class="prices-item-content">
							<h3>
								ADVANCE
							</h3>
							<hr >
							<ul >
								<li>Đầy đủ Module Website</li>
								<li>Live chat Messenger/Zalo</li>
								<li>Đa ngôn ngữ</li>
								<li>Tương thích phiên bản mobile</li>
								<li>Bàn giao toàn bộ source code</li>
								<li>Bảo mật SSL miễn phí</li>
								<li>Cài đặt Google Analytic</li>
							</ul>

							<h4>
								5 - 10 Triệu
							</h4>

							<a class="btn-price-card" href="">Tư vấn báo giá</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<!-- Section9 -->
	<section class="section9">
		<div class="section9__title">
			<h2>8 LÝ DO NÊN CHỌN <br><span class="homenest-sw__landingpage__hl-title">HOMENEST THIẾT KẾ WEBSITE CHUYÊN NGHIỆP</span></h2>
		</div>
		<div class="section9__reason-content">
			<div class="section9__left">
				<img src="http://h2.homenest.tech/wp-content/uploads/2025/06/Animation-1749543914697.gif" alt="">
			</div>
			<div class="section9__right">
				<div class="swiper mySwiper">
					<div class="swiper-wrapper">

						<!-- Slide 1 -->
						<div class="swiper-slide">
							<div class="section9__card-grid">
								<div class="section9__card">
									<div class="section9__icon-card">
										<img src="http://homenest.software/wp-content/uploads/2025/06/Mask-group-4.webp" alt="Icon">
									</div>
									<h3>1. Khả năng mở rộng cao</h3>
									<p><a class="highlight-text" href="">WordPress</a> phù hợp với cả các website nhỏ lẫn lớn, và có khả năng mở rộng dễ dàng khi HomeNest phát triển thêm nhiều tính năng hoặc dịch vụ.</p>
								</div>
								<div class="section9__card">
									<div class="section9__icon-card">
										<img src="http://homenest.software/wp-content/uploads/2025/06/Mask-group-4.webp" alt="Icon">
									</div>
									<h3>2. Giao diện chuyên nghiệp</h3>
									<p>HomeNest thiết kế giao diện hiện đại, chuẩn UX/UI, phù hợp mọi ngành nghề.</p>
								</div>
								<div class="section9__card">
									<div class="section9__icon-card">
										<img src="http://homenest.software/wp-content/uploads/2025/06/Mask-group-4.webp" alt="Icon">
									</div>
									<h3>3. Tối ưu tốc độ tải trang</h3>
									<p>Website được tối ưu hoá để tải nhanh, cải thiện trải nghiệm người dùng.</p>
								</div>
								<div class="section9__card">
									<div class="section9__icon-card">
										<img src="http://homenest.software/wp-content/uploads/2025/06/Mask-group-4.webp" alt="Icon">
									</div>
									<h3>4. Chuẩn SEO từ đầu</h3>
									<p>Code sạch, cấu trúc chuẩn SEO giúp website dễ dàng lên top Google.</p>
								</div>
							</div>
						</div>

						<!-- Slide 2 -->
						<div class="swiper-slide">
							<div class="section9__card-grid">
								<div class="section9__card">
									<div class="section9__icon-card">
										<img src="http://homenest.software/wp-content/uploads/2025/06/Mask-group-4.webp" alt="Icon">
									</div>
									<h3>5. Dễ dàng quản trị nội dung</h3>
									<p>Giao diện quản trị thân thiện, không cần biết lập trình vẫn sử dụng tốt.</p>
								</div>
								<div class="section9__card">
									<div class="section9__icon-card">
										<img src="http://homenest.software/wp-content/uploads/2025/06/Mask-group-4.webp" alt="Icon">
									</div>
									<h3>6. Bảo mật cao</h3>
									<p>Website được cập nhật và bảo vệ thường xuyên khỏi các rủi ro bảo mật.</p>
								</div>
								<div class="section9__card">
									<div class="section9__icon-card">
										<img src="http://homenest.software/wp-content/uploads/2025/06/Mask-group-4.webp" alt="Icon">
									</div>
									<h3>7. Hỗ trợ kỹ thuật 24/7</h3>
									<p>HomeNest luôn sẵn sàng hỗ trợ bạn bất kỳ lúc nào khi có sự cố.</p>
								</div>
								<div class="section9__card">
									<div class="section9__icon-card">
										<img src="http://homenest.software/wp-content/uploads/2025/06/Mask-group-4.webp" alt="Icon">
									</div>
									<h3>8. Tích hợp nhiều tính năng hiện đại</h3>
									<p>Chatbot, thanh toán online, đặt lịch... được tích hợp dễ dàng theo yêu cầu.</p>
								</div>
							</div>
						</div>
					</div>
					<!-- Navigation buttons -->

					<div class="swiper-btn-next custom-nav">
						<!--             <svg aria-hidden="true" class="e-font-icon-svg e-fas-arrow-circle-right" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="M256 8c137 0 248 111 248 248S393 504 256 504 8 393 8 256 119 8 256 8zm-28.9 143.6l75.5 72.4H120c-13.3 0-24 10.7-24 24v16c0 13.3 10.7 24 24 24h182.6l-75.5 72.4c-9.7 9.3-9.9 24.8-.4 34.3l11 10.9c9.4 9.4 24.6 9.4 33.9 0L404.3 273c9.4-9.4 9.4-24.6 0-33.9L271.6 106.3c-9.4-9.4-24.6-9.4-33.9 0l-11 10.9c-9.5 9.6-9.3 25.1.4 34.4z"></path></svg> -->
					</div>
					<div class="swiper-btn-prev custom-nav">
						<!--             <svg aria-hidden="true" class="e-font-icon-svg e-fas-arrow-circle-left" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="M256 504C119 504 8 393 8 256S119 8 256 8s248 111 248 248-111 248-248 248zm28.9-143.6L209.4 288H392c13.3 0 24-10.7 24-24v-16c0-13.3-10.7-24-24-24H209.4l75.5-72.4c9.7-9.3 9.9-24.8.4-34.3l-11-10.9c-9.4-9.4-24.6-9.4-33.9 0L107.7 239c-9.4 9.4-9.4 24.6 0 33.9l132.7 132.7c9.4 9.4 24.6 9.4 33.9 0l11-10.9c9.5-9.5 9.3-25-.4-34.3z"></path></svg> -->
					</div>
				</div>
			</div>
		</div>

		<div class="section9__project section9__title" >
			<h2><span class="homenest-sw__landingpage__hl-title">DỰ ÁN TIÊU BIỂU</span></h2>

		</div>


		</div>
	<!-- section 10 -->
	</section>


<?php
// Lấy danh sách dự án từ CPT "project"
$args = array(
	'post_type' => 'case_study',
	'posts_per_page' => 10 // Lấy 10 dự án để hiển thị
);

$query = new WP_Query($args);
$projects = [];

// Lấy thông tin hình ảnh và liên kết
if ($query->have_posts()) {
	while ($query->have_posts()) {
		$query->the_post();
		$projects[] = [
			'image' => get_the_post_thumbnail_url(get_the_ID(), 'full'),
			'link'  => get_permalink(get_the_ID()),
			'title' => get_the_title()
		];
	}
	wp_reset_postdata();
}

// Đảm bảo chúng ta có đủ 10 vị trí, nếu không đủ sẽ lặp lại các dự án đã có
$total_projects = count($projects);
if ($total_projects > 0 && $total_projects < 10) {
	$original_projects = $projects;
	for ($i = $total_projects; $i < 10; $i++) {
		$projects[] = $original_projects[$i % $total_projects];
	}
}
?>

<div class="section10">
	<div class="section10__slider" style="--width: 800px; --height: 490px; --quantity: 9;">
		<div class="section10__list">
			<?php
			// Kiểm tra nếu có dự án
			if (!empty($projects)) {
				// Hiển thị 10 vị trí
				for ($i = 0; $i < 10; $i++) {
					$position = $i + 1;
					// Lấy 4 hình ảnh cho mỗi vị trí (có thể lặp lại nếu không đủ)
					$img1 = !empty($projects[$i % $total_projects]['image']) ? $projects[$i % $total_projects]['image'] : get_stylesheet_directory_uri() . "/assets/placeholder.png";
					$link1 = $projects[$i % $total_projects]['link'];

					$img2 = !empty($projects[($i + 1) % $total_projects]['image']) ? $projects[($i + 1) % $total_projects]['image'] : get_stylesheet_directory_uri() . "/assets/placeholder.png";
					$link2 = $projects[($i + 1) % $total_projects]['link'];

					$img3 = !empty($projects[($i + 2) % $total_projects]['image']) ? $projects[($i + 2) % $total_projects]['image'] : get_stylesheet_directory_uri() . "/assets/placeholder.png";
					$link3 = $projects[($i + 2) % $total_projects]['link'];

					$img4 = !empty($projects[($i + 3) % $total_projects]['image']) ? $projects[($i + 3) % $total_projects]['image'] : get_stylesheet_directory_uri() . "/assets/placeholder.png";
					$link4 = $projects[($i + 3) % $total_projects]['link'];
			?>
			<!-- Position <?php echo $position; ?> -->
			<div class="section10__item" style="--position: <?php echo $position; ?>">
				<a href="<?php echo esc_url($link1); ?>"><div class="section10__div1"><img src="<?php echo esc_url($img1); ?>" alt="<?php echo esc_attr($projects[$i % $total_projects]['title']); ?>"></div></a>
				<a href="<?php echo esc_url($link2); ?>"><div class="section10__div2"><img src="<?php echo esc_url($img2); ?>" alt="<?php echo esc_attr($projects[($i + 1) % $total_projects]['title']); ?>"></div></a>
				<a href="<?php echo esc_url($link3); ?>"><div class="section10__div4"><img src="<?php echo esc_url($img3); ?>" alt="<?php echo esc_attr($projects[($i + 2) % $total_projects]['title']); ?>"></div></a>
				<a href="<?php echo esc_url($link4); ?>"><div class="section10__div5"><img src="<?php echo esc_url($img4); ?>" alt="<?php echo esc_attr($projects[($i + 3) % $total_projects]['title']); ?>"></div></a>
			</div>
			<?php
				}
			} else {
				// Nếu không tìm thấy dự án, hiển thị thông báo
				echo '<p>Không có dự án nào để hiển thị.</p>';
			}
			?>
		</div>
	</div>
	<div class="section10__btn">
		<a href="<?php echo esc_url(get_post_type_archive_link('project')); ?>" class="homenest-sw__landingpage__hl-title"><span class="homenest-sw__landingpage__hl-title">Xem tất cả</span></a>
		<div class="arrow-container">
			<div class="arrow"><img src="http://h2.homenest.tech/wp-content/uploads/2025/06/right-arrow.webp"/></div>
		</div>
	</div>
	</section>
<!-- Section 8 -->
<section class="section8">
	<div class="section8__left">
		<img src="http://homenest.software/wp-content/uploads/2025/06/Mask-group-1-1.webp" alt="">

	</div>
	<div class="section8__right">
		<div class="section8__wrap-title">
			<div class="section8__sub-title">
				<span>Website</span>
			</div>
			<div class="section8__brain-title">
				<h1 class="section8__brain-title__text">HOMENEST</h1>
			</div>
		</div>
		<div class="section8__main-title">
			<h2>QUY TRÌNH THỰC HIỆN</h2>
			<span class="homenest-sw__landingpage__hl-title">THIẾT KẾ WEBSITE THEO YÊU CẦU</span>
		</div>
		<div class="section8__content">

			<div class="step">
				<div class="step-icon">
					<span>.01</span>
				</div>
				<div class="content-step">
					<h4>Tư vấn & Báo giá</h4>
					<p>Tư vấn chi tiết về những mong muốn và ý tưởng của khách hàng, đưa ra tính năng và gói dịch vụ phù hợp với ngân sách và lên báo giá chi tiết</p>
				</div>
			</div>
			<div class="step content-step--mgleft">
				<div class="step-icon">
					<span>.02</span>
				</div>
				<div class="content-step">
					<h4>Lập kế hoạch chi tiết</h4>
					<p>Sau khi tiếp nhận yêu cầu của khách hàng, bộ phận UI/UX và Dev sẽ thảo luận để đưa ra kế hoạch tối ưu nhất dành cho khách hàng</p>
				</div>
			</div>
			<div class="step">
				<div class="step-icon">
					<span>.03</span>
				</div>
				<div class="content-step">
					<h4>Thiết kế và lập trình</h4>
					<p>Bộ phận UI/UX Design sau khi có kế hoạch sẽ tiến hành lên demo và gửi khách hàng bản Figma. Khách hàng điều chỉnh trước khi lập trình</p>
				</div>
			</div>
			<div class="step content-step--mgleft">
				<div class="step-icon">
					<span>.04</span>
				</div>
				<div class="content-step">
					<h4>Thử nghiệm và điều chỉnh</h4>
					<p>Khách hàng thử nghiệm website của họ sau khi lập trình và tiến hành điều chỉnh nếu có vấn đề phát sinh</p>
				</div>
			</div>
			<div class="step">
				<div class="step-icon">
					<span>.05</span>
				</div>
				<div class="content-step">
					<h4>Hướng dẫn quản trị</h4>
					<p>Trao đổi và hướng dẫn khách hàng tự quản lí website của họ một các chuyên nghiệp và chính xác</p>
				</div>
			</div>
			<div class="step content-step--mgleft">
				<div class="step-icon">
					<span>.06</span>
				</div>
				<div class="content-step">
					<h4>Bàn giao và bảo hành</h4>
					<p>Sau khi hoàn thành các bước thử nghiệm và đào tạo, tiến hàng bàn giao và bảo hành cho khách trong những trường hợp cụ thể về kĩ thuật</p>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="section11">
	<div class="section11__title">
		<h2><span class="homenest-sw__landingpage__hl-title">CÂU HỎI THƯỜNG GẶP</span></h2>
		<div class="section11__content">
			<div class="section11__question">
				<div class="section11__question-num">01</div>
				<div class="section11__question-text">
					<span >Tại sao phải thiết kế website theo yêu cầu?
					</span>
				</div>
				<div class="section11__question-icon"><i class="fa-brands fa-uncharted"></i></div>
			</div>
			<div class="sectio11__answer">
				<p>
					Website hiện nay là bộ mặt của Công ty, là một công cụ hỗ trợ kinh doanh bán hàng đắc lực trong thời kỳ 4.0. Thời đại ngày càng thay đổi các công ty, doanh nghiệp thậm chí các cá thể kinh doanh đều đang hướng đến xây dựng thương hiệu riêng để mọi người chỉ cần nhìn thấy là nhớ đến đặc trưng cũng như là ngành nghề hoạt động của mình.
				</p>
			</div>
		</div>
		<hr>
		<div class="section11__content">
			<div class="section11__question">
				<div class="section11__question-num">02</div>
				<div class="section11__question-text">
					<span >Phí gia hạn web hàng năm là gì?
					</span>
				</div>
				<div class="section11__question-icon"><i class="fa-brands fa-uncharted"></i></div>
			</div>
			<div class="sectio11__answer">
				<p>
					Website hiện nay là bộ mặt của Công ty, là một công cụ hỗ trợ kinh doanh bán hàng đắc lực trong thời kỳ 4.0. Thời đại ngày càng thay đổi các công ty, doanh nghiệp thậm chí các cá thể kinh doanh đều đang hướng đến xây dựng thương hiệu riêng để mọi người chỉ cần nhìn thấy là nhớ đến đặc trưng cũng như là ngành nghề hoạt động của mình.
				</p>
			</div>
		</div>
		<hr>
		<div class="section11__content">
			<div class="section11__question">
				<div class="section11__question-num">03</div>
				<div class="section11__question-text">
					<span >Tôi có được cấp Souce Code của website không?
					</span>
				</div>
				<div class="section11__question-icon"><i class="fa-brands fa-uncharted"></i></div>
			</div>
			<div class="sectio11__answer">
				<p>
					Website hiện nay là bộ mặt của Công ty, là một công cụ hỗ trợ kinh doanh bán hàng đắc lực trong thời kỳ 4.0. Thời đại ngày càng thay đổi các công ty, doanh nghiệp thậm chí các cá thể kinh doanh đều đang hướng đến xây dựng thương hiệu riêng để mọi người chỉ cần nhìn thấy là nhớ đến đặc trưng cũng như là ngành nghề hoạt động của mình.
				</p>
			</div>
		</div>
		<hr>
		<div class="section11__content">
			<div class="section11__question">
				<div class="section11__question-num">04</div>
				<div class="section11__question-text">
					<span >Tôi cần thanh toán trước bao nhiêu phần trăm khi ký hợp đồng thiết kế web?
					</span>
				</div>
				<div class="section11__question-icon"><i class="fa-brands fa-uncharted"></i></div>
			</div>
			<div class="sectio11__answer">
				<p>
					Website hiện nay là bộ mặt của Công ty, là một công cụ hỗ trợ kinh doanh bán hàng đắc lực trong thời kỳ 4.0. Thời đại ngày càng thay đổi các công ty, doanh nghiệp thậm chí các cá thể kinh doanh đều đang hướng đến xây dựng thương hiệu riêng để mọi người chỉ cần nhìn thấy là nhớ đến đặc trưng cũng như là ngành nghề hoạt động của mình.
				</p>
			</div>
		</div>
		<hr>
		<div class="section11__content">
			<div class="section11__question">
				<div class="section11__question-num">05</div>
				<div class="section11__question-text">
					<span >Website thiết kế website theo các ngôn ngữ lập trình nào?
					</span>
				</div>
				<div class="section11__question-icon"><i class="fa-brands fa-uncharted"></i></div>
			</div>
			<div class="sectio11__answer">
				<p>
					Website hiện nay là bộ mặt của Công ty, là một công cụ hỗ trợ kinh doanh bán hàng đắc lực trong thời kỳ 4.0. Thời đại ngày càng thay đổi các công ty, doanh nghiệp thậm chí các cá thể kinh doanh đều đang hướng đến xây dựng thương hiệu riêng để mọi người chỉ cần nhìn thấy là nhớ đến đặc trưng cũng như là ngành nghề hoạt động của mình.
				</p>
			</div>
		</div>
		<hr>
		<div class="section11__content">
			<div class="section11__question">
				<div class="section11__question-num">06</div>
				<div class="section11__question-text">
					<span >Website chuẩn UX là gì?
					</span>
				</div>
				<div class="section11__question-icon"><i class="fa-brands fa-uncharted"></i></div>
			</div>
			<div class="sectio11__answer">
				<p>
					Website chuẩn UX là website được thiết kế để mang lại trải nghiệm người dùng tốt nhất, dễ sử dụng, tốc độ nhanh, và có giao diện trực quan, dễ điều hướng. Các yếu tố như tốc độ tải trang, tính tương thích với thiết bị, và khả năng tìm kiếm thông tin dễ dàng là rất quan trọng.
				</p>
			</div>
		</div>
		<hr>
		<div class="section11__content">
			<div class="section11__question">
				<div class="section11__question-num">07</div>
				<div class="section11__question-text">
					<span >Website chuẩn UI là gì?
					</span>
				</div>
				<div class="section11__question-icon"><i class="fa-brands fa-uncharted"></i></div>
			</div>
			<div class="sectio11__answer">
				<p>
					Website chuẩn UI (User Interface) là website có giao diện người dùng được thiết kế một cách trực quan, dễ nhìn và dễ sử dụng. UI tập trung vào các yếu tố như màu sắc, phông chữ, bố cục, và các yếu tố tương tác để tạo ra trải nghiệm thẩm mỹ và dễ dàng thao tác cho người dùng.
				</p>
			</div>
		</div>
		<hr>
		<div class="section11__content">
			<div class="section11__question">
				<div class="section11__question-num">08</div>
				<div class="section11__question-text">
					<span >Website chuẩn Sales là gì?
					</span>
				</div>
				<div class="section11__question-icon"><i class="fa-brands fa-uncharted"></i></div>
			</div>
			<div class="sectio11__answer">
				<p>
					Website hiện nay là bộ mặt của Công ty, là một công cụ hỗ trợ kinh doanh bán hàng đắc lực trong thời kỳ 4.0. Thời đại ngày càng thay đổi các công ty, doanh nghiệp thậm chí các cá thể kinh doanh đều đang hướng đến xây dựng thương hiệu riêng để mọi người chỉ cần nhìn thấy là nhớ đến đặc trưng cũng như là ngành nghề hoạt động của mình.
				</p>
			</div>
		</div>
		<hr>
		<div class="section11__content">
			<div class="section11__question">
				<div class="section11__question-num">09</div>
				<div class="section11__question-text">
					<span >Website chuẩn Marketing là gì?
					</span>
				</div>
				<div class="section11__question-icon"><i class="fa-brands fa-uncharted"></i></div>
			</div>
			<div class="sectio11__answer">
				<p>
					Website hiện nay là bộ mặt của Công ty, là một công cụ hỗ trợ kinh doanh bán hàng đắc lực trong thời kỳ 4.0. Thời đại ngày càng thay đổi các công ty, doanh nghiệp thậm chí các cá thể kinh doanh đều đang hướng đến xây dựng thương hiệu riêng để mọi người chỉ cần nhìn thấy là nhớ đến đặc trưng cũng như là ngành nghề hoạt động của mình.
				</p>
			</div>
		</div>
		<hr>
		<div class="section11__content">
			<div class="section11__question">
				<div class="section11__question-num">10</div>
				<div class="section11__question-text">
					<span >Website chuẩn SEO là gì?
					</span>
				</div>
				<div class="section11__question-icon"><i class="fa-brands fa-uncharted"></i></div>
			</div>
			<div class="sectio11__answer">
				<p>
					Website chuẩn SEO (Search Engine Optimization) là một trang web được tối ưu hóa để dễ dàng được tìm thấy và xếp hạng cao trên các công cụ tìm kiếm như Google. Điều này bao gồm việc tối ưu hóa các yếu tố kỹ thuật, nội dung, và cấu trúc của website để cải thiện khả năng hiển thị và thu hút lượng truy cập từ người dùng.
				</p>
			</div>
		</div>
		<hr>
	</div>
</section>
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script >
	document.addEventListener('DOMContentLoaded', function() {
		document.querySelectorAll('.show-more-btn-li').forEach(function (btn) {
			btn.addEventListener('click', function () {
				const list = btn.parentElement;
				const hiddenItem = list.querySelector('.more-items');
				const isHidden = hiddenItem.style.display === "none";

				hiddenItem.style.display = isHidden ? "block" : "none";

				const textEl = btn.querySelector('.toggle-text');
				const iconEl = btn.querySelector('.toggle-icon');

				textEl.textContent = isHidden ? "Thu gọn" : "Xem thêm";

				// Xoay icon xuống hoặc lên (nếu là tam giác)
				iconEl.style.transform = isHidden ? "rotate(180deg)" : "rotate(0deg)";
			});

		});
		const swiper = new Swiper(".mySwiper", {
			navigation: {
				nextEl: ".swiper-btn-next",
				prevEl: ".swiper-btn-prev"
			},
			spaceBetween: 20,
			autoplay: {
				delay: 3000,      // 3 giây
				disableOnInteraction: false, // vẫn tiếp tục chạy sau khi người dùng tương tác
			},
			loop: false
		});


		document.querySelectorAll('.section11__question').forEach(function (question) {
			question.addEventListener('click', function () {
				let answer = this.nextElementSibling;
				let icon = this.querySelector('.section11__question-icon');

				// Đóng tất cả câu trả lời khác trước khi mở câu trả lời hiện tại
				document.querySelectorAll('.section11__question').forEach(function (otherQuestion) {
					if (otherQuestion !== question) {
						let otherAnswer = otherQuestion.nextElementSibling;
						let otherIcon = otherQuestion.querySelector('.section11__question-icon');

						// Đóng câu trả lời khác nếu đang mở
						if (otherAnswer.style.opacity === "1" || otherAnswer.style.maxHeight !== "0px") {
							otherAnswer.style.opacity = "0";
							otherAnswer.style.maxHeight = "0";

							setTimeout(function () {
								otherAnswer.style.display = "none";
							}, 500);

							otherIcon.classList.remove('rotated');
						}
					}
				});

				// Mở câu trả lời hiện tại
				if (answer.style.display === "none" || answer.style.display === "") {
					answer.style.display = "block";

					setTimeout(function () {
						answer.style.opacity = "1";
						answer.style.maxHeight = "2000px";
					}, 10);

					icon.classList.add('rotated');
				} else {
					// Đóng câu trả lời hiện tại nếu đang mở
					answer.style.opacity = "0";
					answer.style.maxHeight = "0";

					setTimeout(function () {
						answer.style.display = "none";
					}, 500);

					icon.classList.remove('rotated');
				}
			});
		});



		const toggleBtn = document.querySelector(".toggle-btn-du-an");
		const moreText = document.querySelector(".section9__more-text");

		toggleBtn.addEventListener("click", function () {
			const isHidden = moreText.style.display === "none";

			moreText.style.display = isHidden ? "inline" : "none";
			toggleBtn.textContent = isHidden ? "Thu gọn" : "Xem thêm";
		});

		const section13__swiper = new Swiper('.section13__swiper-container', {
			slidesPerView: 1,  // Hiển thị 1 card trên mobile
			spaceBetween: 20,
			centeredSlides: false,
			grabCursor: true,
			loop: true,  // Vòng lặp qua các slide

			// Nút điều hướng
			navigation: {
				nextEl: '.swiper-button-next',
				prevEl: '.swiper-button-prev',
			},



			// Responsive breakpoints
			breakpoints: {
				// >= 768px (tablet)
				768: {
					slidesPerView: 2,
					spaceBetween: 30,
				},
				// >= 1200px (desktop)
				1200: {
					slidesPerView: 4,
					spaceBetween: 25,
				}
			}
		});


		document.querySelectorAll('.price-text').forEach((priceEl) => {
			const originalText = priceEl.textContent;

			priceEl.addEventListener('mouseenter', () => {
				priceEl.textContent = priceEl.dataset.hoverText;
			});

			priceEl.addEventListener('mouseleave', () => {
				priceEl.textContent = originalText;
			});
		});




	});
</script>
</body>
<?php get_footer(); ?>
