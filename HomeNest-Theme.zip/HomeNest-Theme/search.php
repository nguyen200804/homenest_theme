<?php get_header(); ?>

<main class="search-page">
<!--     <?php get_template_part('template-parts/search/searchform'); ?> -->
    <?php get_template_part('template-parts/search/search'); ?>
</main>

<?php get_footer(); ?>
