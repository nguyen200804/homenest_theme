document.addEventListener('DOMContentLoaded', function() {
    // Page Menu Toggle
    const pageMenuToggle = document.querySelector('.page-menu-toggle');
    const pageMenuWrapper = document.querySelector('.page-menu-wrapper');
    const pageMenu = document.querySelector('.page-menu');
    const closePageMenu = document.querySelector('.close-page-menu');
    const pageMenuOverlay = document.querySelector('.page-menu-overlay');
    const heroSection = document.querySelector('.hero-section');
    const blogGrid = document.querySelector('.blog-grid');

    // Xử lý hiển thị/ẩn nút menu khi scroll
    window.addEventListener('scroll', () => {
        const heroBottom = heroSection.getBoundingClientRect().bottom;
        const blogGridTop = blogGrid.getBoundingClientRect().top;
        const blogGridBottom = blogGrid.getBoundingClientRect().bottom;
        
        // Chỉ hiện nút khi đang ở trong vùng blog grid
        if (blogGridTop <= 0 && blogGridBottom > 0) {
            pageMenuToggle.style.display = 'flex';
        } else {
            pageMenuToggle.style.display = 'none';
        }
    });

    // Mở menu
    pageMenuToggle.addEventListener('click', () => {
        pageMenuWrapper.classList.add('active');
        document.body.style.overflow = 'hidden'; // Ngăn scroll khi menu mở
    });

    // Đóng menu khi click vào nút close
    closePageMenu.addEventListener('click', () => {
        closeMenu();
    });

    // Đóng menu khi click vào overlay
    pageMenuOverlay.addEventListener('click', (e) => {
        if (e.target === pageMenuOverlay) {
            closeMenu();
        }
    });

    // Đóng menu khi click ra ngoài
    document.addEventListener('click', (e) => {
        if (pageMenuWrapper.classList.contains('active') && 
            !pageMenu.contains(e.target) && 
            !pageMenuToggle.contains(e.target)) {
            closeMenu();
        }
    });

    // Hàm đóng menu
    function closeMenu() {
        pageMenuWrapper.classList.remove('active');
        document.body.style.overflow = ''; // Cho phép scroll lại
    }

    // Ngăn việc click vào menu content sẽ đóng menu
    pageMenu.addEventListener('click', (e) => {
        e.stopPropagation();
    });

    // Load More functionality
    const loadMoreBtn = document.getElementById('load-more');
    const postsPerPage = 6; // Số bài viết hiển thị ban đầu
    let currentlyShown = postsPerPage;
    
    if (loadMoreBtn) {
        // Ẩn các bài viết ban đầu
        const allPosts = document.querySelectorAll('.blog-post');
        Array.from(allPosts).forEach((post, index) => {
            if (index >= postsPerPage) {
                post.style.display = 'none';
            }
        });

        loadMoreBtn.addEventListener('click', function() {
            const button = this;
            const allPosts = document.querySelectorAll('.blog-post');
            const totalPosts = allPosts.length;

            if (button.classList.contains('showing-all')) {
                // Ẩn bớt
                Array.from(allPosts).forEach((post, index) => {
                    if (index >= postsPerPage) {
                        post.style.display = 'none';
                    }
                });
                currentlyShown = postsPerPage;
                button.innerHTML = '<span>Thu gọn <i class="fas fa-chevron-up"></i></span>';
                button.classList.remove('showing-all');
            } else {
                // Hiện thêm
                const nextBatch = Array.from(allPosts).slice(currentlyShown, currentlyShown + postsPerPage);
                nextBatch.forEach(post => {
                    post.style.display = 'block';
                });
                currentlyShown += postsPerPage;

                // Kiểm tra nếu đã hiện tất cả
                if (currentlyShown >= totalPosts) {
                    button.innerHTML = '<span>Thu gọn <i class="fas fa-chevron-up"></i></span>';
                    button.classList.add('showing-all');
                }
            }
        });
    }
});