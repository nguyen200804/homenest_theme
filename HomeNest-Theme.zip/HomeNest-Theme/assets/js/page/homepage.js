document.addEventListener('DOMContentLoaded', function() {
	document.querySelector('.next-slide').addEventListener('click', function() {
		document.querySelector('.col2 .swiper-button-next').click();
		document.querySelector('.col3 .swiper-button-next').click();
	});

	document.querySelector('.prev-slide').addEventListener('click', function() {
		document.querySelector('.col2 .swiper-button-prev').click();
		document.querySelector('.col3 .swiper-button-prev').click();
	});
});


document.addEventListener('DOMContentLoaded', function() {
	var swiper = new Swiper(".mySwiper", {
		loop: true,
		allowTouchMove: false,
		navigation: {
			nextEl: ".swiper-button-next",
			prevEl: ".swiper-button-prev",
		},
		breakpoints: {
			0: {
				allowTouchMove: true
			},
			768: {
				allowTouchMove: false
			}
		}
	});


	var swiper2 = new Swiper(".mySwiper2", {
		loop: true,
		allowTouchMove: false,
		navigation: {
			nextEl: ".swiper-button-next",
			prevEl: ".swiper-button-prev",
		},
	});







	var swiper5 = new Swiper(".swiperReviews", {
		slidesPerView: 3,
		spaceBetween: 30,
		loop: true,
		pagination: {
			el: ".swiper-pagination",
			clickable: true,
		},
		navigation: {
			nextEl: ".swiper-button-next",
			prevEl: ".swiper-button-prev",
		},
		breakpoints: {
			0: {
				slidesPerView: 1
			},
			768: {
				slidesPerView: 3
			}
		}
	});




	var swiper6 = new Swiper(".swiperBlogs", {
		slidesPerView: 1,
		spaceBetween: 30,
		pagination: {
			el: ".swiper-pagination",
			clickable: true,
		},
		breakpoints: {
			0: {
				slidesPerView: 1
			},
			480: {
				slidesPerView: 2
			},
			834: {
				slidesPerView: 3
			},
		},
	});

});


document.addEventListener('DOMContentLoaded', () => {
	const marqueeContainer = document.querySelector('.section-brands .marquee-contains');
	const marqueeBrands = document.querySelector('.section-brands .marqueeBrands');

	if (marqueeContainer && marqueeBrands) {
		// Get width and set CSS variable
		const width = marqueeContainer.offsetWidth;
		marqueeBrands.style.setProperty('--w', `${width}px`);

		// Duplicate marquee-contains element
		const duplicateContainer = marqueeContainer.cloneNode(true);
		marqueeBrands.appendChild(duplicateContainer);
	}
});


document.addEventListener('DOMContentLoaded', function() {
	// Lấy container chứa các slide
	const swiperWrapper = document.querySelector('.swiperServices .swiper-wrapper');

	// Lấy tất cả các slide gốc
	const slides = swiperWrapper.querySelectorAll('.swiper-slide');
	const originalSlideCount = slides.length; // Số slide gốc (ví dụ: 5)

	// Duplicate các slide để lấp đầy không gian
	slides.forEach((slide) => {
		const clonedSlide = slide.cloneNode(true); // Sao chép slide
		swiperWrapper.appendChild(clonedSlide); // Thêm vào wrapper
	});

	// Khởi tạo Swiper
	var swiper4 = new Swiper('.swiperServices', {
		slidesPerView: 4.8,
		centeredSlides: true,
		loop: true,
		loopAdditionalSlides: 0, // Không thêm slide bổ sung vào pagination
		loopedSlides: originalSlideCount, // Số slide lặp bằng số slide gốc
		spaceBetween: 30,
		speed: 400,
		allowTouchMove: true,
		pagination: {
			el: '.swiper-pagination',
			clickable: true,
			// Tùy chỉnh renderBullet để tạo dot cho slide gốc
			renderBullet: function (index, className) {
				if (index < originalSlideCount) {
					return '<span class="' + className + '"></span>';
					// 							return '<span class="' + className + '">' + (index + 1) + '</span>';
				}
				return '';
			},
		},
		// Sự kiện để cập nhật trạng thái active của dot
		on: {
			slideChange: function () {
				// Lấy chỉ số thực của slide hiện tại (realIndex)
				const realIndex = this.realIndex % originalSlideCount; // Ánh xạ về chỉ số slide gốc
				// Cập nhật trạng thái active cho dot
				const bullets = document.querySelectorAll('.swiper-pagination-bullet');
				bullets.forEach((bullet, index) => {
					if (index === realIndex) {
						bullet.classList.add('swiper-pagination-bullet-active');
					} else {
						bullet.classList.remove('swiper-pagination-bullet-active');
					}
				});
			},
		},

		breakpoints: {
			0: {
				slidesPerView: 1.1
			},
			480: {
				slidesPerView: 2.5
			},
			834: {
				slidesPerView: 3.4
			},
			1351: {
				slidesPerView: 4
			},
			1600: {
				slidesPerView: 4.8
			}
		}
	});
});


document.addEventListener('scroll', function() {
	const elements = document.querySelectorAll('.scrollTextEffect');
	const windowHeight = window.innerHeight;

	elements.forEach(element => {
		const rect = element.getBoundingClientRect();
		const elementY = rect.top;

		// Calculate scroll progress (from 100% to 50% of viewport height)
		const startPoint = windowHeight * 0.8; // 100% viewport height
		const endPoint = windowHeight * 0.35; // 50% viewport height

		if (elementY <= startPoint && elementY >= endPoint) {
			// Linear interpolation for smooth transition
			const progress = (startPoint - elementY) / (startPoint - endPoint);
			const xValue = progress * 100; // Map to 0-100

			element.style.setProperty('--x', `${xValue}%`);
		} else if (elementY > startPoint) {
			element.style.setProperty('--x', '0%');
		} else if (elementY < endPoint) {
			element.style.setProperty('--x', '100%');
		}
	});
});





function handleScrollReveal() {
	const elements = document.querySelectorAll('.showElement');
	const extraScroll = 0;

	elements.forEach(element => {
		const rect = element.getBoundingClientRect();
		const windowHeight = window.innerHeight || document.documentElement.clientHeight;

		if (rect.top <= windowHeight - extraScroll && rect.bottom >= 0) {
			element.classList.add('showed');
		}
	});
}

// Gọi khi scroll
document.addEventListener('scroll', handleScrollReveal);

// Gọi ngay khi trang load
window.addEventListener('DOMContentLoaded', handleScrollReveal);




document.addEventListener('DOMContentLoaded', function() {
	const counters = document.querySelectorAll('.count');
	const targetNumbers = [10, 50, 1500, 50, 99, 89, 99];

	function updateCounter(counter, target) {
		let current = 0;
		const increment = target / 100;

		const timer = setInterval(() => {
			current += increment;
			counter.textContent = Math.round(current);

			if (current >= target) {
				counter.textContent = target;
				clearInterval(timer);
			}
		}, 20);
	}

	// Tạo IntersectionObserver
	const observer = new IntersectionObserver((entries, observer) => {
		entries.forEach(entry => {
			if (entry.isIntersecting) {
				const counter = entry.target;
				const index = Array.from(counters).indexOf(counter);
				updateCounter(counter, targetNumbers[index]);
				observer.unobserve(counter); // Ngừng quan sát sau khi đếm
			}
		});
	}, {
		threshold: 0.1 // Kích hoạt khi 10% phần tử xuất hiện trong viewport
	});

	// Quan sát từng counter
	counters.forEach(counter => {
		observer.observe(counter);
	});
});







document.addEventListener('DOMContentLoaded', function () {
	const video = document.getElementById('videoPresentation');
	const playButton = document.querySelector('.button-popup-video');
	const pauseArea = document.querySelector('.homenest__video');

	if (!video || !playButton || !pauseArea) return;

	// Khi bấm nút play
	playButton.addEventListener('click', function (e) {
		e.stopPropagation();
		video.play().then(() => {
			playButton.style.display = 'none'; // Ẩn nút sau khi play
		}).catch((err) => {
			console.warn("Không thể phát video:", err);
		});
	});

	// Khi click vùng video (trừ nút play) thì dừng
	pauseArea.addEventListener('click', function (e) {
		if (e.target.closest('.button-popup-video')) return;
		video.pause();
	});

	// Khi video bị pause (tạm dừng thủ công hoặc qua JS)
	video.addEventListener('pause', function () {
		playButton.style.display = 'block'; // Hiện lại nút
	});
});
