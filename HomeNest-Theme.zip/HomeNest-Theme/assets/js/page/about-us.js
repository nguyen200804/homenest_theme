document.addEventListener('DOMContentLoaded', () => {
	// IntersectionObserver configuration for all animations
	const observerOptions = {
		root: null,
		rootMargin: '0px',
		threshold: 0.1 // Trigger when 10% of the element is visible
	};



	// 2. Animated Text Gradient Effect on Scroll
	const animatedTextElements = document.querySelectorAll('#animatedText');
	const handleTextGradient = () => {
		const windowHeight = window.innerHeight;

		animatedTextElements.forEach(element => {
			const rect = element.getBoundingClientRect();
			const elementY = rect.top;

			// Calculate scroll progress (from 80% to 35% of viewport height)
			const startPoint = windowHeight * 0.8;
			const endPoint = windowHeight * 0.35;

			if (elementY <= startPoint && elementY >= endPoint) {
				const progress = (startPoint - elementY) / (startPoint - endPoint);
				const xValue = progress * 100;
				element.style.setProperty('--x', `${xValue}%`);
			} else if (elementY > startPoint) {
				element.style.setProperty('--x', '0%');
			} else if (elementY < endPoint) {
				element.style.setProperty('--x', '100%');
			}
		});
	};

	window.addEventListener('scroll', () => requestAnimationFrame(handleTextGradient));
	handleTextGradient(); // Initial call

	// 3. Why Choose Us Animated Text
	const whyChooseUsTextElements = document.querySelectorAll('.whychooseus__animated-text');
	const textObserverWhyChooseUs = new IntersectionObserver((entries, observer) => {
		entries.forEach(entry => {
			if (entry.isIntersecting) {
				const textElement = entry.target;
				const textContent = textElement.textContent;

				textElement.innerHTML = textContent
					.split('')
					.map(char => `<span>${char}</span>`)
					.join('');

				const spans = textElement.querySelectorAll('span');

				const animateWhyChooseUsText = () => {
					const scrollPosition = window.scrollY;
					const elementRect = textElement.getBoundingClientRect();
					const elementTop = elementRect.top + scrollPosition;
					const windowHeight = window.innerHeight;

					spans.forEach((span, index) => {
						const spanPosition = elementTop + (index * 2);
						const distanceFromView = spanPosition - scrollPosition - windowHeight * 0.5;
						const activationRange = 150;
						const activationLevel = Math.max(0, Math.min(1, 1 - distanceFromView / activationRange));

						if (activationLevel > 0.2) {
							span.classList.add('active');
							span.style.opacity = 0.5 + activationLevel * 0.5;
						} else {
							span.classList.remove('active');
							span.style.opacity = 0.5;
						}
					});
				};

				window.addEventListener('scroll', () => requestAnimationFrame(animateWhyChooseUsText));
				animateWhyChooseUsText(); // Initial call
				observer.unobserve(textElement);
			}
		});
	}, observerOptions);

	whyChooseUsTextElements.forEach(text => textObserverWhyChooseUs.observe(text));

	// 4. Counter Animation
	const counter = document.getElementById('counter');
	if (counter) {
		const counterObserver = new IntersectionObserver((entries, observer) => {
			entries.forEach(entry => {
				if (entry.isIntersecting) {
					const animateCounter = (start, end, duration) => {
						let current = start;
						const increment = (end - start) / (duration / 10);
						const timer = setInterval(() => {
							current += increment;
							counter.textContent = Math.round(current);
							if (current >= end) {
								counter.textContent = end;
								clearInterval(timer);
							}
						}, 10);
					};

					animateCounter(1, 10, 1500);
					observer.unobserve(counter);
				}
			});
		}, observerOptions);

		counterObserver.observe(counter);
	}

	// 5. FAQ Toggle
	const questionDivs = document.querySelectorAll('.question');
	const toggleAnswer = (questionDiv) => {
		const faqItem = questionDiv.closest('.faq-item');
		const answer = faqItem.querySelector('.answer');
		const button = questionDiv.querySelector('.toggle-button');

		// Close all other answers
		document.querySelectorAll('.faq-item').forEach(item => {
			const otherAnswer = item.querySelector('.answer');
			const otherButton = item.querySelector('.toggle-button');
			if (otherAnswer !== answer && !otherAnswer.classList.contains('hidden')) {
				otherAnswer.classList.add('hidden');
				otherButton.textContent = '+';
				otherButton.classList.remove('minus');
			}
		});

		// Toggle the selected answer
		answer.classList.toggle('hidden');
		button.textContent = answer.classList.contains('hidden') ? '+' : '−';
		button.classList.toggle('minus', !answer.classList.contains('hidden'));
	};

	const faqObserver = new IntersectionObserver((entries, observer) => {
		entries.forEach(entry => {
			if (entry.isIntersecting) {
				const questionDiv = entry.target;
				questionDiv.addEventListener('click', () => toggleAnswer(questionDiv));
				observer.unobserve(questionDiv);
			}
		});
	}, observerOptions);

	questionDivs.forEach(questionDiv => {
		faqObserver.observe(questionDiv);
		const button = questionDiv.querySelector('.toggle-button');
		if (button) {
			button.addEventListener('click', (event) => {
				event.stopPropagation();
				toggleAnswer(questionDiv);
			});
		}
	});

	// 6. Image Reveal Animation
	const images = document.querySelectorAll('.animation-font img');
	const revealObserver = new IntersectionObserver((entries, observer) => {
		entries.forEach(entry => {
			if (entry.isIntersecting) {
				const img = entry.target;
				img.style.clipPath = 'inset(0 100% 0 0)';

				const duration = 1000;
				const startTime = performance.now();

				const animate = (currentTime) => {
					const elapsed = currentTime - startTime;
					const progress = Math.min(elapsed / duration, 1);
					const percentage = 100 * (1 - progress);
					img.style.clipPath = `inset(0 ${percentage}% 0 0)`;
					if (progress < 1) requestAnimationFrame(animate);
				};

				requestAnimationFrame(animate);
				observer.unobserve(img);
			}
		});
	}, observerOptions);

	images.forEach(img => {
		img.style.marginTop = '40px';
		revealObserver.observe(img);
	});

	// 7. Blog Post Slider
	const postWrapper = document.querySelector('.post-wrapper');
	const posts = document.querySelectorAll('.post');
	const dots = document.querySelectorAll('.dot');
	const prevBtn = document.getElementById('prevBtn');
	const nextBtn = document.getElementById('nextBtn');

	if (postWrapper && posts.length && prevBtn && nextBtn && dots.length) {
		const postWidth = 50; // 50% mỗi slide (2 post/slide)
		let currentIndex = 0;
		const totalSlides = Math.ceil(posts.length -1);


		postWrapper.style.transition = 'transform 0.5s ease-in-out';
		postWrapper.style.display = 'flex';
		postWrapper.style.cursor = 'grab';

		let isDragging = false;
		let startPos = 0;
		let currentTranslate = 0;
		let prevTranslate = 0;

		const getPositionX = (event) =>
		event.type.includes('mouse') ? event.clientX : event.touches[0].clientX;

		const dragStart = (event) => {
			startPos = getPositionX(event);
			isDragging = true;
			postWrapper.style.transition = 'none';
			postWrapper.style.cursor = 'grabbing';
			prevTranslate = currentTranslate;
		};

		const drag = (event) => {
			if (!isDragging) return;
			event.preventDefault();
			const currentPosition = getPositionX(event);
			const currentMove = currentPosition - startPos;
			currentTranslate = prevTranslate + (currentMove / postWrapper.offsetWidth) * 100;

			const maxTranslate = 0;
			const minTranslate = -(totalSlides * postWidth);

			if (currentTranslate > maxTranslate) {
				currentTranslate = maxTranslate + (currentTranslate - maxTranslate) / 3;
			}
			if (currentTranslate < minTranslate) {
				currentTranslate = minTranslate + (currentTranslate - minTranslate) / 3;
			}
			postWrapper.style.transform = `translateX(${currentTranslate}%)`;
		};

		const dragEnd = () => {
			if (!isDragging) return;
			isDragging = false;
			postWrapper.style.cursor = 'grab';
			postWrapper.style.transition = 'transform 0.5s ease-in-out';

			const movedBy = currentTranslate - prevTranslate;
			if (movedBy < -20 && currentIndex < totalSlides) {
				currentIndex++;
			} else if (movedBy > 20 && currentIndex > 0) {
				currentIndex--;
			}

			setPositionByIndex();
		};

		const setPositionByIndex = () => {
			currentTranslate = -currentIndex * postWidth;
			prevTranslate = currentTranslate;
			postWrapper.style.transform = `translateX(${currentTranslate}%)`;
			updateDots();
			prevBtn.disabled = currentIndex === 0;
			nextBtn.disabled = currentIndex === totalSlides;
		};

		const updateDots = () => {
			dots.forEach((dot, index) => {
				dot.classList.toggle('active', index === currentIndex);
			});
		};

		// Nút điều hướng
		const updateButtonsActiveState = () => {
			if (currentIndex > 0) {
				prevBtn.classList.add('active');
				prevBtn.disabled = false;
			} else {
				prevBtn.classList.remove('active');
				prevBtn.disabled = true;
			}

			if (currentIndex < totalSlides - 1) {
				nextBtn.classList.add('active');
				nextBtn.disabled = false;
			} else {
				nextBtn.classList.remove('active');
				nextBtn.disabled = true;
			}
		};

		prevBtn.addEventListener('click', () => {
			if (currentIndex > 0) {
				currentIndex--;
				setPositionByIndex();
				updateButtonsActiveState();
			}
		});

		nextBtn.addEventListener('click', () => {
			if (currentIndex < totalSlides - 1) {
				currentIndex++;
				setPositionByIndex();
				updateButtonsActiveState();
			}
		});

		// Gọi 1 lần khi khởi tạo
		updateButtonsActiveState();


		// Dots
		dots.forEach((dot, index) => {
			dot.addEventListener('click', () => {
				currentIndex = index;
				setPositionByIndex();
			});
		});

		// Drag Events
		postWrapper.addEventListener('mousedown', dragStart);
		postWrapper.addEventListener('touchstart', dragStart);
		postWrapper.addEventListener('mousemove', drag);
		postWrapper.addEventListener('touchmove', drag);
		postWrapper.addEventListener('mouseup', dragEnd);
		postWrapper.addEventListener('touchend', dragEnd);
		postWrapper.addEventListener('mouseleave', dragEnd);
		postWrapper.addEventListener('dragstart', (e) => e.preventDefault());

		// Observer khi xuất hiện trong viewport
		const observerOptions = {
			root: null,
			threshold: 0.1
		};

		const sliderObserver = new IntersectionObserver((entries) => {
			entries.forEach((entry) => {
				if (entry.isIntersecting) {
					setPositionByIndex();
				}
			});
		}, observerOptions);

		sliderObserver.observe(postWrapper);

		// Set vị trí ban đầu
		setPositionByIndex();

		// Xử lý khi resize
		window.addEventListener('resize', () => {
			setPositionByIndex();
		});
	}

	// 8. Testimonial Slider
	const testimonials = [
		{
			id: 1,
			name: "Mie Azenka",
			role: "Web Developer",
			avatar: "/wp-content/uploads/2025/05/img-team-h5-2.webp",
			content: "Aimmo exceeded our expectations! Their AI solutions streamlined our workflow, boosted efficiency, and enhanced user experience. Highly recommend their expertise for innovative, data-driven results!"
		},
		{
			id: 2,
			name: "Alex Johnson",
			role: "Marketing Director",
			avatar: "/wp-content/uploads/2025/05/img-team-h5-3.webp",
			content: "Working with this team transformed our digital marketing strategy. Their data-driven approach and innovative solutions delivered measurable results within months!"
		},
		{
			id: 3,
			name: "Sarah Zhang",
			role: "Product Manager",
			avatar: "/wp-content/uploads/2025/05/img-team-h5-4.webp",
			content: "The customer support is outstanding! Every interaction with their team was professional and productive. Our product launch was a success thanks to their expertise."
		}
	];

	const avatarContainer = document.getElementById('avatarContainer');
	const sliderTrack = document.getElementById('sliderTrack');
	const dotsContainer = document.getElementById('dotsContainer');
	const sliderContainer = document.getElementById('sliderContainer');

	if (avatarContainer && sliderTrack && dotsContainer && sliderContainer) {
		let activeIndex = 0;
		let isDragging = false;
		let startX = 0;
		let autoPlayInterval;

		const initSlider = () => {
			testimonials.forEach((testimonial, index) => {
				// Render avatars
				const avatarElement = document.createElement('img');
				avatarElement.src = testimonial.avatar;
				avatarElement.alt = testimonial.name;
				avatarElement.className = `avatar ${index === activeIndex ? 'active' : ''}`;
				avatarElement.addEventListener('click', () => goToSlide(index));
				avatarContainer.appendChild(avatarElement);

				// Render testimonials
				const testimonialElement = document.createElement('div');
				testimonialElement.className = 'testimonial';
				testimonialElement.innerHTML = `
<div class="testimonial-content">
<blockquote class="testimonial-text">"${testimonial.content}"</blockquote>
<div class="testimonial-author">
<div class="author-name">${testimonial.name}</div>
<span class="author-separator">•</span>
<div class="author-role">${testimonial.role}</div>
</div>
</div>
`;
				sliderTrack.appendChild(testimonialElement);

				// Render dots
				const dotElement = document.createElement('div');
				dotElement.className = `dot ${index === activeIndex ? 'active' : ''}`;
				dotElement.addEventListener('click', () => goToSlide(index));
				dotsContainer.appendChild(dotElement);
			});

			sliderContainer.addEventListener('mousedown', handleDragStart);
			sliderContainer.addEventListener('touchstart', handleTouchStart);
			sliderContainer.addEventListener('mousemove', handleDragMove);
			sliderContainer.addEventListener('touchmove', handleTouchMove);
			sliderContainer.addEventListener('mouseup', handleDragEnd);
			sliderContainer.addEventListener('touchend', handleTouchEnd);
			sliderContainer.addEventListener('mouseleave', handleDragEnd);

			startAutoPlay();
		};

		const goToSlide = (index) => {
			activeIndex = index;
			sliderTrack.style.transform = `translateX(-${activeIndex * 100}%)`;

			const avatars = avatarContainer.querySelectorAll('.avatar');
			avatars.forEach((avatar, i) => avatar.className = `avatar ${i === activeIndex ? 'active' : ''}`);

			const dots = dotsContainer.querySelectorAll('.dot');
			dots.forEach((dot, i) => dot.className = `dot ${i === activeIndex ? 'active' : ''}`);

			resetAutoPlay();
		};

		const handleDragStart = (e) => {
			isDragging = true;
			startX = e.type.includes('mouse') ? e.clientX : e.touches[0].clientX;
			sliderTrack.style.transition = 'none';
		};

		const handleDragMove = (e) => {
			if (!isDragging) return;
			e.preventDefault();
			const currentX = e.type.includes('mouse') ? e.clientX : e.touches[0].clientX;
			const diff = startX - currentX;
			const containerWidth = sliderContainer.offsetWidth;
			const movePercentage = (diff / containerWidth) * 100;
			const newTranslate = -(activeIndex * 100) - movePercentage;

			if ((activeIndex === 0 && movePercentage < 0) || (activeIndex === testimonials.length - 1 && movePercentage > 0)) {
				sliderTrack.style.transform = `translateX(${-(activeIndex * 100) + movePercentage / 4}%)`;
			} else {
				sliderTrack.style.transform = `translateX(${newTranslate}%)`;
			}
		};

		const handleDragEnd = (e) => {
			if (!isDragging) return;
			isDragging = false;
			sliderTrack.style.transition = 'transform 0.5s ease-in-out';

			const endX = e.clientX || (e.changedTouches && e.changedTouches[0].clientX);
			if (!endX) return;

			const diff = startX - endX;
			const threshold = sliderContainer.offsetWidth * 0.2;

			if (Math.abs(diff) > threshold) {
				if (diff > 0 && activeIndex < testimonials.length - 1) {
					goToSlide(activeIndex + 1);
				} else if (diff < 0 && activeIndex > 0) {
					goToSlide(activeIndex - 1);
				} else {
					goToSlide(activeIndex);
				}
			} else {
				goToSlide(activeIndex);
			}
		};

		const handleTouchStart = (e) => handleDragStart(e);
		const handleTouchMove = (e) => handleDragMove(e);
		const handleTouchEnd = (e) => handleDragEnd(e);

		const startAutoPlay = () => {
			autoPlayInterval = setInterval(() => {
				const nextIndex = (activeIndex + 1) % testimonials.length;
				goToSlide(nextIndex);
			}, 5000);
		};

		const resetAutoPlay = () => {
			clearInterval(autoPlayInterval);
			startAutoPlay();
		};

		initSlider();
	}
});
// hiệu ứng hình ảnh svg chạy chạy
window.addEventListener('scroll', () => {
	const path = document.querySelector('.circle');
	const scrollPosition = window.scrollY;
	const windowHeight = window.innerHeight;
	const totalLength = 894.393; // Tổng chiều dài path
	const horizontalLength = 477; // Chiều dài đoạn ngang (ước lượng từ M3.5,4 đến L480.5,4)
	const verticalLength = totalLength - horizontalLength; // Chiều dài đoạn dọc

	// Tính tỷ lệ cuộn (scroll) để điều khiển hiệu ứng
	const maxScroll = document.body.scrollHeight - windowHeight;
	const scrollFraction = Math.min((scrollPosition * 8) / maxScroll, 1); // Tỷ lệ cuộn từ 0 đến 1

	// Giai đoạn 1: Vẽ đoạn ngang (từ trái sang phải)
	if (scrollFraction <= 0.5) {
		const offset = totalLength - (scrollFraction * 2 * horizontalLength);
		path.style.strokeDashoffset = offset;
	}
	// Giai đoạn 2: Vẽ đoạn dọc (từ trên xuống dưới)
	else {
		const offset = totalLength - horizontalLength - ((scrollFraction - 0.5) * 2 * verticalLength);
		path.style.strokeDashoffset = Math.max(offset, 0);
	}
});

// Hàm debounce để giới hạn tần suất gọi hàm 
// hiệu ứng croll chuột hiển thị border-left
function debounce(func, wait) {
	let timeout;
	return function executedFunction(...args) {
		const later = () => {
			clearTimeout(timeout);
			func(...args);
		};
		clearTimeout(timeout);
		timeout = setTimeout(later, wait);
	};
}

function updateBorderHeight() {
	const serviceRight = document.querySelector('.homenest__services .service-right');
	if (!serviceRight) return; // Kiểm tra element tồn tại

	const rect = serviceRight.getBoundingClientRect();
	const windowHeight = window.innerHeight;
	// Tính tiến trình cuộn dựa trên vị trí của element
	const scrollProgress = Math.min(Math.max((windowHeight - rect.top) / rect.height, 0), 1);

	// Cập nhật chiều cao border
	serviceRight.style.setProperty('--border-height', `${scrollProgress * 100}%`);

	// Tiếp tục gọi requestAnimationFrame nếu đang cuộn
	if (scrollProgress < 1) {
		requestAnimationFrame(updateBorderHeight);
	}
}

// Gắn sự kiện scroll với debounce
document.addEventListener('scroll', debounce(() => {
	requestAnimationFrame(updateBorderHeight);
}, 10));