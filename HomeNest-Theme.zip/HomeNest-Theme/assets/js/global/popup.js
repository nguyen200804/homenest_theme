document.addEventListener('DOMContentLoaded', function () {
	const popup = document.getElementById('popupPromotion');
	const closeBtn = document.querySelector('.homenest__promotion-popup__close-btn');
	const triggerBtn = document.querySelector('.homenest__promotion-btn > a');
	const closeBannerBtn = document.querySelector('.homenest__promotion-btn .btn-close');
	const bannerWrapper = document.querySelector('.homenest__promotion-btn');

	// Hiển thị popup sau 5 giây
	setTimeout(function () {
		if (popup) {
			popup.classList.remove('hidePopup');
			popup.classList.add('showPopup');
		}
	}, 5000);

	// Mở popup khi bấm vào nút khuyến mãi
	if (triggerBtn && popup) {
		triggerBtn.addEventListener('click', function (e) {
			e.preventDefault();
			popup.classList.remove('hidePopup');
			popup.classList.add('showPopup');
		});
	}

	// Đóng popup khi bấm nút đóng trong popup
	if (closeBtn && popup) {
		closeBtn.addEventListener('click', function () {
			popup.classList.add('closing');

			setTimeout(function () {
				popup.classList.remove('showPopup', 'closing');
				popup.classList.add('hidePopup');
			}, 1000);
		});
	}

	// Xoá phần tử .homenest__promotion-btn khi bấm nút .btn-close
	if (closeBannerBtn && bannerWrapper) {
		closeBannerBtn.addEventListener('click', function () {
			bannerWrapper.remove(); // Xoá khỏi DOM
		});
	}
});
