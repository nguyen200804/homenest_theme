(function($) {
    'use strict';

    /**
     * 1. HÀM TÍNH PHẦN TRĂM CUỘN VÀ CẬP NHẬT GIAO DIỆN (jQuery)
     */
    function calculateScrollPercentage() {
        // Lấy chiều cao body
        var bodyHeight = $('body').height();
        // Lấy chiều cao cửa sổ trình duyệt
        var windowHeight = $(window).height();
        // Tính chiều cao có thể cuộn (body2Height)
        var body2Height = bodyHeight - windowHeight;
        // Lấy vị trí cuộn hiện tại
        var scrollPosition = $(window).scrollTop();
        
        // Tính phần trăm cuộn
        var scrollableHeight = Math.max(0, body2Height);
        var scrollPercentage = scrollableHeight === 0 ? 0 : (scrollPosition / scrollableHeight) * 100;

        // Giới hạn phần trăm trong khoảng 0-100
        scrollPercentage = Math.min(100, Math.max(0, scrollPercentage));

        // Áp dụng:
        // Cập nhật chiều cao cho phần tử .body2
        $('.body2').css('height', body2Height + 'px');
        
        // Cập nhật CSS custom property --progress cho nút cuộn lên
        $('#scrollTopBtn').css('--progress', scrollPercentage.toFixed(2) + '%');
    }

    $(document).ready(function() {
        // Chạy lần đầu khi trang tải xong
        calculateScrollPercentage();

        // Cập nhật khi resize hoặc cuộn
        $(window).on('resize scroll', calculateScrollPercentage);
    });

})(jQuery);


/**
 * 2. CÁC HÀM XỬ LÝ SỰ KIỆN KHÁC (JavaScript thuần túy)
 */
document.addEventListener('DOMContentLoaded', function() {
    const scrollTopBtn = document.getElementById('scrollTopBtn');
    const btnShowMenuMobile = document.querySelector('#btnShowMenuMobile');
    const menuMobile = document.querySelector('#menuMobile');
    const contactFooterMobile = document.querySelector('.contact-footer__mobile');
    let lastScrollTop = 0;
    
    // --- Xử lý Nút Cuộn Lên (#scrollTopBtn) ---
    if (scrollTopBtn) {
        // Lắng nghe sự kiện cuộn trang để hiện/ẩn nút
        window.addEventListener('scroll', function() {
            if (window.scrollY >= 300) {
                scrollTopBtn.classList.add('show');
            } else {
                scrollTopBtn.classList.remove('show');
            }
        });

        // Lắng nghe sự kiện nhấn nút để cuộn về đầu trang
        scrollTopBtn.addEventListener('click', function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }

    // --- Xử lý Menu Mobile ---
    if (btnShowMenuMobile && menuMobile) {
        btnShowMenuMobile.addEventListener('click', function() {
            menuMobile.classList.remove('closed');
            menuMobile.classList.add('open');
            // Bạn nên thêm logic đóng menu ở đây nếu cần (ví dụ: nút đóng hoặc click ra ngoài)
        });
    }

    // --- Xử lý Ẩn/Hiện Footer Mobile khi Cuộn ---
    if (contactFooterMobile) {
        window.addEventListener("scroll", function () {
            const currentScroll = window.pageYOffset || document.documentElement.scrollTop;
            
            // Chỉ thực hiện khi cuộn đủ xa để tránh nhảy khi ở đầu trang
            if (currentScroll > 100) { 
                if (currentScroll > lastScrollTop) {
                    // Scroll Down
                    contactFooterMobile.classList.remove("scrollUp");
                    contactFooterMobile.classList.add("scrollDown");
                } else if (currentScroll < lastScrollTop) {
                    // Scroll Up
                    contactFooterMobile.classList.remove("scrollDown");
                    contactFooterMobile.classList.add("scrollUp");
                }
            } else {
                 // Reset trạng thái khi ở gần đầu trang
                contactFooterMobile.classList.remove("scrollUp", "scrollDown");
            }
            
            lastScrollTop = currentScroll <= 0 ? 0 : currentScroll; // tránh âm
        }, { passive: true }); // Tối ưu hóa hiệu suất cuộn
    }
});