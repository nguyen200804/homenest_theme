console.log("Đã gọi được search-js");
document.addEventListener('DOMContentLoaded', function() {
    const blogPosts = document.querySelectorAll('.blog-item');
    const loadMoreBtn = document.getElementById('load-more');
    const collapseBtn = document.getElementById('collapse-posts');
    let currentVisible = 10; // Số bài viết hiển thị ban đầu

    // Ẩn tất cả bài viết từ 11 trở đi
    blogPosts.forEach((post, index) => {
        if (index >= currentVisible) {
            post.style.display = 'none';
        }
    });

    // Xử lý nút "Xem thêm"
    loadMoreBtn.addEventListener('click', function() {
        // Hiển thị 10 bài viết tiếp theo
        const nextVisible = currentVisible + 10;
        for (let i = currentVisible; i < nextVisible && i < blogPosts.length; i++) {
            blogPosts[i].style.display = 'block';
        }
        currentVisible = nextVisible;

        // Nếu đã hiển thị hết bài viết, ẩn nút "Xem thêm" và hiện nút "Thu gọn"
        if (currentVisible >= blogPosts.length) {
            loadMoreBtn.style.display = 'none';
            collapseBtn.style.display = 'inline-block';
        }
    });

    // Xử lý nút "Thu gọn"
    collapseBtn.addEventListener('click', function() {
        // Ẩn tất cả bài viết từ 11 trở đi
        blogPosts.forEach((post, index) => {
            if (index >= 10) {
                post.style.display = 'none';
            }
        });
        currentVisible = 10; // Đặt lại số bài hiển thị về 10
        loadMoreBtn.style.display = 'inline-block';
        collapseBtn.style.display = 'none';
    });

    // Ẩn nút "Xem thêm" nếu không có bài viết nào để hiển thị thêm
    if (blogPosts.length <= 10) {
        loadMoreBtn.style.display = 'none';
    }
});