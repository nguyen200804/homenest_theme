
  const toTopBtn = document.getElementById("toTopBtn");

  window.addEventListener("scroll", function () {
    const scrollTop = window.scrollY || document.documentElement.scrollTop;
    const docHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;

    if (scrollTop / docHeight > 0.05) {
      toTopBtn.classList.add("show");
    } else {
      toTopBtn.classList.remove("show");
    }
  });

  toTopBtn.addEventListener("click", function (e) {
    e.preventDefault();
    window.scrollTo({ top: 0, behavior: "smooth" });
  });
	
	
////////////////////////////////////////////////////////////////	
////////////////////////////////////////////////////////////////	
const track = document.querySelector('.carousel-track');
const pages = document.querySelectorAll('.carousel-page');
const totalRealPages = pages.length;

// Clone the first page and append it to enable seamless transition
const firstClone = pages[0].cloneNode(true);
track.appendChild(firstClone);

let currentIndex = 0;
let isDragging = false;
let startPos = 0;
let currentTranslate = 0;
let prevTranslate = 0;
let autoSlideTimer = null;

function setPositionByIndex(animated = true) {
  if (animated) {
    track.style.transition = 'transform 0.5s ease';
  } else {
    track.style.transition = 'none';
  }
  currentTranslate = -currentIndex * track.offsetWidth;
  track.style.transform = `translateX(${currentTranslate}px)`;
}

function autoSlide() {
  autoSlideTimer = setInterval(() => {
    currentIndex++;
    setPositionByIndex();

    // When reaching clone, jump to start
    if (currentIndex === totalRealPages) {
      setTimeout(() => {
        currentIndex = 0;
        setPositionByIndex(false);
        prevTranslate = -currentIndex * track.offsetWidth;
      }, 500);
    } else {
      prevTranslate = -currentIndex * track.offsetWidth;
    }
  }, 5000);
}

function dragStart(e) {
  isDragging = true;
  startPos = getPositionX(e);
  clearInterval(autoSlideTimer);
  track.style.transition = 'none';
}

function dragMove(e) {
  if (!isDragging) return;
  const currentPosition = getPositionX(e);
  const diff = currentPosition - startPos;
  currentTranslate = prevTranslate + diff;
  track.style.transform = `translateX(${currentTranslate}px)`;
}

function dragEnd() {
  if (!isDragging) return;
  isDragging = false;

  const movedBy = currentTranslate - prevTranslate;

  if (movedBy < -track.offsetWidth / 4) {
    currentIndex++;
  } else if (movedBy > track.offsetWidth / 4 && currentIndex > 0) {
    currentIndex--;
  }

  setPositionByIndex();

  if (currentIndex === totalRealPages) {
    setTimeout(() => {
      currentIndex = 0;
      setPositionByIndex(false);
      prevTranslate = -currentIndex * track.offsetWidth;
    }, 500);
  } else {
    prevTranslate = -currentIndex * track.offsetWidth;
  }

  autoSlide();
}

function getPositionX(e) {
  return e.type.includes('mouse') ? e.pageX : e.touches[0].clientX;
}

// Mouse + Touch events
track.addEventListener('mousedown', dragStart);
track.addEventListener('touchstart', dragStart);

track.addEventListener('mousemove', dragMove);
track.addEventListener('touchmove', dragMove);

track.addEventListener('mouseup', dragEnd);
track.addEventListener('mouseleave', () => { if (isDragging) dragEnd(); });
track.addEventListener('touchend', dragEnd);

// Initialize
setPositionByIndex(false);
autoSlide();
	
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////	

document.addEventListener("DOMContentLoaded", function () {
  const carousel = document.getElementById("carousel");
  const leftButton = document.getElementById("carousel-left");
  const rightButton = document.getElementById("carousel-right");

  let isDragging = false;
  let startX = 0;
  let startY = 0;
  let scrollStart = 0;
  let lockDirection = null;

	const getSlotCount = () => {
	  if (window.innerWidth <= 760) return 1;
	  if (window.innerWidth <= 1040) return 2;
	  if (window.innerWidth <= 1330) return 3;	
	  return 4;
	};

  function getBoxWidth() {
    return carousel.offsetWidth / getSlotCount();
  }

  function scrollToSlot(index) {
    const boxWidth = getBoxWidth();
    const target = index * boxWidth;
    smoothScrollTo(carousel, target, 400, () => {
      updateButtons();
    });
  }

  function smoothScrollTo(element, to, duration, callback) {
    const start = element.scrollLeft;
    const change = to - start;
    const startTime = performance.now();

    function animate(currentTime) {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const ease = progress * (2 - progress);
      element.scrollLeft = start + change * ease;

      if (progress < 1) {
        requestAnimationFrame(animate);
      } else if (callback) {
        callback();
      }
    }

    requestAnimationFrame(animate);
  }

  function updateButtons() {
    const slotCount = getSlotCount();
    const visibleCount = Math.floor(carousel.offsetWidth / getBoxWidth());
    const totalItems = carousel.querySelectorAll(".sector-7-container-body-cell").length;
    const maxScroll = carousel.scrollWidth - carousel.clientWidth;
    const scrollLeft = carousel.scrollLeft;

    if (totalItems <= slotCount) {
      leftButton.classList.add("disabled");
      rightButton.classList.add("disabled");
      return;
    }

    if (scrollLeft <= 0) {
      leftButton.classList.add("disabled");
    } else {
      leftButton.classList.remove("disabled");
    }

    if (scrollLeft >= maxScroll - 1) {
      rightButton.classList.add("disabled");
    } else {
      rightButton.classList.remove("disabled");
    }
  }

  function getCurrentIndex() {
    const boxWidth = getBoxWidth();
    return Math.round(carousel.scrollLeft / boxWidth);
  }

  leftButton.addEventListener("click", () => {
    const index = getCurrentIndex();
    scrollToSlot(index - 1);
  });

  rightButton.addEventListener("click", () => {
    const index = getCurrentIndex();
    scrollToSlot(index + 1);
  });

  // Desktop mouse events
  carousel.addEventListener("mousedown", (e) => {
    isDragging = true;
    startX = e.pageX;
    scrollStart = carousel.scrollLeft;
    carousel.style.scrollBehavior = "auto";
  });

  document.addEventListener("mousemove", (e) => {
    if (!isDragging) return;
    const walk = e.pageX - startX;
    carousel.scrollLeft = scrollStart - walk;
  });

  document.addEventListener("mouseup", () => {
    if (!isDragging) return;
    isDragging = false;
    snapToSlot();
  });

  // Touch support with diagonal lock
  carousel.addEventListener("touchstart", (e) => {
    isDragging = true;
    startX = e.touches[0].pageX;
    startY = e.touches[0].pageY;
    scrollStart = carousel.scrollLeft;
    carousel.style.scrollBehavior = "auto";
    lockDirection = null;
  }, { passive: true });

  carousel.addEventListener("touchmove", (e) => {
    if (!isDragging) return;

    const currentX = e.touches[0].pageX;
    const currentY = e.touches[0].pageY;
    const dx = currentX - startX;
    const dy = currentY - startY;

    if (lockDirection === null) {
      const angle = Math.abs(Math.atan2(dy, dx)) * (180 / Math.PI);
      lockDirection = (angle <= 30) ? 'horizontal' : 'vertical';
    }

    if (lockDirection === 'horizontal') {
      e.preventDefault();
      carousel.scrollLeft = scrollStart - dx;
    }
  }, { passive: false });

  carousel.addEventListener("touchend", () => {
    if (!isDragging) return;
    isDragging = false;
    snapToSlot();
  });

  function snapToSlot() {
    const boxWidth = getBoxWidth();
    const index = Math.round(carousel.scrollLeft / boxWidth);
    scrollToSlot(index);
  }

  carousel.addEventListener("scroll", () => {
    clearTimeout(carousel._scrollTimeout);
    carousel._scrollTimeout = setTimeout(updateButtons, 100);
  });

  window.addEventListener("resize", () => {
    updateButtons();
  });

  updateButtons();
});

////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////	
	
document.addEventListener('DOMContentLoaded', () => {
  const items = document.querySelectorAll('.sector-9-container-body-item');

  items.forEach(item => {
    item.addEventListener('click', () => {
      // Collapse other items
      items.forEach(el => {
        if (el !== item) el.classList.remove('expanded');
      });

      // Toggle current item
      item.classList.toggle('expanded');
    });

    // Prevent collapse when clicking inside .sector-9-container-body-item-second
    const content = item.querySelector('.sector-9-container-body-item-second');
    if (content) {
      content.addEventListener('click', (e) => {
        e.stopPropagation(); 
      });
    }
  });
});