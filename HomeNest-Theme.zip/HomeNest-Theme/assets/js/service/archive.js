	// Bắt trình duyệt KHÔNG tự cuộn về đầu
	if ('scrollRestoration' in history) {
		history.scrollRestoration = 'manual';
	}

	// Khôi phục vị trí scroll đã lưu SỚM NHẤT CÓ THỂ
	const savedScroll = sessionStorage.getItem('scrollPos');
	if (savedScroll !== null) {
		window.scrollTo(0, parseInt(savedScroll));
	}

	// Lưu vị trí scroll trước khi rời trang
	window.addEventListener('beforeunload', () => {
		sessionStorage.setItem('scrollPos', window.scrollY);
	});

	// Với một số trình duyệt (Safari), cần xử lý cả sự kiện pageshow (nhất là khi dùng back/forward)
	window.addEventListener('pageshow', (event) => {
		if (event.persisted) {
			const savedScroll = sessionStorage.getItem('scrollPos');
			if (savedScroll !== null) {
				window.scrollTo(0, parseInt(savedScroll));
			}
		}
	});
	// Counter animation function
	function animateCounter(element, start, end, duration) {
		let startTime = null;

		function step(timestamp) {
			if (!startTime) startTime = timestamp;
			const progress = Math.min((timestamp - startTime) / duration, 1);
			const current = Math.floor(progress * (end - start) + start);
			element.textContent = current.toLocaleString(); // Format with commas
			if (progress < 1) {
				requestAnimationFrame(step);
			}
		}

		requestAnimationFrame(step);
	}

	// Intersection Observer to trigger animation when element is visible
	const counterElement = document.querySelector('.counter--number');
	const observer = new IntersectionObserver((entries, observer) => {
		entries.forEach(entry => {
			if (entry.isIntersecting) {
				animateCounter(counterElement, 0, 20, 1000); // Count from 0 to 20,000 over 2 seconds
				observer.unobserve(entry.target); // Stop observing after animation starts
			}
		});
	}, {
		threshold: 0.5
	}); // Trigger when 50% of element is visible

	observer.observe(counterElement);

	document.addEventListener('DOMContentLoaded', function() {
		document.addEventListener('scroll', function() {
			const elements = document.querySelectorAll('.scrollTextEffect');
			const windowHeight = window.innerHeight;

			elements.forEach(element => {
				const rect = element.getBoundingClientRect();
				const elementY = rect.top;

				// Calculate scroll progress (from 100% to 50% of viewport height)
				const startPoint = windowHeight * 0.8; // 100% viewport height
				const endPoint = windowHeight * 0.35; // 50% viewport height

				if (elementY <= startPoint && elementY >= endPoint) {
					// Linear interpolation for smooth transition
					const progress = (startPoint - elementY) / (startPoint - endPoint);
					const xValue = progress * 100; // Map to 0-100

					element.style.setProperty('--x', `${xValue}%`);
				} else if (elementY > startPoint) {
					element.style.setProperty('--x', '0%');
				} else if (elementY < endPoint) {
					element.style.setProperty('--x', '100%');
				}
			});
		});

	});

	document.addEventListener("DOMContentLoaded", function() {
		const cards = document.querySelectorAll(
			".process-steps__cards1, .process-steps__cards2, .process-steps__cards3"
		);

		cards.forEach((card) => {
			card.addEventListener("click", function() {
				cards.forEach((c) => {
					c.classList.remove("active");
					c.style.zIndex = 0; // Reset z-index
				});

				this.classList.add("active");
				this.style.zIndex = 1; // Nổi lên
			});
		});
	});

	document.addEventListener("DOMContentLoaded", function() {
		const counters = document.querySelectorAll(".counter-number, .stat-number");

		const startCounting = (counter) => {
			const target = +counter.getAttribute("data-target") || +counter.innerText;
			counter.innerText = "0";

			const speed = 200;

			const updateCount = () => {
				const current = +counter.innerText;
				const increment = Math.ceil(target / speed);

				if (current < target) {
					counter.innerText = current + increment;
					setTimeout(updateCount, 10);
				} else {
					counter.innerText = target;
				}
			};

			updateCount();
		};

		// Sử dụng IntersectionObserver
		const observer = new IntersectionObserver(
			(entries, observer) => {
				entries.forEach((entry) => {
					if (entry.isIntersecting) {
						startCounting(entry.target);
						observer.unobserve(entry.target); // chỉ đếm 1 lần
					}
				});
			}, {
				threshold: 0.5, // Khi phần tử hiển thị ít nhất 50% trên màn hình thì kích hoạt
			}
		);

		counters.forEach((counter) => {
			observer.observe(counter);
		});
	});

	// Xử lý menu mobile
	document.addEventListener('DOMContentLoaded', function() {
		const menuToggle = document.querySelector('.menu-toggle');
		const navMenu = document.querySelector('.nav-menu');

		if (menuToggle && navMenu) {
			menuToggle.addEventListener('click', function() {
				navMenu.classList.toggle('active');
				menuToggle.classList.toggle('active');
			});
		}

		// Đóng menu khi click ra ngoài
		document.addEventListener('click', function(event) {
			if (!event.target.closest('.nav-menu') && !event.target.closest('.menu-toggle')) {
				navMenu.classList.remove('active');
				menuToggle.classList.remove('active');
			}
		});
	});

	// Lazy loading cho hình ảnh
	document.addEventListener('DOMContentLoaded', function() {
		const lazyImages = document.querySelectorAll('img[data-src]');

		const imageObserver = new IntersectionObserver((entries, observer) => {
			entries.forEach(entry => {
				if (entry.isIntersecting) {
					const img = entry.target;
					img.src = img.dataset.src;
					img.removeAttribute('data-src');
					observer.unobserve(img);
				}
			});
		});

		lazyImages.forEach(img => imageObserver.observe(img));
	});

	// Smooth scroll cho mobile
	document.querySelectorAll('a[href^="#"]').forEach(anchor => {
		anchor.addEventListener('click', function(e) {
			e.preventDefault();
			const target = document.querySelector(this.getAttribute('href'));
			if (target) {
				target.scrollIntoView({
					behavior: 'smooth',
					block: 'start'
				});
				// Đóng menu mobile sau khi click
				const navMenu = document.querySelector('.nav-menu');
				if (navMenu) {
					navMenu.classList.remove('active');
				}
			}
		});
	});

	// Xử lý resize window
	let resizeTimer;
	window.addEventListener('resize', function() {
		clearTimeout(resizeTimer);
		resizeTimer = setTimeout(function() {
			// Đóng menu mobile khi resize sang desktop
			if (window.innerWidth > 768) {
				const navMenu = document.querySelector('.nav-menu');
				const menuToggle = document.querySelector('.menu-toggle');
				if (navMenu) navMenu.classList.remove('active');
				if (menuToggle) menuToggle.classList.remove('active');
			}
		}, 250);
	});

	// Tối ưu hiệu suất scroll
	let scrollTimer;
	window.addEventListener('scroll', function() {
		if (!scrollTimer) {
			scrollTimer = setTimeout(function() {
				scrollTimer = null;
				// Thêm các xử lý scroll ở đây nếu cần
			}, 100);
		}
	});

	// Xử lý touch events cho mobile
	document.addEventListener('touchstart', function() {}, {
		passive: true
	});

	document.addEventListener("DOMContentLoaded", function () {
		const stickyEl = document.querySelector(".homenest__services__heading");
		const offsetTop = stickyEl.offsetTop; // Vị trí ban đầu tương đối với document

		window.addEventListener("scroll", function () {
			if (window.scrollY >= offsetTop - 80) {
				stickyEl.classList.add("sticky-fixed");
			} else {
				stickyEl.classList.remove("sticky-fixed");
			}
		});
	});

	
			document.addEventListener("DOMContentLoaded", function() {
				new Swiper(".blog-swiper", {
					slidesPerView: 1,
					spaceBetween: 30,
					navigation: {
						nextEl: ".swiper-button-next",
						prevEl: ".swiper-button-prev",
					},
					loop: false,
				});
			});
		