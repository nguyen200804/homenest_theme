window.addEventListener('DOMContentLoaded', function() {
  setTimeout(function() {
    document.querySelector('.hn__marquee-col1').classList.add('marquee-animate');
    document.querySelector('.hn__marquee-col2').classList.add('marquee-animate');
    document.querySelector('.hn__marquee-col3').classList.add('marquee-animate');
  }, 1000); // 1 giây sau khi load, bắt đầu chạy
});







const steps = document.querySelectorAll('.homenest_seo_step');

  steps.forEach(step => {
    step.addEventListener('click', () => {
      steps.forEach(s => s.classList.remove('homenest_seo_active'));
      step.classList.add('homenest_seo_active');
    });
  });








document.addEventListener("DOMContentLoaded", function () {
    const faqItems = document.querySelectorAll(".faq-item");
    const toggleMoreBtn = document.getElementById("toggleMore");
    let isExpanded = false;

    // 1. Ẩn các item từ thứ 6 trở đi
    faqItems.forEach((item, index) => {
      if (index >= 5) {
        item.classList.add("hidden");
      }
    });

    // 2. Xử lý nút "Xem tất cả FAQ"
    toggleMoreBtn.addEventListener("click", function () {
      faqItems.forEach((item, index) => {
        if (index >= 5) {
          item.classList.toggle("hidden");
        }
      });

      isExpanded = !isExpanded;
      toggleMoreBtn.textContent = isExpanded ? "Thu gọn" : "Xem tất cả FAQ";
    });

    // 3. Gán sự kiện cho mỗi tiêu đề FAQ
    document.querySelectorAll(".faq-title").forEach(title => {
      title.addEventListener("click", function () {
        const currentItem = title.parentElement;
        const currentContent = currentItem.querySelector(".faq-content");
        const isOpen = currentItem.classList.contains("active");

        // Đóng tất cả item khác
        faqItems.forEach(item => {
          item.classList.remove("active");
          const content = item.querySelector(".faq-content");
          if (content) content.style.maxHeight = null;
        });

        // Nếu chưa mở thì mở item được click
        if (!isOpen) {
          currentItem.classList.add("active");
          currentContent.style.maxHeight = currentContent.scrollHeight + "px";
        }
      });
    });
  });











function formatNumber(num) {
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

function animateCounter(element, target, duration = 2000) {
  let start = 0;
  let startTime = null;
  target = parseInt(target.replace(/\./g, ""), 10);

  function updateCounter(timestamp) {
    if (!startTime) startTime = timestamp;
    const progress = Math.min((timestamp - startTime) / duration, 1);
    const current = Math.floor(progress * target);
    element.textContent = formatNumber(current);

    if (progress < 1) {
      requestAnimationFrame(updateCounter);
    } else {
      element.textContent = formatNumber(target);
    }
  }
  requestAnimationFrame(updateCounter);
}

document.addEventListener("DOMContentLoaded", function() {
  document.querySelectorAll('.homenest_seo_counter_data').forEach(function(el) {
    const target = el.textContent.trim();
    el.textContent = "0";
    animateCounter(el, target, 3000);
  });
});