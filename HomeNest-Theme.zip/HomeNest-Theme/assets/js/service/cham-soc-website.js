document.addEventListener('DOMContentLoaded', function() {
    // ======================================
    // 1. Logic xử lý hiệu ứng Hover Thẻ (group_card)
    // ======================================
    document.querySelectorAll('.group_card .card').forEach(card => {
        card.addEventListener('mouseenter', () => {
            // Loại bỏ 'active' khỏi tất cả các main_card
            document.querySelectorAll('.main_card').forEach(c => c.classList.remove('active'));
            // Thêm 'active' cho main_card bên trong thẻ đang hover
            const mainCard = card.querySelector('.main_card');
            if (mainCard) {
                mainCard.classList.add('active');
            }
        });
    });

    // ======================================
    // 2. Khởi tạo Swiper Slider (mySwiper)
    // ======================================
    // Kiểm tra xem thư viện Swiper đã được tải chưa trước khi khởi tạo
    if (typeof Swiper !== 'undefined') {
        var swiper = new Swiper(".mySwiper", {
            spaceBetween: 30,
            centeredSlides: true,
            autoplay: {
                delay: 5000,
                disableOnInteraction: false,
            },
            loop: true,
            navigation: {
                nextEl: ".swiper-button-next-ab",
                prevEl: ".swiper-button-prev-ab",
            },
        });
    } else {
        console.warn("Thư viện Swiper không tìm thấy. Không thể khởi tạo slider.");
    }

    // ======================================
    // 3. Logic xử lý Hiệu ứng Fade khi Cuộn (Intersection Observer)
    // ======================================
    const fadeElements = document.querySelectorAll('.fade-element');

    // Chỉ khởi tạo Observer nếu có phần tử cần theo dõi
    if (fadeElements.length > 0 && typeof IntersectionObserver !== 'undefined') {
        const observer = new IntersectionObserver(entries => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                    observer.unobserve(entry.target); // Ngừng theo dõi sau khi đã hiển thị
                }
            });
        }, {
            threshold: 0.1 // xuất hiện khi 10% phần tử vào viewport
        });

        fadeElements.forEach(el => observer.observe(el));
    }


    // ======================================
    // 4. Logic Render và Xử lý Quy trình Chăm sóc Website
    //    (Yêu cầu dữ liệu từ biến toàn cục 'quyTrinhContain')
    // ======================================
    // Kiểm tra xem mảng quyTrinhContain có tồn tại và đã được load chưa
    if (typeof quyTrinhContain === 'undefined' || !Array.isArray(quyTrinhContain)) {
		console.error("Mảng 'quyTrinhContain' chưa được định nghĩa (cần phải được định nghĩa trong thẻ <script> trước file này).");
		return;
	}

	// 4.1. Render các item từ mảng ra HTML
	const container = document.querySelector('.homenest__quy-trinh-cham-soc-website__contain');
	if (container) {
		container.innerHTML = quyTrinhContain.map((item, index) => `
			<li class="homenest__quy-trinh-cham-soc-website__item" style="background-image: linear-gradient(to bottom, #00000000, #000000),url('${item.linkImg}')">
				<div class="hn__heading">
					<div class="number">0${index + 1}.</div>
					<div>${item.heading}</div>
				</div>
				<div class="hn__heading-and-content" >
					<div class="number">0${index + 1}.</div>
					<h3 class="heading">${item.heading}</h3>
					<p class="content">${item.content}</p>
				</div>
			</li>
		`).join('');
	}

	// 4.2. Xử lý sự kiện click
	const items = document.querySelectorAll('.homenest__quy-trinh-cham-soc-website__item');
	let isClickable = true;

	items.forEach((item, index) => {
		item.addEventListener('click', function() {
			if (!isClickable) return;

			isClickable = false;
			items.forEach(el => el.classList.remove('active'));
			this.classList.add('active');

			// Log thông tin (có thể thay bằng logic tùy chỉnh)
			// console.log('Đã chọn:', quyTrinhContain[index].heading);

			setTimeout(() => {
				isClickable = true;
			}, 300);
		});
	});

	// 4.3. Active item đầu tiên khi load trang
	if (items.length > 0) {
		items[0].classList.add('active');
	}

});