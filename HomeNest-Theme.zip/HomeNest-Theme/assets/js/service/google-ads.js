let counted = false;


function animateCounters() {
    if (counted) return;   

    const counters = document.querySelectorAll(".counter");
    counters.forEach(counter => {
        const target = +counter.getAttribute("data-target");
        let count = 0;

        const update = () => {
            const increment = Math.ceil(target / 300);
            if (count < target) {
                count += increment;
                counter.innerText = count > target ? target : count;
                setTimeout(update, 30);
            } else {
                counter.innerText = target;
            }
        };

        update();
    });

    counted = true;
}

window.addEventListener("scroll", () => {
    const stats = document.getElementById("stats");
    if (!stats) return;

    const rect = stats.getBoundingClientRect();
    if (rect.top < window.innerHeight && rect.bottom >= 0) {
        animateCounters();
    }
});

document.addEventListener("DOMContentLoaded", function () {
    let started = false;

    window.addEventListener("scroll", () => {
        const trigger = document.getElementById("scrollingTextTrigger");
        const text = document.getElementById("scrollingText");
        if (!trigger || !text) return;

        const rect = trigger.getBoundingClientRect();
        if (!started && rect.top < window.innerHeight && rect.bottom > 0) {
            text.classList.add("animate");
            started = true;
        }
    });
});

document.addEventListener("DOMContentLoaded", () => {
    const marquees = document.querySelectorAll(".marquee--text");
    const getSpeed = () => window.innerWidth < 768 ? 0.75 : 2;

    marquees.forEach(marquee => {
        const originalContent = marquee.querySelector("span").textContent;
        marquee.innerHTML = `<span>${originalContent}</span><span>${originalContent}</span>`;
        let position = 0;
        let speed = getSpeed();

        function animateMarquee() {
            position -= speed;
            if (position <= -marquee.firstElementChild.offsetWidth) position = 0;
            marquee.style.transform = `translateX(${position}px)`;
            requestAnimationFrame(animateMarquee);
        }

        window.addEventListener("resize", () => {
            speed = getSpeed();
        });

        animateMarquee();
    });
});

document.addEventListener("DOMContentLoaded", function () {
    if (typeof Swiper !== "undefined") {
        new Swiper(".mySwiper", {
            slidesPerView: "auto",
            centeredSlides: true,
            spaceBetween: 30,
            loop: true,
            grabCursor: true,
            pagination: {
                el: ".swiper-pagination",
                clickable: true,
            },
        });
    } else {
        console.error("Swiper is not defined. Make sure Swiper JS is loaded before this script.");
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const spotlight = document.getElementById("spotlightText");
    if (!spotlight) return;

    spotlight.setAttribute("data-content", spotlight.innerText);

    let mouseX = 50, mouseY = 50;
    let rafId = null;
    let isInside = false;

    const updateLight = () => {
        spotlight.style.setProperty("--x", `${mouseX}%`);
        spotlight.style.setProperty("--y", `${mouseY}%`);
        rafId = null;
    };

    const onMouseMove = (e) => {
        if (!isInside) return;

        const rect = spotlight.getBoundingClientRect();
        mouseX = ((e.clientX - rect.left) / rect.width) * 100;
        mouseY = ((e.clientY - rect.top) / rect.height) * 100;

        if (!rafId) {
            rafId = requestAnimationFrame(updateLight);
        }
    };

    spotlight.addEventListener("mouseenter", () => {
        isInside = true;
        spotlight.classList.add("active");
    });

    spotlight.addEventListener("mouseleave", () => {
        isInside = false;
        spotlight.classList.remove("active");
    });

    document.addEventListener("mousemove", onMouseMove);
});

document.addEventListener("DOMContentLoaded", function () {
    const counters = document.querySelectorAll(".ai-number");
    const options = { threshold: 0.6 };

    const startCount = (entry) => {
        const el = entry.target;
        const target = +el.getAttribute("data-target");
        let current = 0;
        const step = Math.ceil(target / 100);
        const duration = 1000;
        const interval = duration / (target / step);

        const counter = setInterval(() => {
            current += step;
            if (current >= target) {
                el.textContent = target + "+";
                clearInterval(counter);
            } else {
                el.textContent = current;
            }
        }, interval);
    };

    const observer = new IntersectionObserver((entries, obs) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                startCount(entry);
                obs.unobserve(entry.target);
            }
        });
    }, options);

    counters.forEach(counter => observer.observe(counter));
});

document.addEventListener("DOMContentLoaded", () => {
    const heading = document.querySelector(".fade-heading");
    if (!heading) return;

    const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                heading.classList.add("visible");
            }
        });
    }, { threshold: 0.5 });

    observer.observe(heading);
});

document.addEventListener("DOMContentLoaded", function () {
    const revealElements = document.querySelectorAll('.reveal-on-scroll');

    const revealObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach((entry, i) => {
            if (entry.isIntersecting) {
                setTimeout(() => {
                    entry.target.classList.add('visible');
                }, i * 150);
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.2
    });

    revealElements.forEach(el => {
        revealObserver.observe(el);
    });
});
console.log("JavaScripts1");
// Bảng hỏi đáp (FAQ)
document.addEventListener("DOMContentLoaded", function () {
  const faqData = [
    {
      question: "Tại sao phải thiết kế website theo yêu cầu?",
      answer:
        "Thiết kế website theo yêu cầu giúp doanh nghiệp có giao diện, tính năng phù hợp với đặc thù hoạt động, tăng hiệu quả kinh doanh và nhận diện thương hiệu.",
    },
    {
      question: "Phí gia hạn web hàng năm là gì?",
      answer:
        "Phí gia hạn web hàng năm bao gồm chi phí duy trì tên miền, hosting và các dịch vụ kỹ thuật kèm theo để website hoạt động ổn định.",
    },
    {
      question: "Thiết kế website chuẩn SEO là gì?",
      answer:
        "Website chuẩn SEO giúp tối ưu công cụ tìm kiếm, dễ được Google index và cải thiện thứ hạng trên kết quả tìm kiếm.",
    },
    {
      question: "Hosting là gì và tại sao cần thiết?",
      answer:
        "Hosting là nơi lưu trữ toàn bộ dữ liệu website. Không có hosting thì website không thể hoạt động được trên internet.",
    },
    {
      question: "Tên miền là gì?",
      answer:
        "Tên miền là địa chỉ của website trên internet, ví dụ như www.tenmien.com. Nó giúp người dùng truy cập nhanh chóng vào website.",
    },
    {
      question: "Website có cần bảo mật SSL không?",
      answer:
        "Có. SSL giúp mã hóa dữ liệu giữa người dùng và máy chủ, tăng độ tin cậy và bảo vệ thông tin cá nhân, đặc biệt quan trọng với các website thương mại điện tử.",
    },
    {
      question: "Tôi có thể chỉnh sửa nội dung website không?",
      answer:
        "Có. Với hệ thống quản trị nội dung (CMS), bạn có thể dễ dàng cập nhật nội dung mà không cần kiến thức lập trình.",
    },
    {
      question: "Chi phí thiết kế website là bao nhiêu?",
      answer:
        "Chi phí tùy thuộc vào mức độ phức tạp và yêu cầu cụ thể. Bạn có thể liên hệ để được báo giá chi tiết.",
    },
    {
      question: "Thời gian thiết kế website mất bao lâu?",
      answer:
        "Thông thường từ 7-20 ngày làm việc tùy theo mức độ phức tạp và số lượng tính năng yêu cầu.",
    },
    {
      question: "Website có tương thích với điện thoại không?",
      answer:
        "Có. Website được thiết kế responsive, hiển thị tốt trên mọi thiết bị như điện thoại, máy tính bảng và laptop.",
    },
  ];

  const faqContainer = document.getElementById(
    "homenest__professional_website_faq-container"
  );

  faqData.forEach((item, index) => {
    const faqItem = document.createElement("div");
    faqItem.className = "homenest__professional_website_question";

    faqItem.innerHTML = `
      <div class="homenest__professional_website_question-header-number">
        <span class="homenest__professional_website_question-number"><span>${(
          index + 1
        )
          .toString()
          .padStart(2, "0")}
          </span></span>
        <span class="homenest__professional_website_question-label">QUESTION - ${(
          index + 1
        )
          .toString()
          .padStart(2, "0")}</span>
      </div>
      <div class="homenest__professional_website_question-header">
        <div style="width: 40px; height: 40px;"></div>
        <span class="homenest__professional_website_question-title">${
          item.question
        }</span>
        <button class="homenest__professional_website_toggle-btn">
          +
        </button>
      </div>
      <div class="homenest__professional_website_answer-wrapper">
        <div style="width: 40px; height: 40px;"></div>
        <div class="homenest__professional_website_answer">${item.answer}</div>
        <div style="width: 40px; height: 40px;"></div>
      </div>
    `;

    faqContainer.appendChild(faqItem);
  });

  document
    .querySelectorAll(".homenest__professional_website_question-header")
    .forEach((header) => {
      header.addEventListener("click", () => {
        const allAnswers = document.querySelectorAll(
          ".homenest__professional_website_answer-wrapper"
        );
        const allButtons = document.querySelectorAll(
          ".homenest__professional_website_toggle-btn"
        );

        const currentAnswer = header.nextElementSibling;
        const currentButton = header.querySelector(
          ".homenest__professional_website_toggle-btn"
        );

        // Close all other answers and reset their buttons
        allAnswers.forEach((answer) => {
          if (answer !== currentAnswer) answer.classList.remove("show");
        });

        allButtons.forEach((btn) => {
          if (btn !== currentButton) {
            btn.classList.remove("open");
            btn.textContent = "+";
          }
        });

        // Toggle current
        const isOpen = currentAnswer.classList.contains("show");
        currentAnswer.classList.toggle("show", !isOpen);
        currentButton.classList.toggle("open", !isOpen);
        currentButton.textContent = !isOpen ? "−" : "+";
      });
    });
});

//slide  

const slidesContainer = document.querySelector(".slides");
const images = document.querySelectorAll(".slides img");
const prev = document.querySelector(".prev");
const next = document.querySelector(".next");

let currentIndex = 0;
const visibleSlides = 3;
const totalSlides = images.length;

function updateSlider() {
  const slideWidth = slidesContainer.clientWidth / visibleSlides;
  slidesContainer.style.transform = `translateX(-${currentIndex * slideWidth}px)`;
}

next.addEventListener("click", () => {
  currentIndex = (currentIndex + 1) % (totalSlides - visibleSlides + 1);
  updateSlider();
});

prev.addEventListener("click", () => {
  currentIndex = (currentIndex - 1 + (totalSlides - visibleSlides + 1)) % (totalSlides - visibleSlides + 1);
  updateSlider();
});

window.addEventListener("resize", updateSlider);
window.addEventListener("load", updateSlider);


// bảng báo giá
// Toggle "Xem thêm / Thu hồi"
document.querySelectorAll('.toggle-btn').forEach(button => {
  button.addEventListener('click', () => {
    const card = button.closest('.card');
    const extras = card.querySelectorAll('.extra');
    extras.forEach(item => item.classList.toggle('hidden'));
    button.textContent = button.textContent === 'Xem thêm' ? 'Thu hồi' : 'Xem thêm';
  });
});

// Reveal Platinum+ when scrolling to end
const slider = document.querySelector('.pricing-slider');
slider.addEventListener('scroll', () => {
  const platinumPlus = document.querySelector('.platinum-plus');
  if (slider.scrollLeft + slider.clientWidth >= slider.scrollWidth - 10) {
    platinumPlus.classList.remove('hidden');
  }
});
	
  var swiper = new Swiper(".mySwiper", {
    slidesPerView: 1,
    spaceBetween: 30,
    freeMode: true,
    loop: true,
    autoplay: {
      delay: 5000,
      disableOnInteraction: false 
    },
    navigation: {
      nextEl: '.next',
      prevEl: '.prev',
    },
    breakpoints: {
      480: {
        slidesPerView: 1,
      },
      768: {
        slidesPerView: 2,
      },
      1024: {
        slidesPerView: 3,
      },
      1280: {
        slidesPerView: 4,
      }
    }
  });



const steps = document.querySelectorAll('.step, .step-1');
const processWrapper = document.querySelector('.process-wrapper');

let lastScrollTop = 0;

processWrapper.addEventListener('scroll', () => {
  const scrollTop = processWrapper.scrollTop;
  const isScrollingDown = scrollTop > lastScrollTop;

  steps.forEach((step) => {
    const offsetTop = step.offsetTop;
    const distanceFromTop = offsetTop - scrollTop;

    if (isScrollingDown) {
      if (distanceFromTop < -100) {
        step.classList.add('hidden');
      }
    } else {
      if (distanceFromTop < 300) {
        step.classList.remove('hidden');
      }
    }
  });

  lastScrollTop = scrollTop <= 0 ? 0 : scrollTop;
});




