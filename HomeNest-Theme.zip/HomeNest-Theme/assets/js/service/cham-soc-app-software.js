// ======================================
// 1. Khởi tạo AOS (Animate On Scroll)
// ======================================
// Kiểm tra xem thư viện AOS có tồn tại không
if (typeof AOS !== 'undefined') {
    AOS.init({
        duration: 1000,           // Thời gian chuyển động (ms)
        easing: 'ease-out-cubic', // Hàm easing cho chuyển động mượt mà
        once: false,              // true: chỉ chạy 1 lần; false: chạy lại khi cuộn lên/xuống
        offset: 50                // Khoảng cách (px) so với viewport để bắt đầu animation
    });
} else {
    console.warn("Thư viện AOS không được tải. Hiệu ứng cuộn không hoạt động.");
}

// ======================================
// 2. Hàm đếm số nguyên (Integer Count Up)
// ======================================
/**
 * Thực hiện hiệu ứng đếm số từ 0 lên giá trị đích.
 * @param {HTMLElement} element - Phần tử hiển thị số.
 * @param {number} target - Giá trị đích cần đếm tới.
 * @param {number} [duration=3000] - Thời gian đếm (ms).
 */
function animateCountUp(element, target, duration = 3000) {
    let startTime = null;

    function step(timestamp) {
        if (!startTime) startTime = timestamp;
        const progress = Math.min((timestamp - startTime) / duration, 1);
        const value = Math.floor(progress * target);
        
        // Cập nhật nội dung với định dạng local (ví dụ: thêm dấu phẩy)
        element.textContent = value.toLocaleString();
        
        if (progress < 1) {
            window.requestAnimationFrame(step);
        }
    }

    window.requestAnimationFrame(step);
}

// ======================================
// 3. Hàm đếm số thập phân (Float Count Up)
// ======================================
/**
 * Thực hiện hiệu ứng đếm số thập phân từ giá trị khởi tạo lên giá trị đích.
 * @param {HTMLElement} element - Phần tử hiển thị số.
 * @param {number} target - Giá trị đích cần đếm tới.
 * @param {number} [duration=2000] - Thời gian đếm (ms).
 * @param {number} [start=0.1] - Giá trị khởi tạo (float).
 */
function countUpFloat(element, target, duration = 2000, start = 0.1) {
	let startTime = null;

	function step(timestamp) {
		if (!startTime) startTime = timestamp;
		const progress = Math.min((timestamp - startTime) / duration, 1);
		const value = start + (target - start) * progress;
		
		// Hiện 1 chữ số thập phân
		element.textContent = value.toFixed(1); 
		
		if (progress < 1) {
			window.requestAnimationFrame(step);
		}
	}

	window.requestAnimationFrame(step);
}


// ======================================
// 4. Khởi tạo khi DOM đã tải (Cả Integer và Float)
// ======================================
document.addEventListener('DOMContentLoaded', () => {
    
    // --- 4.1. Khởi tạo đếm số nguyên (.count-up) ---
    const integerCounters = document.querySelectorAll('.count-up');
    
    // Sử dụng Intersection Observer để kích hoạt đếm số nguyên khi vào viewport
    const integerObserver = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const el = entry.target;
                const target = parseInt(el.getAttribute('data-target'));
                animateCountUp(el, target);
                integerObserver.unobserve(el); // Ngừng theo dõi sau khi đã đếm xong
            }
        });
    }, {
        threshold: 0.1 // Kích hoạt khi 10% phần tử vào viewport
    });

    integerCounters.forEach(counter => integerObserver.observe(counter));


    // --- 4.2. Khởi tạo đếm số thập phân (.count-up-review) ---
    const floatCounters = document.querySelectorAll('.count-up-review');

	const floatObserver = new IntersectionObserver(entries => {
		entries.forEach(entry => {
			if (entry.isIntersecting) {
				const el = entry.target;
				const target = parseFloat(el.getAttribute('data-target'));
				countUpFloat(el, target);
				floatObserver.unobserve(el); // Ngừng theo dõi sau khi đã đếm xong
			}
		});
	}, {
		threshold: 0.6 // Kích hoạt khi 60% phần tử vào viewport
	});

	floatCounters.forEach(counter => floatObserver.observe(counter));
});