// CUNG CẤP MỌI LOẠI HÌNH QUẢNG CÁO FACEBOOK
document.addEventListener("DOMContentLoaded", () => {
  const items = document.querySelectorAll(".faq-item");

  items.forEach((item) => {
    const content = item.querySelector(".details-body-group");

    // Khởi tạo trạng thái cho content
    if (item.hasAttribute("open")) {
      content.style.height = content.scrollHeight + "px";
    } else {
      content.style.height = "0";
      content.style.overflow = "hidden";
    }

    item.addEventListener("toggle", () => {
      if (item.open) {
        // Đóng các mục khác
        items.forEach((el) => {
          if (el !== item) {
            el.removeAttribute("open");
            const elContent = el.querySelector(".details-body-group");
            elContent.style.height = "0";
            elContent.style.overflow = "hidden";
          }
        });

        // Mở mục hiện tại
        // Bắt đầu bằng height = 0 (để chắc chắn có transition)
        content.style.height = "0";
        content.style.overflow = "hidden";

        // Cho browser kịp render trước khi set height đúng
        requestAnimationFrame(() => {
          content.style.transition = "height 0.5s ease";
          content.style.height = content.scrollHeight + "px";
        });

        // Khi animation kết thúc, set height về auto để nội dung co dãn tự nhiên
        content.addEventListener(
          "transitionend",
          function handler(e) {
            if (e.propertyName === "height") {
              content.style.height = "auto";
              content.style.overflow = "visible";
              content.style.transition = "";
              content.removeEventListener("transitionend", handler);
            }
          }
        );
      } else {
        // Đóng mục: set height từ auto (hoặc chiều cao thực) về 0
        // Trước đó set height hiện tại để browser biết chiều cao bắt đầu là bao nhiêu
        content.style.height = content.scrollHeight + "px";

        // Cho browser kịp render trước khi chuyển về 0
        requestAnimationFrame(() => {
          content.style.transition = "height 0.5s ease";
          content.style.height = "0";
          content.style.overflow = "hidden";
        });

        // Khi kết thúc animation, giữ nguyên height = 0
        content.addEventListener(
          "transitionend",
          function handler(e) {
            if (e.propertyName === "height") {
              content.style.transition = "";
              content.removeEventListener("transitionend", handler);
            }
          }
        );
      }
    });
  });
});


  //  FAQ
   document.addEventListener("DOMContentLoaded", function () {
  const faqData = [
    {
      question: "Tại sao phải thiết kế website theo yêu cầu?",
      answer:
        "Thiết kế website theo yêu cầu giúp doanh nghiệp có giao diện, tính năng phù hợp với đặc thù hoạt động, tăng hiệu quả kinh doanh và nhận diện thương hiệu.",
    },
    {
      question: "Phí gia hạn web hàng năm là gì?",
      answer:
        "Phí gia hạn web hàng năm bao gồm chi phí duy trì tên miền, hosting và các dịch vụ kỹ thuật kèm theo để website hoạt động ổn định.",
    },
    {
      question: "Thiết kế website chuẩn SEO là gì?",
      answer:
        "Website chuẩn SEO giúp tối ưu công cụ tìm kiếm, dễ được Google index và cải thiện thứ hạng trên kết quả tìm kiếm.",
    },
    {
      question: "Hosting là gì và tại sao cần thiết?",
      answer:
        "Hosting là nơi lưu trữ toàn bộ dữ liệu website. Không có hosting thì website không thể hoạt động được trên internet.",
    },
    {
      question: "Tên miền là gì?",
      answer:
        "Tên miền là địa chỉ của website trên internet, ví dụ như www.tenmien.com. Nó giúp người dùng truy cập nhanh chóng vào website.",
    },
    {
      question: "Website có cần bảo mật SSL không?",
      answer:
        "Có. SSL giúp mã hóa dữ liệu giữa người dùng và máy chủ, tăng độ tin cậy và bảo vệ thông tin cá nhân, đặc biệt quan trọng với các website thương mại điện tử.",
    },
    {
      question: "Tôi có thể chỉnh sửa nội dung website không?",
      answer:
        "Có. Với hệ thống quản trị nội dung (CMS), bạn có thể dễ dàng cập nhật nội dung mà không cần kiến thức lập trình.",
    },
    {
      question: "Chi phí thiết kế website là bao nhiêu?",
      answer:
        "Chi phí tùy thuộc vào mức độ phức tạp và yêu cầu cụ thể. Bạn có thể liên hệ để được báo giá chi tiết.",
    },
    {
      question: "Thời gian thiết kế website mất bao lâu?",
      answer:
        "Thông thường từ 7-20 ngày làm việc tùy theo mức độ phức tạp và số lượng tính năng yêu cầu.",
    },
    {
      question: "Website có tương thích với điện thoại không?",
      answer:
        "Có. Website được thiết kế responsive, hiển thị tốt trên mọi thiết bị như điện thoại, máy tính bảng và laptop.",
    },
  ];

  const faqContainer = document.getElementById(
    "homenest__professional_website_faq-container"
  );

  faqData.forEach((item, index) => {
    const faqItem = document.createElement("div");
    faqItem.className = "homenest__professional_website_question";

    faqItem.innerHTML = `
      <div class="homenest__professional_website_question-header-number">
        <span class="homenest__professional_website_question-number"><span>${(
          index + 1
        )
          .toString()
          .padStart(2, "0")}
          </span></span>
        <span class="homenest__professional_website_question-label">QUESTION - ${(
          index + 1
        )
          .toString()
          .padStart(2, "0")}</span>
      </div>
      <div class="homenest__professional_website_question-header">
        <div style="width: 40px; height: 40px;"></div>
        <span class="homenest__professional_website_question-title">${
          item.question
        }</span>
        <button class="homenest__professional_website_toggle-btn">
          +
        </button>
      </div>
      <div class="homenest__professional_website_answer-wrapper">
        <div style="width: 40px; height: 40px;"></div>
        <div class="homenest__professional_website_answer">${item.answer}</div>
        <div style="width: 40px; height: 40px;"></div>
      </div>
    `;

    faqContainer.appendChild(faqItem);
  });

  document
    .querySelectorAll(".homenest__professional_website_question-header")
    .forEach((header) => {
      header.addEventListener("click", () => {
        const allAnswers = document.querySelectorAll(
          ".homenest__professional_website_answer-wrapper"
        );
        const allButtons = document.querySelectorAll(
          ".homenest__professional_website_toggle-btn"
        );

        const currentAnswer = header.nextElementSibling;
        const currentButton = header.querySelector(
          ".homenest__professional_website_toggle-btn"
        );

        // Close all other answers and reset their buttons
        allAnswers.forEach((answer) => {
          if (answer !== currentAnswer) answer.classList.remove("show");
        });

        allButtons.forEach((btn) => {
          if (btn !== currentButton) {
            btn.classList.remove("open");
            btn.textContent = "+";
          }
        });

        // Toggle current
        const isOpen = currentAnswer.classList.contains("show");
        currentAnswer.classList.toggle("show", !isOpen);
        currentButton.classList.toggle("open", !isOpen);
        currentButton.textContent = !isOpen ? "−" : "+";
      });
    });
});

 
