document.addEventListener('DOMContentLoaded', function() {
	var swiper = new Swiper(".swiperLogoChuyenNghiep", {
		pagination: {
			el: ".swiper-pagination",
			dynamicBullets: true,
		},
	});

});




document.addEventListener('DOMContentLoaded', function() {
	// Mảng dữ liệu các bước quy trình
	const quyTrinhContain = [
		{
			heading: "Phân tích và lập kế hoạch",
			content: "Xác định mục tiêu, nhu cầu và đối tượng khách hàng của website. Lên kế hoạch chi tiết về nội dung, kỹ thuật, bảo mật và các chỉ số đánh giá hiệu quả (KPI).",
			linkImg: "/wp-content/uploads/2025/06/761d2291534b7cd6cf9fc1eaccf9f8b6-scaled-1.webp",
		},
		{
			heading: "Quản trị và cập nhật nội dung",
			content: "Đăng tải, chỉnh sửa nội dung mới chuẩn SEO, cập nhật hình ảnh, banner, sản phẩm/dịch vụ. Đảm bảo nội dung luôn hấp dẫn, phù hợp xu hướng và tăng trải nghiệm người dùng.",
			linkImg: "/wp-content/uploads/2025/06/761d2291534b7cd6cf9fc1eaccf9f8b6-scaled-1.webp",
		},
		{
			heading: "Bảo trì kỹ thuật và tối ưu hiệu suất",
			content: "Kiểm tra, sửa lỗi kỹ thuật, cập nhật hệ thống, plugin và theme. Tối ưu tốc độ tải trang, dọn dẹp dữ liệu không cần thiết, đảm bảo website hoạt động mượt mà trên mọi thiết bị.",
			linkImg: "/wp-content/uploads/2025/06/761d2291534b7cd6cf9fc1eaccf9f8b6-scaled-1.webp",
		},
		{
			heading: "Tăng cường bảo mật và sao lưu dữ liệu",
			content: "Cài đặt và cập nhật các giải pháp bảo mật, quét mã độc định kỳ. Sao lưu dữ liệu thường xuyên để phòng tránh mất mát và hỗ trợ phục hồi nhanh khi có sự cố.",
			linkImg: "/wp-content/uploads/2025/06/761d2291534b7cd6cf9fc1eaccf9f8b6-scaled-1.webp",
		},
		{
			heading: "Theo dõi, phân tích và báo cáo",
			content: "Sử dụng công cụ như Google Analytics, Google Search Console để theo dõi lưu lượng, hành vi người dùng và thứ hạng từ khóa. Báo cáo định kỳ, đánh giá hiệu quả và đề xuất cải tiến phù hợp.",
			linkImg: "/wp-content/uploads/2025/06/761d2291534b7cd6cf9fc1eaccf9f8b6-scaled-1.webp",
		},
	];

	// Render các item từ mảng ra HTML
	const container = document.querySelector('.homenest__quy-trinh-cham-soc-website__contain');
	if (container) {
		container.innerHTML = quyTrinhContain.map((item, index) => `
<li class="homenest__quy-trinh-cham-soc-website__item" style="background-image: linear-gradient(to bottom, #00000000, #000000),url('${item.linkImg}')">
<div class="hn__heading">
<div class="number">0${index + 1}.</div>
<div>${item.heading}</div>
</div>
<div class="hn__heading-and-content" >
<div class="number">0${index + 1}.</div>
<h3 class="heading">${item.heading}</h3>
<p class="content">${item.content}</p>
</div>
</li>
`).join('');
	}

	// Xử lý sự kiện click như code cũ
	const items = document.querySelectorAll('.homenest__quy-trinh-cham-soc-website__item');
	let isClickable = true;

	items.forEach((item, index) => {
		item.addEventListener('click', function() {
			if (!isClickable) return;

			isClickable = false;
			items.forEach(el => el.classList.remove('active'));
			this.classList.add('active');

			// Có thể thêm logic xử lý khi click vào item ở đây
			// Ví dụ: hiển thị nội dung chi tiết hơn ở một phần khác
			console.log('Đã chọn:', quyTrinhContain[index]);

			setTimeout(() => {
				isClickable = true;
			}, 300);
		});
	});

	// Active item đầu tiên khi load trang
	if (items.length > 0) {
		items[0].classList.add('active');
	}
});



document.addEventListener('DOMContentLoaded', function () {
	const items = document.querySelectorAll('.package-item');

	items.forEach(item => {
		const featureList = item.querySelector('.package-features-list');
		const hideList = featureList?.querySelector('.hide-list');
		const seeMoreBtn = item.querySelector('.btn-see-more');

		if (featureList && hideList) {
		const height = hideList.offsetHeight;
		featureList.style.setProperty('--h', height + "px");

		// Thiết lập trạng thái ẩn ban đầu
		hideList.style.height = '0px';
		hideList.style.overflow = 'hidden';
		hideList.style.transition = 'height 0.4s ease';
		}

		if (seeMoreBtn && featureList && hideList) {
		seeMoreBtn.addEventListener('click', function () {
		const isExpanded = featureList.classList.toggle('show');

		hideList.style.height = isExpanded ? `var(--h)` : '0px';
		seeMoreBtn.textContent = isExpanded ? 'Thu gọn' : 'Xem thêm';
	});
}
						  });
});







document.addEventListener("DOMContentLoaded", function () {
	const faqData = [
		{ 
			question: "SEO từ khóa là gì ?", 
			answer: "<h1>Logo thương hiệu là biểu tượng cô đọng của giá trị và bản sắc doanh nghiệp. Nó không chỉ là hình ảnh đại diện mà còn truyền tải thông điệp, sứ mệnh và tinh thần của thương hiệu tới khách hàng. Một logo ấn tượng tạo dấu ấn mạnh mẽ, giúp thương hiệu dễ nhận diện, tạo lòng tin và kết nối cảm xúc với khách hàng. Khi được thiết kế đúng cách, logo sẽ là công cụ đắc lực trong việc xây dựng uy tín và ghi nhớ thương hiệu lâu dài.</h1>" 
		},
		{ 
			question: "Lợi ích của việc SEO từ khóa ?", 
			answer: "Phí gia hạn web hàng năm bao gồm chi phí duy trì tên miền, hosting và các dịch vụ kỹ thuật kèm theo để website hoạt động ổn định." 
		},
		{ 
			question: "Làm SEO từ khóa mất bao lâu để có kết quả ?", 
			answer: "Logo chuyên nghiệp là yếu tố cốt lõi để tạo dựng và nhận diện thương hiệu mạnh mẽ. Một logo được thiết kế chỉn chu không chỉ thu hút ánh nhìn mà còn truyền tải rõ ràng giá trị, cá tính và thông điệp của doanh nghiệp. Nó giúp thương hiệu nổi bật, tạo ấn tượng lâu dài với khách hàng và xây dựng lòng tin một cách hiệu quả. Đồng thời, logo chuyên nghiệp đảm bảo sự linh hoạt khi sử dụng trên các phương tiện khác nhau, từ ấn phẩm quảng cáo đến nền tảng kỹ thuật số, giúp thương hiệu phát triển và thích ứng tốt với thị trường." 
		},
		{ 
			question: "SEO từ khóa có thực sự cần thiết ?", 
			answer: "Hosting là nơi lưu trữ toàn bộ dữ liệu website. Không có hosting thì website không thể hoạt động được trên internet." 
		},
		{ 
			question: "Chi phí cho dịch vụ SEO từ khóa là bao nhiêu ?", 
			answer: "Tên miền là địa chỉ của website trên internet, ví dụ như www.tenmien.com. Nó giúp người dùng truy cập nhanh chóng vào website." 
		},
		{ 
			question: "Tôi có cần cập nhật nội dung thường xuyên khi làm SEO từ khóa ?", 
			answer: "Có. SSL giúp mã hóa dữ liệu giữa người dùng và máy chủ, tăng độ tin cậy và bảo vệ thông tin cá nhân, đặc biệt quan trọng với các website thương mại điện tử." 
		},
		{ 
			question: "Làm SEO từ khóa có rủi ro không ?", 
			answer: "Có. Với hệ thống quản trị nội dung (CMS), bạn có thể dễ dàng cập nhật nội dung mà không cần kiến thức lập trình." 
		},
		{ 
			question: "Làm sao để chọn đúng từ khóa ?", 
			answer: "Chi phí tùy thuộc vào mức độ phức tạp và yêu cầu cụ thể. Bạn có thể liên hệ để được báo giá chi tiết Chi phí tùy thuộc vào mức độ phức tạp và yêu cầu cụ thể. Bạn có thể liên hệ để được báo giá chi tiếtChi phí tùy thuộc vào mức độ phức tạp và yêu cầu cụ thể. Bạn có thể liên hệ để được báo giá chi tiếtChi phí tùy thuộc vào mức độ phức tạp và yêu cầu cụ thể. Bạn có thể liên hệ để được báo giá chi tiếtChi phí tùy thuộc vào mức độ phức tạp và yêu cầu cụ thể. Bạn có thể liên hệ để được báo giá chi tiếtChi phí tùy thuộc vào mức độ phức tạp và yêu cầu cụ thể. Bạn có thể liên hệ để được báo giá chi tiếtChi phí tùy thuộc vào mức độ phức tạp và yêu cầu cụ thể. Bạn có thể liên hệ để được báo giá chi tiếtChi phí tùy thuộc vào mức độ phức tạp và yêu cầu cụ thể. Bạn có thể liên hệ để được báo giá chi tiếtChi phí tùy thuộc vào mức độ phức tạp và yêu cầu cụ thể. Bạn có thể liên hệ để được báo giá chi tiếtChi phí tùy thuộc vào mức độ phức tạp và yêu cầu cụ thể. Bạn có thể liên hệ để được báo giá chi tiếtChi phí tùy thuộc vào mức độ phức tạp và yêu cầu cụ thể. Bạn có thể liên hệ để được báo giá chi tiết." 
		},
		{ 
			question: "Dịch vụ SEO từ khóa có đảm bảo lên Top Google không ?", 
			answer: "Thông thường từ 7-20 ngày làm việc tùy theo mức độ phức tạp và số lượng tính năng yêu cầu." 
		},
		{ 
			question: "SEO từ khóa khác gì so với quảng cáo Google Ads ?", 
			answer: "Có. Website được thiết kế responsive, hiển thị tốt trên mọi thiết bị như điện thoại, máy tính bảng và laptop." 
		},
		{ 
			question: "Khi nào cần thuê dịch vụ SEO từ khóa ?", 
			answer: "Có. Website được thiết kế responsive, hiển thị tốt trên mọi thiết bị như điện thoại, máy tính bảng và laptop." 
		},
	];

	const faqContainer = document.getElementById("homenest__single-service__seo-tu-khoa__faq-container");
	if (!faqContainer) return;

	let openedAnswer = null;
	let openedButton = null;

	faqData.forEach((item, index) => {
		const faqItem = document.createElement("div");
		faqItem.className = "homenest__single-service__seo-tu-khoa__faq-question";

		faqItem.innerHTML = `
			<span class="homenest__single-service__seo-tu-khoa__faq-question-number">
				<span class="text-gradient">${(index + 1).toString().padStart(2, "0")}</span>
			</span>
			<div class="homenest__single-service__seo-tu-khoa__faq-question-header-number">
				<span class="homenest__single-service__seo-tu-khoa__faq-question-label text-gradient">QUESTION - ${(index + 1).toString().padStart(2, "0")}</span>
			</div>
			<div class="homenest__single-service__seo-tu-khoa__faq-question-header">
				<span class="homenest__single-service__seo-tu-khoa__faq-question-title">${item.question}</span>
				<button class="homenest__single-service__seo-tu-khoa__faq-toggle-btn" aria-expanded="false" aria-label="Toggle answer">
					<span>+</span>
				</button>
			</div>
			<div class="homenest__single-service__seo-tu-khoa__faq-answer-wrapper">
				<div class="homenest__single-service__seo-tu-khoa__faq-answer">${item.answer}</div>
			</div>
		`;

		faqContainer.appendChild(faqItem);

		const header = faqItem.querySelector(".homenest__single-service__seo-tu-khoa__faq-question-header");
		const buttonSpan = faqItem.querySelector(".homenest__single-service__seo-tu-khoa__faq-toggle-btn span");
		const button = faqItem.querySelector(".homenest__single-service__seo-tu-khoa__faq-toggle-btn");
		const answerWrapper = faqItem.querySelector(".homenest__single-service__seo-tu-khoa__faq-answer-wrapper");
		const answerWrapper2 = faqItem.querySelector(".homenest__single-service__seo-tu-khoa__faq-answer");

		// 👉 Gán chiều cao thực tế cho biến CSS --height-answer
		const contentHeight = answerWrapper2.scrollHeight;
		answerWrapper2.style.setProperty("--height-answer", `${contentHeight}px`);

		header.addEventListener("click", () => {
			const isOpen = answerWrapper.classList.contains("show");

			// Đóng phần cũ nếu có
			if (openedAnswer && openedAnswer !== answerWrapper) {
				openedAnswer.classList.remove("show");
				openedButton.textContent = "+";
				openedButton.setAttribute("aria-expanded", "false");
			}

			if (!isOpen) {
				answerWrapper.classList.add("show");
				buttonSpan.textContent = "−";
				button.setAttribute("aria-expanded", "true");
				openedAnswer = answerWrapper;
				openedButton = buttonSpan;
			} else {
				answerWrapper.classList.remove("show");
				buttonSpan.textContent = "+";
				button.setAttribute("aria-expanded", "false");
				openedAnswer = null;
				openedButton = null;
			}
		});
	});

	console.log("Câu hỏi thường gặp");
});





// ================================
// Javascript show hide dự án
// ================================

document.addEventListener("DOMContentLoaded", function () {
  const items = document.querySelectorAll(".homenest__single-services__seo-tu-khoa__project-item");
  const btn = document.querySelector(".homenest__single-services__seo-tu-khoa__btn-see");
  let visibleCount = 6;

  // Ẩn từ phần tử thứ 7 trở đi
  items.forEach((item, index) => {
    if (index >= visibleCount) {
      item.style.display = "none";
    }
  });

  // Xử lý khi click nút "Xem thêm"
  btn?.addEventListener("click", function (e) {
    e.preventDefault();
    const nextVisible = visibleCount + 6;
    for (let i = visibleCount; i < nextVisible && i < items.length; i++) {
      items[i].style.display = "";
    }
    visibleCount = nextVisible;

    // Nếu đã hiện hết thì ẩn nút
    if (visibleCount >= items.length) {
      btn.style.display = "none";
    }
  });
});








(function initTestimonialCarousel() {
	function initCarousel() {
		const container = document.querySelector(".testimonial-carousell");
		if (!container) {
			console.log("Waiting for testimonial carousel element...");
			setTimeout(initCarousel, 100);
			return;
		}

		const circleContainer = container.querySelector(".testimonial-circle-container"); // Changed from .circle-container
		const scrollContainer = container.querySelector(".scroll-container");
		const scrollIndicator = container.querySelector(".scroll-indicator");
		const sections = container.querySelectorAll(".section");

		if (!circleContainer || !sections.length) {
			console.log("Waiting for carousel elements...");
			setTimeout(initCarousel, 100);
			return;
		}

		let currentRotation = 0;
		let targetRotation = 0;
		let activeIndex = 0;
		let scrolling = false;
		let lastScrollTime = 0;
		let scrollTimeout;
		let animationFrame;
		let lastScrollPos = 0;
		let isAnimating = false;
		const ANIMATION_DURATION = 600; // Increased from 500ms to 600ms
		const SCROLL_DELAY = 600; // Increased from 500ms to 600ms
		const radius = 400;
		const angleIncrement = 360 / sections.length;

		function isMobile() {
			return window.innerWidth <= 768;
		}

		function updateSections() {
			// First remove active class from all sections
			sections.forEach((section) => section.classList.remove("active"));

			requestAnimationFrame(() => {
				sections.forEach((section, index) => {
					const relativePosToActive = (index - activeIndex + sections.length) % sections.length;
					section.style.display = "block";

					let y = 0;
					let x = 0;
					let opacity = 0;
					let scale = 1;
					let zIndex = 0;
					section.classList.remove("clickable");

					if (isMobile()) {
						switch (relativePosToActive) {
							case 0:
								y = 0;
								x = 30;
								opacity = 1;
								scale = 1;
								zIndex = 4;
								break;
							case 1:
								y = 160;
								x = 0;
								opacity = 0.9;
								scale = 0.95;
								zIndex = 3;
								section.classList.add("clickable");
								break;
							case sections.length - 1:
								y = -160;
								x = 0;
								opacity = 0.9;
								scale = 0.95;
								zIndex = 3;
								section.classList.add("clickable");
								break;
							case 2:
								y = 0;
								x = -40;
								opacity = 0.2;
								scale = 0.8;
								zIndex = 1;
								break;
						}
					} else {
						switch (relativePosToActive) {
							case 0:
								y = 0;
								x = 50;
								opacity = 1;
								scale = 1;
								zIndex = 4;
								break;
							case 1:
								y = 170;
								x = 0;
								opacity = 0.9;
								scale = 0.95;
								zIndex = 3;
								section.classList.add("clickable");
								break;
							case sections.length - 1:
								y = -170;
								x = 0;
								opacity = 0.9;
								scale = 0.95;
								zIndex = 3;
								section.classList.add("clickable");
								break;
							case 2:
								y = 0;
								x = -100;
								opacity = 0.2;
								scale = 0.8;
								zIndex = 1;
								break;
						}
					}

					// Apply transforms first
					requestAnimationFrame(() => {
						section.style.transform = `translate(${x}px, calc(-50% + ${y}px)) scale(${scale})`;
						section.style.opacity = opacity;
						section.style.zIndex = zIndex;

						// Add active class with a small delay for smooth transition
						if (relativePosToActive === 0) {
							setTimeout(() => {
								section.classList.add("active");
							}, 50);
						}
					});
				});
			});
		}

		function handleScroll() {
			if (isAnimating) return;
			const scrollPosition = scrollContainer.scrollTop;
			const scrollDelta = scrollPosition - lastScrollPos;
			if (Math.abs(scrollDelta) > 20) {
				const direction = scrollDelta > 0 ? 1 : -1;
				queueScroll(direction);
			}
			lastScrollPos = scrollPosition;
		}

		function queueScroll(direction) {
			if (isAnimating) return;
			isAnimating = true;

			// Add delay before starting animation
			setTimeout(() => {
				activeIndex = (activeIndex + direction + sections.length) % sections.length;
				updateSections();

				setTimeout(() => {
					isAnimating = false;
				}, ANIMATION_DURATION + 50);
			}, 50);
		}

		// Add click handler for sections
		sections.forEach((section, index) => {
			section.addEventListener("click", () => {
				if (isAnimating || !section.classList.contains("clickable")) return;

				const currentIndex = parseInt(section.dataset.index);
				const direction = currentIndex > activeIndex ? (currentIndex - activeIndex <= sections.length / 2 ? 1 : -1) : activeIndex - currentIndex <= sections.length / 2 ? -1 : 1;
				queueScroll(direction);
			});
		});

		// Initialize
		try {
			sections.forEach((section, index) => {
				section.dataset.index = index;
			});
			circleContainer.style.transformOrigin = `center center -${radius}px`;

			// Add error handling to event listeners
			scrollContainer.addEventListener("scroll", () => {
				try {
					const now = Date.now();
					if (now - lastScrollTime > 50) {
						handleScroll();
						lastScrollTime = now;
					} else {
						clearTimeout(scrollTimeout);
						scrollTimeout = setTimeout(handleScroll, 50);
					}
				} catch (error) {
					console.error("Scroll handler error:", error);
				}
			});

			scrollContainer.addEventListener(
				"wheel",
				(e) => {
					e.preventDefault();
					if (isAnimating) return;
					const direction = e.deltaY > 0 ? 1 : -1;
					queueScroll(direction);
				},
				{ passive: false }
			);

			const scrollHeight = window.innerHeight * 2;
			const dummy = document.createElement("div");
			dummy.style.height = `${scrollHeight}px`;
			scrollContainer.appendChild(dummy);

			function initializeSections() {
				document.body.classList.add("init-transitions");
				updateSections();
				void document.body.offsetHeight;
				document.body.classList.remove("init-transitions");
			}

			initializeSections();

			window.addEventListener("unload", () => {
				cancelAnimationFrame(animationFrame);
			});
		} catch (error) {
			console.error("Carousel initialization error:", error);
			setTimeout(initCarousel, 100);
		}
	}

	// Start initialization
	if (document.readyState === "loading") {
		document.addEventListener("DOMContentLoaded", initCarousel);
	} else {
		initCarousel();
	}

	window.addEventListener("resize", updateSections);
})();









