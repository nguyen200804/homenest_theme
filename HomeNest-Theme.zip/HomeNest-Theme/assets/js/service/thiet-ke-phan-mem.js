const img = document.querySelector('.rated-img-parallax');
let baseTop = 0;

if (img) {
    // Lưu vị trí gốc của ảnh
    baseTop = img.getBoundingClientRect().top + window.scrollY;
    window.addEventListener('scroll', function () {
        // Lấy vị trí cuộn trang
        const scrollY = window.scrollY || window.pageYOffset;
        // Tính khoảng cách dịch chuyển, nhỏ thôi (ví dụ 0.08)
        const offset = (scrollY - baseTop + 300) * 0.08;
        img.style.transform = `translateY(${offset}px)`;
    });
}
const img2 = document.querySelector('.card-img-overlay-2');
const img3 = document.querySelector('.card-img-overlay-3');


if (img2 && img3) {
    // Lưu vị trí gốc của container
    const container = document.querySelector('.manage-cards-image-container');
    baseTop = container.getBoundingClientRect().top + window.scrollY;

    window.addEventListener('scroll', function () {
        // Lấy vị trí cuộn trang
        const scrollY = window.scrollY || window.pageYOffset;
        // Tính offset dựa trên vị trí cuộn
        const offset = (scrollY - baseTop) * 0.1; // Nhân với 0.1 để hiệu ứng mượt mà

        // card-img-2: Thụt vào (trái) khi cuộn lên, lòi ra (phải) khi cuộn xuống
        img2.style.transform = `translateX(${Math.max(-50, Math.min(0, -offset))}px)`;

        // card-img-3: Lòi ra (phải) khi cuộn lên, thụt vào (trái) khi cuộn xuống
        img3.style.transform = `translateX(${Math.max(-50, Math.min(0, offset))}px)`;
    });
}

// Testimonial Carousel Stack Effect (3 card hiển thị)
document.addEventListener('DOMContentLoaded', function () {
    const cards = document.querySelectorAll('.testi-card');
    const prevBtn = document.querySelector('.testi-btn-prev');
    const nextBtn = document.querySelector('.testi-btn-next');
    let current = 0;

    function updateClasses() {
        cards.forEach((card, i) => {
            card.classList.remove('active', 'prev', 'next');
        });
        cards[current].classList.add('active');
        if (cards.length > 1) {
            cards[(current - 1 + cards.length) % cards.length].classList.add('prev');
            cards[(current + 1) % cards.length].classList.add('next');
        }
    }

    updateClasses();

    nextBtn.addEventListener('click', function () {
        current = (current + 1) % cards.length;
        updateClasses();
    });

    prevBtn.addEventListener('click', function () {
        current = (current - 1 + cards.length) % cards.length;
        updateClasses();
    });

    // Drag to change testimonial (giống olddg.html ngưỡng)
    const carouselEl = document.querySelector('.testi-carousel');
    if (carouselEl && cards.length) {
      let isDragging = false;
      let startX = 0;
      let currentX = 0;

      const getX = (e) => (e.touches ? e.touches[0].clientX : e.clientX);

      const onDown = (e) => {
        isDragging = true;
        startX = getX(e);
        // tắt transition trong lúc kéo (nếu muốn)
        cards.forEach(c => c.style.transition = 'none');
      };

      const onMove = (e) => {
        if (!isDragging) return;
        currentX = getX(e);
        // Có thể thêm hiệu ứng kéo nhẹ nếu muốn, còn nếu không thì bỏ trống để chỉ xét threshold khi nhả
      };

      const onUp = () => {
        if (!isDragging) return;
        isDragging = false;
        const dx = currentX - startX;
        const threshold = 40; // px: kéo quá ngưỡng mới đổi card

        // khôi phục transition
        cards.forEach(c => c.style.transition = '');

        if (dx < -threshold) {
          // kéo sang trái → next
          current = (current + 1) % cards.length;
          updateClasses();
        } else if (dx > threshold) {
          // kéo sang phải → prev
          current = (current - 1 + cards.length) % cards.length;
          updateClasses();
        } else {
          // không đủ ngưỡng → giữ nguyên
          updateClasses();
        }
      };

      // Mouse
      carouselEl.addEventListener('mousedown', onDown);
      window.addEventListener('mousemove', onMove);
      window.addEventListener('mouseup', onUp);

      // Touch
      carouselEl.addEventListener('touchstart', onDown, { passive: true });
      window.addEventListener('touchmove', onMove, { passive: true });
      window.addEventListener('touchend', onUp);
    }
});
// btn-custom-blue
document.querySelectorAll('.btn-custom-blue').forEach(function (btn) {
    let animFrame, radius = 0, maxRadius = 300;
    btn.addEventListener('mousemove', function (e) {
        const rect = btn.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        btn.style.setProperty('--x', x + 'px');
        btn.style.setProperty('--y', y + 'px');
    });
    btn.addEventListener('mouseenter', function () {
        radius = 0;
        btn.style.setProperty('--radius', radius + 'px');
        cancelAnimationFrame(animFrame);
        function grow() {
            radius += 10; // tốc độ lan
            btn.style.setProperty('--radius', radius + 'px');
            if (radius < maxRadius) {
                animFrame = requestAnimationFrame(grow);
            }
        }
        grow();
    });
    btn.addEventListener('mouseleave', function () {
        cancelAnimationFrame(animFrame);
        function shrink() {
            radius -= 2; // tốc độ thu nhỏ chậm
            btn.style.setProperty('--radius', radius + 'px');
            if (radius > 0) {
                animFrame = requestAnimationFrame(shrink);
            }
        }
        shrink();
    });
});
// btn-rated
document.querySelectorAll('.btn-rate').forEach(function (btn) {
    let animFrame, radius = 0, maxRadius = 300;
    btn.addEventListener('mousemove', function (e) {
        const rect = btn.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        btn.style.setProperty('--x', x + 'px');
        btn.style.setProperty('--y', y + 'px');
    });
    btn.addEventListener('mouseenter', function () {
        radius = 0;
        btn.style.setProperty('--radius', radius + 'px');
        cancelAnimationFrame(animFrame);
        function grow() {
            radius += 10; // tốc độ lan
            btn.style.setProperty('--radius', radius + 'px');
            if (radius < maxRadius) {
                animFrame = requestAnimationFrame(grow);
            }
        }
        grow();
    });
    btn.addEventListener('mouseleave', function () {
        cancelAnimationFrame(animFrame);
        function shrink() {
            radius -= 2; // tốc độ thu nhỏ chậm
            btn.style.setProperty('--radius', radius + 'px');
            if (radius > 0) {
                animFrame = requestAnimationFrame(shrink);
            }
        }
        shrink();
    });
});
document.addEventListener('DOMContentLoaded', function () {
    var desc = document.querySelector('.hero-desc-animate');
    if (desc) {
        var html = desc.innerHTML;
        var chars = [];
        for (let i = 0; i < html.length; i++) {
            if (html[i] === '<') {
                // Giữ nguyên thẻ <br>
                let tag = '';
                while (i < html.length && html[i] !== '>') {
                    tag += html[i];
                    i++;
                }
                tag += '>';
                chars.push(tag);
            } else {
                chars.push(html[i]);
            }
        }
        desc.innerHTML = '';
        let delay = 0;
        chars.forEach(function (char) {
            if (char.startsWith && char.startsWith('<br')) {
                desc.innerHTML += char;
            } else if (char === ' ') {
                desc.innerHTML += ' ';
            } else {
                var span = document.createElement('span');
                span.textContent = char;
                span.style.animationDelay = (delay * 0.045) + 's';
                delay++;
                desc.appendChild(span);
            }
        });
    }
    var logoWrap = document.querySelector('.platform-logos-animate');
    if (logoWrap) {
        var logos = logoWrap.querySelectorAll('.logo-link');
        logos.forEach(function (logo, i) {
            logo.style.animationDelay = (i * 0.12) + 's';
        });
    }
    var btns = document.querySelectorAll('.btn-animate-up');
    btns.forEach(function (btn, i) {
        btn.style.animationDelay = (i * 0.13) + 's';
    });
    // Hiệu ứng khi cuộn tới mới animate
    function animateOnView(selector, cb) {
        var els = document.querySelectorAll(selector);
        if (!('IntersectionObserver' in window)) {
            els.forEach(el => {
                el.classList.add('animate');
                if (cb) cb(el, 0);
            });
            return;
        }
        var observer = new IntersectionObserver(function (entries, observer) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate');
                    if (cb) cb(entry.target, Array.from(els).indexOf(entry.target));
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.2 });
        els.forEach(function (el, i) {
            observer.observe(el);
        });
    }
    animateOnView('.title-slide-left');
    animateOnView('.btn-slide-right');
    animateOnView('.card-slide-left');
    animateOnView('.card-slide-right');
    // Card dưới: set delay lần lượt
    var upCards = document.querySelectorAll('.card-slide-up');
    upCards.forEach(function (card, i) {
        card.style.setProperty('--card-delay', (0.15 * i + 0.1) + 's');
    });
    animateOnView('.card-slide-up');
    animateOnView('.slide-up-on-scroll');
});
