// Thêm event listener cho hiệu ứng ripple
document.addEventListener('DOMContentLoaded', function () {

  const canvas = document.getElementById("homenest__website-design__section2--canvas");
  const ctx = canvas.getContext("2d");

  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;

  let particles = [];
  const numberOfParticles = 200;
  const mouse = {
    x: null,
    y: null,
    radius: 150
  };

  // Define gradient colors array
  const gradientColors = ["#ff6b6b", "#4ecdc4", "#45b7d1", "#96c93d"];

  class Particle {
    constructor() {
      this.x = Math.random() * canvas.width;
      this.y = Math.random() * canvas.height;
      this.size = Math.random() * 2 + 0.5; // Slightly smaller particles
      this.baseX = this.x;
      this.baseY = this.y;
      this.density = Math.random() * 30 + 1;
      this.color =
        gradientColors[Math.floor(Math.random() * gradientColors.length)];
      this.alpha = Math.random() * 0.5 + 0.5; // Add transparency
    }

    draw() {
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
      ctx.closePath();
      ctx.fillStyle = this.color;
      ctx.globalAlpha = this.alpha;
      ctx.fill();
      ctx.globalAlpha = 1;
    }

    update() {
      let dx = mouse.x - this.x;
      let dy = mouse.y - this.y;
      let distance = Math.sqrt(dx * dx + dy * dy);
      let forceDirectionX = dx / distance;
      let forceDirectionY = dy / distance;
      let maxDistance = mouse.radius;
      let force = (maxDistance - distance) / maxDistance;
      let directionX = forceDirectionX * force * this.density;
      let directionY = forceDirectionY * force * this.density;

      if (distance < mouse.radius) {
        this.x -= directionX;
        this.y -= directionY;
      } else {
        if (this.x !== this.baseX) {
          let dx = this.x - this.baseX;
          this.x -= dx / 10;
        }
        if (this.y !== this.baseY) {
          let dy = this.y - this.baseY;
          this.y -= dy / 10;
        }
      }
    }
  }

  function init() {
    particles = [];
    for (let i = 0; i < numberOfParticles; i++) {
      particles.push(new Particle());
    }
  }

  function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    for (let i = 0; i < particles.length; i++) {
      particles[i].update();
      particles[i].draw();
    }
    requestAnimationFrame(animate);
  }

  window.addEventListener("mousemove", (e) => {
    mouse.x = e.x;
    mouse.y = e.y;
  });

  window.addEventListener("resize", () => {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    init();
  });

  window.addEventListener("mouseout", () => {
    mouse.x = undefined;
    mouse.y = undefined;
  });

  init();
  animate();


  const p = document.getElementById('homenest__website-design__section1__hover-text');
  const text = p.textContent;
  const images = [
    '/wp-content/uploads/2025/05/popup-1.webp',
    '/wp-content/uploads/2025/05/popup-2.png',
    '/wp-content/uploads/2025/05/popup-3.webp',
    '/wp-content/uploads/2025/05/popup-4.webp',
    '/wp-content/uploads/2025/05/popup-5.webp',
    '/wp-content/uploads/2025/05/popup-6.webp',
    '/wp-content/uploads/2025/05/popup-7.png',
    '/wp-content/uploads/2025/05/popup-8.webp'
  ];

  p.textContent = ''; // Clear original text

  [...text].forEach((char, i) => {
    const span = document.createElement('span');
    span.className = 'homenest__website-design__section1--letter';
    span.textContent = char;

    const popup = document.createElement('img');
    popup.className = 'homenest__website-design__section1--popup-image';
    popup.src = images[i];

    // Update position randomly on every hover
    span.addEventListener('mouseenter', () => {
      const offsetX = Math.random() * 100 - 50; // -50px to +50px
      const offsetY = Math.random() * 100 - 50;
      popup.style.left = `${offsetX}px`;
      popup.style.top = `${offsetY}px`;
    });

    span.appendChild(popup);
    p.appendChild(span);
  });



  // Lấy các elements
  const openPopupBtn = document.getElementById('open-popup-video');
  const popupOverlay = document.getElementById('popup-overlay');
  const closePopupBtn = document.getElementById('close-popup');
  const videoFrame = document.getElementById('video-frame');

  // Mở popup
  openPopupBtn.addEventListener('click', function (e) {
    e.preventDefault();

    // Lấy URL video từ data attribute
    const videoUrl = this.getAttribute('data-video-url');

    // Set video URL vào iframe
    videoFrame.src = videoUrl;

    // Hiển thị popup
    popupOverlay.classList.add('active');

    // Ngăn scroll của body
    document.body.style.overflow = 'hidden';
  });

  // Đóng popup
  function closePopup() {
    popupOverlay.classList.remove('active');

    // Dừng video bằng cách xóa src
    videoFrame.src = '';

    // Cho phép scroll lại
    document.body.style.overflow = 'auto';
  }

  // Đóng popup khi nhấn nút X
  closePopupBtn.addEventListener('click', closePopup);

  // Đóng popup khi nhấn vào overlay
  popupOverlay.addEventListener('click', function (e) {
    if (e.target === this) {
      closePopup();
    }
  });

  // Đóng popup khi nhấn ESC
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && popupOverlay.classList.contains('active')) {
      closePopup();
    }
  });



  function animateDigitsOnScroll() {
    const counters = document.querySelectorAll('.homenest__website-design__section5--title-num-count .digit');

    counters.forEach(digit => {
      const value = parseInt(digit.dataset.value);
      // if (value === 0) return; // không cần anim cho số 0

      const digitHeight = digit.children[0].offsetHeight;

      const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            digit.style.transform = `translateY(-${digitHeight * value}px)`;
            observer.unobserve(entry.target); // chỉ chạy 1 lần
          }
        });
      }, { threshold: 0.5 });

      observer.observe(digit);
    });
  }

  window.addEventListener('DOMContentLoaded', animateDigitsOnScroll);

  function animateDigitsOnScrollSection7() {
    const counters = document.querySelectorAll('.homenest__website-design__section7--title-num-count .digit');

    counters.forEach(digit => {
      const value = parseInt(digit.dataset.value);
      // if (value === 0) return; // không cần anim cho số 0

      const digitHeight = digit.children[0].offsetHeight;

      const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            digit.style.transform = `translateY(-${digitHeight * value}px)`;
            observer.unobserve(entry.target); // chỉ chạy 1 lần
          }
        });
      }, { threshold: 0.5 });

      observer.observe(digit);
    });
  }

  window.addEventListener('DOMContentLoaded', animateDigitsOnScrollSection7);

const toggleBtn = document.querySelector('.open-tooltip');
  const tooltip = document.querySelector('.section7__footer--tooltip');
  const mainContent = document.querySelector('.homenest__website-design__section7--footer-main-content');

  // FIX: Kiểm tra elements tồn tại
  if (!toggleBtn || !tooltip || !mainContent) {
    console.error('Required elements not found');
    return;
  }

  function openTooltip() {
    tooltip.classList.add('active');
    mainContent.classList.add('hidden');
    toggleBtn.classList.add('active'); // FIX: Thêm class active cho nút
  }

  function closeTooltip() {
    tooltip.classList.remove('active');
    mainContent.classList.remove('hidden');
    toggleBtn.classList.remove('active'); // FIX: Remove class active
  }

  // FIX: Cải thiện event listener
  toggleBtn.addEventListener('click', function (e) {
    e.preventDefault();
    e.stopPropagation();

    if (tooltip.classList.contains('active')) {
      closeTooltip();
    } else {
      openTooltip();
    }
  });

  // FIX: Thêm khả năng đóng tooltip khi click outside
  document.addEventListener('click', function (e) {
    if (tooltip.classList.contains('active') &&
      !tooltip.contains(e.target) &&
      !toggleBtn.contains(e.target)) {
      closeTooltip();
    }
  });

  // FIX: Thêm khả năng đóng bằng phím ESC
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && tooltip.classList.contains('active')) {
      closeTooltip();
    }
  });
	
	
	
  const marqueeItems = document.querySelectorAll('.intigration-marquee');
  marqueeItems.forEach(item => {
    const div = item.querySelector('.intigration-container');
    if (div) {
      // Lấy width và gán vào --width
      const width = div.offsetWidth;
      item.style.setProperty('--width', `${width}px`);

      // Sao chép phần tử div
      const divClone = div.cloneNode(true); // true để sao chép cả nội dung bên trong
      item.appendChild(divClone); // Thêm bản sao vào .marquee-item
    }
  });
	
	
	// 5. FAQ Toggle
  // Lấy tất cả các FAQ items
  const faqItems = document.querySelectorAll('.faq-item');

  // Hàm helper để đóng một FAQ item
  function closeFAQItem(faqItem) {
    const answer = faqItem.querySelector('.answer');
    const button = faqItem.querySelector('.toggle-button');

    answer.style.maxHeight = '0';
    answer.style.opacity = '0';
    answer.style.paddingTop = '0';

    button.textContent = '+';
    button.classList.remove('minus');
    faqItem.classList.remove('active');

    setTimeout(() => {
      answer.classList.add('hidden');
    }, 400);
  }

  // Hàm helper để mở một FAQ item
  function openFAQItem(faqItem) {
    const answer = faqItem.querySelector('.answer');
    const button = faqItem.querySelector('.toggle-button');

    answer.classList.remove('hidden');
    answer.style.maxHeight = answer.scrollHeight + 'px';
    answer.style.opacity = '1';
    answer.style.paddingTop = '15px';

    button.textContent = '−';
    button.classList.add('minus');
    faqItem.classList.add('active');
  }

  faqItems.forEach(item => {
    const toggleButton = item.querySelector('.toggle-button');
    const answer = item.querySelector('.answer');
    const question = item.querySelector('.question');

    // Thiết lập initial state cho answers
    if (answer.classList.contains('hidden')) {
      answer.style.maxHeight = '0';
      answer.style.opacity = '0';
      answer.style.overflow = 'hidden';
      answer.style.transition = 'max-height 0.4s ease-in-out, opacity 0.3s ease-in-out, padding 0.3s ease-in-out';
    } else {
      // Nếu answer đang hiển thị (như question 01)
      answer.style.maxHeight = answer.scrollHeight + 'px';
      answer.style.opacity = '1';
      answer.style.transition = 'max-height 0.4s ease-in-out, opacity 0.3s ease-in-out, padding 0.3s ease-in-out';
    }

    // Xử lý sự kiện click
    toggleButton.addEventListener('click', function () {
      const isHidden = answer.classList.contains('hidden');

      if (isHidden) {
        // Đóng tất cả các FAQ items khác trước
        faqItems.forEach(otherItem => {
          if (otherItem !== item) {
            const otherAnswer = otherItem.querySelector('.answer');
            const otherButton = otherItem.querySelector('.toggle-button');

            if (!otherAnswer.classList.contains('hidden')) {
              // Ẩn answer khác
              otherAnswer.style.maxHeight = '0';
              otherAnswer.style.opacity = '0';
              otherAnswer.style.paddingTop = '0';

              // Đổi button từ - thành +
              otherButton.textContent = '+';
              otherButton.classList.remove('minus');

              // Remove class active
              otherItem.classList.remove('active');

              // Thêm hidden class sau khi animation hoàn tất
              setTimeout(() => {
                otherAnswer.classList.add('hidden');
              }, 400);
            }
          }
        });

        // Hiển thị answer hiện tại sau delay nhỏ để animation mượt hơn
        setTimeout(() => {
          answer.classList.remove('hidden');
          answer.style.maxHeight = answer.scrollHeight + 'px';
          answer.style.opacity = '1';
          answer.style.paddingTop = '0px';

          // Đổi button từ + thành -
          toggleButton.textContent = '−';
          toggleButton.classList.add('minus');

          // Thêm class active cho styling
          item.classList.add('active');
        }, 200);

      } else {
        // Ẩn answer hiện tại
        answer.style.maxHeight = '0';
        answer.style.opacity = '0';
        answer.style.paddingTop = '0';

        // Đổi button từ - thành +
        toggleButton.textContent = '+';
        toggleButton.classList.remove('minus');

        // Remove class active
        item.classList.remove('active');

        // Thêm hidden class sau khi animation hoàn tất
        setTimeout(() => {
          answer.classList.add('hidden');
        }, 400);
      }
    });

    // Thêm hover effect cho question
    question.addEventListener('mouseenter', function () {
      question.style.transform = 'translateX(1px)';
      question.style.transition = 'transform 0.2s ease';
    });

    question.addEventListener('mouseleave', function () {
      question.style.transform = 'translateX(0)';
    });
  });

  // Thêm animation cho animated text header
  const animatedText = document.getElementById('animatedText');
  if (animatedText) {
    // Typing effect
    const text = animatedText.textContent;
    animatedText.textContent = '';
    let i = 0;

    function typeWriter() {
      if (i < text.length) {
        animatedText.textContent += text.charAt(i);
        i++;
        setTimeout(typeWriter, 100);
      }
    }

    // Bắt đầu typing effect sau 500ms
    setTimeout(typeWriter, 500);
  }

  // Smooth scroll animation khi page load
  const faqContainer = document.querySelector('.homenest__web-design__popular-question');
  if (faqContainer) {
    faqContainer.style.opacity = '0';
    faqContainer.style.transform = 'translateY(30px)';
    faqContainer.style.transition = 'opacity 0.6s ease, transform 0.6s ease';

    setTimeout(() => {
      faqContainer.style.opacity = '1';
      faqContainer.style.transform = 'translateY(0)';
    }, 200);
  }
	
	//Thêm hiệu ứng xuất hiện của các element
  const animatedElements = document.querySelectorAll('.fadeInLeft-Webdesign, .fadeInUp-Webdesign, .fadeInRight-Webdesign');

  function handleScroll() {
    animatedElements.forEach(el => {
      const rect = el.getBoundingClientRect();
      if (rect.top <= window.innerHeight * 0.9) {
        el.classList.add('active');
      }
    });
  }

  window.addEventListener('scroll', handleScroll);
  window.addEventListener('load', handleScroll);

	
	
	
});







/**
 * Bảng giá thiết kế website
 * Hàm để render các thẻ giá và xử lý sự kiện
 */
function initializePricingCards() {
    // 1. Kiểm tra dữ liệu đầu vào
    if (typeof pricingPlans === 'undefined' || !Array.isArray(pricingPlans)) {
        console.error("Mảng 'pricingPlans' chưa được định nghĩa hoặc không phải là mảng.");
        return;
    }

    const container = document.querySelector(
        ".homenest__professional_website_hn-pricing-cards"
    );

    if (!container) return;

    // 2. Hàm hỗ trợ để tạo cấu trúc HTML cho mỗi thẻ giá
    const createCardHTML = (plan) => {
        // Tạo danh sách các tính năng hiển thị
        const visibleFeaturesHTML = plan.features
            .map((f) => `<li>${f}</li>`)
            .join("");

        // Tạo danh sách các tính năng ẩn
        const hiddenFeaturesHTML = plan.hiddenFeatures
            .map((f) => `<li>${f}</li>`)
            .join("");

        // Cấu trúc HTML hoàn chỉnh cho thẻ
        return `
            <div class="homenest__professional_website_hn-card__header">${plan.tag}</div>
            <div style="display: flex; flex-direction: column; gap: 20px; margin-top: 10px; margin-bottom: 10px;">
                <div style="margin-top: 10px; margin-bottom: 10px;">
                    <p>
                        <span class="homenest__professional_website_black_normal" style="font-weight: 300;">
                            <span style="color: ${plan.color}; font-weight: bold;">${plan.title}</span> ${plan.description}
                        </span>
                    </p>
                </div>
                <div class="homenest__professional_website_elementor-divider">
                    <span class="homenest__professional_website_elementor-divider-separator"></span>
                </div>
            </div>
            <div class="homenest__professional_website_hn-card__body">
                <ul class="homenest__professional_website_hn-card__features" style="margin-top: 20px; margin-bottom: 20px;">
                    ${visibleFeaturesHTML}
                    <span class="homenest__professional_website_hn-card_hidden-features" style="max-height: 0; overflow: hidden; display: flex; flex-direction: column; transition: max-height 0.3s ease-in-out;">
                        ${hiddenFeaturesHTML}
                    </span>
                    <li><a href="#" class="homenest__professional_website_hn-card__link">${textViewMore}</a></li>
                </ul>
            </div>
            <div style="display: flex; flex-direction: column; gap: 20px; margin-top: 10px; margin-bottom: 10px;">
                <div class="homenest__professional_website_elementor-divider">
                    <span class="homenest__professional_website_elementor-divider-separator"></span>
                </div>
                <p class="homenest__professional_website_black_normal" > ${textQuote}</p>
                <div class="homenest__professional_website_hn-card__footer">
                    <button class="homenest__professional_website_hn-card__button">
                        <div style="display: flex; justify-content: center; align-items: center; margin: 0 auto;">
                            <img src="https://homenest.media/wp-content/uploads/2025/02/Icon-Call-Homenest.media_.svg" alt="Icon Call">
                        </div>
                    </button>
                    <div class="homenest__professional_website_hn-card__price">
                        <p class="homenest__professional_website_hn-card__price_price-text">${plan.price}</p>
                        <p class="homenest__professional_website_hn-card__price_hover-text">${textConsult}</p>
                    </div>
                </div>
            </div>
        `;
    };

    // 3. Render các thẻ giá
    pricingPlans.forEach((plan) => {
        const card = document.createElement("div");
        card.className = `homenest__professional_website_hn-card homenest__professional_website_hn-card--${plan.typeClass}`;
        card.innerHTML = createCardHTML(plan);
        container.appendChild(card);
    });

    // 4. Xử lý sự kiện click "Xem thêm/Thu hồi"
    container.addEventListener("click", function (e) {
        if (e.target.matches(".homenest__professional_website_hn-card__link")) {
            e.preventDefault();
            const link = e.target;
            const featureList = link.closest("ul");
            const hiddenFeatures = featureList.querySelector(
                ".homenest__professional_website_hn-card_hidden-features"
            );

            // Kiểm tra trạng thái hiện tại (maxHeight === "" hoặc "0px" là trạng thái thu gọn)
            const isCollapsed =
                hiddenFeatures.style.maxHeight === "" ||
                hiddenFeatures.style.maxHeight === "0px";

            if (isCollapsed) {
                // Mở rộng: đặt maxHeight bằng chiều cao thực tế của nội dung
                hiddenFeatures.style.maxHeight = hiddenFeatures.scrollHeight + "px";
                link.textContent = textCollapse;
            } else {
                // Thu gọn: đặt maxHeight về 0
                hiddenFeatures.style.maxHeight = "0";
                link.textContent = textViewMore;
            }
        }
    });
}

/**
 * Hàm xử lý cuộn thẻ (được giữ lại từ code gốc)
 */
function scrollCards(direction) {
	const container = document.querySelector(
		".homenest__professional_website_hn-pricing-cards-wrapper"
	);
	const card = document.querySelector(
		".homenest__professional_website_hn-card"
	);

	if (!card || !container) return;

	// Điều chỉnh dựa trên chiều rộng thẻ và khoảng cách (24px)
	const cardWidth = card.offsetWidth + 24; 
	container.scrollBy({
		left: direction * cardWidth,
		behavior: "smooth",
	});
}

// Chạy hàm render khi DOM đã được tải hoàn chỉnh
document.addEventListener("DOMContentLoaded", initializePricingCards);