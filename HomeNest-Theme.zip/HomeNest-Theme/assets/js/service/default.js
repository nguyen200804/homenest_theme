document.addEventListener('DOMContentLoaded', () => {
	const itemsFaq = document.querySelectorAll('ul.list-faq > li .content .text');
	itemsFaq.forEach(itemFaq => {
		const height = itemFaq.offsetHeight;
		itemFaq.style.setProperty('--h', `${height}px`);
		itemFaq.style.height = '0px';
	});

	const headersFaq = document.querySelectorAll('ul.list-faq > li .content h3');
	headersFaq.forEach(headerFaq => {
		headerFaq.addEventListener('click', () => {
			// Xóa class active khỏi tất cả h3
			headersFaq.forEach(h => h.classList.remove('active'));
			// Thêm class active cho h3 được click
			headerFaq.classList.add('active');
		});
	});



	// 	Marquee brands
	const marqueeItems = document.querySelectorAll('.marquee-item');
	marqueeItems.forEach(item => {
		const div = item.querySelector('div');
		if (div) {
			// Lấy width và gán vào --width
			const width = div.offsetWidth;
			item.style.setProperty('--width', `${width}px`);

			// Sao chép phần tử div
			const divClone = div.cloneNode(true); // true để sao chép cả nội dung bên trong
			item.appendChild(divClone); // Thêm bản sao vào .marquee-item
		}
	});
});