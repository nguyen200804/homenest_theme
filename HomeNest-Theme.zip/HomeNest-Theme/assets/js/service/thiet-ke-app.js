document.addEventListener('DOMContentLoaded', function() {
	function wrapChars() {
		const lines = document.querySelectorAll(".line");
		lines.forEach((line) => {
			const chars = line.textContent.split("");
			line.innerHTML = chars
				.map((c) => `<span class="char">${c === " " ? "&nbsp;" : c}</span>`)
				.join("");
		});
	}

	function handleScroll() {
		const chars = document.querySelectorAll(".char");
		const textBlock = document.getElementById("revealText");
		const rect = textBlock.getBoundingClientRect();
		const windowHeight = window.innerHeight;

		const blockTop = rect.top;
		const blockHeight = rect.height;

		const progress = Math.min(
			Math.max((windowHeight - blockTop) / (windowHeight + blockHeight), 0),
			1
		);

		const totalChars = chars.length;
		const charsToReveal = Math.floor(progress * totalChars);

		chars.forEach((char, index) => {
			if (index < charsToReveal) {
				char.classList.add("revealed");
			} else {
				char.classList.remove("revealed");
			}
		});
	}

	wrapChars();
	handleScroll();

	let ticking = false;
	window.addEventListener("scroll", () => {
		if (!ticking) {
			requestAnimationFrame(() => {
				handleScroll();
				ticking = false;
			});
			ticking = true;
		}
	});
	const faqItems = document.querySelectorAll(".homenest_nexux_section7_faq_item");

	faqItems.forEach((item) => {
		const icon = item.querySelector(".homenest_nexux_section7_faq_icon");

		item.addEventListener("click", () => {
			const isActive = item.classList.contains("active");

			// Đóng tất cả item
			faqItems.forEach((i) => {
				i.classList.remove("active");
				const ic = i.querySelector(".homenest_nexux_section7_faq_icon");
				if (ic) ic.textContent = "+"; // reset icon
			});

			// Nếu item ban đầu chưa active → mở lại và đổi dấu
			if (!isActive) {
				item.classList.add("active");
				if (icon) icon.textContent = "−";
			}
		});
	});
	const container = document.querySelector(".homenest_nexux_section9_cards");
	const cards = Array.from(
		container.querySelectorAll(".homenest_nexux_section9_card")
	);
	const dotsContainer = document.querySelector(".homenest_nexux_section9_dots");

	let currentIndex = Math.floor(cards.length / 2);

	// Tạo dot tương ứng với số lượng card
	function createDots() {
		dotsContainer.innerHTML = "";
		cards.forEach((_, i) => {
			const dot = document.createElement("div");
			if (i === currentIndex) dot.classList.add("active");
			dot.addEventListener("click", () => {
				currentIndex = i;
				updateCards();
			});
			dotsContainer.appendChild(dot);
		});
	}

	function updateCards() {
		cards.forEach((card, i) => {
			const offset = i - currentIndex;

			// Càng xa trung tâm, càng mờ dần
			const opacity = 1;
			card.style.opacity = opacity.toString();
			card.style.pointerEvents = opacity > 0.1 ? "auto" : "none";

			// Xếp theo tầng: card giữa ở trên
			card.style.zIndex = 1000 - Math.abs(offset);


			const baseDistance = 80;
			const translateX =
				  Math.sign(offset) * baseDistance * Math.log2(Math.abs(offset) + 1);
			const rotateZ = offset * 5; // độ nghiêng
			const scale = offset === 0 ? 1 : 0.9; // card trung tâm to hơn

			card.style.transform = `
translateX(calc(-50% + ${translateX}px))
translateY(0)
scale(${scale})
rotateZ(${rotateZ}deg)
`;
		});

		// Cập nhật dot
		const dots = dotsContainer.querySelectorAll("div");
		dots.forEach((dot, i) => {
			dot.classList.toggle("active", i === currentIndex);
		});
	}

	// Kéo chuột để chuyển card
	let isDragging = false;
	let startX = 0;

	function handleDragStart(e) {
		isDragging = true;
		startX = e.type.includes("touch") ? e.touches[0].clientX : e.clientX;
	}

	function handleDragMove(e) {
		if (!isDragging) return;
		const currentX = e.type.includes("touch") ? e.touches[0].clientX : e.clientX;
		const diff = currentX - startX;

		if (Math.abs(diff) > 50) {
			if (diff < 0 && currentIndex < cards.length - 1) {
				currentIndex++;
			} else if (diff > 0 && currentIndex > 0) {
				currentIndex--;
			}
			updateCards();
			isDragging = false;
		}
	}

	function handleDragEnd() {
		isDragging = false;
	}

	container.addEventListener("mousedown", handleDragStart);
	container.addEventListener("mousemove", handleDragMove);
	container.addEventListener("mouseup", handleDragEnd);
	container.addEventListener("mouseleave", handleDragEnd);

	container.addEventListener("touchstart", handleDragStart);
	container.addEventListener("touchmove", handleDragMove);
	container.addEventListener("touchend", handleDragEnd);

	// Khởi tạo ban đầu
	createDots();
	updateCards();

});


document.addEventListener('DOMContentLoaded', function() {
	const swiper = new Swiper('.slider-mobile-app', {
		loop: true,
		slidesPerView: 'auto',
		slidesPerGroup: 1,
		spaceBetween: 20,
		centeredSlides: true,
		effect: 'slide',
		speed: 1000,
		lazy: true,
		loadOnTransitionStart: true,
		autoplay: {
			delay: 1000,
			disableOnInteraction: false,
		},
	});
});



// ==============================
// Các quy trình dịch vụ nói chung
// ==============================
document.addEventListener('DOMContentLoaded', function() {
	// Kiểm tra xem mảng cacQuyTrinh có tồn tại và đã được load chưa
	if (typeof cacQuyTrinh === 'undefined' || !Array.isArray(cacQuyTrinh)) {
		console.error("Mảng 'cacQuyTrinh' chưa được định nghĩa hoặc không phải là mảng.");
		return;
	}

	// 1. Render các item từ mảng ra HTML
	const container = document.querySelector('.homenest__procedure-section__contain');
	if (container) {
		container.innerHTML = cacQuyTrinh.map((item, index) => `
<li class="homenest__procedure-section__item" style="background-image: linear-gradient(to bottom, #00000000, #000000),url('${item.linkImg}')">
<div class="hn__heading">
<div class="number">0${index + 1}.</div>
<div>${item.heading}</div>
</div>
<div class="hn__heading-and-content" >
<div class="number">0${index + 1}.</div>
<h3 class="heading">${item.heading}</h3>
<p class="content">${item.content}</p>
</div>
</li>
`).join('');
	}

	// 2. Xử lý sự kiện click
	const items = document.querySelectorAll('.homenest__procedure-section__item');
	let isClickable = true;

	items.forEach((item, index) => {
		item.addEventListener('click', function() {
			// Đảm bảo chỉ xử lý một lần nhấp trong khoảng thời gian ngắn
			if (!isClickable) return;

			isClickable = false;
			
			// Loại bỏ class 'active' khỏi tất cả các item
			items.forEach(el => el.classList.remove('active'));
			
			// Thêm class 'active' cho item hiện tại
			this.classList.add('active');

			// Log thông tin (có thể thay bằng logic tùy chỉnh)
			console.log('Đã chọn:', cacQuyTrinh[index].heading);

			// Cho phép click lại sau 300ms
			setTimeout(() => {
				isClickable = true;
			}, 300);
		});
	});

	// 3. Active item đầu tiên khi load trang
	if (items.length > 0) {
		items[0].classList.add('active');
	}
});