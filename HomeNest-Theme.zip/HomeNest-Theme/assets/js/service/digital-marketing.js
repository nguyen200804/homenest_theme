// Counter
document.addEventListener('DOMContentLoaded', () => {
	function animateCounters(className, max, duration) {
		const element = document.querySelectorAll("." + className)[0];

		let start = 0;
		const stepTime = Math.abs(Math.floor(duration / max));

		const timer = setInterval(() => {
			start++;
			element.textContent = start;
			if (start >= max) {
				clearInterval(timer);
			}
		}, stepTime);
	}
});



// FAQ
document.addEventListener('DOMContentLoaded', () => {
	let selectedQuesCol1 = document.querySelectorAll(".section8_row2_col1")[0]
	.firstElementChild.firstElementChild;

	let selectedQuesCol2 = document.querySelectorAll(".section8_row2_col2")[0]
	.firstElementChild.firstElementChild;

	click_question(selectedQuesCol1);
	click_question(selectedQuesCol2);

	function click_question(itemQues) {
		if (itemQues) itemQues.classList.add("background_gradient");

		let itemQuesIcon = itemQues.firstElementChild;
		itemQuesIcon.style.color = "var(--color_main_title)";
		itemQuesIcon.innerHTML = "-";

		let itemAns = itemQues.nextElementSibling;
		itemAns.classList.add("selected");
		//Gán chiều cao bằng với content thay vì dùng trasition max-height bị giật
		itemAns.style.height = itemAns.scrollHeight + "px";
	}

	function unSelected_question(itemQues) {
		itemQues.classList.remove("background_gradient");

		let itemQuesIcon = itemQues.firstElementChild;
		itemQuesIcon.style.color = "var(--icon_color)";
		itemQuesIcon.innerHTML = "+";

		let itemAns = itemQues.nextElementSibling;
		itemAns.classList.remove("selected");
		itemAns.style.height = "0px";
	}

	document.querySelectorAll(".section8_row2_col_item_question").forEach((itemQues) => {
		itemQues.addEventListener("click", () => {
			let isCol1 = itemQues.parentElement.parentElement.classList.contains(
				"section8_row2_col1"
			)
			? true
			: false;

			Array.from(
				document.querySelectorAll(
					isCol1 ? ".section8_row2_col1" : ".section8_row2_col2"
				)[0].children
			).forEach((item) => unSelected_question(item.firstElementChild));

			let seletedQuesCol = isCol1 ? selectedQuesCol1 : selectedQuesCol2;

			let section8_row2_col1 = itemQues.parentElement.parentElement;

			if (seletedQuesCol != itemQues) {
				if (isCol1) selectedQuesCol1 = itemQues;
				else selectedQuesCol2 = itemQues;

				section8_row2_col1.style.flex = "2";

				click_question(itemQues);
			} else if (seletedQuesCol == itemQues) {
				if (isCol1) selectedQuesCol1 = null;
				else selectedQuesCol2 = null;

				section8_row2_col1.style.flex = "1";

				unSelected_question(itemQues);
			}
		});
	});  
});



// Scroll Y
document.addEventListener('DOMContentLoaded', () => {
	function observeWithDelay(className, offset = 0, baseDelay = 300) {
		const observer = new IntersectionObserver((entries) => {
			entries.forEach((entry, index) => {
				if (entry.isIntersecting) {
					const delay = offset + index * baseDelay;
					setTimeout(() => {
						entry.target.classList.add("show");
					}, delay);
				}
			});
		});

		document.querySelectorAll(`.${className}`).forEach((el) => {
			observer.observe(el);
		});
	}

	// -------------------------------------------------------------------------------------------------------------
	observeWithDelay("sub_title");
	observeWithDelay("section1_col1_main_title");
	observeWithDelay("section2_row1_col2", 300);
	observeWithDelay("section9_row2 ", 600);
	// -------------------------------------------------------------------------------------------------------------
	observeWithDelay("section8_row1");
	observeWithDelay("section8_row2_col", 300);
	// -------------------------------------------------------------------------------------------------------------
	observeWithDelay("section7_col2_item", 300, 400);
	// -------------------------------------------------------------------------------------------------------------
	let is_counter1_show = false;
	let is_counter2_show = false;

	function counterObserveWithDelay(
	className,
	 value,
	 is_counter_show,
	 time = 3000
	) {
		const observer = new IntersectionObserver((entries) => {
			entries.forEach((entry, index) => {
				if (entry.isIntersecting && !is_counter_show) {
					is_counter_show = true;
					animateCounters(className, value, time);
				}
			});
		});

		document.querySelectorAll(`.${className}`).forEach((el) => {
			observer.observe(el);
		});
	}

	counterObserveWithDelay(
		"section6_row2_item_text_value_HC",
		65,
		is_counter2_show
	);
	counterObserveWithDelay(
		"section6_row2_item_text_value_integer_PD",
		2,
		is_counter2_show,
		1000
	);
	counterObserveWithDelay(
		"section6_row2_item_text_value_decimal_PD",
		65,
		is_counter2_show
	);
	counterObserveWithDelay(
		"section6_row2_item_text_value_integer_CR",
		4,
		is_counter2_show,
		2000
	);
	counterObserveWithDelay(
		"section6_row2_item_text_value_decimal_CR",
		9,
		is_counter2_show
	);
	counterObserveWithDelay(
		"section6_row2_item_text_value_YE",
		69,
		is_counter2_show
	);

	observeWithDelay("section6_row2_item", 300);
	// -------------------------------------------------------------------------------------------------------------
	observeWithDelay("section5_row1_main_title");
	observeWithDelay("section5_row2_item", 300);
	observeWithDelay("section5_row2_col2", 1200);
	// -------------------------------------------------------------------------------------------------------------
	observeWithDelay("section3_row2_col1", 600);
	observeWithDelay("section3_row2_col2", 900);
	// -------------------------------------------------------------------------------------------------------------
	observeWithDelay("section2_row2_item ", 300);
	// -------------------------------------------------------------------------------------------------------------
	observeWithDelay("section1_col1_content", 300);
	observeWithDelay("section1_col1_button", 600);
	observeWithDelay("section1_col1_play_btt", 900);
	observeWithDelay("section1_col1_counter", 1500);

	counterObserveWithDelay("section1_col1_counter1_value", 239, is_counter1_show);
	counterObserveWithDelay("section1_col1_counter2_value ", 65, is_counter1_show);
	counterObserveWithDelay(
		"section1_col1_counter3_value_value ",
		12,
		is_counter1_show
	);
});
