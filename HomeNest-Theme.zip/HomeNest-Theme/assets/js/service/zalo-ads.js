document.addEventListener("DOMContentLoaded", () => {
  setupAccordion();
  setupSwiper();
});

function setupAccordion() {
  const accordionItems = document.querySelectorAll(".elementor-accordion-item");

  accordionItems.forEach((item) => {
    const answer = item.querySelector(".anwser");
    const toggleLink = item.querySelector(".title__7 a");
    const icon = item.querySelector(".icon-toggle");

    toggleLink.addEventListener("click", (event) => {
      event.preventDefault();

      const isShown = answer.classList.contains("show");

      // Ẩn tất cả các mục khác
      accordionItems.forEach((i) => {
        const ans = i.querySelector(".anwser");
        const ic = i.querySelector(".icon-toggle");
        ans.classList.remove("show");
        ans.style.animation = "";
        ic.classList.remove("active");
      });

      if (!isShown) {
        answer.classList.add("show");
        answer.style.animation = "slideDown 0.4s ease forwards";
        icon.classList.add("active");
      } else {
        answer.style.animation = "slideUp 0.3s ease forwards";
        icon.classList.remove("active");

        setTimeout(() => {
          answer.classList.remove("show");
          answer.style.animation = "";
        }, 300);
      }
    });
  });
}

function setupSwiper() {
  new Swiper(".mySwiper", {
    slidesPerView: 1,
    spaceBetween: 30,
    loop: true,
    autoHeight: true,
    navigation: {
      prevEl: ".swiper_button_prev__icon",
      nextEl: ".swiper_button_next__icon",
    },
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
    breakpoints: {
      640: { slidesPerView: 2 },
      768: { slidesPerView: 2 },
      1024: { slidesPerView: 3 },
      1300: { slidesPerView: 4 },
    },
  });
}
document.addEventListener("DOMContentLoaded", function () {
  const faqData = [
    {
      question: "Tại sao phải thiết kế website theo yêu cầu?",
      answer:
        "Thiết kế website theo yêu cầu giúp doanh nghiệp có giao diện, tính năng phù hợp với đặc thù hoạt động, tăng hiệu quả kinh doanh và nhận diện thương hiệu.",
    },
    {
      question: "Phí gia hạn web hàng năm là gì?",
      answer:
        "Phí gia hạn web hàng năm bao gồm chi phí duy trì tên miền, hosting và các dịch vụ kỹ thuật kèm theo để website hoạt động ổn định.",
    },
    {
      question: "Thiết kế website chuẩn SEO là gì?",
      answer:
        "Website chuẩn SEO giúp tối ưu công cụ tìm kiếm, dễ được Google index và cải thiện thứ hạng trên kết quả tìm kiếm.",
    },
    {
      question: "Hosting là gì và tại sao cần thiết?",
      answer:
        "Hosting là nơi lưu trữ toàn bộ dữ liệu website. Không có hosting thì website không thể hoạt động được trên internet.",
    },
    {
      question: "Tên miền là gì?",
      answer:
        "Tên miền là địa chỉ của website trên internet, ví dụ như www.tenmien.com. Nó giúp người dùng truy cập nhanh chóng vào website.",
    },
    {
      question: "Website có cần bảo mật SSL không?",
      answer:
        "Có. SSL giúp mã hóa dữ liệu giữa người dùng và máy chủ, tăng độ tin cậy và bảo vệ thông tin cá nhân, đặc biệt quan trọng với các website thương mại điện tử.",
    },
    {
      question: "Tôi có thể chỉnh sửa nội dung website không?",
      answer:
        "Có. Với hệ thống quản trị nội dung (CMS), bạn có thể dễ dàng cập nhật nội dung mà không cần kiến thức lập trình.",
    },
    {
      question: "Chi phí thiết kế website là bao nhiêu?",
      answer:
        "Chi phí tùy thuộc vào mức độ phức tạp và yêu cầu cụ thể. Bạn có thể liên hệ để được báo giá chi tiết.",
    },
    {
      question: "Thời gian thiết kế website mất bao lâu?",
      answer:
        "Thông thường từ 7-20 ngày làm việc tùy theo mức độ phức tạp và số lượng tính năng yêu cầu.",
    },
    {
      question: "Website có tương thích với điện thoại không?",
      answer:
        "Có. Website được thiết kế responsive, hiển thị tốt trên mọi thiết bị như điện thoại, máy tính bảng và laptop.",
    },
  ];

  const faqContainer = document.getElementById(
    "homenest__professional_website_faq-container"
  );

  faqData.forEach((item, index) => {
    const faqItem = document.createElement("div");
    faqItem.className = "homenest__professional_website_question";

    faqItem.innerHTML = `
      <div class="homenest__professional_website_question-header-number">
        <span class="homenest__professional_website_question-number"><span>${(
          index + 1
        )
          .toString()
          .padStart(2, "0")}
          </span></span>
        <span class="homenest__professional_website_question-label">QUESTION - ${(
          index + 1
        )
          .toString()
          .padStart(2, "0")}</span>
      </div>
      <div class="homenest__professional_website_question-header">
        <div style="width: 40px; height: 40px;"></div>
        <span class="homenest__professional_website_question-title">${
          item.question
        }</span>
        <button class="homenest__professional_website_toggle-btn">
          +
        </button>
      </div>
      <div class="homenest__professional_website_answer-wrapper">
        <div style="width: 40px; height: 40px;"></div>
        <div class="homenest__professional_website_answer">${item.answer}</div>
        <div style="width: 40px; height: 40px;"></div>
      </div>
    `;

    faqContainer.appendChild(faqItem);
  });

  document
    .querySelectorAll(".homenest__professional_website_question-header")
    .forEach((header) => {
      header.addEventListener("click", () => {
        const allAnswers = document.querySelectorAll(
          ".homenest__professional_website_answer-wrapper"
        );
        const allButtons = document.querySelectorAll(
          ".homenest__professional_website_toggle-btn"
        );

        const currentAnswer = header.nextElementSibling;
        const currentButton = header.querySelector(
          ".homenest__professional_website_toggle-btn"
        );

        // Close all other answers and reset their buttons
        allAnswers.forEach((answer) => {
          if (answer !== currentAnswer) answer.classList.remove("show");
        });

        allButtons.forEach((btn) => {
          if (btn !== currentButton) {
            btn.classList.remove("open");
            btn.textContent = "+";
          }
        });

        // Toggle current
        const isOpen = currentAnswer.classList.contains("show");
        currentAnswer.classList.toggle("show", !isOpen);
        currentButton.classList.toggle("open", !isOpen);
        currentButton.textContent = !isOpen ? "−" : "+";
      });
    });
});

function toggleMore(selector, toggleBtn) {
  const items = document.querySelectorAll(selector);
  const text = toggleBtn.querySelector(".toggle-text");
  const isOpen = items[0]?.classList.contains("show");

  items.forEach((item) => {
    item.classList.toggle("show", !isOpen);
  });

  if (text) {
    text.textContent = isOpen ? "Xem thêm" : "Thu hồi";
  }

  const swiper = document.querySelector(".mySwiper")?.swiper;
  if (swiper) {
    requestAnimationFrame(() => swiper.updateAutoHeight(300));
  }
}
