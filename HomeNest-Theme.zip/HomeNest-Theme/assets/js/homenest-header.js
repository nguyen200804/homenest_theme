document.addEventListener("DOMContentLoaded", function () {
	const icons = document.querySelectorAll("i[class^='homenest-icon-']");
	icons.forEach(i => {
		const svgId = i.className;
		const svgTemplate = document.getElementById(svgId);
		if (svgTemplate) {
			const clone = svgTemplate.cloneNode(true);
			clone.removeAttribute("id");
			clone.style.display = "inline-block";
			i.replaceWith(clone);
		}
	});
});		




document.addEventListener('DOMContentLoaded', function () {
// Mở menu mobile
	const btnMenuMobile = document.querySelector('.btn-menu-mobile');
	if (btnMenuMobile) {
		btnMenuMobile.addEventListener('click', function (e) {
			e.preventDefault();
			const menuMobile = document.querySelector('#menuMobile');
			if (menuMobile) {
				menuMobile.classList.add('open');
				menuMobile.classList.remove('closed');
			}
		});
	}

	// Đóng menu mobile
	const closeMenuBtn = document.querySelector('.close-menu');
	if (closeMenuBtn) {
		closeMenuBtn.addEventListener('click', function (e) {
			e.preventDefault();
			const menuMobile = document.querySelector('#menuMobile');
			if (menuMobile) {
				menuMobile.classList.add('closed');
				menuMobile.classList.remove('open');
			}
		});
	}
});


document.querySelector('.icon-search').addEventListener('click', function () {
	const overlay = document.querySelector('#searchOverlay');
	overlay.classList.remove('closed');
	overlay.classList.add('open');
});

document.querySelector('.clear-search').addEventListener('click', function () {
	const overlay = document.querySelector('#searchOverlay');
	overlay.classList.remove('open');
	overlay.classList.add('closed');
});

// Click ra ngoài panel thì đóng
document.querySelector('#searchOverlay').addEventListener('click', function (e) {
	const panel = document.querySelector('#searchPanel');
	if (!panel.contains(e.target)) {
		this.classList.remove('open');
		this.classList.add('closed');
	}
});

let lastScroll = 0;
const header = document.getElementById('mainHeader');

window.addEventListener('scroll', () => {
	const currentScroll = window.pageYOffset;

	if (currentScroll < lastScroll) {
		// Cuộn lên
		header.classList.add('header-sticky', 'header-show');
	} else {
		// Cuộn xuống
		header.classList.remove('header-show');
	}

	lastScroll = currentScroll;
});

// JavaScript cho header cố định với hiệu ứng khi cuộn
document.addEventListener('DOMContentLoaded', function() {
	const header = document.getElementById('mainHeader');
	let lastScrollTop = 0;
	const scrollThreshold = 100; // Ngưỡng cuộn để kích hoạt hiệu ứng

	// Đặt trạng thái ban đầu là initial
	header.classList.add('initial');

	window.addEventListener('scroll', function() {
		const currentScrollTop = window.pageYOffset || document.documentElement.scrollTop;

		// Kiểm tra hướng cuộn
		if (currentScrollTop > lastScrollTop && currentScrollTop > scrollThreshold) {
			// Cuộn xuống và đã vượt qua ngưỡng - ẩn header
			header.classList.remove('visible');
			header.classList.remove('animate-in');
			header.classList.add('hidden');
		} else if (currentScrollTop < lastScrollTop) {
			// Cuộn lên - hiển thị header với hiệu ứng
			if (header.classList.contains('hidden')) {
				header.classList.remove('hidden');
				header.classList.remove('initial');
				header.classList.add('animate-in');
				header.classList.add('visible');
			}
		}

		// Nếu ở đầu trang, trở về trạng thái ban đầu
		if (currentScrollTop <= 10) {
			header.classList.remove('visible');
			header.classList.remove('hidden');
			header.classList.remove('animate-in');
			header.classList.add('initial');
		}

		lastScrollTop = currentScrollTop <= 0 ? 0 : currentScrollTop; // Cho iOS
	}, { passive: true });
});


document.addEventListener('DOMContentLoaded', () => {
	// Thay đổi văn bản của các option
	document.querySelectorAll('.homenest__header--translate--mobile .gtranslate_wrapper [value="vi|en"]').forEach(element => {
		element.textContent = 'EN';
	});

	document.querySelectorAll('.homenest__header--translate--mobile .gtranslate_wrapper [value="vi|vi"]').forEach(element => {
		element.textContent = 'VI';
	});

	// Xóa phần tử option đầu tiên của select trong .gtranslate_wrapper
	const selectElement = document.querySelector('.homenest__header--translate--mobile .gtranslate_wrapper select');
	if (selectElement && selectElement.options.length > 0) {
		const firstOption = selectElement.options[0];
		if (firstOption.value === "") { // Đảm bảo chỉ xóa option "Select Language"
			selectElement.removeChild(firstOption);
		}
	}
});



document.addEventListener('DOMContentLoaded', () => {
	// Thay đổi văn bản của các option
	document.querySelectorAll('.homenest__header__translate .gtranslate_wrapper [value="vi|en"]').forEach(element => {
		element.textContent = 'EN';
	});

	document.querySelectorAll('.homenest__header__translate .gtranslate_wrapper [value="vi|vi"]').forEach(element => {
		element.textContent = 'VI';
	});

	// Xóa phần tử option đầu tiên của select trong .gtranslate_wrapper
	const selectElement = document.querySelector('.homenest__header__translate .gtranslate_wrapper select');
	if (selectElement && selectElement.options.length > 0) {
		const firstOption = selectElement.options[0];
		if (firstOption.value === "") { // Đảm bảo chỉ xóa option "Select Language"
			selectElement.removeChild(firstOption);
		}
	}
});