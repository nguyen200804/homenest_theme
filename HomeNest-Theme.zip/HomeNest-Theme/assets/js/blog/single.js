// Back to Top Functionality
const backToTopButton = document.querySelector('.homenest__single__back-to-top');
if (backToTopButton) {
	window.addEventListener('scroll', () => {
		if (window.scrollY > 300) {
			backToTopButton.classList.add('show');
		} else {
			backToTopButton.classList.remove('show');
		}
	});

	backToTopButton.addEventListener('click', () => {
		window.scrollTo({
			top: 0,
			behavior: 'smooth'
		});
	});
}

// View All Posts Button
document.addEventListener('DOMContentLoaded', function() {
	const viewAllButton = document.querySelector('.view-all-button');
	const morePostsContainer = document.querySelector('.more-posts-container');

	if (viewAllButton && morePostsContainer) {
		let isExpanded = false;

		// Set initial state
		viewAllButton.innerHTML = '<i class="fas fa-chevron-down"></i> Xem tất cả bài viết';
		morePostsContainer.style.cssText = 'display: none; opacity: 0; transition: opacity 0.3s ease;';

		viewAllButton.addEventListener('click', function() {
			isExpanded = !isExpanded;

			if (isExpanded) {
				// Show more posts
				morePostsContainer.style.display = 'block';
				requestAnimationFrame(() => {
					morePostsContainer.style.opacity = '1';
				});
				viewAllButton.innerHTML = '<i class="fas fa-chevron-up"></i> Ẩn bớt';

				// Scroll to new content
				setTimeout(() => {
					morePostsContainer.scrollIntoView({
						behavior: 'smooth',
						block: 'start'
					});
				}, 100);
			} else {
				// Hide posts
				morePostsContainer.style.opacity = '0';
				viewAllButton.innerHTML = '<i class="fas fa-chevron-down"></i> Xem tất cả bài viết';

				setTimeout(() => {
					morePostsContainer.style.display = 'none';
					viewAllButton.scrollIntoView({
						behavior: 'smooth',
						block: 'center'
					});
				}, 300);
			}
		});
	}
});

// AJAX Comment Reply
document.addEventListener('DOMContentLoaded', () => {
	const replyLinks = document.querySelectorAll('.comment-reply-link');
	replyLinks.forEach(link => {
		link.addEventListener('click', (e) => {
			e.preventDefault();

			// Remove existing reply forms to prevent multiple forms
			document.querySelectorAll('.reply-form-container').forEach(form => form.remove());

			const commentId = link.getAttribute('data-comment-id');
			const commentItem = document.querySelector(`.comment-item[data-comment-id="${commentId}"]`);
			let replyFormContainer = document.createElement('div');
			replyFormContainer.className = 'reply-form-container';
			replyFormContainer.innerHTML = `
<form class="reply-form-inline" id="reply-form-${commentId}">
<div class="underline-inputs-row">
<div class="underline-input underline-input-half">
<input type="text" name="reply_author" placeholder="Họ và tên*" required>
</div>
<div class="underline-input underline-input-half">
<input type="email" name="reply_email" placeholder="Email*" required>
</div>
</div>
<div class="underline-input">
<textarea name="reply_comment" placeholder="Trả lời*" rows="3" required></textarea>
</div>
<button type="submit" class="send-reply"><i class="fas fa-paper-plane"></i> Gửi trả lời</button>
<div class="reply-success-message" style="display: none;"></div>
<div class="reply-error-message" style="display: none;"></div>
</form>
`;
			commentItem.appendChild(replyFormContainer);

			const replyForm = replyFormContainer.querySelector('.reply-form-inline');
			const successMessage = replyForm.querySelector('.reply-success-message');
			const errorMessage = replyForm.querySelector('.reply-error-message');
			const sendButton = replyForm.querySelector('.send-reply');

			replyForm.addEventListener('submit', async (e) => {
				e.preventDefault();

				// Get form data
				const author = replyForm.querySelector('input[name="reply_author"]').value.trim();
				const email = replyForm.querySelector('input[name="reply_email"]').value.trim();
				const comment = replyForm.querySelector('textarea[name="reply_comment"]').value.trim();

				// Validate input
				if (!author || !email || !comment) {
					errorMessage.textContent = 'Vui lòng điền đầy đủ thông tin.';
					errorMessage.style.display = 'block';
					successMessage.style.display = 'none';
					return;
				}

				// Validate email format
				const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
				if (!emailRegex.test(email)) {
					errorMessage.textContent = 'Email không hợp lệ.';
					errorMessage.style.display = 'block';
					successMessage.style.display = 'none';
					return;
				}

				// Disable button while processing
				sendButton.disabled = true;
				sendButton.style.cursor = 'not-allowed';

				try {
					const formData = new FormData();
					formData.append('action', 'homenest_submit_reply');
					formData.append('comment_post_ID', '<?php echo esc_js(get_the_ID()); ?>');
					formData.append('comment_parent', commentId);
					formData.append('author', author);
					formData.append('email', email);
					formData.append('comment', comment);
					formData.append('_wpnonce', '<?php echo wp_create_nonce("homenest_reply_nonce"); ?>');

					console.log('Sending reply submission request...');
					const response = await fetch('<?php echo admin_url("admin-ajax.php"); ?>', {
						method: 'POST',
						body: formData,
						credentials: 'same-origin'
					});

					console.log('Response received:', response);
					const result = await response.json();
					console.log('Response data:', result);

					if (result.success) {
						successMessage.textContent = result.data.message || 'Trả lời của bạn đã được gửi và đang chờ duyệt!';
						successMessage.style.display = 'block';
						errorMessage.style.display = 'none';
						replyForm.reset();

						// Hide success message after 3 seconds
						setTimeout(() => {
							successMessage.style.opacity = '0';
							setTimeout(() => {
								successMessage.style.display = 'none';
								successMessage.style.opacity = '1';
							}, 500);
						}, 3000);
					} else {
						throw new Error(result.data?.message || 'Có lỗi xảy ra. Vui lòng thử lại.');
										}
										} catch (error) {
										console.error('Error submitting reply:', error);
										errorMessage.textContent = error.message;
										errorMessage.style.display = 'block';
										successMessage.style.display = 'none';
										} finally {
										sendButton.disabled = false;
										sendButton.style.cursor = 'pointer';
										}
										});
										});
										});
										});

										// Ensure back-to-top button visibility on scroll
										window.addEventListener('scroll', () => {
										if (window.scrollY > 300) {
										backToTopButton.style.display = 'flex';
										} else {
										backToTopButton.style.display = 'none';
										}
										});

										// Close button functionality
										document.querySelectorAll('.popup-close').forEach(button => {
										button.addEventListener('click', function() {
										this.closest('.popup-form').style.display = 'none';
										});
										});

										// Form submission
										['promoForm', 'seoForm'].forEach(formId => {
										document.getElementById(formId).addEventListener('submit', function(e) {
										e.preventDefault();
										// Add your form submission logic here
										alert('Cảm ơn bạn đã đăng ký! Chúng tôi sẽ liên hệ sớm nhất.');
										this.closest('.popup-form').style.display = 'none';
										});
										});

										document.addEventListener('DOMContentLoaded', function() {
										// Handle reply form submission
										document.addEventListener('submit', function(e) {
										if (e.target.classList.contains('reply-form-inline')) {
										e.preventDefault();

										const form = e.target;
										const submitButton = form.querySelector('.send-reply');
										const successMessage = form.querySelector('.reply-success-message');
										const errorMessage = form.querySelector('.reply-error-message');

										// Disable submit button
										submitButton.disabled = true;

										// Get form data
										const formData = new FormData(form);
										formData.append('action', 'homenest_submit_reply');
										formData.append('_wpnonce', '<?php echo wp_create_nonce("homenest_reply_nonce"); ?>');

										// Send AJAX request
										fetch('<?php echo admin_url("admin-ajax.php"); ?>', {
										method: 'POST',
										body: formData,
										credentials: 'same-origin'
										})
							.then(response => response.json())
							.then(data => {
							if (data.success) {
								// Show success message
								successMessage.textContent = data.data;
								successMessage.style.display = 'block';
								errorMessage.style.display = 'none';

								// Clear form
								form.reset();

								// Hide success message after 3 seconds
								setTimeout(() => {
									successMessage.style.display = 'none';
								}, 3000);
							} else {
								// Show error message
								errorMessage.textContent = data.data;
								errorMessage.style.display = 'block';
								successMessage.style.display = 'none';
							}
						})
							.catch(error => {
							// Show error message
							errorMessage.textContent = 'Có lỗi xảy ra. Vui lòng thử lại.';
							errorMessage.style.display = 'block';
							successMessage.style.display = 'none';
						})
							.finally(() => {
							// Re-enable submit button
							submitButton.disabled = false;
						});
					}
				});

				// Handle reply link clicks
				document.querySelectorAll('.comment-reply-link').forEach(link => {
					link.addEventListener('click', function(e) {
						e.preventDefault();

						// Hide all reply forms
						document.querySelectorAll('.reply-form-container').forEach(form => {
							form.style.display = 'none';
						});

						// Show the reply form for this comment
						const commentId = this.getAttribute('data-comment-id');
						const commentItem = this.closest('.comment-item');
						const replyForm = commentItem.querySelector('.reply-form-container');
						if (replyForm) {
							replyForm.style.display = 'block';
						}
					});
				});

				// Handle reply form submissions
				document.querySelectorAll('.reply-form-inline').forEach(form => {
					form.addEventListener('submit', function(e) {
						e.preventDefault();

						const submitButton = this.querySelector('.send-reply');
						const successMessage = this.querySelector('.reply-success-message');
						const errorMessage = this.querySelector('.reply-error-message');

						// Disable submit button
						submitButton.disabled = true;
						submitButton.style.cursor = 'not-allowed';

						// Get form data
						const formData = new FormData(this);
						formData.append('action', 'homenest_submit_reply');
						formData.append('_wpnonce', '<?php echo wp_create_nonce("homenest_reply_nonce"); ?>');

						// Send request
						fetch('<?php echo admin_url("admin-ajax.php"); ?>', {
							method: 'POST',
							body: formData,
							credentials: 'same-origin'
						})
							.then(response => response.json())
							.then(data => {
							if (data.success) {
								// Show success message
								successMessage.textContent = data.data;
								successMessage.style.display = 'block';
								errorMessage.style.display = 'none';

								// Clear form
								this.reset();

								// Hide success message after 3 seconds
								setTimeout(() => {
									successMessage.style.display = 'none';
								}, 3000);
							} else {
								// Show error message
								errorMessage.textContent = data.data;
								errorMessage.style.display = 'block';
								successMessage.style.display = 'none';
							}
						})
							.catch(() => {
							// Show error message
							errorMessage.textContent = 'Có lỗi xảy ra. Vui lòng thử lại.';
							errorMessage.style.display = 'block';
							successMessage.style.display = 'none';
						})
							.finally(() => {
							// Re-enable submit button
							submitButton.disabled = false;
							submitButton.style.cursor = 'pointer';
						});
					});
				});
			});