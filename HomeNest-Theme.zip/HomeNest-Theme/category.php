<?php
/*
Template Name: Blog
*/
get_header(); ?>

<main>
	<section class="homenest__blog-page">
		<div class="homenest__blog-page__container">
			<h1 style="display: none;">
				Homenest Wiki
			</h1>
			<div class="homenest__blog-page__blog-grid">
				<?php
				// Lấy số trang hiện tại từ URL (mặc định là 1 nếu không có)
				$paged = get_query_var('paged') ? get_query_var('paged') : 1;

				// Lấy danh mục hiện tại từ URL
				$queried_object = get_queried_object();
				$category_slug = '';

				if ($queried_object instanceof WP_Term) {
					$category_slug = $queried_object->slug; // Lấy slug của danh mục
				}

				$args = array(
					'post_type'      => 'post',
					'posts_per_page' => 41,
					'paged'          => $paged,
					'post_status'    => 'publish',
					'category_name'  => $category_slug, // Thêm danh mục từ URL
				);

				$query = new WP_Query($args);

				if ($query->have_posts()) {
					$index = 1;

					while ($query->have_posts()) {
						$query->the_post();

						$thumbnail = get_the_post_thumbnail_url(get_the_ID(), 'large');
						$author    = get_the_author();
						$date      = get_the_date('F j, Y');
						$date_day  = get_the_date('d');
						$date_month_year = get_the_date('M Y');
						$title     = get_the_title();
						$excerpt   = get_the_excerpt();

						$categories = get_the_category();
						$category_names = array();
						if (!empty($categories)) {
							foreach ($categories as $cat) {
								$category_names[] = $cat->name;
							}
						}
						$category_string = '/ ' . implode(' / ', $category_names) . ' /';

						// PHÂN NHÁNH THEO TRANG & INDEX
						if ($paged == 1 && $index <= 21) {
							// TRANG 1: bài 1–21
				?>
				<div class="homenest__blog-page__item-1">
					<div class="homenest__blog-page__item-1__inner">
						<a href="<?php echo esc_url(get_permalink()); ?>" class="homenest__blog-page__item-1__thumbnail">
							<img src="<?php echo esc_url($thumbnail); ?>" alt="<?php echo esc_attr($title); ?>">
						</a>
						<div class="homenest__blog-page__item-1__meta">
							<span class="homenest__blog-page__item-1__meta-date text--gradient"><?php echo esc_html($date); ?></span> /
							<a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>" class="homenest__blog-page__item-1__meta-author text--gradient">
								<?php echo esc_html($author); ?>
							</a>
						</div>
					</div>
					<div class="homenest__blog-page__item-1__content">
						<h3 class="homenest__blog-page__item-1__title text--gradient">
							<a href="<?php echo esc_url(get_permalink()); ?>"><?php echo esc_html($title); ?></a>
						</h3>
						<p class="homenest__blog-page__item-1__excerpt"><?php echo esc_html($excerpt); ?></p>
						<div class="homenest__blog-page__item-1__category"><?php echo esc_html($category_string); ?></div>
					</div>
				</div>

				<?php
						} else {
							// TRANG 1: bài 22–41 hoặc TRANG > 1
				?>
				<div class="homenest__blog-page__item-2">
					<div class="homenest__blog-page__item-2__date-box">
						<div class="homenest__blog-page__item-2__date-day text--gradient"><?php echo esc_html($date_day); ?></div>
						<div class="homenest__blog-page__item-2__date-month-year text--gradient"><?php echo esc_html($date_month_year); ?></div>
					</div>
					<div class="homenest__blog-page__item-2__content">
						<h3 class="homenest__blog-page__item-2__title text--gradient">
							<a href="<?php echo esc_url(get_permalink()); ?>"><?php echo esc_html($title); ?></a>
						</h3>
						<p class="homenest__blog-page__item-2__excerpt"><?php echo esc_html($excerpt); ?></p>
						<div class="homenest__blog-page__item-2__meta">
							<span class="homenest__blog-page__item-2__category"><?php echo esc_html($category_string); ?></span>
							<a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>" class="homenest__blog-page__item-2__author  text--gradient">
								<?php echo esc_html($author); ?>
							</a>
						</div>
					</div>
				</div>

				<?php
						}
						$index++;
					}
					// PHÂN TRANG
					$total_pages = $query->max_num_pages;
					if ($total_pages > 1) {
						echo '<div class="homenest__blog-page__pagination">';
						echo paginate_links(array(
							'current'   => max(1, $paged),
							'total'     => $total_pages,
							'prev_text' => '«',
							'next_text' => '»',
						));
						echo '</div>';
					}

					wp_reset_postdata();
				} else {
					// Trường hợp không có bài viết nào
					echo 'Không có bài viết nào trong danh mục này.';
				}
				?>
			</div>


			<div class="homenest__blog-page__widgets">
				<?php echo do_shortcode('[contact-form-7 id="0408b1b" title="Đăng kí nhận ưu đãi"]'); ?>

				
				<div class="homepage__blog-page__banner">
					<img src="/wp-content/uploads/2025/05/1-18.webp">
				</div>
			</div>

		</div>
	</section>
</main>

<?php get_footer(); ?>