<?php get_header(); ?>

<main style="text-align: center;background: #fff; color: #333;">

	<section class="homenest__error--404">
		<video muted loop autoplay>
			<source src="/wp-content/uploads/2025/06/GettyImages-1293116199-1.mov" type="video/mp4">
		</video>
		<div class="container">
			<div class="col1">
				<div class="text404">
					404
				</div>
			</div>
			
			<img src="/wp-content/uploads/2025/06/middle.webp">


			<div class="col2">
				<h2 class="title">
					Oops!<br>
					Có gì đó <br>
					không đúng
				</h2>
				<p class="content">
					Bạn đang ở đây vì bạn đã nhập địa chỉ của một trang không còn tồn tại hoặc đã được chuyển đến một địa chỉ khác
				</p>
				<a class="button" href="<?php echo esc_url( home_url( '/' ) ); ?>"><span>Quay về trang chủ</span></a>
			</div>
		</div>
	</section>


</main>

<?php get_footer(); ?>
