<?php
/*
Template Name: About Us - En
*/
get_header(); ?>




<main id='page-about-us'>

	<div class="homenest__hero-section">
		<div class="container__about-us">
			<div style="padding: 0 15px">
				<h1 class="heading-primary">HomeNest <span class="heading-secondary">- Our Team Story and Mission</span></h1>

			</div>
			<div style="padding: 15px">
				<p class="description">HomeNest accompanies businesses in digital transformation, brand building, and sustainable development.</p>
				<a href="#" class="button _txt __about-us">
					Discover Now! 
					<svg class="btn-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
						<path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
					</svg>
				</a>
			</div>
		</div>
	</div>

	<div class="homenest__about-us">
		<div class="container__about-us">
			<div class="left__about-us">
				<div class="grid-container">

					<div class="cricle__about-us">
						<div class="center_shape">
							<div class="rotate_wrap">
								<img src="/wp-content/uploads/2025/05/img-cricle1.webp" class="shape shape1" alt="Homenest" title="Homenest">
								<img src="/wp-content/uploads/2025/05/img-cricle2.webp" class="shape shape2" alt="Homenest" title="Homenest">
								<img src="/wp-content/uploads/2025/05/img-cricle3.webp" class="shape shape3" alt="Homenest" title="Homenest">
							</div>
						</div>
						<img src="/wp-content/uploads/2025/05/img-hand.webp" class="image_hand_robot" alt="Homenest" title="Homenest">
						<img src="/wp-content/uploads/2025/05/3d-rendering-arrow-icon.webp" class="image_arrow" alt="Homenest" title="Homenest">
						<img class="img_blur" src="/wp-content/uploads/2025/05/Vector-1-1.webp" alt="Homenest" title="Homenest">

						<div class="client__about-us">

							<div style="display: flex; align-items: center; justify-content: center; position: relative; height: 70px">
								<div class="image-circle" style="z-index: 1; right: 66%">
									<img src="/wp-content/uploads/2025/05/user-2.webp" alt="Homenest" title="Homenest">
								</div>
								<div class="image-circle" style="z-index: 2; right: 49%">
									<img src="/wp-content/uploads/2025/05/user-3.webp" alt="Homenest" title="Homenest">
								</div>
								<div class="image-circle" style="z-index: 3; right: 31%">
									<img src="/wp-content/uploads/2025/05/user-4.webp" alt="Homenest" title="Homenest">
								</div>
								<div class="image-circle" style="z-index: 4; right: 13%">
									<img src="/wp-content/uploads/2025/05/user-5.webp" alt="Homenest" title="Homenest">
								</div>
							</div>

							<div class="text-container">
								<span>1500+</span>
								<p>Clients satisfied when using our service</p>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="right__about-us">
				<div class="information__about-us">
					<p class="title__about-us">
						About us
					</p>
					<div class="about-section">
						<p class="experience-heading">
							<span class="counter" id="counter">1</span>
							<span class="yearof">Years of Experience</span>
						</p>
						<div class="key-features">
							<div class="feature-point">Professional Work</div>
							<div class="feature-point">Innovative Development</div>
							<div class="feature-point">Dedicated Service</div>
							<div class="feature-point">Reliable Partnership</div>
							<div class="feature-point">Effective Solutions</div>
						</div>
					</div>
				</div>

				<div class="animation-font">
					<p>
						<span style="color: #fff; font-size:  46px">Services</span>
						<span class="animated-text" id="animatedText">We are a comprehensive digital transformation partner, helping businesses achieve breakthroughs and conquer customers in the digital age. </span>
					</p>

					<div class="line">
						<img style="width: 100%" src="/wp-content/uploads/2025/05/img-grid-fl.webp" alt="Homenest" title="Homenest"> 
						<svg xmlns="http://www.w3.org/2000/svg" width="493" height="329" viewBox="0 0 493 329" fill="none">
							<path d="M3.5,0.833 C2.027,0.833 2.027,2.027 0.833,3.5 C0.833,4.973 2.027,6.167 3.5,6.167 C4.973,6.167 6.167,4.973 6.167,3.5 C6.167,2.027 4.973,0.833 3.5,0.833 Z M3.5,4 L480.5,4 C486.851,4 492,9.149 492,15.5 L492,316 C492,322.351 486.851,327.5 480.5,327.5 L416.5,327.5" stroke="url(#paint0_linear)" stroke-width="1" fill="none" style="stroke-dasharray: 894.393; stroke-dashoffset: 894.393;" class="circle"/>
							<defs>
								<linearGradient id="paint0_linear" x1="3.5" y1="171.345" x2="492.5" y2="171.345" gradientUnits="userSpaceOnUse">
									<stop stop-color="#EC04FB"/>
									<stop offset="0.500625" stop-color="#7A69FF"/>
									<stop offset="1" stop-color="#1BE8FF"/>
								</linearGradient>
							</defs>
						</svg>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="homenest__gradient-marquee">
		<div class="container__about-us">
			<div class="block top-block">
				<span>HomeNest.tech // Technologies Meets Imagination.</span>
				<span>HomeNest.tech // Technologies Meets Imagination.</span>
				<span>HomeNest.tech // Technologies Meets Imagination.</span>
				<span>HomeNest.tech // Technologies Meets Imagination.</span>
				<span>HomeNest.tech // Technologies Meets Imagination.</span>
			</div>

			<div class="block bottom-block">
				<span>HomeNest.tech // Technologies Meets Imagination.</span>
				<span>HomeNest.tech // Technologies Meets Imagination.</span>
				<span>HomeNest.tech // Technologies Meets Imagination.</span>
				<span>HomeNest.tech // Technologies Meets Imagination.</span>
				<span>HomeNest.tech // Technologies Meets Imagination.</span>
			</div>
		</div>
	</div>

	<div class="homenest__services">
		<div class="container__about-us"> 
			<div class="services-left">
				<!-- 				<div class="img__service-left">
<img src="/wp-content/uploads/2025/05/abstract-flow-background.webp" >
</div> -->

				<div class="block block-service-7">
					<div class="services-label">Services</div>
					<span class="heading animated-text" id="animatedText">Comprehensive <br> Services at HomeNest </span>
					<a href="/dich-vu/thiet-ke-app" class="button _txt">
						Experience Now!
						<svg class="btn-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
							<path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
						</svg>
					</a>
				</div>
				<div class="block block-service-1"></div>
				<div class="block block-service-2"></div>
				<div class="block block-service-3"></div>
				<div class="block block-service-4"></div>
				<div class="block block-service-5"></div>
				<div class="block block-service-6"></div>
			</div>

			<div class="service-right">
				<div class="cart-list">

					<div class="cart-item">
						<div class="card">
							<div class="card-content">
								<!-- 								<svg xmlns="http://www.w3.org/2000/svg" width="326" height="446" viewBox="0 0 326 446" fill="none"> <foreignObject x="-20" y="-20" width="366" height="486"></foreignObject><path data-figma-bg-blur-radius="20" fill-rule="evenodd" clip-rule="evenodd" d="M326 10C326 4.47715 321.523 0 316 0H10C4.47715 0 0 4.47716 0 10V436C0 441.523 4.47715 446 10 446H119C124.523 446 128.852 441.427 130.452 436.141C134.678 422.171 147.651 412 163 412C178.349 412 191.322 422.171 195.548 436.141C197.148 441.427 201.477 446 207 446H316C321.523 446 326 441.523 326 436V10Z" fill="white" fill-opacity="0.12"></path> <defs> <clipPath id="bgblur_0_1_298_clip_path"> <path fill-rule="evenodd" clip-rule="evenodd" d="M326 10C326 4.47715 321.523 0 316 0H10C4.47715 0 0 4.47716 0 10V436C0 441.523 4.47715 446 10 446H119C124.523 446 128.852 441.427 130.452 436.141C134.678 422.171 147.651 412 163 412C178.349 412 191.322 422.171 195.548 436.141C197.148 441.427 201.477 446 207 446H316C321.523 446 326 441.523 326 436V10Z"></path> <path d="M0,0 L300,0 L300,240 C210,300 90,300 0,240 Z"></path> </clipPath></defs> </svg> -->
								<h3 class="card-title">Website Design Service </h3>
								<div class="card-image">
									<img src="/wp-content/uploads/2025/05/img-service7-508x320-1.webp" alt="Machine Learning Visualization">
								</div>
								<p class="card-description">
									HomeNest works with you to create impressive, UX/UI-compliant, SEO-optimized, and cross-platform websites, helping your brand stand out instantly to customers.
								</p>
								<a class="card-button" href="/en/dich-vu/professional-website-design/">
									<svg class="arrow-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
										<path fill="white" d="M5 13h11.17l-4.88 4.88c-.39.39-.39 1.03 0 1.42.39.39 1.02.39 1.41 0l6.59-6.59c.39-.39.39-1.02 0-1.41l-6.58-6.6c-.39-.39-1.02-.39-1.41 0-.39.39-.39 1.02 0 1.41L16.17 11H5c-.55 0-1 .45-1 1s.45 1 1 1z"/>
									</svg>
								</a>
							</div>
						</div>

					</div>

					<div class="cart-item">
						<div class="card">
							<div class="card-content">
								<h2 class="card-title">Application Design Service </h2>
								<div class="card-image">
									<img src="/wp-content/uploads/2025/05/img-service6-508x320-1.webp" alt="Machine Learning Visualization">
								</div>
								<p class="card-description">
									HomeNest transforms your ideas into smooth, user-friendly mobile applications, helping businesses connect with users anytime, anywhere.
								</p>
								<a class="card-button" href="/en/dich-vu/app-design/">
									<svg class="arrow-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
										<path fill="white" d="M5 13h11.17l-4.88 4.88c-.39.39-.39 1.03 0 1.42.39.39 1.02.39 1.41 0l6.59-6.59c.39-.39.39-1.02 0-1.41l-6.58-6.6c-.39-.39-1.02-.39-1.41 0-.39.39-.39 1.02 0 1.41L16.17 11H5c-.55 0-1 .45-1 1s.45 1 1 1z"/>
									</svg>
								</a>
							</div>
						</div>

					</div>
				</div>

				<div class="cart-list">

					<div class="cart-item">
						<div class="card">
							<div class="card-content">
								<h2 class="card-title">Software Design Service </h2>
								<div class="card-image">
									<img src="/wp-content/uploads/2025/05/img-service5-508x320-1.webp" alt="Machine Learning Visualization">
								</div>
								<p class="card-description">
									HomeNest provides customized software solutions, utilizing new technology to help businesses manage effectively in the digital environment.
								</p>

								<a class="card-button" href="/en/dich-vu/software-design/">
									<svg class="arrow-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
										<path fill="white" d="M5 13h11.17l-4.88 4.88c-.39.39-.39 1.03 0 1.42.39.39 1.02.39 1.41 0l6.59-6.59c.39-.39.39-1.02 0-1.41l-6.58-6.6c-.39-.39-1.02-.39-1.41 0-.39.39-.39 1.02 0 1.41L16.17 11H5c-.55 0-1 .45-1 1s.45 1 1 1z"/>
									</svg>
								</a>
							</div>
						</div>

					</div>

					<div class="cart-item">
						<div class="card">
							<div class="card-content">
								<h2 class="card-title">Digital Marketing Service</h2>
								<div class="card-image">
									<img src="/wp-content/uploads/2025/05/img-service4-508x320-1.webp" alt="Machine Learning Visualization">
								</div>
								<p class="card-description">
									HomeNest offers comprehensive digital marketing services, helping businesses enhance their brand and grow their customer base on digital platforms.
								</p>
								<a class="card-button"  href="/en/dich-vu/digital-marketing/">
									<svg class="arrow-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
										<path fill="white" d="M5 13h11.17l-4.88 4.88c-.39.39-.39 1.03 0 1.42.39.39 1.02.39 1.41 0l6.59-6.59c.39-.39.39-1.02 0-1.41l-6.58-6.6c-.39-.39-1.02-.39-1.41 0-.39.39-.39 1.02 0 1.41L16.17 11H5c-.55 0-1 .45-1 1s.45 1 1 1z"/>
									</svg>
								</a>
							</div>
						</div>

					</div>
				</div>
			</div>
		</div>	
	</div>




	<div class="homenest__popular-question">

		<div class="container__about-us">
			<div class="header">
				<div class="popular-questions">
					<p style="color: #111 !important; font-weight: 500;">FAQ</p>
				</div>
				<span class="animated-text" id="animatedText">Frequently Asked Questions</span>
			</div>

			<div class="divider"></div>

			<div class="faq-item">
				<div class="question-header">
					<div class="question-number">01</div>
					<div class="question-label">Question 1</div>
				</div>
				<div class="question">
					<p>What services does HomeNest offer?</p>
					<div class="button-container">
						<button class="toggle-button minus">−</button>
					</div>
				</div>
				<div class="answer">
					HomeNest provides comprehensive digital transformation solutions: website design, app design, software design, digital marketing, branding, event organizing, website care, and multi-channel advertising, suitable for businesses of all sizes. This provides flexible, cost-optimized, and practical solutions, helping businesses develop sustainably in the digital age.
				</div>
			</div>

			<div class="divider"></div>

			<div class="faq-item">
				<div class="question-header">
					<div class="question-number">02</div>
					<div class="question-label">Question 2</div>
				</div>
				<div class="question">
					<p>Why should I choose HomeNest over other providers?</p>
					<div class="button-container">
						<button class="toggle-button">+</button>
					</div>
				</div>
				<div class="answer hidden">
					HomeNest gathers a team of experienced experts, professional processes, and flexible services, meeting every business need. We are always ready to accompany you, providing effective, secure, and cost-optimized solutions for every client.
				</div>
			</div>

			<div class="divider"></div>

			<div class="faq-item">
				<div class="question-header">
					<div class="question-number">03</div>
					<div class="question-label">Question 3</div>
				</div>
				<div class="question">
					<p>Is the service cost at HomeNest transparent?</p>
					<div class="button-container">
						<button class="toggle-button">+</button>
					</div>
				</div>
				<div class="answer hidden">
					Costs at HomeNest are always transparent and flexible, with a commitment to no hidden fees. We develop diverse service packages, easily customizable to the budget and specific needs of each business, from startups to large corporations. You can be completely confident choosing the most suitable solution for you.
				</div>
			</div>

			<div class="divider"></div>

			<div class="faq-item">
				<div class="question-header">
					<div class="question-number">04</div>
					<div class="question-label">Question 4</div>
				</div>
				<div class="question">
					<p>How long does service implementation take?</p>
					<div class="button-container">
						<button class="toggle-button">+</button>
					</div>
				</div>
				<div class="answer hidden">
					Service implementation time at HomeNest usually ranges from 1 to 3 weeks, depending on the scale and specific requirements of each project. For projects with special features or services, the implementation time may be longer to ensure optimal quality. Therefore, you can contact HomeNest so the team can advise you in more detail.
				</div>
			</div>

			<div class="divider"></div>

			<div class="faq-item">
				<div class="question-header">
					<div class="question-number">05</div>
					<div class="question-label">Question 5</div>
				</div>
				<div class="question">
					<p>How does HomeNest support clients after project handover?</p>
					<div class="button-container">
						<button class="toggle-button">+</button>
					</div>
				</div>
				<div class="answer hidden">
					After project handover, HomeNest is always ready to support you 24/7. We regularly perform maintenance, security updates, and ensure the system runs smoothly. If you wish to expand or make changes, the HomeNest team will provide dedicated consultation so you can confidently grow your business.
				</div>
			</div>

			<div class="divider"></div>
		</div>
	</div>

	<div class="homenest__why-choose-us">
		<div class="overlay-1"></div>
		<div class="top-section">

			<div class="header" style="justify-content: left;">
				<span style="color: #fff; font-size: 16px; text-transform: capitalize;">What Makes HomeNest Different</span>
			</div>

			<div class="title">
				<p class="whychooseus__animated-text" id="whychoosus__animatedText" >
					Creating Digital Value with Flexible Solutions, Custom-Designed for Your Business
				</p>
			</div>

			<div class="content">
				<p>HomeNest delivers flexible solutions with a dedicated and experienced team of experts. HomeNest is committed to long-term partnership, providing solutions that help businesses develop effectively and sustainably.</p>
			</div>

		</div>

		<div class="bottom-section">
			<div class="stats-container">
				<div class="stat-group">
					<div class="stat-number">1k</div>
					<div class="stat-divider">/</div>
					<div class="stat-label">
						<div class="stat-title">Trusted</div>
						<div class="stat-subtitle">Clients</div>
					</div>
				</div>

				<div class="stat-group">
					<div class="stat-number">1k5<span class="stat-plus">+</span></div>
					<div class="stat-divider">/</div>
					<div class="stat-label">
						<div class="stat-title">Completed</div>
						<div class="stat-subtitle">Projects</div>
					</div>
				</div>

				<div class="stat-group">
					<div class="stat-number">10<span class="stat-plus">+</span></div>
					<div class="stat-divider">/</div>
					<div class="stat-label">
						<div class="stat-title">Years</div>
						<div class="stat-subtitle">of Experience</div>
					</div>
				</div>
			</div>

			<div class="feature-list-container">
				<div class="feature-list">
					<div class="feature-item">
						<span class="feature-icon">✦</span>
						Experienced team
					</div>

					<div class="feature-item">
						<span class="feature-icon">✦</span>
						Comprehensive solutions
					</div>

					<div class="feature-item">
						<span class="feature-icon">✦</span>
						Transparent, reasonable costs
					</div>

					<div class="feature-item">
						<span class="feature-icon">✦</span>
						24/7 technical support
					</div>

					<div class="feature-item">
						<span class="feature-icon">✦</span>
						Security & stable operation
					</div>

					<div class="feature-item">
						<span class="feature-icon">✦</span>
						Reliability and transparency
					</div>

					<div class="feature-item">
						<span class="feature-icon">✦</span>
						Commitment to long-term partnership
					</div>
				</div>
			</div>
		</div>

	</div>

	<div class="homenest__blog-new">
		<div class="container__about-us">
			<div class="blog-container">
				<div class="blog-header">
					<div class="blog-category">
						<span style="color: #111;">Handbook & News</span>	
					</div>
					<span class="blog-title animated-text" id="animatedText">HomeNest Handbook <br>
						News & Expert Insights</span>
				</div>

				<div class="blog-grid">
					<?php
					// Lấy bài viết mới nhất
					$latest_post = get_posts(array(
						'post_type' => 'post',
						'posts_per_page' => 1,
						'post_status' => 'publish'
					));

					if ($latest_post) :
					// Thiết lập dữ liệu post
					$post = $latest_post[0];
					setup_postdata($post);

					// Lấy ngày đăng
					$day = get_the_date('d');
					$month = get_the_date('F');

					// Lấy hình ảnh đại diện
					$thumbnail_url = get_the_post_thumbnail_url($post->ID, 'full');
					if (!$thumbnail_url) {
						$thumbnail_url = '/wp-content/uploads/2025/05/img-post-update1-1720x600-1.webp'; // Hình mặc định
					}
					?>
					<a class="blog-card" href="<?php echo get_permalink($post->ID) ?>" style="text-decoration: none;">
						<div class="blog-card-image">
							<img src="<?php echo esc_url($thumbnail_url); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
							<div class="blog-date">
								<div class="blog-date-day"><?php echo $day; ?></div>
								<div class="blog-date-month"><?php echo $month; ?></div>
							</div>
						</div>
						<div class="blog-content">
							<h2><?php echo get_the_title(); ?></h2>
							<p><?php echo wp_trim_words(get_the_excerpt(), 20, '...'); ?></p>
						</div>
						<div class="block-color" style="position: absolute;top: 20%;right: 0%;z-index: -1;">
							<img src="/wp-content/uploads/2025/05/Group1261154698.webp" alt="Homenest" title="Homenest">
						</div>
					</a>
					<?php
					wp_reset_postdata();
					else :
					// Nếu không có bài viết nào, hiển thị nội dung mặc định
					?>
					<div class="blog-card">
						<div class="blog-card-image">
							<img src="/wp-content/uploads/2025/05/img-post-update1-1720x600-1.webp" alt="Default Post">
							<div class="blog-date">
								<div class="blog-date-day">--</div>
								<div class="blog-date-month">----</div>
							</div>
						</div>
						<div class="blog-content">
							<h2>Chưa có bài viết nào</h2>
							<p>Vui lòng thêm bài viết mới.</p>
						</div>
						<div class="block-color" style="position: absolute;top: 16%;right: 0%;z-index: -1;">
							<img src="/wp-content/uploads/2025/05/Group1261154698.webp" alt="Homenest" title="Homenest">
						</div>
					</div>
					<?php endif; ?>

					<div class="blog-card-right">
						<?php
						$latest_posts = get_posts(array(

							'post_type' => 'post',
							'posts_per_page' => 6,
							'post_status' => 'publish',
							'offset' => 1
						)); ?>
						<!-- Navigation -->
						<div class="navigation">
							<button id="prevBtn"><svg width="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="icon line" transform="scale(-1 1)"><path style="fill:none;stroke:#fff;stroke-linecap:round;stroke-linejoin:round;stroke-width:1.5" d="m14 5 7 7-7 7"/><path data-name="primary" style="fill:none;stroke:#fff;stroke-linecap:round;stroke-linejoin:round;stroke-width:1.5" d="M21 12H3"/></svg></button>
							<?php
							if (!empty($latest_posts)) {
								$dot_count = count($latest_posts);
								for ($i = 1; $i < $dot_count; $i++) {
									echo '<span class="dot" data-index="' . $i . '"></span>';
								}
							}
							?>
							<button id="nextBtn"><svg fill="#fff" width="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="icon line"><path style="fill:none;stroke:#fff;stroke-linecap:round;stroke-linejoin:round;stroke-width:1.5" d="m14 5 7 7-7 7"/><path data-name="primary" style="fill:none;stroke:#fff;stroke-linecap:round;stroke-linejoin:round;stroke-width:1.5" d="M21 12H3"/></svg></button>
						</div>


						<!-- Posts -->

						<?php
						if ($latest_posts) :
						echo '<div class="posts"><div class="post-wrapper">';
						foreach ($latest_posts as $post) :
						setup_postdata($post);
						// Lấy ngày đăng
						$day = get_the_date('d');
						$month = get_the_date('F');
						?>
						<!-- Post 1 -->
						<a href="<?php echo get_permalink($post->ID) ?>" class="post" style="text-decoration: none;" >
							<div class="post-inner">
								<div class="post-image" style="background: url('<?php echo get_the_post_thumbnail_url(get_the_ID()) ?>') center / cover no-repeat;">
									<div class="date-tag">
										<span class="day"><?php echo $day; ?></span>
										<span class="month"><?php echo $month ?></span>
									</div>
								</div>
								<div class="post-content">
									<h2><?php the_title(); ?></h2>
									<p><?php echo wp_trim_words(get_the_excerpt(), 25, '...'); ?></p>
								</div>
							</div>
						</a>

						<?php
						endforeach;
						wp_reset_postdata();
						echo '</div></div>';
						else :
						echo '<p>Không tìm thấy bài viết nào</p>';
						endif;
						?>

						<?php 
						// Hiển thị phân trang nếu có nhiều bài viết
						the_posts_pagination(array(
							'mid_size' => 6,
							'prev_text' => __('Trước'),
							'next_text' => __('Sau'),
						));
						?>
					</div>
				</div>
			</div>
		</div>

		<div class="btn__blog-new">
			<a href="<?php echo get_permalink( get_page_by_path('blog') ); ?>" class="btn__about-us" data-text="View All Blog">
				<svg class="btn-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
					<path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
				</svg>
			</a>
		</div>
	</div>	
	<div class="homenest__image-globe">
		<div class="rotating-image">
			<img class="img-globe" src="/wp-content/uploads/2025/05/global2.webp" alt="Homenest" title="Homenest">			
		</div>
	</div>

	<div class="homenest__testimonial">
		<div class="testimonial-container">
			<!-- Avatar Container -->
			<div class="avatar-container" id="avatarContainer">
				<!-- Avatars will be inserted here via JavaScript -->
			</div>

			<!-- Testimonial Slider -->
			<div class="slider-container" id="sliderContainer">
				<div class="slider-track" id="sliderTrack">
					<!-- Testimonials will be inserted here via JavaScript -->
				</div>
			</div>

			<!-- Dots Indicator -->
			<div class="dots-container" id="dotsContainer">
				<!-- Dots will be inserted here via JavaScript -->
			</div>
		</div>	

		<div class="img-testimonial">
			<img src="/wp-content/uploads/2025/05/image-young-lady.webp" alt="Homenest" title="Homenest"> 
			<img src="/wp-content/uploads/2025/05/3d-rendering-arrow-icon525.webp" alt="Homenest" title="Homenest">
		</div>
	</div>

</main>

<script>
	

</script>

<?php get_footer(); ?>
