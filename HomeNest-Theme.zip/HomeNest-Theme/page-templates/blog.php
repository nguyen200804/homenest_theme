<?php
/*
Template Name: Blog
*/
get_header(); ?>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,wght@0,400;0,500;0,700;1,400&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">



<div class="hero-section">
    <div class="main-content">
        <h1 class="blog-title">Khám phá Blog sáng tạo</h1>
        <p class="blog-description">Khám phá những hiểu biết mới mẻ và ý tưởng sáng tạo bằng cách khám phá blog của chúng tôi, nơi chúng tôi chia sẻ những quan điểm sáng tạo</p>
        <a href="#" class="discover-btn">
           Khám phá thêm 
         <svg width="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="icon line"><path style="fill:none;stroke:#fff;stroke-linecap:round;stroke-linejoin:round;stroke-width:1.5" d="m14 5 7 7-7 7"/><path data-name="primary" style="fill:none;stroke:#fff;stroke-linecap:round;stroke-linejoin:round;stroke-width:1.5" d="M21 12H3"/></svg>
        </a>
    </div>
</div>

<div class="page-menu-wrapper">
    <div class="page-menu-overlay"></div>
    <div class="page-menu">
        <div class="page-menu-header">
            <h3 class="homenest__blog__page-menu-header">Danh Mục</h3>
            <button class="close-page-menu">×</button>
        </div>
        
        <div class="menu-block">
            <h4>Tìm Kiếm</h4>
            <form role="search" method="get" action="<?php echo home_url('/'); ?>" class="menu-search">
                <input type="search" placeholder="Tìm kiếm..." name="s">
                <button type="submit"><svg width="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10 4a6 6 0 1 0 0 12 6 6 0 0 0 0-12m-8 6a8 8 0 1 1 14.32 4.906l5.387 5.387a1 1 0 0 1-1.414 1.414l-5.387-5.387A8 8 0 0 1 2 10" fill="#fff"/></svg></button>
            </form>
        </div>

        <div class="menu-block">
            <h4>Danh mục</h4>
            <ul class="menu-list">
                <?php
                $categories = get_categories();
                foreach($categories as $category) {
                    echo '<li>
                            <a href="' . get_category_link($category->term_id) . '">
                                <span>' . $category->name . '</span>
                                <span class="count">' . $category->count . '</span>
                            </a>
                          </li>';
                }
                ?>
            </ul>
        </div>

        <div class="menu-block">
            <h4>Bài Viết Mới Nhất</h4>
            <ul class="menu-list">
                <?php
                $recent_posts = wp_get_recent_posts(array(
                    'numberposts' => 5,
                    'post_status' => 'publish'
                ));
                foreach($recent_posts as $post) {
                    echo '<li>
                            <a href="' . get_permalink($post['ID']) . '">
                                ' . $post['post_title'] . '
                            </a>
                          </li>';
                }
                wp_reset_postdata();
                ?>
            </ul>
        </div>

        <div class="menu-block">
            <h4>Thẻ</h4>
            <div class="menu-tags">
                <?php
                $tags = get_tags();
                if($tags) {
                    foreach($tags as $tag) {
                        echo '<a href="' . get_tag_link($tag->term_id) . '">' 
                            . $tag->name . '</a>';
                    }
                }
                ?>
            </div>
        </div>
    </div>
</div>
<button class="page-menu-toggle">
                <i class="fa-regular fa-grid-2"></i>
            </button>
<div class="blog-content">
    <div class="blog-main">
        <div class="page-menu-trigger">
          
        </div>
        <div class="blog-grid">
            <?php
            $args = array(
                'post_type' => 'post',
                'posts_per_page' => -1, // Load tất cả bài viết
            );
            $blog_query = new WP_Query($args);

            if ($blog_query->have_posts()) :
                while ($blog_query->have_posts()) : $blog_query->the_post();
            ?>
                <div class="blog-post">
                    <div class="post-image">
                        <?php if (has_post_thumbnail()) : ?>
                            <a href="<?php the_permalink(); ?>">
                                <?php the_post_thumbnail('large', array('class' => 'post-image')); ?>
                            </a>
                        <?php else : ?>
                            <a href="<?php the_permalink(); ?>">
                                <img src="/wp-content/uploads/2025/07/Logo_HomeNest-team.webp" alt="<?php the_title(); ?>">
                            </a>
                        <?php endif; ?>
                        <div class="post-category">
                            <?php
                            $categories = get_the_category();
                            if (!empty($categories)) {
                                echo esc_html($categories[0]->name);
                            }
                            ?>
                        </div>
                    </div>
                    <div class="post-content">
                        <h3 class="post-title">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </h3>
                        <div class="post-meta">
                            <div class="author-info">
                                <div class="author-avatar">
                                    <?php echo get_avatar(get_the_author_meta('ID'), 40); ?>
                                </div>
                                <div class="author-meta">
                                    <span class="by">Tác giả:</span>
                                    <span class="author-name"><?php the_author(); ?></span>
                                </div>
                            </div>
                            <span class="post-date"><?php 
                                $date = get_the_date('F j, Y');
                                $date = str_replace(
                                    array('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'),
                                    array('Tháng 1', 'Tháng 2', 'Tháng 3', 'Tháng 4', 'Tháng 5', 'Tháng 6', 'Tháng 7', 'Tháng 8', 'Tháng 9', 'Tháng 10', 'Tháng 11', 'Tháng 12'),
                                    $date
                                );
                                echo $date;
                            ?></span>
                        </div>
                        <p class="post-excerpt"><?php echo wp_trim_words(get_the_excerpt(), 20, '...'); ?></p>
                        <a href="<?php the_permalink(); ?>" class="read-more">Đọc thêm <svg width="20" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="icon line"><path style="fill:none;stroke:#1a85f8;stroke-linecap:round;stroke-linejoin:round;stroke-width:1.5" d="m14 5 7 7-7 7"/><path data-name="primary" style="fill:none;stroke:#1a85f8;stroke-linecap:round;stroke-linejoin:round;stroke-width:1.5" d="M21 12H3"/></svg></a>
                    </div>
                </div>
            <?php
                endwhile;
                wp_reset_postdata();
            else :
                echo '<p>Không tìm thấy bài viết nào.</p>';
            endif;
            ?>
        </div>
        
        <div class="load-more-container">
            <button id="load-more" class="load-more-button" data-page="1" data-max="<?php echo $blog_query->max_num_pages; ?>">
                <span>Xem thêm <svg width="20" fill="#fff" viewBox="-77 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="m98 460-34-34 163-164L64 98l34-34 196 198z"/></svg></span>
            </button>
        </div>
    </div>

    <div class="search-section">
        <div class="search-container">
            <h3 class="homenest__blog__search-title">Tìm kiếm</h3>
            <div class="search-box">
                <form role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
                    <input type="text" class="search-input" placeholder="Tìm kiếm..." value="<?php echo get_search_query(); ?>" name="s">
                    <button type="submit" class="search-button">
                        <svg width="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10 4a6 6 0 1 0 0 12 6 6 0 0 0 0-12m-8 6a8 8 0 1 1 14.32 4.906l5.387 5.387a1 1 0 0 1-1.414 1.414l-5.387-5.387A8 8 0 0 1 2 10" fill="#fff"/></svg>
                    </button>
                </form>
            </div>

            <div class="categories-section">
                <h3 class="homenest__blog__categories-title">Thể loại</h3>
                <ul class="categories-list">
                    <?php
                    $categories = get_categories(array(
                        'orderby' => 'name',
                        'order' => 'ASC',
                        'hide_empty' => true,
                    ));
                    foreach ($categories as $category) :
                    ?>
                        <li class="category-item">
                            <span>
                                <svg width="16" viewBox="-77 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="m98 460-34-34 163-164L64 98l34-34 196 198z"/></svg>
                                <a href="<?php echo get_category_link($category->term_id); ?>">
                                    <?php echo esc_html($category->name); ?>
                                </a>
                            </span>
                            <span class="category-count"><?php echo $category->count; ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div class="recent-posts">
                <h3 class="homenest__blog__recent-posts-title">Bài viết gần đây</h3>
                <?php
                $recent_posts = new WP_Query(array(
                    'post_type' => 'post',
                    'posts_per_page' => 3,
                    'orderby' => 'date',
                    'order' => 'DESC',
                ));
                if ($recent_posts->have_posts()) :
                    while ($recent_posts->have_posts()) : $recent_posts->the_post();
                ?>
                    <div class="recent-post-item">
                        <div class="recent-post-image">
                            <?php if (has_post_thumbnail()) : ?>
                                <a href="<?php the_permalink(); ?>">
                                    <?php the_post_thumbnail('thumbnail'); ?>
                                </a>
                            <?php else : ?>
                                <a href="<?php the_permalink(); ?>">
                                    <img src="/wp-content/uploads/2025/07/Logo_HomeNest-team.webp" alt="<?php the_title(); ?>">
                                </a>
                            <?php endif; ?>
                        </div>
                        <div class="recent-post-content">
                            <span class="post-category-label">
                                <?php
                                $categories = get_the_category();
                                if (!empty($categories)) {
                                    echo esc_html($categories[0]->name);
                                }
                                ?>
                            </span>
                            <h4 class="recent-post-title">
                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            </h4>
                            <div class="recent-post-meta">
                                <span><svg width="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="2" y="4" width="20" height="18" rx="4" stroke="#666" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M8 2v4m8-4v4M2 10h20" stroke="#666" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg> <?php echo get_the_date('F j, Y'); ?></span>
                            </div>
                        </div>
                    </div>
                <?php
                    endwhile;
                    wp_reset_postdata();
                endif;
                ?>
            </div>

            <div class="tags-section">
                <h3 class="homenest__blog__tags-title">Thẻ</h3>
                <div class="tags-cloud">
                    <?php
                    $tags = get_tags(array(
                        'hide_empty' => true,
                    ));
                    foreach ($tags as $tag) :
                    ?>
                        <a href="<?php echo get_tag_link($tag->term_id); ?>" class="tag-item">
                            <?php echo esc_html($tag->name); ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>




<?php
// Thêm function này vào functions.php
function load_more_posts() {
    check_ajax_referer('load_more_nonce', 'nonce');
    
    $page = $_POST['page'];
    $args = array(
        'post_type' => 'post',
        'posts_per_page' => 6,
        'paged' => $page,
    );
    
    $blog_query = new WP_Query($args);
    $response = array();
    
    if ($blog_query->have_posts()) {
        ob_start();
        while ($blog_query->have_posts()) {
            $blog_query->the_post();
            // Include template part cho single post
            get_template_part('template-parts/content', 'blog-item');
        }
        $response['success'] = true;
        $response['data']['html'] = ob_get_clean();
    } else {
        $response['success'] = false;
    }
    
    wp_send_json($response);
    wp_die();
}
add_action('wp_ajax_load_more_posts', 'load_more_posts');
add_action('wp_ajax_nopriv_load_more_posts', 'load_more_posts');

// Thêm nonce cho AJAX
function add_load_more_nonce() {
    wp_localize_script('your-theme-scripts', 'loadMoreNonce', wp_create_nonce('load_more_nonce'));
}
add_action('wp_enqueue_scripts', 'add_load_more_nonce');
?>

<?php get_footer(); ?>