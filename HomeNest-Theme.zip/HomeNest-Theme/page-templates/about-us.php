<?php
/*
Template Name: About Us
*/
get_header(); ?>




<main id='page-about-us'>

	<div class="homenest__hero-section">
		<div class="container__about-us">
			<div style="padding: 0 15px">
				<h1 class="heading-primary">HomeNest <span class="heading-secondary">- Câu chuyện đội ngũ và sứ mệnh</span></h1>

			</div>
			<div style="padding: 15px">
				<p class="description">HomeNest đồng hành cùng doanh nghiệp chuyển đổi số, xây dựng thương hiệu và phát triển bền vững</p>
				<a href="#" class="button _txt __about-us">
					Tìm hiểu ngay!
					<svg class="btn-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
						<path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
					</svg>
				</a>
			</div>
		</div>
	</div>

	<div class="homenest__about-us">
		<div class="container__about-us">
			<div class="left__about-us">
				<div class="grid-container">

					<div class="cricle__about-us">
						<div class="center_shape">
							<div class="rotate_wrap">
								<img src="/wp-content/uploads/2025/05/img-cricle1.webp" class="shape shape1" alt="Homenest" title="Homenest">
								<img src="/wp-content/uploads/2025/05/img-cricle2.webp" class="shape shape2" alt="Homenest" title="Homenest">
								<img src="/wp-content/uploads/2025/05/img-cricle3.webp" class="shape shape3" alt="Homenest" title="Homenest">
							</div>
						</div>
						<img src="/wp-content/uploads/2025/05/img-hand.webp" class="image_hand_robot" alt="Homenest" title="Homenest">
						<img src="/wp-content/uploads/2025/05/3d-rendering-arrow-icon.webp" class="image_arrow" alt="Homenest" title="Homenest">
						<img class="img_blur" src="/wp-content/uploads/2025/05/Vector-1-1.webp" alt="Homenest" title="Homenest">

						<div class="client__about-us">

							<div style="display: flex; align-items: center; justify-content: center; position: relative; height: 70px">
								<div class="image-circle" style="z-index: 1; right: 66%">
									<img src="/wp-content/uploads/2025/05/user-2.webp" alt="Homenest" title="Homenest">
								</div>
								<div class="image-circle" style="z-index: 2; right: 49%">
									<img src="/wp-content/uploads/2025/05/user-3.webp" alt="Homenest" title="Homenest">
								</div>
								<div class="image-circle" style="z-index: 3; right: 31%">
									<img src="/wp-content/uploads/2025/05/user-4.webp" alt="Homenest" title="Homenest">
								</div>
								<div class="image-circle" style="z-index: 4; right: 13%">
									<img src="/wp-content/uploads/2025/05/user-5.webp" alt="Homenest" title="Homenest">
								</div>
							</div>

							<div class="text-container">
								<span>1500+</span>
								<p>Khách hàng đã hài lòng khi sử dụng dịch vụ của chúng tôi</p>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="right__about-us">
				<div class="information__about-us">
					<p class="title__about-us">
						Về chúng tôi
					</p>
					<div class="about-section">
						<p class="experience-heading">
							<span class="counter" id="counter">1</span>
							<span class="yearof">Năm kinh nghiệm</span>
						</p>
						<div class="key-features">
							<div class="feature-point">Làm việc chuyên nghiệp</div>
							<div class="feature-point">Đổi mới sáng tạo</div>
							<div class="feature-point">Phục vụ tận tâm</div>
							<div class="feature-point">Hợp tác tin cậy</div>
							<div class="feature-point">Giải pháp hiệu quả</div>
						</div>
					</div>
				</div>

				<div class="animation-font">
					<p>
						<span style="color: #fff; font-size:  46px">Dịch vụ</span>
						<span class="animated-text" id="animatedText">Chúng tôi là đối tác chuyển đổi số toàn diện, giúp doanh nghiệp bứt phá và chinh phục khách hàng trong kỷ nguyên số</span>
					</p>

					<div class="line">
						<img style="width: 100%" src="/wp-content/uploads/2025/05/img-grid-fl.webp" alt="Homenest" title="Homenest"> 
						<svg xmlns="http://www.w3.org/2000/svg" width="493" height="329" viewBox="0 0 493 329" fill="none">
							<path d="M3.5,0.833 C2.027,0.833 2.027,2.027 0.833,3.5 C0.833,4.973 2.027,6.167 3.5,6.167 C4.973,6.167 6.167,4.973 6.167,3.5 C6.167,2.027 4.973,0.833 3.5,0.833 Z M3.5,4 L480.5,4 C486.851,4 492,9.149 492,15.5 L492,316 C492,322.351 486.851,327.5 480.5,327.5 L416.5,327.5" stroke="url(#paint0_linear)" stroke-width="1" fill="none" style="stroke-dasharray: 894.393; stroke-dashoffset: 894.393;" class="circle"/>
							<defs>
								<linearGradient id="paint0_linear" x1="3.5" y1="171.345" x2="492.5" y2="171.345" gradientUnits="userSpaceOnUse">
									<stop stop-color="#EC04FB"/>
									<stop offset="0.500625" stop-color="#7A69FF"/>
									<stop offset="1" stop-color="#1BE8FF"/>
								</linearGradient>
							</defs>
						</svg>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="homenest__gradient-marquee">
		<div class="container__about-us">
			<div class="block top-block">
				<span>HomeNest.tech // Technologies Meets Imagination.</span>
				<span>HomeNest.tech // Technologies Meets Imagination.</span>
				<span>HomeNest.tech // Technologies Meets Imagination.</span>
				<span>HomeNest.tech // Technologies Meets Imagination.</span>
				<span>HomeNest.tech // Technologies Meets Imagination.</span>
			</div>

			<div class="block bottom-block">
				<span>HomeNest.tech // Technologies Meets Imagination.</span>
				<span>HomeNest.tech // Technologies Meets Imagination.</span>
				<span>HomeNest.tech // Technologies Meets Imagination.</span>
				<span>HomeNest.tech // Technologies Meets Imagination.</span>
				<span>HomeNest.tech // Technologies Meets Imagination.</span>
			</div>
		</div>
	</div>

	<div class="homenest__services">
		<div class="container__about-us"> 
			<div class="services-left">
				<!-- 				<div class="img__service-left">
<img src="/wp-content/uploads/2025/05/abstract-flow-background.webp" >
</div> -->

				<div class="block block-service-7">
					<div class="services-label">Dịch vụ</div>
					<span class="heading animated-text" id="animatedText">Dịch vụ toàn diện<br> tại HomeNest</span>
					<a href="/dich-vu/thiet-ke-app" class="button _txt">
						Trải nghiệm ngay!
						<svg class="btn-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
							<path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
						</svg>
					</a>
				</div>
				<div class="block block-service-1"></div>
				<div class="block block-service-2"></div>
				<div class="block block-service-3"></div>
				<div class="block block-service-4"></div>
				<div class="block block-service-5"></div>
				<div class="block block-service-6"></div>
			</div>

			<div class="service-right">
				<div class="cart-list">

					<div class="cart-item">
						<div class="card">
							<div class="card-content">
								<!-- 								<svg xmlns="http://www.w3.org/2000/svg" width="326" height="446" viewBox="0 0 326 446" fill="none"> <foreignObject x="-20" y="-20" width="366" height="486"></foreignObject><path data-figma-bg-blur-radius="20" fill-rule="evenodd" clip-rule="evenodd" d="M326 10C326 4.47715 321.523 0 316 0H10C4.47715 0 0 4.47716 0 10V436C0 441.523 4.47715 446 10 446H119C124.523 446 128.852 441.427 130.452 436.141C134.678 422.171 147.651 412 163 412C178.349 412 191.322 422.171 195.548 436.141C197.148 441.427 201.477 446 207 446H316C321.523 446 326 441.523 326 436V10Z" fill="white" fill-opacity="0.12"></path> <defs> <clipPath id="bgblur_0_1_298_clip_path"> <path fill-rule="evenodd" clip-rule="evenodd" d="M326 10C326 4.47715 321.523 0 316 0H10C4.47715 0 0 4.47716 0 10V436C0 441.523 4.47715 446 10 446H119C124.523 446 128.852 441.427 130.452 436.141C134.678 422.171 147.651 412 163 412C178.349 412 191.322 422.171 195.548 436.141C197.148 441.427 201.477 446 207 446H316C321.523 446 326 441.523 326 436V10Z"></path> <path d="M0,0 L300,0 L300,240 C210,300 90,300 0,240 Z"></path> </clipPath></defs> </svg> -->
								<h3 class="card-title">Dịch Vụ Thiết Kế Website </h3>
								<div class="card-image">
									<img src="/wp-content/uploads/2025/05/img-service7-508x320-1.webp" alt="Machine Learning Visualization">
								</div>
								<p class="card-description">
									HomeNest cùng bạn tạo website ấn tượng, chuẩn UX/UI, tối ưu SEO và đa nền tảng, giúp thương hiệu nổi bật ngay trong mắt khách hàng 
								</p>
								<a class="card-button" href="/dich-vu/thiet-ke-website/">
									<svg class="arrow-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
										<path fill="white" d="M5 13h11.17l-4.88 4.88c-.39.39-.39 1.03 0 1.42.39.39 1.02.39 1.41 0l6.59-6.59c.39-.39.39-1.02 0-1.41l-6.58-6.6c-.39-.39-1.02-.39-1.41 0-.39.39-.39 1.02 0 1.41L16.17 11H5c-.55 0-1 .45-1 1s.45 1 1 1z"/>
									</svg>
								</a>
							</div>
						</div>

					</div>

					<div class="cart-item">
						<div class="card">
							<div class="card-content">
								<h2 class="card-title">Dịch Vụ Thiết Kế Ứng Dụng </h2>
								<div class="card-image">
									<img src="/wp-content/uploads/2025/05/img-service6-508x320-1.webp" alt="Machine Learning Visualization">
								</div>
								<p class="card-description">
									HomeNest biến ý tưởng của bạn thành ứng dụng di động mượt mà, giao diện thân thiện, giúp doanh nghiệp kết nối nguời dùng mọi lúc, mọi nơi
								</p>
								<a class="card-button" href="/dich-vu/thiet-ke-website/">
									<svg class="arrow-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
										<path fill="white" d="M5 13h11.17l-4.88 4.88c-.39.39-.39 1.03 0 1.42.39.39 1.02.39 1.41 0l6.59-6.59c.39-.39.39-1.02 0-1.41l-6.58-6.6c-.39-.39-1.02-.39-1.41 0-.39.39-.39 1.02 0 1.41L16.17 11H5c-.55 0-1 .45-1 1s.45 1 1 1z"/>
									</svg>
								</a>
							</div>
						</div>

					</div>
				</div>

				<div class="cart-list">

					<div class="cart-item">
						<div class="card">
							<div class="card-content">
								<h2 class="card-title">Dịch Vụ Thiết Kế Phần Mềm </h2>
								<div class="card-image">
									<img src="/wp-content/uploads/2025/05/img-service5-508x320-1.webp" alt="Machine Learning Visualization">
								</div>
								<p class="card-description">
									HomeNest cung cấp giải pháp phần mềm tùy chỉnh, ứng dụng công nghệ mới giúp doanh nghiệp quản lý hiệu quả trong môi trường số.
								</p>

								<a class="card-button" href="/dich-vu/thiet-ke-phan-mem/">
									<svg class="arrow-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
										<path fill="white" d="M5 13h11.17l-4.88 4.88c-.39.39-.39 1.03 0 1.42.39.39 1.02.39 1.41 0l6.59-6.59c.39-.39.39-1.02 0-1.41l-6.58-6.6c-.39-.39-1.02-.39-1.41 0-.39.39-.39 1.02 0 1.41L16.17 11H5c-.55 0-1 .45-1 1s.45 1 1 1z"/>
									</svg>
								</a>
							</div>
						</div>

					</div>

					<div class="cart-item">
						<div class="card">
							<div class="card-content">
								<h2 class="card-title">Dịch Vụ Digital Marketing</h2>
								<div class="card-image">
									<img src="/wp-content/uploads/2025/05/img-service4-508x320-1.webp" alt="Machine Learning Visualization">
								</div>
								<p class="card-description">
									HomeNest cung cấp dịch vụ digital marketing tổng thể, giúp doanh nghiệp nâng cao thương hiệu và tăng trưởng khách hàng trên nền tảng số.
								</p>
								<a class="card-button"  href="/dich-vu/digital-marketing/">
									<svg class="arrow-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
										<path fill="white" d="M5 13h11.17l-4.88 4.88c-.39.39-.39 1.03 0 1.42.39.39 1.02.39 1.41 0l6.59-6.59c.39-.39.39-1.02 0-1.41l-6.58-6.6c-.39-.39-1.02-.39-1.41 0-.39.39-.39 1.02 0 1.41L16.17 11H5c-.55 0-1 .45-1 1s.45 1 1 1z"/>
									</svg>
								</a>
							</div>
						</div>

					</div>
				</div>
			</div>
		</div>	
	</div>




	<div class="homenest__popular-question">

		<div class="container__about-us">
			<div class="header">
				<div class="popular-questions">
					<p style="color: #111 !important; font-weight: 500;">FAQ</p>
				</div>
				<span class="animated-text" id="animatedText">Những câu hỏi thường gặp</span>
			</div>

			<div class="divider"></div>

			<div class="faq-item">
				<div class="question-header">
					<div class="question-number">01</div>
					<div class="question-label">Câu hỏi số 1</div>
				</div>
				<div class="question">
					<p>HomeNest cung cấp những dịch vụ gì?</p>
					<div class="button-container">
						<button class="toggle-button minus">−</button>
					</div>
				</div>
				<div class="answer">
					HomeNest cung cấp giải pháp chuyển đổi số toàn diện: thiết kế website, thiết kế app, thiết kế phần mềm, digital marketing, branding, tổ chức sự kiện, chăm sóc website và quảng cáo đa kênh, phù hợp cho mọi quy mô doanh nghiệp.Giúp mang đến giải pháp linh hoạt, tối ưu chi phí và hiệu quả thực tiễn, giúp doanh nghiệp phát triển bền vững trong kỷ nguyên số.
				</div>
			</div>

			<div class="divider"></div>

			<div class="faq-item">
				<div class="question-header">
					<div class="question-number">02</div>
					<div class="question-label">Câu hỏi số 2</div>
				</div>
				<div class="question">
					<p>Vì sao nên chọn HomeNest thay vì các đơn vị khác?</p>
					<div class="button-container">
						<button class="toggle-button">+</button>
					</div>
				</div>
				<div class="answer hidden">
					HomeNest quy tụ đội ngũ chuyên gia giàu kinh nghiệm, quy trình chuyên nghiệp và dịch vụ linh hoạt, đáp ứng mọi nhu cầu của doanh nghiệp. Chúng tôi luôn sẵn sàng đồng hành, mang đến giải pháp hiệu quả, an toàn và tối ưu chi phí cho từng khách hàng.
				</div>
			</div>

			<div class="divider"></div>

			<div class="faq-item">
				<div class="question-header">
					<div class="question-number">03</div>
					<div class="question-label">Cau hỏi số 3</div>
				</div>
				<div class="question">
					<p>Chi phí dịch vụ tại HomeNest có minh bạch không?</p>
					<div class="button-container">
						<button class="toggle-button">+</button>
					</div>
				</div>
				<div class="answer hidden">
					Chi phí tại HomeNest luôn minh bạch và linh hoạt, cam kết không phát sinh khoản phí ẩn. Chúng tôi xây dựng đa dạng gói dịch vụ, dễ dàng tùy chỉnh theo ngân sách và nhu cầu riêng của từng doanh nghiệp, từ startup đến tập đoàn lớn. Bạn hoàn toàn an tâm lựa chọn giải pháp phù hợp nhất cho mình.
				</div>
			</div>

			<div class="divider"></div>

			<div class="faq-item">
				<div class="question-header">
					<div class="question-number">04</div>
					<div class="question-label">Câu hỏi số 4</div>
				</div>
				<div class="question">
					<p>Thời gian triển khai dịch vụ mất bao lâu?</p>
					<div class="button-container">
						<button class="toggle-button">+</button>
					</div>
				</div>
				<div class="answer hidden">
					Thời gian triển khai dịch vụ tại HomeNest thường dao động từ 1 đến 3 tuần, tùy theo quy mô và yêu cầu cụ thể của từng dự án. Với các dự án có tính năng hoặc dịch vụ đặc biệt, thời gian thực hiện có thể dài hơn để đảm bảo chất lượng tối ưu. Nên bạn có thể liên hệ với HomeNest, để đội ngũ có thể tư vấn cho bạn chi tiết hơn.
				</div>
			</div>

			<div class="divider"></div>

			<div class="faq-item">
				<div class="question-header">
					<div class="question-number">05</div>
					<div class="question-label">Câu hỏi số 5</div>
				</div>
				<div class="question">
					<p>HomeNest hỗ trợ khách hàng như thế nào sau khi bàn giao dự án?</p>
					<div class="button-container">
						<button class="toggle-button">+</button>
					</div>
				</div>
				<div class="answer hidden">
					Sau khi bàn giao dự án, HomeNest luôn sẵn sàng hỗ trợ bạn 24/7. Chúng tôi thường xuyên bảo trì, cập nhật bảo mật và giúp hệ thống hoạt động mượt mà. Nếu bạn muốn mở rộng hay thay đổi, đội ngũ HomeNest sẽ tư vấn tận tình để bạn yên tâm phát triển doanh nghiệp.
				</div>
			</div>

			<div class="divider"></div>
		</div>
	</div>

	<div class="homenest__why-choose-us">
		<div class="overlay-1"></div>
		<div class="top-section">

			<div class="header" style="justify-content: left;">
				<span style="color: #fff; font-size: 16px; text-transform: capitalize;">Điều Gì Khiến HomeNest Khác Biệt </span>
			</div>

			<div class="title">
				<p class="whychooseus__animated-text" id="whychoosus__animatedText" >
					Kiến Tạo Giá Trị Số với Giải Pháp Linh Hoạt, Được Thiết Kế Riêng Cho Doanh Nghiệp Của Bạn 
				</p>
			</div>

			<div class="content">
				<p>
					HomeNest mang đến giải pháp lĩnh hoạt, với đội ngũ chuyên gia tận tâm và giàu kinh nghiệm. HomeNest cam kết đồng hành lâu dài, đưa ra các giải pháp giúp doanh nghiệp phát triển hiệu quả và bền vững.
				</p>
			</div>

		</div>

		<div class="bottom-section">
			<div class="stats-container">
				<div class="stat-group">
					<div class="stat-number">1k</div>
					<div class="stat-divider">/</div>
					<div class="stat-label">
						<div class="stat-title">Khách Hàng</div>
						<div class="stat-subtitle">Tin Tưởng</div>
					</div>
				</div>

				<div class="stat-group">
					<div class="stat-number">1k5<span class="stat-plus">+</span></div>
					<div class="stat-divider">/</div>
					<div class="stat-label">
						<div class="stat-title">Dự Án</div>
						<div class="stat-subtitle">Đã Hoàn Thành</div>
					</div>
				</div>

				<div class="stat-group">
					<div class="stat-number">10<span class="stat-plus">+</span></div>
					<div class="stat-divider">/</div>
					<div class="stat-label">
						<div class="stat-title">Năm</div>
						<div class="stat-subtitle">Kinh Nghiệm</div>
					</div>
				</div>
			</div>

			<div class="feature-list-container">
				<div class="feature-list">
					<div class="feature-item">
						<span class="feature-icon">✦</span>
						Đội ngũ giàu kinh nghiệm
					</div>

					<div class="feature-item">
						<span class="feature-icon">✦</span>
						Giải pháp toàn diện
					</div>

					<div class="feature-item">
						<span class="feature-icon">✦</span>
						Chi phí minh bạch, hợp lý
					</div>

					<div class="feature-item">
						<span class="feature-icon">✦</span>
						Hỗ trợ kỹ thuật 24/7
					</div>

					<div class="feature-item">
						<span class="feature-icon">✦</span>
						Bảo mật & vận hành ổn định
					</div>

					<div class="feature-item">
						<span class="feature-icon">✦</span>
						Uy tín và minh bạch
					</div>

					<div class="feature-item">
						<span class="feature-icon">✦</span>
						Cam kết đồng hành lâu dài
					</div>
				</div>
			</div>
		</div>

	</div>

	<div class="homenest__blog-new">
		<div class="container__about-us">
			<div class="blog-container">
				<div class="blog-header">
					<div class="blog-category">
						<span style="color: #111;">Cẩm nang & Tin tức</span>	
					</div>
					<span class="blog-title animated-text" id="animatedText">Cẩm nang từ HomeNest <br>
						Tin tức & Góc nhìn chuyên môn</span>
				</div>

				<div class="blog-grid">
					<?php
					// Lấy bài viết mới nhất
					$latest_post = get_posts(array(
						'post_type' => 'post',
						'posts_per_page' => 1,
						'post_status' => 'publish'
					));

					if ($latest_post) :
					// Thiết lập dữ liệu post
					$post = $latest_post[0];
					setup_postdata($post);

					// Lấy ngày đăng
					$day = get_the_date('d');
					$month = get_the_date('F');

					// Lấy hình ảnh đại diện
					$thumbnail_url = get_the_post_thumbnail_url($post->ID, 'full');
					if (!$thumbnail_url) {
						$thumbnail_url = '/wp-content/uploads/2025/05/img-post-update1-1720x600-1.webp'; // Hình mặc định
					}
					?>
					<a class="blog-card" href="<?php echo get_permalink($post->ID) ?>" style="text-decoration: none;">
						<div class="blog-card-image">
							<img src="<?php echo esc_url($thumbnail_url); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
							<div class="blog-date">
								<div class="blog-date-day"><?php echo $day; ?></div>
								<div class="blog-date-month"><?php echo $month; ?></div>
							</div>
						</div>
						<div class="blog-content">
							<h2><?php echo get_the_title(); ?></h2>
							<p><?php echo wp_trim_words(get_the_excerpt(), 20, '...'); ?></p>
						</div>
						<div class="block-color" style="position: absolute;top: 20%;right: 0%;z-index: -1;">
							<img src="/wp-content/uploads/2025/05/Group1261154698.webp" alt="Homenest" title="Homenest">
						</div>
					</a>
					<?php
					wp_reset_postdata();
					else :
					// Nếu không có bài viết nào, hiển thị nội dung mặc định
					?>
					<div class="blog-card">
						<div class="blog-card-image">
							<img src="/wp-content/uploads/2025/05/img-post-update1-1720x600-1.webp" alt="Default Post">
							<div class="blog-date">
								<div class="blog-date-day">--</div>
								<div class="blog-date-month">----</div>
							</div>
						</div>
						<div class="blog-content">
							<h2>Chưa có bài viết nào</h2>
							<p>Vui lòng thêm bài viết mới.</p>
						</div>
						<div class="block-color" style="position: absolute;top: 16%;right: 0%;z-index: -1;">
							<img src="/wp-content/uploads/2025/05/Group1261154698.webp" alt="Homenest" title="Homenest">
						</div>
					</div>
					<?php endif; ?>

					<div class="blog-card-right">
						<?php
						$latest_posts = get_posts(array(

							'post_type' => 'post',
							'posts_per_page' => 6,
							'post_status' => 'publish',
							'offset' => 1
						)); ?>
						<!-- Navigation -->
						<div class="navigation">
							<button id="prevBtn"><svg width="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="icon line" transform="scale(-1 1)"><path style="fill:none;stroke:#fff;stroke-linecap:round;stroke-linejoin:round;stroke-width:1.5" d="m14 5 7 7-7 7"/><path data-name="primary" style="fill:none;stroke:#fff;stroke-linecap:round;stroke-linejoin:round;stroke-width:1.5" d="M21 12H3"/></svg></button>
							<?php
							if (!empty($latest_posts)) {
								$dot_count = count($latest_posts);
								for ($i = 1; $i < $dot_count; $i++) {
									echo '<span class="dot" data-index="' . $i . '"></span>';
								}
							}
							?>
							<button id="nextBtn"><svg fill="#fff" width="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="icon line"><path style="fill:none;stroke:#fff;stroke-linecap:round;stroke-linejoin:round;stroke-width:1.5" d="m14 5 7 7-7 7"/><path data-name="primary" style="fill:none;stroke:#fff;stroke-linecap:round;stroke-linejoin:round;stroke-width:1.5" d="M21 12H3"/></svg></button>
						</div>


						<!-- Posts -->

						<?php
						if ($latest_posts) :
						echo '<div class="posts"><div class="post-wrapper">';
						foreach ($latest_posts as $post) :
						setup_postdata($post);
						// Lấy ngày đăng
						$day = get_the_date('d');
						$month = get_the_date('F');
						?>
						<!-- Post 1 -->
						<a href="<?php echo get_permalink($post->ID) ?>" class="post" style="text-decoration: none;" >
							<div class="post-inner">
								<div class="post-image" style="background: url('<?php echo get_the_post_thumbnail_url(get_the_ID()) ?>') center / cover no-repeat;">
									<div class="date-tag">
										<span class="day"><?php echo $day; ?></span>
										<span class="month"><?php echo $month ?></span>
									</div>
								</div>
								<div class="post-content">
									<h2><?php the_title(); ?></h2>
									<p><?php echo wp_trim_words(get_the_excerpt(), 25, '...'); ?></p>
								</div>
							</div>
						</a>

						<?php
						endforeach;
						wp_reset_postdata();
						echo '</div></div>';
						else :
						echo '<p>Không tìm thấy bài viết nào</p>';
						endif;
						?>

						<?php 
						// Hiển thị phân trang nếu có nhiều bài viết
						the_posts_pagination(array(
							'mid_size' => 6,
							'prev_text' => __('Trước'),
							'next_text' => __('Sau'),
						));
						?>
					</div>
				</div>
			</div>
		</div>

		<div class="btn__blog-new">
			<a href="<?php echo get_permalink( get_page_by_path('blog') ); ?>" class="btn__about-us" data-text="View All Blog">
				<svg class="btn-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
					<path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
				</svg>
			</a>
		</div>
	</div>	
	<div class="homenest__image-globe">
		<div class="rotating-image">
			<img class="img-globe" src="/wp-content/uploads/2025/05/global2.webp" alt="Homenest" title="Homenest">			
		</div>
	</div>

	<div class="homenest__testimonial">
		<div class="testimonial-container">
			<!-- Avatar Container -->
			<div class="avatar-container" id="avatarContainer">
				<!-- Avatars will be inserted here via JavaScript -->
			</div>

			<!-- Testimonial Slider -->
			<div class="slider-container" id="sliderContainer">
				<div class="slider-track" id="sliderTrack">
					<!-- Testimonials will be inserted here via JavaScript -->
				</div>
			</div>

			<!-- Dots Indicator -->
			<div class="dots-container" id="dotsContainer">
				<!-- Dots will be inserted here via JavaScript -->
			</div>
		</div>	

		<div class="img-testimonial">
			<img src="/wp-content/uploads/2025/05/image-young-lady.webp" alt="Homenest" title="Homenest"> 
			<img src="/wp-content/uploads/2025/05/3d-rendering-arrow-icon525.webp" alt="Homenest" title="Homenest">
		</div>
	</div>

</main>

<script>
	

</script>

<?php get_footer(); ?>
