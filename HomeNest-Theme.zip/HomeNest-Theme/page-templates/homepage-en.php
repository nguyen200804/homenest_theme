<?php
/*
Template Name: Homepage En
*/
?>
<?php get_header(); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
<main>
	<section class="homenest__homepage--banner">
		<img src="/wp-content/uploads/2025/05/download.webp" alt="Homenest" title="Homenest">
		<div class="background2">
			<!-- 			<link rel="preload" as="image" href="/path/to/banner.webp" fetchpriority="high"> -->
			<img src="/wp-content/uploads/2025/05/img-bg-slide-h512.webp" alt="Homenest" title="Homenest">
		</div>
		<div class=" container--fullwidth">
			<!-- 		Social icon	 -->
			<div class=" showElement left col1 social-icons">
				<a href="#"><svg width="24" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path fill="#fff" d="M7.2 16V8.5h-2V5.8h2V3.5C7.2 1.7 8.4 0 11.1 0c1.1 0 1.9.1 1.9.1l-.1 2.5h-1.7c-1 0-1.1.4-1.1 1.2v2H13l-.1 2.7h-2.8V16z"/></svg></a>
				<a href="#"><svg fill="#fff" width="24" viewBox="-2 -2 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin" class="jam jam-linkedin"><path d="M19.959 11.719v7.379h-4.278v-6.885c0-1.73-.619-2.91-2.167-2.91-1.182 0-1.886.796-2.195 1.565-.113.275-.142.658-.142 1.043v7.187h-4.28s.058-11.66 0-12.869h4.28v1.824l-.028.042h.028v-.042c.568-.875 1.583-2.126 3.856-2.126 2.815 0 4.926 1.84 4.926 5.792M2.421.026C.958.026 0 .986 0 2.249c0 1.235.93 2.224 2.365 2.224h.028c1.493 0 2.42-.989 2.42-2.224C4.787.986 3.887.026 2.422.026zM.254 19.098h4.278V6.229H.254z"/></svg></a>
				<a href="#"><svg fill="#fff" width="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" data-name="Layer 1"><path d="M22 5.8a8.5 8.5 0 0 1-2.36.64 4.13 4.13 0 0 0 1.81-2.27 8.2 8.2 0 0 1-2.61 1 4.1 4.1 0 0 0-7 3.74 11.64 11.64 0 0 1-8.45-4.29 4.16 4.16 0 0 0-.55 2.07 4.09 4.09 0 0 0 1.82 3.41 4.05 4.05 0 0 1-1.86-.51v.05a4.1 4.1 0 0 0 3.3 4 4 4 0 0 1-1.1.17 5 5 0 0 1-.77-.07 4.11 4.11 0 0 0 3.83 2.84A8.22 8.22 0 0 1 3 18.34a8 8 0 0 1-1-.06 11.57 11.57 0 0 0 6.29 1.85A11.59 11.59 0 0 0 20 8.45v-.53a8.4 8.4 0 0 0 2-2.12"/></svg></a>
				<a href="#"><svg fill="#fff" width="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" data-name="Layer 1"><path d="M17.34 5.46a1.2 1.2 0 1 0 1.2 1.2 1.2 1.2 0 0 0-1.2-1.2m4.6 2.42a7.6 7.6 0 0 0-.46-2.43 4.9 4.9 0 0 0-1.16-1.77 4.7 4.7 0 0 0-1.77-1.15 7.3 7.3 0 0 0-2.43-.47C15.06 2 14.72 2 12 2s-3.06 0-4.12.06a7.3 7.3 0 0 0-2.43.47 4.8 4.8 0 0 0-1.77 1.15 4.7 4.7 0 0 0-1.15 1.77 7.3 7.3 0 0 0-.47 2.43C2 8.94 2 9.28 2 12s0 3.06.06 4.12a7.3 7.3 0 0 0 .47 2.43 4.7 4.7 0 0 0 1.15 1.77 4.8 4.8 0 0 0 1.77 1.15 7.3 7.3 0 0 0 2.43.47C8.94 22 9.28 22 12 22s3.06 0 4.12-.06a7.3 7.3 0 0 0 2.43-.47 4.7 4.7 0 0 0 1.77-1.15 4.85 4.85 0 0 0 1.16-1.77 7.6 7.6 0 0 0 .46-2.43c0-1.06.06-1.4.06-4.12s0-3.06-.06-4.12M20.14 16a5.6 5.6 0 0 1-.34 1.86 3.06 3.06 0 0 1-.75 1.15 3.2 3.2 0 0 1-1.15.75 5.6 5.6 0 0 1-1.86.34c-1 .05-1.37.06-4 .06s-3 0-4-.06a5.7 5.7 0 0 1-1.94-.3 3.3 3.3 0 0 1-1.1-.75 3 3 0 0 1-.74-1.15 5.5 5.5 0 0 1-.4-1.9c0-1-.06-1.37-.06-4s0-3 .06-4a5.5 5.5 0 0 1 .35-1.9A3 3 0 0 1 5 5a3.1 3.1 0 0 1 1.1-.8A5.7 5.7 0 0 1 8 3.86c1 0 1.37-.06 4-.06s3 0 4 .06a5.6 5.6 0 0 1 1.86.34 3.06 3.06 0 0 1 1.19.8 3.1 3.1 0 0 1 .75 1.1 5.6 5.6 0 0 1 .34 1.9c.05 1 .06 1.37.06 4s-.01 3-.06 4M12 6.87A5.13 5.13 0 1 0 17.14 12 5.12 5.12 0 0 0 12 6.87m0 8.46A3.33 3.33 0 1 1 15.33 12 3.33 3.33 0 0 1 12 15.33"/></svg></a>
			</div>

			<!-- 		Text about	 -->
			<div class="col2">
				<div class="swiper mySwiper">
					<div class="swiper-wrapper">
						<div class="swiper-slide">
							<p style="--d-in: 0s" class="subtitle">Your Business Companion</p>
							<h1 style="--d-in: 0.25s" class="title">HOMENEST</h1>
							<p style="--d-in: 0.5s" class="content">As a reputable digital transformation partner, Homenest offers professional solutions in web, app, and software design, empowering businesses to elevate their brand presence and thrive sustainably in the digital era.</p>
							<a style="--d-in: 0.75s" class="button __homepage _txt" href="/about-us/">
								Learn More!
							</a>
						</div>
						<div class="swiper-slide">
							<p style="--d-in: 0s" class="subtitle">Promote Digital Business</p>
							<h5 style="--d-in: 0.25s"  class="title">HOMENEST</h5>
							<p style="--d-in: 0.5s"  class="content">HomeNest provides digital solutions that help businesses manage effectively and develop sustainably. We always accompany, listen to, and create practical value with our clients.</p>
							<a style="--d-in: 0.75s"  class="button __homepage _txt" href="/about-us/">
								Learn More!
							</a>
						</div>
						<div class="swiper-slide">
							<p style="--d-in: 0s" class="subtitle">Impact in Every Project</p>
							<h5 style="--d-in: 0.25s" class="title">HOMENEST</h5>
							<p style="--d-in: 0.5s" class="content">HomeNest is proud to accompany businesses on their digital journey. Let's look at real-world success stories from our clients as we work together to make a difference.</p>
							<a style="--d-in: 0.75s" class="button __homepage _txt" href="/case-studies/">
								Discover Now!
							</a>
						</div>
					</div>
					<div class="swiper-button-next"></div>
					<div class="swiper-button-prev"></div>
				</div>
			</div>

			<!-- 			Image about -->
			<div class="col3">
				<div class="swiper mySwiper2">
					<div class="swiper-wrapper">
						<div class="swiper-slide">
							<img src="/wp-content/uploads/2025/05/img2-slide-h5-840x840-1.webp" alt="Homenest" title="Homenest">
						</div>
						<div class="swiper-slide">
							<img src="/wp-content/uploads/2025/05/img3-slide-h5-840x840-1.webp" alt="Homenest" title="Homenest">
						</div>
						<div class="swiper-slide">
							<img src="/wp-content/uploads/2025/05/img-slide-h5-840x840-1.webp" alt="Homenest" title="Homenest">
						</div>
					</div>
					<div class="swiper-button-next"></div>
					<div class="swiper-button-prev"></div>
				</div>
			</div>

			<!-- 		img and button	 -->
			<div class="col4">
				<img class="showElement right" src="/wp-content/uploads/2025/05/img-2-slide-h5.webp" alt="Homenest" title="Homenest">
				<div class=" showElement  btn-moveslide">
					<button class="prev-slide">
						<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="white"> <path d="M12.9447 11.0003V5.19531L2.05469 12.0003L12.9397 18.8053V13.0003H21.9397V11.0003H12.9447ZM10.9447 11.0003V13.0003V15.1953L5.82969 12.0003L10.9447 8.80531V11.0003Z"></path> </svg>
					</button>
					<button class="next-slide">
						<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="white"> <path d="M12.9447 11.0003V5.19531L2.05469 12.0003L12.9397 18.8053V13.0003H21.9397V11.0003H12.9447ZM10.9447 11.0003V13.0003V15.1953L5.82969 12.0003L10.9447 8.80531V11.0003Z"></path> </svg>
					</button>
				</div>
			</div>
		</div>
	</section>



	<section class="homenest__brands--intro--services">
		<div class="section-brands">

			<div class="col1">
				<h2>More than 1500+ customers have trusted and are currently using our services</h2>
				<!-- 				<img src="/wp-content/uploads/2025/05/bg-h5.webp"> -->
				<img 
					 src="/wp-content/uploads/2025/05/bg-h5.webp" 
					 alt="Trusted by 3450+ happy customers" 
					 width="90" height="90"
					 decoding="async" 
					 fetchpriority="high" 
					 loading="eager">

			</div>

			<div class="showElement col2">
				<div class="marqueeBrands swiperBrands">
					<div class="marquee-contains">
						<img src="/wp-content/uploads/2025/05/Logo_website-1.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-2.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-3.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-4.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-5.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-6.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-7.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-8.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-9.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-10.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-11.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-12.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-13.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-14.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-15.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-16.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-17.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-18.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-19.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-20.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-21.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-22.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-23.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-24.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-25.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-26.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-27.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-28.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-29.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-30.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-31.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-32.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-33.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-34.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-35.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-36.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-37.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-38.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-39.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-40.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-41.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-42.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-43.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-44.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-45.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-46.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-47.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-48.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-49.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-50.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-51.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-52.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-53.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-54.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-55.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-56.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-57.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-58.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-59.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-60.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-61.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-62.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-63.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-64.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-65.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-66.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/05/Logo_website-67.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/06/Logo_website-68.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/06/Logo_website-69.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/06/Logo_website-70.webp" alt="Logo khách hàng" title="Logo khách hàng">
						<img src="/wp-content/uploads/2025/06/Logo_website-71.webp" alt="Logo khách hàng" title="Logo khách hàng">
					</div>
				</div>
			</div>

		</div>


		<div class="section-intro">
			<img src="/wp-content/uploads/2025/05/img-.webp">
			<div class="container--boxed">
				<div class="col1 showElement">
					<div class="image-effect">
						<img class="image1" src="/wp-content/uploads/2025/07/ebbf997d8b31d0f5a4c99bb2d6e5f4e3fe3d9154.webp" alt="Homenest" title="Homenest">
						<img class="image2" src="/wp-content/uploads/2025/07/24e2bfe4bc7e9ee23ef344e919913f94f7c3b880.webp"  alt="Homenest" title="Homenest">
					</div>
					<img src="/wp-content/uploads/2025/05/img-img-img.webp" alt="Homenest" title="Homenest">
				</div>
				<div class="col2">
					<h2 class="title scrollTextEffect showElement" data-text="Accelerate Your Vision with AI-Driven Innovation.">
						<span class="text-gradient ">HomeNest <br>Practical Effectiveness <br>Sustainable Value</span>
					</h2>
					<p class="content showElement">
						Professionalism, innovation, dedication, and proven results are what establish HomeNest as the preferred choice, trusted by clients as a partner in their digital transformation and sustainable development journey.
					</p>
					<div class="line showElement"></div>
					<ul class="list showElement">
						<li><svg width="20" height="800Параметры: px" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="a" x1="0%" y1="0%" x2="100%" y2="0%" gradientTransform="rotate(92.16)"><stop offset="0%" stop-color="#020C6A"/><stop offset="56.7%" stop-color="#1A85F8"/><stop offset="100%" stop-color="#66E5FB"/></linearGradient></defs><path d="M10 1 6.818 6.818 1 10l5.818 3.182L10 19l3.182-5.818L19 10l-5.818-3.182zm0 2.084 2.445 4.47L16.916 10l-4.47 2.445L10 16.916l-2.445-4.47L3.084 10l4.47-2.445z" style="fill:url(#a);fill-opacity:1;stroke:none;stroke-width:0"/></svg>Customer-Centric Approach</li>
						<li><svg width="20" height="800Параметры: px" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="a" x1="0%" y1="0%" x2="100%" y2="0%" gradientTransform="rotate(92.16)"><stop offset="0%" stop-color="#020C6A"/><stop offset="56.7%" stop-color="#1A85F8"/><stop offset="100%" stop-color="#66E5FB"/></linearGradient></defs><path d="M10 1 6.818 6.818 1 10l5.818 3.182L10 19l3.182-5.818L19 10l-5.818-3.182zm0 2.084 2.445 4.47L16.916 10l-4.47 2.445L10 16.916l-2.445-4.47L3.084 10l4.47-2.445z" style="fill:url(#a);fill-opacity:1;stroke:none;stroke-width:0"/></svg>Professional & Dedicated</li>
						<li><svg width="20" height="800Параметры: px" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="a" x1="0%" y1="0%" x2="100%" y2="0%" gradientTransform="rotate(92.16)"><stop offset="0%" stop-color="#020C6A"/><stop offset="56.7%" stop-color="#1A85F8"/><stop offset="100%" stop-color="#66E5FB"/></linearGradient></defs><path d="M10 1 6.818 6.818 1 10l5.818 3.182L10 19l3.182-5.818L19 10l-5.818-3.182zm0 2.084 2.445 4.47L16.916 10l-4.47 2.445L10 16.916l-2.445-4.47L3.084 10l4.47-2.445z" style="fill:url(#a);fill-opacity:1;stroke:none;stroke-width:0"/></svg>Comprehensive Solutions</li>
						<li><svg width="20" height="800Параметры: px" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="a" x1="0%" y1="0%" x2="100%" y2="0%" gradientTransform="rotate(92.16)"><stop offset="0%" stop-color="#020C6A"/><stop offset="56.7%" stop-color="#1A85F8"/><stop offset="100%" stop-color="#66E5FB"/></linearGradient></defs><path d="M10 1 6.818 6.818 1 10l5.818 3.182L10 19l3.182-5.818L19 10l-5.818-3.182zm0 2.084 2.445 4.47L16.916 10l-4.47 2.445L10 16.916l-2.445-4.47L3.084 10l4.47-2.445z" style="fill:url(#a);fill-opacity:1;stroke:none;stroke-width:0"/></svg>24/7 Dedicated Technical Support</li>
						<li><svg width="20" height="800Параметры: px" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="a" x1="0%" y1="0%" x2="100%" y2="0%" gradientTransform="rotate(92.16)"><stop offset="0%" stop-color="#020C6A"/><stop offset="56.7%" stop-color="#1A85F8"/><stop offset="100%" stop-color="#66E5FB"/></linearGradient></defs><path d="M10 1 6.818 6.818 1 10l5.818 3.182L10 19l3.182-5.818L19 10l-5.818-3.182zm0 2.084 2.445 4.47L16.916 10l-4.47 2.445L10 16.916l-2.445-4.47L3.084 10l4.47-2.445z" style="fill:url(#a);fill-opacity:1;stroke:none;stroke-width:0"/></svg>Modern Technology & Innovation</li>
						<li><svg width="20" height="800Параметры: px" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="a" x1="0%" y1="0%" x2="100%" y2="0%" gradientTransform="rotate(92.16)"><stop offset="0%" stop-color="#020C6A"/><stop offset="56.7%" stop-color="#1A85F8"/><stop offset="100%" stop-color="#66E5FB"/></linearGradient></defs><path d="M10 1 6.818 6.818 1 10l5.818 3.182L10 19l3.182-5.818L19 10l-5.818-3.182zm0 2.084 2.445 4.47L16.916 10l-4.47 2.445L10 16.916l-2.445-4.47L3.084 10l4.47-2.445z" style="fill:url(#a);fill-opacity:1;stroke:none;stroke-width:0"/></svg>Proven Results & Client Satisfaction</li>
					</ul>
					<div class="line showElement"></div>
					<a class="button _txt __homepage showElement" href="/about-us/">
						About Us!
					</a>
				</div>
			</div>
		</div>


		<div class="section-services ">
			<h2 class="container--boxed title scrollTextEffect showElement">
				<span class="text-gradient">Our Services <br>Solutions for Every Need</span>
			</h2>
			<div class="all-services">
				<div class="swiper swiperServices showElement">
					<?php
					// Mảng màu gradient
					$service_colors = array(
						array('color1' => '#D5EAD6', 'color2' => '#AFDBB1'),
						array('color1' => '#ffe7d4', 'color2' => '#fbcfac'),
						array('color1' => '#B5DEE1', 'color2' => '#91CFD3'),
						array('color1' => '#F5D9D9', 'color2' => '#F2C6C6'),
						array('color1' => '#FFF0CE', 'color2' => '#F9E0AC'),
						array('color1' => '#B5DEE1', 'color2' => '#91CFD3')
					);

					// Truy vấn service
					$args = array(
						'post_type' => 'service',
						'post_status' => 'publish',
						'posts_per_page' => -1,
						'orderby' => 'date',
						'order' => 'DESC'
					);

					$services_query = new WP_Query($args);

					if ($services_query->have_posts()) {
					?>

					<div class="services-list swiper-wrapper">
						<?php
						$index = 0;
						while ($services_query->have_posts()) {
							$services_query->the_post();
							$title = get_the_title();
							$permalink = get_permalink();
							$featured_image = get_the_post_thumbnail_url(get_the_ID(), 'full'); // small, medium, large, full
							$color1 = $service_colors[$index]['color1'] ?? '#000';
							$color2 = $service_colors[$index]['color2'] ?? '#000';
							$index++;
						?>
						<div class="card swiper-slide" style="background: linear-gradient(135deg, <?php echo esc_attr($color1); ?>, <?php echo esc_attr($color2); ?>);">
							<?php if ($featured_image): ?>
							<a href="<?php echo esc_url($permalink); ?>" class="circle-image">
								<img src="<?php echo esc_url($featured_image); ?>" alt="<?php echo esc_attr($title); ?>">
							</a>
							<?php endif; ?>
							<h3>
								<a href="<?php echo esc_url($permalink); ?>">
									<?php echo esc_html($title); ?>
								</a>
							</h3>
						</div>
						<?php
						}
						echo '</div>';
						wp_reset_postdata();
					} else {
						echo 'Không tìm thấy dịch vụ nào.';
					}
						?>


						<div class="swiper-pagination"></div>
					</div>
				</div>
			</div>
		</div>



		<section class="homenest__achievement">
			<div class="container--boxed">
				<h2 class="title scrollTextEffect showElement "><span class="text-gradient2">Impressive Numbers <br>What We Have Achieved</span></h2>
				<div class="stats__item">
					<div class="item1 showElement top"></div>
					<div class="item2 showElement" style="--bg-img: url('/wp-content/uploads/2025/05/bg-counter-h5-item.webp');">
						<div class="counter-section">
							<p class="content">Years of Experience</p>
							<p class="number"><span class="count">0</span>+</p>
						</div>
					</div>
					<div class="item3 showElement top" style="--bg-img: url('/wp-content/uploads/2025/05/img-bg-counter-h5-2.webp');">
						<div class="counter-section">
							<p class="content">Industries Served</p>
							<p class="number"><span class="count">0</span>+</p>
						</div>
					</div>
					<div class="item4 showElement">
						<img src="/wp-content/uploads/2025/05/img-ss-counter-h5.webp" alt="Homenest" title="Homenest">
					</div>
					<div class="item5 showElement top"></div>
					<div class="item6 showElement" style="--bg-img: url('/wp-content/uploads/2025/05/img-bg-counter-h5-3.webp');">
						<div class="counter-section">
							<p class="content">Completed Projects</p>
							<p class="number"><span class="count">0</span>+</p>
						</div>
					</div>
					<div class="item7 showElement top" style="--bg-img: url('/wp-content/uploads/2025/05/img-bg-counter-h5-4.webp');">
						<div class="counter-section">
							<p class="content">Personnel</p>
							<p class="number"><span class="count">0</span>+</p>
						</div>
					</div>
					<div class="item8 showElement" style="--bg-img: url('/wp-content/uploads/2025/05/img-bg-counter-h5-7-1.webp');">
						<div class="counter-section">
							<p class="content">Client Satisfaction</p>
							<p class="number"><span class="count">0</span>%</p>
						</div>
					</div>
				</div>
			</div>
		</section>




		<section class="homenest__homepage__teams">
			<div class="container--boxed">
				<div class="homenest__homepage__teams__title-wrapper">
					<h2 class="homenest__homepage__teams__title scrollTextEffect showElement"><span class="text-gradient">Our Team at HomeNest</span></h2>
				</div>
				<p class="homenest__homepage__teams__desc showElement"><span>Every HomeNest website and software solution is expertly consulted, developed, and optimized to drive measurable business efficiency for our clients.</span></p>
				<div class="homenest__homepage__teams__list">
					<div class="homenest__homepage__teams__item _1 showElement top"><span class="text"><strong>Competitive Pricing</strong> Intellectual Property Protection</span></div>
					<div class="homenest__homepage__teams__item _2 showElement top"><img src="/wp-content/uploads/2025/07/Logo_HomeNest-team.webp" alt="Homenest" title="Homenest"></div>
					<div class="homenest__homepage__teams__item _3 showElement top"><span class="text">International Standard <strong>Processes</strong></span></div>

					<div class="homenest__homepage__teams__item _4 showElement"><img src="/wp-content/uploads/2025/07/nguyen.jpg" alt="Homenest" title="Homenest"></div> 

					<div class="homenest__homepage__teams__item _5 showElement"><img src="/wp-content/uploads/2025/07/tien.jpg" alt="Homenest" title="Homenest"></div>

					<div class="homenest__homepage__teams__item _6 showElement"><img src="/wp-content/uploads/2025/07/chan.jpg" alt="Homenest" title="Homenest"></div>

					<div class="homenest__homepage__teams__item _7 showElement"><img src="/wp-content/uploads/2025/07/Logo_HomeNest-team.webp" alt=""></div>
					<div class="homenest__homepage__teams__item _8 showElement top"><img src="/wp-content/uploads/2025/07/vu.jpg" alt="Homenest" title="Homenest"></div>
					<div class="homenest__homepage__teams__item _9 showElement top"><span class="text"><strong>Robust Technology Foundation</strong></span></div>
					<div class="homenest__homepage__teams__item _10 showElement top"><img src="/wp-content/uploads/2025/07/trieu.jpg" alt="Homenest" title="Homenest"></div>
					<div class="homenest__homepage__teams__item _11 showElement"><span class="text"><strong>10+ Years of Experience</strong></span></div>
					<div class="homenest__homepage__teams__item _12 showElement"><span class="text">Offices in <strong>Major Vietnamese Cities</strong></span></div>
					<!-- 				<img src="/wp-content/uploads/2025/07/Group-1.webp"> -->
				</div>
			</div>
		</section>



		<section class="homenest__success">

			<div class="container--boxed">
				<div class="row1">
					<div class="col-1">
						<h2 class="title scrollTextEffect showElement"><span class="text-gradient">HomeNest <br>The Journey of Creating Value <br>Together with Clients</span></h2>
						<p class="content showElement">HomeNest proudly serves as a trusted strategic partner to hundreds of businesses both locally and globally. We architect breakthrough digital solutions that elevate brands and fuel sustainable growth, clearly showcasing the distinct impact and value we deliver to each partnership.</p>
						<a class="button _txt showElement __homepage" href="/case-studies/">
							Learn More!
						</a>
					</div>
					<div class="col-2 showElement">
						<div class="image-effect">
							<img class="image1" src="/wp-content/uploads/2025/05/img-ss3-h5.webp" alt="Homenest" title="Homenest">
							<img class="image2" src="/wp-content/uploads/2025/07/316fb02b703ba40d1453ca0c90f407d6f00404f1.webp" alt="Homenest" title="Homenest">
						</div>
						<img style="--x: 31px;" class="img-bg1" src="/wp-content/uploads/2025/05/image-suc2.webp" alt="Homenest" title="Homenest">
						<img style="--x: 0;" class="img-bg2" src="/wp-content/uploads/2025/05/image-suc1.webp" alt="Homenest" title="Homenest">
					</div>
				</div>

				<div class="row2">
					<div class="col-1 showElement">
						<div>
							<img style="height: 450px; object-fit: cover;" src="/wp-content/uploads/2025/07/8c08d6747e5c1dff7fdffa31ddab0f4d432e639c-scaled.webp" alt="Homenest" title="Homenest">
						</div>
					</div>
					<div class="col-2">
						<div class="percent--section">
							<div class="percent-item">
								<p class="number showElement"><span class="count">0</span>%</p>
								<div class="line showElement"></div>
								<h3 class="title showElement">
									Conversion Rate
								</h3>
								<p class="content showElement">
									HomeNest's solutions drive impressive conversion rates, proving the practical effectiveness of our design and marketing strategies in optimizing business goals and fueling exceptional growth.
								</p>
							</div>
							<div class="percent-item">
								<p class="number showElement"><span class="count">0</span>%</p>
								<div class="line showElement"></div>
								<h3 class="title showElement">
									Satisfaction Rate
								</h3>
								<p class="content showElement">
									With a 99% client satisfaction rate, HomeNest's projects not only meet but often exceed expectations, affirming our service quality and dedication in every deployed solution.
								</p>
							</div>
						</div>
					</div>

				</div>
			</div>
		</section>



		<section class="homenest__video">
			<div class="background-video">
				<video id="videoPresentation" muted loop playsinline>
					<source src="/wp-content/uploads/2025/05/homnest1.mp4" type="video/mp4">
					Trình duyệt của bạn không hỗ trợ video.
				</video>
				<button class="button-popup-video">
					<svg width="24" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
						<defs>
							<linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%" gradientTransform="rotate(92.16)">
								<stop offset="0%" stop-color="#020C6A" />
								<stop offset="56.7%" stop-color="#1A85F8" />
								<stop offset="100%" stop-color="#66E5FB" />
							</linearGradient>
						</defs>
						<path d="M4.79 2.093A.5.5 0 0 0 4 2.5v10a.5.5 0 0 0 .79.407l7-5a.5.5 0 0 0 0-.814z" fill="url(#gradient)" />
					</svg>
				</button>
			</div>
		</section>




		<section class="homenest__process">
			<div class="container--boxed">
				<h2 class="title scrollTextEffect showElement"><span class="text-gradient">HomeNest Software <br>Leading Technology Solutions</span></h2>
				<div class="process--grid">
					<div style="--color-bg: #E8CDFF; --color-icon: #A02DFF;" class="process--item showElement">
						<div class="icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="140" height="140" viewBox="0 0 140 140" fill="#fff"><g opacity="1"><path d="M135.625 68.3594H71.636V44.0188C71.636 25.4007 55.8031 10.2539 37.185 10.2539C18.567 10.2539 2.73438 25.4007 2.73438 44.0188V70C2.73438 70.9059 3.4691 71.6406 4.375 71.6406H68.364V95.9812C68.364 114.599 84.1969 129.746 102.815 129.746C121.433 129.746 137.266 114.599 137.266 95.9812V70C137.266 69.0938 136.531 68.3594 135.625 68.3594H135.625ZM47.2218 68.3594H27.1485V44.68C27.1485 39.1508 31.6509 34.6525 37.1853 34.6525C42.7197 34.6525 47.2218 39.1508 47.2218 44.68V68.3594ZM58.3928 68.3594H50.5031V44.68C50.5031 37.3414 44.5288 31.3712 37.1853 31.3712C29.8419 31.3712 23.8673 37.3414 23.8673 44.68V68.3594H15.9775V44.6802C15.9775 32.9957 25.4912 23.4896 37.1853 23.4896C48.8794 23.4896 58.3928 32.9957 58.3928 44.6802V68.3594ZM68.355 68.3594H61.6741V44.6802C61.6741 31.1864 50.6885 20.2084 37.1853 20.2084C23.6821 20.2084 12.6965 31.1864 12.6965 44.6802V68.3594H6.01562V44.0188C6.01562 27.21 20.3766 13.5352 37.1853 13.5352C53.9941 13.5352 68.355 27.21 68.355 44.0188V68.3594ZM92.7782 71.6406H112.851V95.32C112.851 100.849 108.349 105.348 102.815 105.348C97.2803 105.348 92.7782 100.849 92.7782 95.32V71.6406ZM81.6071 71.6406H89.4969V95.32C89.4969 102.659 95.4712 108.629 102.815 108.629C110.158 108.629 116.133 102.659 116.133 95.32V71.6406H124.022V95.32C124.022 107.004 114.509 116.51 102.815 116.51C91.1206 116.51 81.6071 107.004 81.6071 95.32V71.6406ZM133.984 95.9812C133.984 112.79 119.623 126.465 102.815 126.465C86.0059 126.465 71.645 112.79 71.645 95.9812V71.6406H78.3259V95.32C78.3259 108.814 89.3115 119.792 102.815 119.792C116.318 119.792 127.304 108.814 127.304 95.32V71.6406H133.985V95.9812H133.984Z"></path><path d="M37.3222 78.1406C31.1007 78.1406 26.0391 83.1989 26.0391 89.4166C26.0391 95.6343 31.1007 100.692 37.3222 100.692C43.5437 100.692 48.6056 95.6341 48.6056 89.4166C48.6056 83.1992 43.5437 78.1406 37.3222 78.1406ZM37.3222 97.4114C32.91 97.4114 29.3203 93.825 29.3203 89.4169C29.3203 85.0088 32.91 81.4222 37.3222 81.4222C41.7344 81.4222 45.3243 85.0086 45.3243 89.4169C45.3243 93.8253 41.7346 97.4114 37.3222 97.4114Z"></path><path d="M37.1855 106.875C30.9639 106.875 25.9023 111.933 25.9023 118.151C25.9023 124.368 30.9639 129.426 37.1855 129.426C43.407 129.426 48.4689 124.368 48.4689 118.151C48.4689 111.933 43.407 106.875 37.1855 106.875ZM37.1855 126.146C32.7733 126.146 29.1836 122.559 29.1836 118.151C29.1836 113.743 32.7733 110.157 37.1855 110.157C41.5977 110.157 45.1876 113.743 45.1876 118.151C45.1876 122.559 41.5979 126.146 37.1855 126.146Z"></path><path d="M102.885 11.3848C96.6634 11.3848 91.6016 16.4431 91.6016 22.6608C91.6016 28.8785 96.6634 33.9368 102.885 33.9368C109.106 33.9368 114.168 28.8785 114.168 22.6608C114.168 16.4431 109.106 11.3848 102.885 11.3848ZM102.885 30.6555C98.4725 30.6555 94.8828 27.0691 94.8828 22.6608C94.8828 18.2524 98.4725 14.666 102.885 14.666C107.297 14.666 110.887 18.2524 110.887 22.6608C110.887 27.0691 107.297 30.6555 102.885 30.6555Z"></path><path d="M102.748 40.1191C96.5267 40.1191 91.4648 45.1775 91.4648 51.3949C91.4648 57.6123 96.5267 62.6709 102.748 62.6709C108.97 62.6709 114.031 57.6126 114.031 51.3949C114.031 45.1772 108.97 40.1191 102.748 40.1191ZM102.748 59.3897C98.3358 59.3897 94.7461 55.8032 94.7461 51.3949C94.7461 46.9865 98.3358 43.4004 102.748 43.4004C107.161 43.4004 110.75 46.9868 110.75 51.3949C110.75 55.803 107.16 59.3897 102.748 59.3897Z"></path></g></svg>
						</div>
						<h3>Comprehensive Digital Transformation</h3>
						<p>HomeNest modernizes business operations through integrated solutions featuring advanced technologies, optimizing your company’s digital transformation journey.</p>
					</div>
					<div style="--color-bg: #FFE2D1; --color-icon: #FF7321;" class="process--item showElement top">
						<div class="icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="140" height="140" viewBox="0 0 140 140" fill="#fff"><g opacity="1"><path d="M133.094 90.5827H86.7467V63.5137H105.235C107.299 63.5137 108.977 61.8348 108.977 59.7714V40.9234C108.977 38.86 107.299 37.1811 105.235 37.1811H86.3874C84.3241 37.1811 82.6452 38.86 82.6452 40.9234V59.4119H55.5762V14.8399C55.5762 12.7766 53.8973 11.0977 51.8339 11.0977H24.4216C23.289 11.0977 22.3708 12.0156 22.3708 13.1484C22.3708 14.2813 23.289 15.1992 24.4216 15.1992H51.4749V59.4121H7.26199V15.1995H14.8343C15.9669 15.1995 16.8851 14.2816 16.8851 13.1487C16.8851 12.0159 15.9669 11.0979 14.8343 11.0979H6.90242C4.83906 11.0979 3.16016 12.7768 3.16016 14.8402V59.7717C3.16016 61.8351 4.83879 63.514 6.90242 63.514H51.4747V90.5829H24.0464C21.983 90.5829 20.3041 92.2618 20.3041 94.3252V122.113C20.3041 124.176 21.9828 125.855 24.0464 125.855H51.8342C53.8976 125.855 55.5765 124.176 55.5765 122.113V94.6845H82.6454V122.113C82.6454 124.176 84.3243 125.855 86.3877 125.855H91.9021C93.0347 125.855 93.9529 124.937 93.9529 123.804C93.9529 122.672 93.0347 121.754 91.9021 121.754H86.7467V94.6848H132.734V121.754H101.521C100.389 121.754 99.4703 122.672 99.4703 123.804C99.4703 124.937 100.389 125.855 101.521 125.855H133.094C135.157 125.855 136.836 124.176 136.836 122.113V94.3249C136.836 92.2616 135.157 90.5827 133.094 90.5827ZM86.7467 41.283H104.876V59.4121H86.7467V41.283ZM51.4747 121.753H24.4057V94.6845H51.4747V121.753ZM55.5762 63.5137H82.6452V90.5827H55.5762V63.5137Z"></path><path d="M108.617 19.0641H120.197C122.26 19.0641 123.939 17.3852 123.939 15.3218V3.74227C123.939 1.67891 122.26 0 120.197 0H108.617C106.554 0 104.875 1.67891 104.875 3.74227V15.3221C104.875 17.3852 106.554 19.0641 108.617 19.0641ZM108.977 4.10156H119.838V14.9625H108.977V4.10156Z"></path><path d="M22.3546 135.898H5.21094C4.07836 135.898 3.16016 136.816 3.16016 137.949C3.16016 139.082 4.07836 140 5.21094 140H22.3546C23.4872 140 24.4054 139.082 24.4054 137.949C24.4054 136.816 23.4872 135.898 22.3546 135.898Z"></path><path d="M122.336 61.3887C122.336 62.5215 123.254 63.4395 124.387 63.4395H134.784C135.917 63.4395 136.835 62.5215 136.835 61.3887C136.835 60.2558 135.917 59.3379 134.784 59.3379H124.387C123.254 59.3379 122.336 60.2558 122.336 61.3887Z"></path></g></svg>
						</div>
						<h3>Digital Brand Building & Development</h3>
						<p>HomeNest offers website design, software, and digital marketing solutions that help businesses build their brand, effectively attracting and reaching target customers.</p>
					</div>
					<div style="--color-bg: #FFCED3; --color-icon: #FF5364;" class="process--item showElement">
						<div class="icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="140" height="140" viewBox="0 0 140 140" fill="#fff"><g opacity="1"><path d="M21.933 90.7834V116.409C21.933 117.315 22.6674 118.049 23.5736 118.049H49.6757L67.8595 136.768C68.1814 137.099 68.6087 137.266 69.0364 137.266C69.4482 137.266 69.8603 137.112 70.1791 136.802L90.1064 117.458L117.871 116.611C118.306 116.598 118.718 116.412 119.016 116.095C119.314 115.779 119.474 115.356 119.46 114.921L118.651 88.4116L136.82 69.0839C137.118 68.7667 137.278 68.3443 137.264 67.9092C137.251 67.4742 137.065 67.0624 136.748 66.7644L118.066 49.2162V23.591C118.066 22.6852 117.332 21.9504 116.426 21.9504H90.3238L72.1402 3.23171C71.5088 2.58203 70.4708 2.56671 69.8206 3.19753L49.8933 22.5413L22.129 23.3884C21.694 23.4016 21.2822 23.5872 20.9841 23.9041C20.6861 24.221 20.5258 24.6435 20.5392 25.0783L21.3486 51.588L3.17952 70.916C2.88147 71.2332 2.72151 71.6556 2.73518 72.0907C2.74858 72.5257 2.93452 72.9375 3.25171 73.2355L21.933 90.7837V90.7834ZM25.2142 114.768V93.8656L37.0844 105.016C37.401 105.313 37.8046 105.46 38.2074 105.46C38.6444 105.46 39.0802 105.287 39.4032 104.943L68.3594 74.1403V114.768H25.2142ZM69.0706 133.305L54.2503 118.049H70C70.9062 118.049 71.6406 117.315 71.6406 116.409V74.0433L100.023 103.26L69.0706 133.305V133.305ZM93.5982 114.069L103.486 104.471C103.798 104.168 103.977 103.753 103.983 103.318C103.99 102.883 103.823 102.463 103.52 102.151L73.7699 71.526L114.815 70.2737L116.131 113.381L93.5979 114.069L93.5982 114.069ZM133.305 68.0323L118.51 83.7716L118.045 68.5338C118.017 67.6282 117.26 66.9134 116.355 66.944L73.9066 68.239L101.864 38.498L133.306 68.032L133.305 68.0323ZM114.785 25.2314V46.1341L102.915 34.9841C102.255 34.3634 101.217 34.3959 100.597 35.0563L71.6406 65.8593V25.2317H114.786L114.785 25.2314ZM70.9294 6.69452L85.7494 21.9504H70C69.0938 21.9504 68.3594 22.6852 68.3594 23.591V65.9566L39.9774 36.7401L70.9294 6.69452ZM46.4018 25.9309L36.5143 35.5288C36.202 35.8318 36.0229 36.2466 36.0166 36.6819C36.0103 37.1169 36.1769 37.5369 36.4804 37.8492L66.2301 68.4739L25.1852 69.7262L23.8692 26.6188L46.4021 25.9311L46.4018 25.9309ZM21.4903 56.2283L21.9554 71.4661C21.9825 72.3548 22.7114 73.0567 23.5944 73.0567C23.6113 73.0567 23.6283 73.0567 23.6452 73.0559L66.0934 71.7609L38.1355 101.502L6.69456 71.9673L21.4903 56.2283Z"></path></g></svg>
						</div>
						<h3>Marketing Optimization</h3>
						<p>HomeNest partners with you to deploy digital marketing, branding, advertising, and multi-channel communications, driving revenue growth and elevating your brand position.</p>
					</div>
					<div style="--color-bg: #D1E9FF; --color-icon: #3092EA;" class="process--item showElement top">
						<div class="icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="92" height="140" viewBox="0 0 92 84" fill="#fff"><path d="M90.7263 43.2082C89.9876 43.108 89.306 43.6274 89.2064 44.3673C88.4494 49.9902 85.9227 55.0887 81.8997 59.1116C71.8653 69.1463 55.538 69.1463 45.5036 59.1116L38.1544 51.7627L74.463 15.4539C74.5108 15.4058 74.5901 15.4054 74.6382 15.4539L81.8997 22.7156C86.075 26.8908 88.7045 32.419 89.3037 38.2815C89.3796 39.0241 90.044 39.5654 90.7858 39.4886C91.5283 39.4127 92.0688 38.7491 91.9929 38.0064C91.3308 31.5271 88.4251 25.4176 83.8114 20.8038L76.55 13.5421C75.4474 12.4399 73.6538 12.4403 72.5514 13.5421L55.7658 30.3278L50.7576 25.3196L70.9691 5.10815C71.4969 4.5801 71.4969 3.72441 70.9691 3.19655C70.441 2.66886 69.5853 2.66886 69.0575 3.19655L48.846 23.4078L48.4167 22.9785C37.3283 11.8904 19.2862 11.8902 8.19733 22.9787C3.56006 27.6161 0.651112 33.7581 0.00664114 40.2729C-0.0667089 41.0158 0.475937 41.6775 1.21881 41.7511C1.96294 41.8223 2.62363 41.2818 2.69698 40.5389C3.28 34.6444 5.91249 29.0868 10.1093 24.8901C20.1436 14.8554 36.4708 14.8554 46.5051 24.8901L53.8544 32.2392L17.5458 68.548C17.4975 68.5968 17.4189 68.5966 17.3706 68.548L10.1089 61.2863C5.99142 57.1688 3.44886 51.944 2.75573 46.1768C2.66652 45.4355 1.99196 44.9051 1.25251 44.996C0.51126 45.085 -0.0173283 45.7581 0.071701 46.4992C0.837641 52.8736 3.64747 58.6479 8.19715 63.1979L15.4588 70.4596C16.0101 71.0107 16.734 71.2863 17.4582 71.2863C18.1821 71.2863 18.9061 71.0107 19.4574 70.4596L36.2428 53.674L41.251 58.6823L21.0397 78.8936C20.5118 79.4216 20.5118 80.2773 21.0397 80.8052C21.3037 81.069 21.6496 81.2009 21.9956 81.2009C22.3414 81.2009 22.6875 81.069 22.9515 80.8052L43.1629 60.5939L43.592 61.023C49.1365 66.5672 56.4191 69.3393 63.7018 69.3393C70.9844 69.3393 78.2671 66.5672 83.8113 61.023C88.2568 56.5777 91.0488 50.9429 91.8855 44.728C91.985 43.9882 91.466 43.3078 90.7263 43.2082Z"></path><path d="M29.8182 44.5993C33.6421 40.7752 33.6421 34.5533 29.8182 30.7291C25.9939 26.9054 19.772 26.9054 15.948 30.7291C12.1241 34.5533 12.1241 40.7752 15.948 44.5993C17.86 46.5111 20.3716 47.4672 22.8831 47.4672C25.3947 47.4672 27.9062 46.5113 29.8182 44.5993ZM17.8596 42.6877C16.5179 41.346 15.7788 39.562 15.7788 37.6642C15.7788 35.7667 16.5179 33.9827 17.8596 32.6409C19.2014 31.2992 20.9854 30.5601 22.8829 30.5601C24.7807 30.5601 26.5647 31.2992 27.9064 32.6409C30.6764 35.4107 30.6764 39.9179 27.9064 42.6877C25.1364 45.4581 20.6295 45.4577 17.8596 42.6877Z"></path><path d="M46.0048 13.4141C47.6286 13.4141 49.2523 12.796 50.4885 11.56C52.9608 9.08757 52.9608 5.06485 50.4885 2.5924C48.016 0.120303 43.9935 0.120123 41.521 2.59258C39.0489 5.06485 39.0489 9.08757 41.5212 11.56C42.7575 12.796 44.3812 13.4141 46.0048 13.4141ZM43.4326 4.50418C44.142 3.79483 45.0734 3.44052 46.0048 3.44052C46.9361 3.44052 47.8679 3.79519 48.5767 4.50418C49.995 5.92234 49.995 8.23025 48.5767 9.64841C47.1587 11.0666 44.851 11.0664 43.4326 9.64859C42.0147 8.23007 42.0147 5.92234 43.4326 4.50418Z"></path><path d="M41.521 72.4401C39.0489 74.9124 39.0489 78.9351 41.5212 81.4075C42.7574 82.6435 44.381 83.2617 46.0048 83.2617C47.6286 83.2617 49.2523 82.6435 50.4885 81.4075C52.9608 78.9351 52.9608 74.9124 50.4885 72.4399C48.0162 69.968 43.9935 69.9678 41.521 72.4401ZM48.5769 79.4959C47.1589 80.9143 44.8512 80.9139 43.4328 79.4961C42.0147 78.0778 42.0147 75.7699 43.4326 74.3517C44.142 73.6424 45.0734 73.288 46.0048 73.288C46.9361 73.288 47.8679 73.6427 48.5767 74.3517C49.9952 75.7699 49.9952 78.0778 48.5769 79.4959Z"></path><path d="M62.1912 39.403C58.3673 43.2271 58.3673 49.449 62.1912 53.2731C64.1033 55.1853 66.6144 56.141 69.1263 56.141C71.6375 56.141 74.1496 55.1848 76.0614 53.2731C79.8853 49.449 79.8853 43.2271 76.0614 39.403H76.0612C72.2373 35.579 66.0153 35.5794 62.1912 39.403ZM76.2306 46.3382C76.2306 48.2358 75.4915 50.0198 74.1499 51.3615C71.3796 54.1317 66.8724 54.1315 64.1028 51.3615C62.761 50.0198 62.022 48.2358 62.022 46.3382C62.022 44.4405 62.761 42.6565 64.1028 41.3148C65.4878 39.9296 67.3069 39.2373 69.1263 39.2373C70.9456 39.2373 72.7648 39.9298 74.1499 41.3148C75.4919 42.6565 76.2306 44.4403 76.2306 46.3382Z"></path></svg>
						</div>
						<h3>Flexible Solutions for Every Scale</h3>
						<p>HomeNest’s services are flexible and tailored to business needs and budgets—from startups to large corporations—ensuring investment efficiency and sustainable scaling.</p>
					</div>
				</div>
			</div>
		</section>



		<section class="homenest__review">
			<div class="container-fullwidth">
				<div class="title">
					<h2 class="scrollTextEffect showElement"><span class="text-gradient">What Our Customers <br>Are Saying</span></h2>
				</div>
				<div class="author">
					<div class="image showElement">
						<img src="/wp-content/uploads/2025/05/img1-ttm-h3-274x274-1.webp" alt="Homenest" title="Homenest">
					</div>
					<div class="info showElement top">
						<div class="line"></div>
						<div class="info-text">
							<h4 class="name">Nguuyen Ngoc Tien</h4>
							<p class="job">Co-Founder</p>
						</div>
					</div>
					<div class="bio showElement">
						<p class="content">Your satisfaction is our motivation. Let's listen to the real stories shared by businesses that have journeyed with HomeNest.</p>
						<a class="button _txt __homepage" href="#">
							Discover Now!
						</a>
					</div>
				</div>
				<div class="review-wrapper showElement">
					<div class="swiper swiperReviews ">
						<div class="swiper-wrapper">
							<div class="swiper-slide review-item">
								<div class="stars-rating">
									<i class="fa-solid fa-star"></i>
									<i class="fa-solid fa-star"></i>
									<i class="fa-solid fa-star"></i>
									<i class="fa-solid fa-star"></i>
									<i class="fa-solid fa-star"></i>
								</div>
								<h3 class="title-review">Tran Anh Tung </h3>
								<p class="content-review">“I was genuinely impressed by HomeNest! The software design service is incredibly streamlined, effective, and perfectly met my requirements”</p>
							</div>
							<div class="swiper-slide review-item">
								<div class="stars-rating">
									<i class="fa-solid fa-star"></i>
									<i class="fa-solid fa-star"></i>
									<i class="fa-solid fa-star"></i>
									<i class="fa-solid fa-star"></i>
									<i class="fa-regular fa-star"></i>
								</div>
								<h3 class="title-review">Nguyen Thuy Hang </h3>
								<p class="content-review">“So happy with HomeNest's App design service! The App runs smoothly, is easy to use, and is just what I needed. The team is quick and very supportive."</p>
							</div>
							<div class="swiper-slide review-item">
								<div class="stars-rating">
									<i class="fa-solid fa-star"></i>
									<i class="fa-solid fa-star"></i>
									<i class="fa-solid fa-star"></i>
									<i class="fa-solid fa-star"></i>
									<i class="fa-regular fa-star"></i>
								</div>
								<h3 class="title-review">Phan Cong Dang </h3>
								<p class="content-review">“HomeNest truly impressed me with their website design service. The interface is beautiful, user-friendly, and the page loading speed is extremely fast. The team is dedicated and always ready to support whenever needed. I am very satisfied with the final product.”</p>
							</div>
							<div class="swiper-slide review-item">
								<div class="stars-rating">
									<i class="fa-solid fa-star"></i>
									<i class="fa-solid fa-star"></i>
									<i class="fa-solid fa-star"></i>
									<i class="fa-solid fa-star"></i>
									<i class="fa-regular fa-star"></i>
								</div>
								<h3 class="title-review">Tran Thanh Dat </h3>
								<p class="content-review">“Really satisfied with HomeNest's App design service! The App runs smoothly, featuring a friendly and easy-to-use interface. The team is professional, always listening to and meeting all my requirements.”</p>
							</div>
						</div>
						<div class="swiper-buttons">
							<div class="swiper-button-prev"><span style="order: 1;">Previous</span></div>
							<div class="swiper-pagination"></div>
							<div class="swiper-button-next"><span>Next</span></div>
						</div>
					</div>
				</div>
			</div>
		</section>


		<section class="homenest__blog">
			<div class="container--boxed">
				<h2 class="title scrollTextEffect showElement">
					<span class="text-gradient">HomeNest Insights <br>Industry News & Professional Perspectives</span>
				</h2>
				<div class=" blog-container showElement">
					<div class="swiper swiperBlogs">
						<div class="swiper-wrapper">
							<?php
							// Tạo query để lấy tất cả bài viết có post_type = 'post'
							$args = array(
								'post_type'      => 'post',
								'post_status'    => 'publish',
								'posts_per_page' => 6, // Lấy tất cả bài viết
								'orderby'        => 'date',
								'order'          => 'DESC'
							);

							$query = new WP_Query($args);

							// Kiểm tra nếu có bài viết
							if ($query->have_posts()) {
								while ($query->have_posts()) {
									$query->the_post();
									// Lấy thông tin tác giả
									$author_id = get_the_author_meta('ID');
									$author_name = get_the_author();
									$author_avatar = get_avatar_url($author_id, array('size' => 50)); // Ảnh đại diện tác giả
									// Đường dẫn ảnh mặc định khi không có ảnh đại diện
									$default_image = get_template_directory_uri() . '/images/default-thumbnail.jpg';
							?>
							<div class="swiper-slide post-item">
								<!-- Hình ảnh nổi bật -->
								<div class="post-image">
									<a href="<?php the_permalink(); ?>">
										<?php if (has_post_thumbnail()) : ?>
										<?php the_post_thumbnail('large'); ?>
										<?php else : ?>
										<img src="<?php echo esc_url($default_image); ?>" alt="Default Thumbnail" style="max-width: 100%; height: auto;">
										<?php endif; ?>
									</a>
								</div>


								<div class="post-info">
									<h3 class="post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
									<div class="line"></div>
									<div class="author">
										<img src="<?php echo esc_url($author_avatar); ?>" alt="<?php echo esc_attr($author_name); ?>" style="width: 40px; height: 40px; border-radius: 50%;">
										<span>by</span> <span><?php echo esc_html($author_name); ?></span>
									</div>
									<p class="date"><?php echo get_the_date('F j, Y'); ?></p>
								</div>

							</div>
							<?php
								}
								// Reset post data
								wp_reset_postdata();
							} else {
								echo '<p>Không tìm thấy bài viết nào.</p>';
							}
							?>
						</div>
					</div>
				</div>
			</div>
		</section>
		</section>



		





		<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
		






		<?php
		if ( have_posts() ) :
		while ( have_posts() ) : the_post();
		the_content();
		endwhile;
		endif;
		?>
		</main>

	
	
	<?php get_footer(); ?>
