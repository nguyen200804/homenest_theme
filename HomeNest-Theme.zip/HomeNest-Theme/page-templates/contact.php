<?php
/*
Template Name: Contact
*/
get_header();
// Xử lý gửi form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$name    = sanitize_text_field($_POST['name']);
	$phone   = sanitize_text_field($_POST['phone']);
	$email   = sanitize_email($_POST['email']);
	$subject = sanitize_text_field($_POST['subject']);
	$message = sanitize_textarea_field($_POST['message']);

	$to = get_option('admin_email'); // có thể thay bằng email cố định
	$headers = ['Content-Type: text/html; charset=UTF-8'];
	$body = "
        <strong>Name:</strong> $name<br>
        <strong>Phone:</strong> $phone<br>
        <strong>Email:</strong> $email<br>
        <strong>Subject:</strong> $subject<br>
        <strong>Message:</strong> $message
    ";

	$sent = wp_mail($to, "New contact from $name: $subject", $body, $headers);

	if ($sent) {
		echo '<div style="color: green; font-weight: bold;">✅ Cảm ơn bạn! Tin nhắn đã được gửi.</div>';
	} else {
		echo '<div style="color: red; font-weight: bold;">❌ Lỗi khi gửi tin nhắn. Vui lòng thử lại.</div>';
	}
}
?>


<div class="container">
	<h3 class="title-contact">Liên hệ HomeNest</h3>
	<div class="homnet-contact-container">
		<div class="homnet-contact-left">
			<h1>Khám phá tương lai <span class="homnet-highlight">cùng dịch vụ HomeNest</span></h1>
			<img src="https://prisma.axiomthemes.com/wp-content/uploads/2023/09/img-65-copyright.jpg" alt="Homenest" title="Homenest">
		</div>

		<div class="homnet-contact-right">  
			<form method="post" action="">
				<div class="homnet-form-group">
					<svg width="20" viewBox="0 0 24 24" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color"><path d="M21 20a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2 6 6 0 0 1 6-6h6a6 6 0 0 1 6 6m-9-8a5 5 0 1 0-5-5 5 5 0 0 0 5 5" style="fill:#000"/></svg>
					<input type="text" name="name" placeholder="Tên" required>
				</div>  
				<div class="homnet-form-group">
					<svg xmlns="http://www.w3.org/2000/svg" width="20" viewBox="0 0 1200 1200" xml:space="preserve"><path d="m1183.326 997.842-169.187 167.83c-24.974 25.612-58.077 34.289-90.316 34.328-142.571-4.271-277.333-74.304-387.981-146.215C354.22 921.655 187.574 757.82 82.984 559.832 42.87 476.809-4.198 370.878.299 278.209c.401-34.86 9.795-69.073 34.346-91.543L203.831 17.565c35.132-29.883 69.107-19.551 91.589 15.257l136.111 258.102c14.326 30.577 6.108 63.339-15.266 85.188l-62.332 62.3c-3.848 5.271-6.298 11.271-6.36 17.801 23.902 92.522 96.313 177.799 160.281 236.486 63.967 58.688 132.725 138.198 221.977 157.021 11.032 3.077 24.545 4.158 32.438-3.179l72.51-73.743c24.996-18.945 61.086-28.205 87.771-12.714h1.272l245.51 144.943c36.041 22.592 39.799 66.252 13.994 92.815"/></svg>
					<input type="text" name="phone" placeholder="Số điện thoại" required>
				</div>
				<div class="homnet-form-group">
					<svg xmlns="http://www.w3.org/2000/svg" width="20" viewBox="0 0 52 52" xml:space="preserve"><path d="M24.9 30.1c.6.6 1.5.6 2.1 0l22.6-21c.4-.8.3-2.1-1.3-2.1l-44.7.1c-1.2 0-2.2 1.1-1.3 2.1z"/><path d="M50 17.3c0-1-1.2-1.6-2-.9L30.3 32.7c-1.2 1.1-2.7 1.7-4.3 1.7s-3.1-.6-4.3-1.6L4.1 16.4c-.8-.7-2-.2-2 .9C2 17 2 40 2 40c0 2.2 1.8 4 4 4h40c2.2 0 4-1.8 4-4z"/></svg>
					<input type="email" name="email" placeholder="Email" required>
				</div>
				<div class="homnet-form-group">
					<svg xmlns="http://www.w3.org/2000/svg" width="20" viewBox="0 0 52 52" xml:space="preserve"><path d="M26 2C12.7 2 2 12.7 2 26s10.7 24 24 24 24-10.7 24-24S39.3 2 26 2m0 12.1c1.7 0 3 1.3 3 3s-1.3 3-3 3-3-1.3-3-3 1.3-3 3-3m5 21c0 .5-.4.9-1 .9h-8c-.5 0-1-.3-1-.9v-2c0-.5.4-1.1 1-1.1.5 0 1-.3 1-.9v-4c0-.5-.4-1.1-1-1.1-.5 0-1-.3-1-.9v-2c0-.5.4-1.1 1-1.1h6c.5 0 1 .5 1 1.1v8c0 .5.4.9 1 .9.5 0 1 .5 1 1.1z"/></svg>
					<input type="text" name="subject" placeholder="Vấn đề" required>
				</div>
				<div class="homnet-form-group">
					<svg width="20" viewBox="0 0 36 36" xmlns="http://www.w3.org/2000/svg"><path d="M28 30H6V8h13.22l2-2H6a2 2 0 0 0-2 2v22a2 2 0 0 0 2 2h22a2 2 0 0 0 2-2V15l-2 2Z" class="clr-i-outline clr-i-outline-path-1"/><path d="m33.53 5.84-3.37-3.37a1.61 1.61 0 0 0-2.28 0L14.17 16.26l-1.11 4.81A1.61 1.61 0 0 0 14.63 23a1.7 1.7 0 0 0 .37 0l4.85-1.07L33.53 8.12a1.61 1.61 0 0 0 0-2.28M18.81 20.08l-3.66.81.85-3.63L26.32 6.87l2.82 2.82ZM30.27 8.56l-2.82-2.82L29 4.16 31.84 7Z" class="clr-i-outline clr-i-outline-path-2"/><path fill="none" d="M0 0h36v36H0z"/></svg>
					<textarea name="message" rows="" placeholder="Chúng tôi có thể giúp gì cho bạn? Hãy liên hệ với chúng tôi!" required></textarea>
				</div>
				<button class="homnet-submit-btn" type="submit">Gửi thông tin <svg fill="#fff" width="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M23.615.161a.84.84 0 0 1 .36.862l.001-.005-3.426 20.56a.85.85 0 0 1-.424.6l-.004.002a.8.8 0 0 1-.406.107h-.01a.9.9 0 0 1-.326-.069l.006.002-7.054-2.88-3.989 4.377a.79.79 0 0 1-.604.281h-.026.001-.026a.8.8 0 0 1-.287-.056l.005.002a.8.8 0 0 1-.398-.311l-.002-.003a.86.86 0 0 1-.147-.482v-6.055L.539 14.51a.79.79 0 0 1-.535-.736.78.78 0 0 1 .422-.788l.004-.002L22.705.134a.77.77 0 0 1 .912.027L23.615.16zm-4.578 20.065 2.96-17.709-19.196 11.07 4.498 1.834L18.85 6.868l-6.4 10.668z"/></svg></button>
			</form>
		</div>
	</div>
</div> 
<div class="homnest-contact-info_map">
	<div class="homnet-contact1-info">
		<h2 class="homnet-contact"><a href="tel:0898994298">Số điện thoại: 0898-994-298</a></h2>
		<h2><a href="https://maps.app.goo.gl/SbbuzjzYXkf8Y1mU9">Địa chỉ: SAV4 The Sun Avenue, 28 Mai<br>Chí Thọ, Bình Trưng, Hồ Chí Minh</a></h2>
		<h2 class="homnet-contact"><a href="mailto:info@homenest.media">Email: info@homenest.media</a></h2>
	</div>
<!-- 	<iframe 
			src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3919.503027371601!2d106.74387371462202!3d10.784378192318144!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x317527898c77a569%3A0x13e175a79758e845!2sHome%20Nest%20%7C%20D%E1%BB%8Bch%20v%E1%BB%A5%20Thi%E1%BA%BFt%20k%E1%BA%BF%20website%20-%20SEO%20-%20Digital%20Marketing!5e0!3m2!1sen!2s!4v1717236352029!5m2!1sen!2s"
			allowfullscreen=""
			loading="lazy"
			referrerpolicy="no-referrer-when-downgrade">
	</iframe> -->
</div>


<?php get_footer(); ?>
