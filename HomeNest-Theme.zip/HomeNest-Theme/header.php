<?php
// Lấy mã ngôn ngữ hiện tại (ví dụ: 'vi', 'en')
if (function_exists('pll_current_language')) {
    $lang_code = pll_current_language();
} else {
    // Dự phòng nếu Polylang chưa được kích hoạt
    $lang_code = '';
}

// Giả sử Tiếng Việt ('vi') là ngôn ngữ mặc định và sử dụng tệp main.php
// Nếu ngôn ngữ là 'en', $template_name sẽ là 'main-en'.
// Nếu ngôn ngữ là 'vi' hoặc ngôn ngữ mặc định, $template_name sẽ là 'main'.
$template_name = ($lang_code && $lang_code !== 'vi') ? 'main-' . $lang_code : 'main';

// Gọi template
// WordPress sẽ tìm: 
// 1. template-parts/header/main-en.php (nếu $lang_code là 'en')
// 2. template-parts/header/main.php (nếu $lang_code là 'vi' hoặc ngôn ngữ mặc định)
get_template_part('template-parts/header/' . $template_name);
?>